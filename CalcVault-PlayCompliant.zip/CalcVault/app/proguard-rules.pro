# Keep custom EncryptedDataSource and Media3 internals cleanly intact
-keep class com.calcvault.app.vault.EncryptedDataSource { *; }
-dontwarn androidx.media3.**
