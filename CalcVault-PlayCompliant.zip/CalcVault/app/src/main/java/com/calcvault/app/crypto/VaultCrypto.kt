package com.calcvault.app.crypto

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.InputStream
import java.io.OutputStream
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.security.KeyStore
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/**
 * Hardware-backed AndroidKeyStore AES-256-GCM encryption and PBKDF2 PIN verification.
 *
 * Encrypted file format (v1):
 * - Bytes 0..3:   Magic "CVLT"
 * - Byte  4:      Version (1)
 * - Bytes 5..8:   Plaintext chunk size (int, big-endian, default 65536)
 * - Bytes 9..16:  Total plaintext length (long, big-endian)
 * - Repeated chunks: [12-byte GCM IV][ciphertext + 16-byte GCM auth tag]
 *
 * Fixed chunk framing enables O(1) random-access seeking for encrypted video playback.
 */
object VaultCrypto {

    private const val KEYSTORE_PROVIDER = "AndroidKeyStore"
    private const val MASTER_KEY_ALIAS = "calcvault_master_aes256_v1"
    private const val AES_GCM_TRANSFORMATION = "AES/GCM/NoPadding"
    private const val GCM_IV_BYTES = 12
    private const val GCM_TAG_BITS = 128
    private const val GCM_TAG_BYTES = 16

    const val CHUNK_SIZE = 65_536
    const val HEADER_SIZE = 17
    private val MAGIC = byteArrayOf('C'.code.toByte(), 'V'.code.toByte(), 'L'.code.toByte(), 'T'.code.toByte())
    private const val VERSION: Byte = 1

    private const val PREF_AUTH = "calcvault_auth"
    private const val KEY_MAIN_HASH = "main_pin_hash"
    private const val KEY_MAIN_SALT = "main_pin_salt"
    private const val KEY_DECOY_HASH = "decoy_pin_hash"
    private const val KEY_DECOY_SALT = "decoy_pin_salt"
    private const val KEY_BIOMETRIC_ENABLED = "biometric_enabled"
    private const val PBKDF2_ITERATIONS = 120_000

    enum class PinMatch { NONE, MAIN, DECOY }

    data class EncryptedHeader(
        val chunkSize: Int,
        val plainLength: Long
    )

    private val secureRandom = SecureRandom()

    @Synchronized
    fun getOrCreateMasterKey(): SecretKey {
        val ks = KeyStore.getInstance(KEYSTORE_PROVIDER).apply { load(null) }
        val existing = ks.getKey(MASTER_KEY_ALIAS, null) as? SecretKey
        if (existing != null) return existing

        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, KEYSTORE_PROVIDER)
        val spec = KeyGenParameterSpec.Builder(
            MASTER_KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    // ---- PIN & Biometric Auth ----

    private fun authPrefs(ctx: Context) = ctx.getSharedPreferences(PREF_AUTH, Context.MODE_PRIVATE)

    fun hasMainPin(ctx: Context): Boolean = !authPrefs(ctx).getString(KEY_MAIN_HASH, null).isNullOrEmpty()

    fun hasDecoyPin(ctx: Context): Boolean = !authPrefs(ctx).getString(KEY_DECOY_HASH, null).isNullOrEmpty()

    fun isBiometricEnabled(ctx: Context): Boolean = authPrefs(ctx).getBoolean(KEY_BIOMETRIC_ENABLED, false)

    fun setBiometricEnabled(ctx: Context, enabled: Boolean) {
        authPrefs(ctx).edit().putBoolean(KEY_BIOMETRIC_ENABLED, enabled).apply()
    }

    fun setMainPin(ctx: Context, pin: String) {
        val salt = ByteArray(16).also { secureRandom.nextBytes(it) }
        val hash = pbkdf2(pin, salt)
        authPrefs(ctx).edit()
            .putString(KEY_MAIN_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_MAIN_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }

    fun setDecoyPin(ctx: Context, pin: String?) {
        val editor = authPrefs(ctx).edit()
        if (pin.isNullOrEmpty()) {
            editor.remove(KEY_DECOY_SALT).remove(KEY_DECOY_HASH).apply()
            return
        }
        val salt = ByteArray(16).also { secureRandom.nextBytes(it) }
        val hash = pbkdf2(pin, salt)
        editor
            .putString(KEY_DECOY_SALT, Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString(KEY_DECOY_HASH, Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }

    fun verifyPin(ctx: Context, candidate: String): PinMatch {
        if (candidate.isEmpty()) return PinMatch.NONE
        val prefs = authPrefs(ctx)
        if (matches(candidate, prefs.getString(KEY_MAIN_SALT, null), prefs.getString(KEY_MAIN_HASH, null))) {
            return PinMatch.MAIN
        }
        if (matches(candidate, prefs.getString(KEY_DECOY_SALT, null), prefs.getString(KEY_DECOY_HASH, null))) {
            return PinMatch.DECOY
        }
        return PinMatch.NONE
    }

    private fun matches(pin: String, saltB64: String?, hashB64: String?): Boolean {
        if (saltB64.isNullOrEmpty() || hashB64.isNullOrEmpty()) return false
        val salt = Base64.decode(saltB64, Base64.NO_WRAP)
        val expected = Base64.decode(hashB64, Base64.NO_WRAP)
        val actual = pbkdf2(pin, salt)
        return MessageDigest.isEqual(expected, actual)
    }

    private fun pbkdf2(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, PBKDF2_ITERATIONS, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally {
            spec.clearPassword()
        }
    }

    // ---- Small ByteArray Encryption (JSON metadata, notes, thumbnails) ----

    fun encryptBytes(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getOrCreateMasterKey())
        val iv = cipher.iv
        val ciphertext = cipher.doFinal(plain)
        return ByteBuffer.allocate(GCM_IV_BYTES + ciphertext.size)
            .put(iv)
            .put(ciphertext)
            .array()
    }

    fun decryptBytes(blob: ByteArray): ByteArray {
        require(blob.size > GCM_IV_BYTES + GCM_TAG_BYTES) { "Invalid encrypted blob" }
        val iv = blob.copyOfRange(0, GCM_IV_BYTES)
        val ciphertext = blob.copyOfRange(GCM_IV_BYTES, blob.size)
        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
        return cipher.doFinal(ciphertext)
    }

    // ---- Streaming Chunked File Encryption (Photos, Videos, Documents) ----

    fun encryptStreamToFile(input: InputStream, destFile: File): Long {
        destFile.parentFile?.mkdirs()
        val tmpFile = File(destFile.parentFile, "${destFile.name}.tmp")
        var totalPlain = 0L
        try {
            val key = getOrCreateMasterKey()
            BufferedInputStream(input, CHUNK_SIZE).use { bin ->
                RandomAccessFile(tmpFile, "rw").use { raf ->
                    // Placeholder header
                    raf.write(MAGIC)
                    raf.writeByte(VERSION.toInt())
                    raf.writeInt(CHUNK_SIZE)
                    raf.writeLong(0L)

                    val buffer = ByteArray(CHUNK_SIZE)
                    while (true) {
                        val read = readFullChunk(bin, buffer)
                        if (read <= 0) break
                        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
                        cipher.init(Cipher.ENCRYPT_MODE, key)
                        val iv = cipher.iv
                        val encrypted = cipher.doFinal(buffer, 0, read)
                        raf.write(iv)
                        raf.write(encrypted)
                        totalPlain += read
                    }

                    // Patch total plaintext length in header
                    raf.seek(9L)
                    raf.writeLong(totalPlain)
                }
            }
            if (destFile.exists()) destFile.delete()
            if (!tmpFile.renameTo(destFile)) {
                tmpFile.copyTo(destFile, overwrite = true)
                tmpFile.delete()
            }
            return totalPlain
        } catch (t: Throwable) {
            tmpFile.delete()
            throw t
        }
    }

    fun readHeader(file: File): EncryptedHeader {
        DataInputStream(BufferedInputStream(FileInputStream(file), 64)).use { din ->
            val magic = ByteArray(4)
            din.readFully(magic)
            require(magic.contentEquals(MAGIC)) { "Not a CalcVault encrypted file" }
            val version = din.readByte()
            require(version == VERSION) { "Unsupported vault file version: $version" }
            val chunkSize = din.readInt()
            val plainLength = din.readLong()
            return EncryptedHeader(chunkSize, plainLength)
        }
    }

    fun decryptFileToStream(srcFile: File, output: OutputStream) {
        val header = readHeader(srcFile)
        val key = getOrCreateMasterKey()
        BufferedInputStream(FileInputStream(srcFile), CHUNK_SIZE + 64).use { bin ->
            // Skip 17-byte header
            var skipped = 0L
            while (skipped < HEADER_SIZE) {
                val n = bin.skip(HEADER_SIZE - skipped)
                if (n <= 0) break
                skipped += n
            }
            BufferedOutputStream(output, CHUNK_SIZE).use { bout ->
                var remaining = header.plainLength
                val iv = ByteArray(GCM_IV_BYTES)
                while (remaining > 0) {
                    val plainChunkLen = minOf(remaining, header.chunkSize.toLong()).toInt()
                    val encChunkLen = plainChunkLen + GCM_TAG_BYTES
                    readExact(bin, iv, GCM_IV_BYTES)
                    val encBuf = ByteArray(encChunkLen)
                    readExact(bin, encBuf, encChunkLen)

                    val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
                    cipher.init(Cipher.DECRYPT_MODE, key, GCMParameterSpec(GCM_TAG_BITS, iv))
                    val plain = cipher.doFinal(encBuf)
                    bout.write(plain)
                    remaining -= plain.size
                }
                bout.flush()
            }
        }
    }

    fun decryptFileToBytes(srcFile: File): ByteArray {
        val header = readHeader(srcFile)
        val out = java.io.ByteArrayOutputStream(header.plainLength.coerceAtMost(Int.MAX_VALUE.toLong()).toInt())
        decryptFileToStream(srcFile, out)
        return out.toByteArray()
    }

    fun decryptChunkAt(raf: RandomAccessFile, header: EncryptedHeader, chunkIndex: Long): ByteArray {
        val plainOffset = chunkIndex * header.chunkSize.toLong()
        val remaining = header.plainLength - plainOffset
        if (remaining <= 0) return ByteArray(0)

        val plainChunkLen = minOf(remaining, header.chunkSize.toLong()).toInt()
        val encRecordLen = GCM_IV_BYTES + header.chunkSize + GCM_TAG_BYTES
        val fileOffset = HEADER_SIZE.toLong() + chunkIndex * encRecordLen.toLong()

        raf.seek(fileOffset)
        val iv = ByteArray(GCM_IV_BYTES)
        raf.readFully(iv)
        val encBuf = ByteArray(plainChunkLen + GCM_TAG_BYTES)
        raf.readFully(encBuf)

        val cipher = Cipher.getInstance(AES_GCM_TRANSFORMATION)
        cipher.init(Cipher.DECRYPT_MODE, getOrCreateMasterKey(), GCMParameterSpec(GCM_TAG_BITS, iv))
        return cipher.doFinal(encBuf)
    }

    fun secureDelete(file: File): Boolean {
        if (!file.exists()) return true
        return try {
            val len = file.length()
            if (len > 0 && len <= 16L * 1024L * 1024L) {
                RandomAccessFile(file, "rws").use { raf ->
                    val zeros = ByteArray(8192)
                    var left = len
                    while (left > 0) {
                        val toWrite = minOf(left, zeros.size.toLong()).toInt()
                        raf.write(zeros, 0, toWrite)
                        left -= toWrite
                    }
                }
            }
            file.delete()
        } catch (_: Throwable) {
            file.delete()
        }
    }

    private fun readFullChunk(input: InputStream, buffer: ByteArray): Int {
        var offset = 0
        while (offset < buffer.size) {
            val n = input.read(buffer, offset, buffer.size - offset)
            if (n < 0) break
            offset += n
        }
        return offset
    }

    private fun readExact(input: InputStream, buffer: ByteArray, length: Int) {
        var offset = 0
        while (offset < length) {
            val n = input.read(buffer, offset, length - offset)
            if (n < 0) throw java.io.EOFException("Unexpected EOF while decrypting vault file")
            offset += n
        }
    }
}
