package com.calcvault.app.vault

import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.BaseDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import com.calcvault.app.crypto.VaultCrypto
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile

/**
 * Seekable Media3 DataSource that decrypts chunked AES-256-GCM CalcVault files on-the-fly.
 * Enables ExoPlayer video/audio playback directly from the vault with zero unencrypted temp files.
 */
@UnstableApi
class EncryptedDataSource(private val file: File) : BaseDataSource(/* isNetwork = */ false) {

    class Factory(private val file: File) : DataSource.Factory {
        override fun createDataSource(): DataSource = EncryptedDataSource(file)
    }

    private var raf: RandomAccessFile? = null
    private var header: VaultCrypto.EncryptedHeader? = null
    private var currentUri: Uri? = null
    private var position: Long = 0L
    private var bytesRemaining: Long = 0L
    private var cachedChunkIndex: Long = -1L
    private var cachedChunkData: ByteArray = ByteArray(0)
    private var opened = false

    override fun open(dataSpec: DataSpec): Long {
        currentUri = dataSpec.uri
        transferInitializing(dataSpec)
        try {
            val h = VaultCrypto.readHeader(file)
            header = h
            raf = RandomAccessFile(file, "r")
            position = dataSpec.position.coerceIn(0L, h.plainLength)
            val available = h.plainLength - position
            bytesRemaining = if (dataSpec.length != C.LENGTH_UNSET.toLong()) {
                minOf(dataSpec.length, available)
            } else {
                available
            }
            cachedChunkIndex = -1L
            cachedChunkData = ByteArray(0)
            opened = true
            transferStarted(dataSpec)
            return bytesRemaining
        } catch (e: Throwable) {
            close()
            throw IOException("Failed to open encrypted media", e)
        }
    }

    override fun read(buffer: ByteArray, offset: Int, length: Int): Int {
        if (length == 0) return 0
        if (bytesRemaining <= 0L) return C.RESULT_END_OF_INPUT
        val h = header ?: return C.RESULT_END_OF_INPUT
        val r = raf ?: return C.RESULT_END_OF_INPUT

        val chunkSize = h.chunkSize.toLong()
        val chunkIndex = position / chunkSize
        val offsetInChunk = (position % chunkSize).toInt()

        if (chunkIndex != cachedChunkIndex) {
            cachedChunkData = try {
                VaultCrypto.decryptChunkAt(r, h, chunkIndex)
            } catch (e: Throwable) {
                throw IOException("Failed to decrypt media chunk $chunkIndex", e)
            }
            cachedChunkIndex = chunkIndex
        }

        val availableInChunk = cachedChunkData.size - offsetInChunk
        if (availableInChunk <= 0) return C.RESULT_END_OF_INPUT

        val toCopy = minOf(length.toLong(), bytesRemaining, availableInChunk.toLong()).toInt()
        System.arraycopy(cachedChunkData, offsetInChunk, buffer, offset, toCopy)
        position += toCopy
        bytesRemaining -= toCopy
        bytesTransferred(toCopy)
        return toCopy
    }

    override fun getUri(): Uri? = currentUri

    override fun close() {
        currentUri = null
        cachedChunkIndex = -1L
        cachedChunkData = ByteArray(0)
        try {
            raf?.close()
        } catch (_: Throwable) {
        } finally {
            raf = null
            header = null
            if (opened) {
                opened = false
                transferEnded()
            }
        }
    }
}
