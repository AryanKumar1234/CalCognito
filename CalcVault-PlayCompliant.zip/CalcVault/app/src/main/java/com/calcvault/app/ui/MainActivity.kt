package com.calcvault.app.ui

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.calcvault.app.calc.MathEvaluator
import com.calcvault.app.crypto.VaultCrypto
import com.calcvault.app.vault.VaultProfile
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlin.math.roundToInt

/**
 * Fully functional scientific calculator that also serves as the discreet entry point
 * to the hardware-encrypted Private Vault.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var expressionView: TextView
    private lateinit var previewView: TextView
    private lateinit var exprScroll: HorizontalScrollView
    private lateinit var sciPanel: LinearLayout
    private lateinit var degRadBtn: TextView
    private lateinit var bioBtn: TextView

    private val expression = StringBuilder()
    private val history = ArrayList<String>()
    private var useDegrees = true
    private var sciVisible = false
    private var justEvaluated = false

    private val isDark: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val root = buildUi()
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        if (!VaultCrypto.hasMainPin(this)) {
            showFirstRunPinSetup()
        }
    }

    override fun onResume() {
        super.onResume()
        updateBiometricButtonVisibility()
    }

    private fun buildUi(): LinearLayout {
        val bg = if (isDark) Color.parseColor("#0F172A") else Color.parseColor("#F8FAFC")
        val displayBg = if (isDark) Color.parseColor("#1E293B") else Color.parseColor("#FFFFFF")
        val textPrimary = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
        val textSecondary = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")
        val numBg = if (isDark) Color.parseColor("#1E293B") else Color.parseColor("#FFFFFF")
        val opBg = if (isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0")
        val accentBg = if (isDark) Color.parseColor("#3B82F6") else Color.parseColor("#2563EB")
        val clearBg = if (isDark) Color.parseColor("#7F1D1D") else Color.parseColor("#FEE2E2")
        val clearFg = if (isDark) Color.parseColor("#FCA5A5") else Color.parseColor("#B91C1C")
        val sciBg = if (isDark) Color.parseColor("#1E293B") else Color.parseColor("#EFF6FF")
        val sciFg = if (isDark) Color.parseColor("#93C5FD") else Color.parseColor("#1D4ED8")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Top toolbar strip
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(6))
        }

        val titleView = TextView(this).apply {
            text = "Calculator"
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        topBar.addView(titleView)

        bioBtn = makeChipButton("Unlock", sciBg, sciFg) { triggerBiometricUnlock() }
        topBar.addView(bioBtn)

        val sciToggle = makeChipButton("SCI", opBg, textPrimary) {
            sciVisible = !sciVisible
            sciPanel.visibility = if (sciVisible) View.VISIBLE else View.GONE
        }
        topBar.addView(sciToggle)

        val historyBtn = makeChipButton("History", opBg, textPrimary) { showHistoryDialog() }
        topBar.addView(historyBtn)

        root.addView(topBar)

        // Display Card
        val displayCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            background = roundedRect(displayBg, dp(24))
            setPadding(dp(20), dp(18), dp(20), dp(18))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.1f
            ).apply {
                setMargins(dp(12), dp(4), dp(12), dp(10))
            }
        }

        exprScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        expressionView = TextView(this).apply {
            text = ""
            hint = "0"
            setHintTextColor(textSecondary)
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 44f)
            gravity = Gravity.END
            maxLines = 1
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
        }
        exprScroll.addView(expressionView)
        displayCard.addView(exprScroll)

        previewView = TextView(this).apply {
            text = ""
            setTextColor(textSecondary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            gravity = Gravity.END
            maxLines = 1
            setPadding(0, dp(8), 0, 0)
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }
        displayCard.addView(previewView)
        root.addView(displayCard)

        // Collapsible Scientific Panel
        sciPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(10), 0, dp(10), dp(6))
        }
        val sciRow1 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        degRadBtn = makeSciKey("DEG", sciBg, sciFg) {
            useDegrees = !useDegrees
            degRadBtn.text = if (useDegrees) "DEG" else "RAD"
            refreshDisplay()
        }
        sciRow1.addView(degRadBtn)
        listOf("sin(", "cos(", "tan(", "ln(", "log(").forEach { token ->
            sciRow1.addView(makeSciKey(token.removeSuffix("("), sciBg, sciFg) { appendToken(token) })
        }
        sciPanel.addView(sciRow1)

        val sciRow2 = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("(", ")", "√(", "^", "π", "!").forEach { token ->
            sciRow2.addView(makeSciKey(token.removeSuffix("("), sciBg, sciFg) { appendToken(token) })
        }
        sciPanel.addView(sciRow2)
        root.addView(sciPanel)

        // Keypad Grid
        val keypad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(10), dp(2), dp(10), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.85f
            )
        }

        val rows = listOf(
            listOf("AC", "⌫", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "00", "=")
        )

        for (rowKeys in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    0,
                    1f
                )
            }
            for (label in rowKeys) {
                val (kBg, kFg) = when (label) {
                    "AC" -> clearBg to clearFg
                    "=" -> accentBg to Color.WHITE
                    "÷", "×", "−", "+", "%", "⌫" -> opBg to textPrimary
                    else -> numBg to textPrimary
                }
                val btn = TextView(this).apply {
                    text = label
                    setTextColor(kFg)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label == "AC") 20f else 24f)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    gravity = Gravity.CENTER
                    background = roundedRect(kBg, dp(22))
                    isClickable = true
                    isFocusable = true
                    layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f).apply {
                        setMargins(dp(5), dp(5), dp(5), dp(5))
                    }
                    setOnClickListener {
                        performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                        onKeyPressed(label)
                    }
                }
                row.addView(btn)
            }
            keypad.addView(row)
        }

        root.addView(keypad)
        updateBiometricButtonVisibility()
        return root
    }

    private fun makeChipButton(label: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            background = roundedRect(bg, dp(14))
            setPadding(dp(12), dp(6), dp(12), dp(6))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginStart = dp(8)
            }
            setOnClickListener { onClick() }
        }
    }

    private fun makeSciKey(label: String, bg: Int, fg: Int, onClick: () -> Unit): TextView {
        return TextView(this).apply {
            text = label
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            background = roundedRect(bg, dp(12))
            setPadding(dp(4), dp(10), dp(4), dp(10))
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                setMargins(dp(4), dp(3), dp(4), dp(3))
            }
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                onClick()
            }
        }
    }

    private fun onKeyPressed(key: String) {
        when (key) {
            "AC" -> {
                expression.clear()
                justEvaluated = false
                refreshDisplay()
            }
            "⌫" -> {
                if (expression.isNotEmpty()) {
                    expression.deleteCharAt(expression.length - 1)
                }
                justEvaluated = false
                refreshDisplay()
            }
            "=" -> handleEquals()
            else -> appendToken(key)
        }
    }

    private fun appendToken(token: String) {
        val isOperator = token in setOf("+", "−", "×", "÷", "^", "%")
        if (justEvaluated && !isOperator) {
            expression.clear()
        }
        justEvaluated = false
        expression.append(token)
        refreshDisplay()
    }

    private fun handleEquals() {
        val raw = expression.toString().trim()
        if (raw.isEmpty()) return

        // Check if entered digits match Primary or Decoy PIN
        if (raw.all { it.isDigit() } && raw.length in 4..8) {
            when (VaultCrypto.verifyPin(this, raw)) {
                VaultCrypto.PinMatch.MAIN -> {
                    expression.clear()
                    refreshDisplay()
                    openVault(VaultProfile.MAIN)
                    return
                }
                VaultCrypto.PinMatch.DECOY -> {
                    expression.clear()
                    refreshDisplay()
                    openVault(VaultProfile.DECOY)
                    return
                }
                VaultCrypto.PinMatch.NONE -> { /* Continue as regular calculation */ }
            }
        }

        val value = MathEvaluator.evaluate(raw, useDegrees)
        if (value == null) {
            previewView.text = "Error"
            return
        }
        val formatted = MathEvaluator.formatResult(value)
        history.add(0, "$raw = $formatted")
        if (history.size > 50) history.removeAt(history.lastIndex)

        expression.clear()
        expression.append(formatted)
        justEvaluated = true
        refreshDisplay()
    }

    private fun refreshDisplay() {
        val exprStr = expression.toString()
        expressionView.text = exprStr
        exprScroll.post { exprScroll.fullScroll(View.FOCUS_RIGHT) }

        if (exprStr.isEmpty() || justEvaluated) {
            previewView.text = ""
            return
        }
        val valPreview = MathEvaluator.evaluate(exprStr, useDegrees)
        previewView.text = if (valPreview != null) MathEvaluator.formatResult(valPreview) else ""
    }

    private fun openVault(profile: VaultProfile) {
        val intent = Intent(this, VaultActivity::class.java).apply {
            putExtra(VaultActivity.EXTRA_PROFILE, profile.name)
        }
        startActivity(intent)
    }

    private fun updateBiometricButtonVisibility() {
        if (!::bioBtn.isInitialized) return
        val canAuth = BiometricManager.from(this)
            .canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS
        bioBtn.visibility = if (VaultCrypto.hasMainPin(this) && VaultCrypto.isBiometricEnabled(this) && canAuth) {
            View.VISIBLE
        } else {
            View.GONE
        }
    }

    private fun triggerBiometricUnlock() {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                openVault(VaultProfile.MAIN)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock Private Vault")
            .setSubtitle("Authenticate to access your encrypted vault")
            .setNegativeButtonText("Use PIN")
            .build()
        prompt.authenticate(info)
    }

    private fun showFirstRunPinSetup() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(12), dp(24), dp(8))
        }
        val pinInput = EditText(this).apply {
            hint = "Enter 4–8 digit PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(8))
        }
        val confirmInput = EditText(this).apply {
            hint = "Confirm PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(8))
        }
        container.addView(pinInput)
        container.addView(confirmInput)

        MaterialAlertDialogBuilder(this)
            .setTitle("Set Up Your Private Vault PIN")
            .setMessage("Choose a 4–8 digit PIN. Whenever you type your PIN into the calculator and press '=', your encrypted vault will open.")
            .setView(container)
            .setCancelable(false)
            .setPositiveButton("Save PIN", null)
            .create()
            .also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val p1 = pinInput.text.toString().trim()
                        val p2 = confirmInput.text.toString().trim()
                        when {
                            p1.length !in 4..8 || !p1.all { it.isDigit() } ->
                                Toast.makeText(this, "PIN must be 4 to 8 digits", Toast.LENGTH_SHORT).show()
                            p1 != p2 ->
                                Toast.makeText(this, "PINs do not match", Toast.LENGTH_SHORT).show()
                            else -> {
                                VaultCrypto.setMainPin(this, p1)
                                Toast.makeText(this, "PIN saved! Type your PIN and press '=' to unlock.", Toast.LENGTH_LONG).show()
                                dialog.dismiss()
                            }
                        }
                    }
                }
                dialog.show()
            }
    }

    private fun showHistoryDialog() {
        if (history.isEmpty()) {
            Toast.makeText(this, "No calculation history yet", Toast.LENGTH_SHORT).show()
            return
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("History")
            .setItems(history.toTypedArray()) { _, which ->
                val result = history[which].substringAfter("= ").trim()
                expression.clear()
                expression.append(result)
                justEvaluated = false
                refreshDisplay()
            }
            .setNegativeButton("Clear") { _, _ -> history.clear() }
            .setPositiveButton("Close", null)
            .show()
    }

    private fun roundedRect(color: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
