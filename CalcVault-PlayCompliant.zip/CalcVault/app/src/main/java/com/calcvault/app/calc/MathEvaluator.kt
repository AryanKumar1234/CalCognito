package com.calcvault.app.calc

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.ln
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt
import kotlin.math.tan

/**
 * Self-contained recursive-descent scientific calculator evaluator.
 * Supports +, -, ×, ÷, %, ^, !, parentheses, sin, cos, tan, log, ln, √, π, e.
 */
object MathEvaluator {

    fun evaluate(rawExpression: String, useDegrees: Boolean = true): Double? {
        val cleaned = rawExpression
            .replace(" ", "")
            .replace("×", "*")
            .replace("÷", "/")
            .replace("−", "-")
            .trim()
        if (cleaned.isEmpty()) return null
        return try {
            val parser = Parser(cleaned, useDegrees)
            val value = parser.parseExpression()
            if (!parser.isAtEnd()) return null
            if (value.isNaN() || value.isInfinite()) null else value
        } catch (_: Throwable) {
            null
        }
    }

    fun formatResult(value: Double): String {
        if (value.isNaN() || value.isInfinite()) return "Error"
        val normalized = if (abs(value) < 1e-12) 0.0 else value
        val rounded = BigDecimal(normalized, MathContext(12, RoundingMode.HALF_UP))
            .stripTrailingZeros()
        val absVal = abs(normalized)
        return if (absVal != 0.0 && (absVal >= 1e12 || absVal < 1e-7)) {
            String.format(java.util.Locale.US, "%.6g", normalized)
        } else {
            rounded.toPlainString()
        }
    }

    private class Parser(private val s: String, private val useDegrees: Boolean) {
        private var pos = 0

        fun isAtEnd(): Boolean = pos >= s.length

        private fun peek(): Char? = if (pos < s.length) s[pos] else null

        private fun consume(expected: Char): Boolean {
            if (peek() == expected) {
                pos++
                return true
            }
            return false
        }

        fun parseExpression(): Double {
            var x = parseTerm()
            while (true) {
                x = when {
                    consume('+') -> x + parseTerm()
                    consume('-') -> x - parseTerm()
                    else -> return x
                }
            }
        }

        private fun parseTerm(): Double {
            var x = parsePower()
            while (true) {
                val next = peek()
                x = when {
                    consume('*') -> x * parsePower()
                    consume('/') -> {
                        val denom = parsePower()
                        if (denom == 0.0) throw ArithmeticException("Division by zero")
                        x / denom
                    }
                    // Implicit multiplication: 2π, 2(3+4), (2)(3), 2sin(30)
                    next == '(' || next == 'π' || next == '√' || (next != null && next.isLetter()) -> {
                        x * parsePower()
                    }
                    else -> return x
                }
            }
        }

        private fun parsePower(): Double {
            val base = parseUnary()
            return if (consume('^')) {
                base.pow(parsePower())
            } else {
                base
            }
        }

        private fun parseUnary(): Double {
            if (consume('+')) return parseUnary()
            if (consume('-')) return -parseUnary()
            return parsePostfix()
        }

        private fun parsePostfix(): Double {
            var x = parsePrimary()
            while (true) {
                x = when {
                    consume('%') -> x / 100.0
                    consume('!') -> factorial(x)
                    else -> return x
                }
            }
        }

        private fun parsePrimary(): Double {
            val ch = peek() ?: throw IllegalArgumentException("Unexpected end")
            if (consume('(')) {
                val x = parseExpression()
                if (!consume(')')) throw IllegalArgumentException("Missing ')'")
                return x
            }
            if (consume('π')) return PI
            if (consume('√')) return sqrt(parseUnary())

            if (ch.isDigit() || ch == '.') {
                val start = pos
                while (peek()?.let { it.isDigit() || it == '.' } == true) pos++
                return s.substring(start, pos).toDouble()
            }

            if (ch.isLetter()) {
                val start = pos
                while (peek()?.isLetter() == true) pos++
                val name = s.substring(start, pos).lowercase()
                if (name == "e") return kotlin.math.E
                if (name == "pi") return PI
                val arg = if (consume('(')) {
                    val v = parseExpression()
                    if (!consume(')')) throw IllegalArgumentException("Missing ')' after $name")
                    v
                } else {
                    parseUnary()
                }
                val rad = if (useDegrees) Math.toRadians(arg) else arg
                return when (name) {
                    "sin" -> sin(rad)
                    "cos" -> cos(rad)
                    "tan" -> tan(rad)
                    "log" -> log10(arg)
                    "ln" -> ln(arg)
                    "sqrt" -> sqrt(arg)
                    "abs" -> abs(arg)
                    else -> throw IllegalArgumentException("Unknown function: $name")
                }
            }

            throw IllegalArgumentException("Unexpected character: $ch")
        }

        private fun factorial(v: Double): Double {
            if (v < 0 || v > 170 || v != kotlin.math.floor(v)) {
                throw IllegalArgumentException("Invalid factorial")
            }
            var acc = 1.0
            for (i in 2..v.toInt()) acc *= i
            return acc
        }
    }
}
