package com.calcvault.app.vault

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import com.calcvault.app.crypto.VaultCrypto
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.util.UUID

enum class VaultProfile(val dirName: String) {
    MAIN("vault_main"),
    DECOY("vault_decoy")
}

enum class VaultMediaType {
    PHOTO, VIDEO, AUDIO, DOCUMENT
}

data class VaultFileItem(
    val id: String,
    val displayName: String,
    val mimeType: String,
    val mediaType: VaultMediaType,
    val sizeBytes: Long,
    val addedAt: Long,
    val hasThumbnail: Boolean
)

data class VaultNote(
    val id: String,
    val title: String,
    val body: String,
    val updatedAt: Long
)

data class PrivateWebApp(
    val id: String,
    val name: String,
    val url: String
)

/**
 * Manages encrypted files, thumbnails, private notes, and isolated web app shortcuts.
 * All data stays strictly inside app-private storage (ctx.filesDir) and is encrypted with VaultCrypto.
 */
class VaultRepository(private val ctx: Context, val profile: VaultProfile) {

    private val rootDir: File = File(ctx.filesDir, profile.dirName).apply { mkdirs() }
    private val filesDir: File = File(rootDir, "files").apply { mkdirs() }
    private val thumbsDir: File = File(rootDir, "thumbs").apply { mkdirs() }
    private val indexFile: File = File(rootDir, "index.enc")
    private val notesFile: File = File(rootDir, "notes.enc")
    private val webAppsFile: File = File(rootDir, "webapps.enc")

    // ---- Files & Media ----

    fun encryptedFileFor(id: String): File = File(filesDir, "$id.cvlt")
    private fun thumbFileFor(id: String): File = File(thumbsDir, "$id.thumb")

    @Synchronized
    fun listFiles(filter: VaultMediaType? = null): List<VaultFileItem> {
        val all = readFileIndex()
        val filtered = if (filter == null) all else all.filter { it.mediaType == filter }
        return filtered.sortedByDescending { it.addedAt }
    }

    fun importFromUri(uri: Uri): VaultFileItem {
        val cr = ctx.contentResolver
        val mime = cr.getType(uri) ?: "application/octet-stream"
        val displayName = queryDisplayName(uri) ?: "file_${System.currentTimeMillis()}"
        val mediaType = classifyMime(mime, displayName)
        val id = UUID.randomUUID().toString()
        val destFile = encryptedFileFor(id)

        val sizeBytes = cr.openInputStream(uri)?.use { input ->
            VaultCrypto.encryptStreamToFile(input, destFile)
        } ?: throw IllegalStateException("Could not open selected file")

        val hasThumb = generateEncryptedThumbnail(uri, mediaType, id)

        val item = VaultFileItem(
            id = id,
            displayName = displayName,
            mimeType = mime,
            mediaType = mediaType,
            sizeBytes = sizeBytes,
            addedAt = System.currentTimeMillis(),
            hasThumbnail = hasThumb
        )
        synchronized(this) {
            val list = readFileIndex().toMutableList()
            list.add(item)
            writeFileIndex(list)
        }
        return item
    }

    fun exportToUri(item: VaultFileItem, destUri: Uri) {
        val src = encryptedFileFor(item.id)
        require(src.exists()) { "Encrypted file missing" }
        ctx.contentResolver.openOutputStream(destUri)?.use { out ->
            VaultCrypto.decryptFileToStream(src, out)
        } ?: throw IllegalStateException("Could not open destination file")
    }

    @Synchronized
    fun renameFile(id: String, newName: String) {
        val clean = newName.trim()
        if (clean.isEmpty()) return
        val updated = readFileIndex().map {
            if (it.id == id) it.copy(displayName = clean) else it
        }
        writeFileIndex(updated)
    }

    @Synchronized
    fun deleteFile(id: String) {
        VaultCrypto.secureDelete(encryptedFileFor(id))
        VaultCrypto.secureDelete(thumbFileFor(id))
        val updated = readFileIndex().filterNot { it.id == id }
        writeFileIndex(updated)
    }

    fun loadThumbnail(id: String): Bitmap? {
        val tf = thumbFileFor(id)
        if (!tf.exists()) return null
        return try {
            val jpeg = VaultCrypto.decryptBytes(tf.readBytes())
            BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)
        } catch (_: Throwable) {
            null
        }
    }

    private fun generateEncryptedThumbnail(uri: Uri, mediaType: VaultMediaType, id: String): Boolean {
        return try {
            val bm: Bitmap? = when (mediaType) {
                VaultMediaType.PHOTO -> {
                    val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                    val maxDim = maxOf(opts.outWidth, opts.outHeight).coerceAtLeast(1)
                    val sample = (maxDim / 256).coerceAtLeast(1)
                    val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
                    ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, decodeOpts) }
                }
                VaultMediaType.VIDEO -> {
                    val mmr = MediaMetadataRetriever()
                    try {
                        mmr.setDataSource(ctx, uri)
                        mmr.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                    } finally {
                        mmr.release()
                    }
                }
                else -> null
            }
            if (bm != null) {
                val scaled = scaleDown(bm, 256)
                val baos = ByteArrayOutputStream()
                scaled.compress(Bitmap.CompressFormat.JPEG, 75, baos)
                if (scaled !== bm) scaled.recycle()
                bm.recycle()
                thumbFileFor(id).writeBytes(VaultCrypto.encryptBytes(baos.toByteArray()))
                true
            } else {
                false
            }
        } catch (_: Throwable) {
            false
        }
    }

    private fun scaleDown(src: Bitmap, maxEdge: Int): Bitmap {
        val w = src.width
        val h = src.height
        if (w <= maxEdge && h <= maxEdge) return src
        val ratio = maxEdge.toFloat() / maxOf(w, h).toFloat()
        return Bitmap.createScaledBitmap(src, (w * ratio).toInt().coerceAtLeast(1), (h * ratio).toInt().coerceAtLeast(1), true)
    }

    private fun queryDisplayName(uri: Uri): String? {
        return try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) c.getString(0) else null
            }
        } catch (_: Throwable) {
            null
        }
    }

    private fun classifyMime(mime: String, name: String): VaultMediaType {
        val lower = mime.lowercase()
        val ext = name.substringAfterLast('.', "").lowercase()
        return when {
            lower.startsWith("image/") || ext in setOf("jpg", "jpeg", "png", "webp", "gif", "heic") -> VaultMediaType.PHOTO
            lower.startsWith("video/") || ext in setOf("mp4", "mkv", "webm", "mov", "avi") -> VaultMediaType.VIDEO
            lower.startsWith("audio/") || ext in setOf("mp3", "m4a", "wav", "ogg", "flac", "aac") -> VaultMediaType.AUDIO
            else -> VaultMediaType.DOCUMENT
        }
    }

    private fun readFileIndex(): List<VaultFileItem> {
        if (!indexFile.exists()) return emptyList()
        return try {
            val json = String(VaultCrypto.decryptBytes(indexFile.readBytes()), Charsets.UTF_8)
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                VaultFileItem(
                    id = o.getString("id"),
                    displayName = o.getString("name"),
                    mimeType = o.optString("mime", "application/octet-stream"),
                    mediaType = VaultMediaType.valueOf(o.optString("type", "DOCUMENT")),
                    sizeBytes = o.optLong("size", 0L),
                    addedAt = o.optLong("addedAt", 0L),
                    hasThumbnail = o.optBoolean("thumb", false)
                )
            }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    private fun writeFileIndex(items: List<VaultFileItem>) {
        val arr = JSONArray()
        for (it in items) {
            arr.put(
                JSONObject()
                    .put("id", it.id)
                    .put("name", it.displayName)
                    .put("mime", it.mimeType)
                    .put("type", it.mediaType.name)
                    .put("size", it.sizeBytes)
                    .put("addedAt", it.addedAt)
                    .put("thumb", it.hasThumbnail)
            )
        }
        indexFile.writeBytes(VaultCrypto.encryptBytes(arr.toString().toByteArray(Charsets.UTF_8)))
    }

    // ---- Encrypted Private Notes ----

    @Synchronized
    fun listNotes(): List<VaultNote> {
        if (!notesFile.exists()) return emptyList()
        return try {
            val json = String(VaultCrypto.decryptBytes(notesFile.readBytes()), Charsets.UTF_8)
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                VaultNote(
                    id = o.getString("id"),
                    title = o.optString("title", ""),
                    body = o.optString("body", ""),
                    updatedAt = o.optLong("updatedAt", 0L)
                )
            }.sortedByDescending { it.updatedAt }
        } catch (_: Throwable) {
            emptyList()
        }
    }

    @Synchronized
    fun saveNote(id: String?, title: String, body: String): VaultNote {
        val list = listNotes().toMutableList()
        val noteId = id ?: UUID.randomUUID().toString()
        val note = VaultNote(noteId, title.trim().ifEmpty { "Untitled Note" }, body, System.currentTimeMillis())
        val idx = list.indexOfFirst { it.id == noteId }
        if (idx >= 0) list[idx] = note else list.add(0, note)
        writeNotes(list)
        return note
    }

    @Synchronized
    fun deleteNote(id: String) {
        writeNotes(listNotes().filterNot { it.id == id })
    }

    private fun writeNotes(notes: List<VaultNote>) {
        val arr = JSONArray()
        for (n in notes) {
            arr.put(
                JSONObject()
                    .put("id", n.id)
                    .put("title", n.title)
                    .put("body", n.body)
                    .put("updatedAt", n.updatedAt)
            )
        }
        notesFile.writeBytes(VaultCrypto.encryptBytes(arr.toString().toByteArray(Charsets.UTF_8)))
    }

    // ---- Isolated Private Web Apps ----

    @Synchronized
    fun listWebApps(): List<PrivateWebApp> {
        if (!webAppsFile.exists()) return defaultWebApps()
        return try {
            val json = String(VaultCrypto.decryptBytes(webAppsFile.readBytes()), Charsets.UTF_8)
            val arr = JSONArray(json)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                PrivateWebApp(
                    id = o.getString("id"),
                    name = o.getString("name"),
                    url = o.getString("url")
                )
            }
        } catch (_: Throwable) {
            defaultWebApps()
        }
    }

    @Synchronized
    fun addWebApp(name: String, rawUrl: String): PrivateWebApp {
        val normalized = normalizeHttpsUrl(rawUrl)
        val item = PrivateWebApp(UUID.randomUUID().toString(), name.trim().ifEmpty { normalized }, normalized)
        val list = listWebApps().toMutableList()
        list.add(item)
        writeWebApps(list)
        return item
    }

    @Synchronized
    fun deleteWebApp(id: String) {
        writeWebApps(listWebApps().filterNot { it.id == id })
    }

    private fun writeWebApps(apps: List<PrivateWebApp>) {
        val arr = JSONArray()
        for (a in apps) {
            arr.put(JSONObject().put("id", a.id).put("name", a.name).put("url", a.url))
        }
        webAppsFile.writeBytes(VaultCrypto.encryptBytes(arr.toString().toByteArray(Charsets.UTF_8)))
    }

    private fun normalizeHttpsUrl(raw: String): String {
        val trimmed = raw.trim()
        return when {
            trimmed.startsWith("https://", ignoreCase = true) -> trimmed
            trimmed.startsWith("http://", ignoreCase = true) -> "https://" + trimmed.removePrefix("http://")
            else -> "https://$trimmed"
        }
    }

    private fun defaultWebApps(): List<PrivateWebApp> = listOf(
        PrivateWebApp("preset_ig", "Instagram Web", "https://www.instagram.com/"),
        PrivateWebApp("preset_x", "X (Twitter)", "https://x.com/"),
        PrivateWebApp("preset_reddit", "Reddit", "https://www.reddit.com/"),
        PrivateWebApp("preset_tg", "Telegram Web", "https://web.telegram.org/"),
        PrivateWebApp("preset_discord", "Discord Web", "https://discord.com/app"),
        PrivateWebApp("preset_gmail", "Gmail Web", "https://mail.google.com/")
    )

    // ---- Full Vault Wipe ----

    @Synchronized
    fun wipeAll() {
        filesDir.listFiles()?.forEach { VaultCrypto.secureDelete(it) }
        thumbsDir.listFiles()?.forEach { VaultCrypto.secureDelete(it) }
        VaultCrypto.secureDelete(indexFile)
        VaultCrypto.secureDelete(notesFile)
        VaultCrypto.secureDelete(webAppsFile)
    }
}
