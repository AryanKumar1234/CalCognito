package com.calcvault.app.ui

import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputFilter
import android.text.InputType
import android.text.format.Formatter
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.calcvault.app.R
import com.calcvault.app.crypto.VaultCrypto
import com.calcvault.app.vault.PrivateWebApp
import com.calcvault.app.vault.VaultFileItem
import com.calcvault.app.vault.VaultMediaType
import com.calcvault.app.vault.VaultNote
import com.calcvault.app.vault.VaultProfile
import com.calcvault.app.vault.VaultRepository
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.DateFormat
import java.util.Date
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * Hardware-encrypted Private Vault Hub.
 * Enforces FLAG_SECURE, auto-locks on background, uses zero storage permissions (SAF only),
 * and provides Play-compliant Private Apps (Isolated Web Apps + Android Native Private Space guide).
 */
class VaultActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROFILE = "extra_vault_profile"
    }

    private enum class Tab { FILES, NOTES, APPS, SETTINGS }

    private lateinit var repo: VaultRepository
    private lateinit var profile: VaultProfile
    private lateinit var contentContainer: FrameLayout
    private lateinit var headerSubtitle: TextView
    private val tabButtons = LinkedHashMap<Tab, TextView>()
    private var activeTab = Tab.FILES
    private var activeFilter: VaultMediaType? = null
    private var pendingExportItem: VaultFileItem? = null
    private var suppressAutoLockOnce = false

    private val ioExecutor = Executors.newSingleThreadExecutor()

    private val isDark: Boolean
        get() = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        suppressAutoLockOnce = false
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        importFiles(uris)
    }

    private val exportLauncher = registerForActivityResult(ActivityResultContracts.CreateDocument("*/*")) { uri ->
        suppressAutoLockOnce = false
        val item = pendingExportItem ?: return@registerForActivityResult
        pendingExportItem = null
        if (uri == null) return@registerForActivityResult
        ioExecutor.execute {
            try {
                repo.exportToUri(item, uri)
                runOnUiThread {
                    Toast.makeText(this, "Exported ${item.displayName}", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Throwable) {
                runOnUiThread {
                    Toast.makeText(this, "Export failed: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()

        val profileName = intent.getStringExtra(EXTRA_PROFILE) ?: VaultProfile.MAIN.name
        profile = try { VaultProfile.valueOf(profileName) } catch (_: Throwable) { VaultProfile.MAIN }
        repo = VaultRepository(applicationContext, profile)

        val root = buildRootLayout()
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        selectTab(Tab.FILES)
    }

    override fun onStop() {
        super.onStop()
        if (!isChangingConfigurations && !suppressAutoLockOnce) {
            finish()
        }
    }

    override fun onResume() {
        super.onResume()
        suppressAutoLockOnce = false
    }

    override fun onDestroy() {
        super.onDestroy()
        ioExecutor.shutdownNow()
    }

    private fun buildRootLayout(): LinearLayout {
        val bg = if (isDark) Color.parseColor("#0F172A") else Color.parseColor("#F8FAFC")
        val barBg = if (isDark) Color.parseColor("#1E293B") else Color.parseColor("#FFFFFF")
        val textPrimary = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
        val textSecondary = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // Top Bar
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(barBg)
            setPadding(dp(16), dp(14), dp(16), dp(14))
        }
        val titleStack = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        titleStack.addView(TextView(this).apply {
            text = getString(R.string.vault_title)
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        headerSubtitle = TextView(this).apply {
            text = "AES-256-GCM Encrypted • Offline"
            setTextColor(textSecondary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        }
        titleStack.addView(headerSubtitle)
        header.addView(titleStack)

        val lockBtn = makePillButton("Lock", Color.parseColor("#DC2626"), Color.WHITE) {
            finish()
        }
        header.addView(lockBtn)
        root.addView(header)

        // Content container
        contentContainer = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(contentContainer)

        // Bottom Navigation Bar
        val bottomBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setBackgroundColor(barBg)
            setPadding(dp(8), dp(8), dp(8), dp(10))
        }
        val tabs = listOf(
            Tab.FILES to "Files",
            Tab.NOTES to "Notes",
            Tab.APPS to "Private Apps",
            Tab.SETTINGS to "Settings"
        )
        for ((tab, label) in tabs) {
            val btn = TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                setPadding(dp(6), dp(10), dp(6), dp(10))
                layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply {
                    setMargins(dp(4), 0, dp(4), 0)
                }
                setOnClickListener { selectTab(tab) }
            }
            tabButtons[tab] = btn
            bottomBar.addView(btn)
        }
        root.addView(bottomBar)

        return root
    }

    private fun selectTab(tab: Tab) {
        activeTab = tab
        val activeBg = if (isDark) Color.parseColor("#1D4ED8") else Color.parseColor("#DBEAFE")
        val activeFg = if (isDark) Color.WHITE else Color.parseColor("#1E3A8A")
        val inactiveFg = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#475569")

        tabButtons.forEach { (t, btn) ->
            if (t == tab) {
                btn.background = roundedRect(activeBg, dp(14))
                btn.setTextColor(activeFg)
            } else {
                btn.background = null
                btn.setTextColor(inactiveFg)
            }
        }

        contentContainer.removeAllViews()
        when (tab) {
            Tab.FILES -> renderFilesTab()
            Tab.NOTES -> renderNotesTab()
            Tab.APPS -> renderPrivateAppsTab()
            Tab.SETTINGS -> renderSettingsTab()
        }
    }

    // ---- TAB 1: Encrypted Files & Media ----

    private fun renderFilesTab() {
        val cardBg = if (isDark) Color.parseColor("#1E293B") else Color.WHITE
        val textPrimary = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
        val textSecondary = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")
        val accent = if (isDark) Color.parseColor("#3B82F6") else Color.parseColor("#2563EB")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }

        // Action row: Import + Filter chips
        val topRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, 0, 0, dp(10))
        }
        topRow.addView(makePillButton("+ Import Files", accent, Color.WHITE) {
            suppressAutoLockOnce = true
            importLauncher.launch(arrayOf("*/*"))
        })
        topRow.addView(View(this).apply { layoutParams = LinearLayout.LayoutParams(dp(8), 1) })
        topRow.addView(makePillButton("+ Photos/Videos", Color.parseColor("#0F766E"), Color.WHITE) {
            suppressAutoLockOnce = true
            importLauncher.launch(arrayOf("image/*", "video/*"))
        })
        layout.addView(topRow)

        // Filter chips
        val filtersRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(0, 0, 0, dp(10))
        }
        val filters = listOf(
            null to "All",
            VaultMediaType.PHOTO to "Photos",
            VaultMediaType.VIDEO to "Videos",
            VaultMediaType.AUDIO to "Audio",
            VaultMediaType.DOCUMENT to "Docs"
        )
        for ((type, label) in filters) {
            val selected = activeFilter == type
            val bg = if (selected) accent else cardBg
            val fg = if (selected) Color.WHITE else textSecondary
            filtersRow.addView(TextView(this).apply {
                text = label
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                background = roundedRect(bg, dp(12))
                setPadding(dp(10), dp(6), dp(10), dp(6))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { marginEnd = dp(6) }
                setOnClickListener {
                    activeFilter = type
                    selectTab(Tab.FILES)
                }
            })
        }
        layout.addView(filtersRow)

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val listCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listCol)
        layout.addView(scroll)
        contentContainer.addView(layout)

        ioExecutor.execute {
            val items = repo.listFiles(activeFilter)
            runOnUiThread {
                if (activeTab != Tab.FILES) return@runOnUiThread
                listCol.removeAllViews()
                if (items.isEmpty()) {
                    listCol.addView(makeEmptyState(
                        "No encrypted files yet.\nTap '+ Import Files' or '+ Photos/Videos' to encrypt items using Android's system picker (zero storage permissions needed)."
                    ))
                    return@runOnUiThread
                }
                for (item in items) {
                    listCol.addView(buildFileCard(item, cardBg, textPrimary, textSecondary))
                }
            }
        }
    }

    private fun buildFileCard(item: VaultFileItem, cardBg: Int, textPrimary: Int, textSecondary: Int): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = roundedRect(cardBg, dp(16))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }

        val thumb = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            background = roundedRect(if (isDark) Color.parseColor("#334155") else Color.parseColor("#E2E8F0"), dp(10))
            layoutParams = LinearLayout.LayoutParams(dp(52), dp(52)).apply { marginEnd = dp(12) }
        }
        card.addView(thumb)
        if (item.hasThumbnail) {
            ioExecutor.execute {
                val bm = repo.loadThumbnail(item.id)
                if (bm != null) runOnUiThread { thumb.setImageBitmap(bm) }
            }
        }

        val meta = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        meta.addView(TextView(this).apply {
            text = item.displayName
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
        })
        val sizeStr = Formatter.formatShortFileSize(this, item.sizeBytes)
        val dateStr = DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(item.addedAt))
        meta.addView(TextView(this).apply {
            text = "${item.mediaType.name} • $sizeStr • $dateStr"
            setTextColor(textSecondary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        })
        card.addView(meta)

        card.setOnClickListener { openVaultItem(item) }
        card.setOnLongClickListener {
            showFileOptionsDialog(item)
            true
        }
        return card
    }

    private fun openVaultItem(item: VaultFileItem) {
        if (item.mediaType == VaultMediaType.DOCUMENT) {
            showFileOptionsDialog(item)
            return
        }
        suppressAutoLockOnce = true
        val intent = Intent(this, MediaViewerActivity::class.java).apply {
            putExtra(MediaViewerActivity.EXTRA_PROFILE, profile.name)
            putExtra(MediaViewerActivity.EXTRA_FILE_ID, item.id)
            putExtra(MediaViewerActivity.EXTRA_DISPLAY_NAME, item.displayName)
            putExtra(MediaViewerActivity.EXTRA_MEDIA_TYPE, item.mediaType.name)
        }
        startActivity(intent)
    }

    private fun showFileOptionsDialog(item: VaultFileItem) {
        val options = arrayOf("Export / Restore Copy", "Rename", "Secure Delete")
        MaterialAlertDialogBuilder(this)
            .setTitle(item.displayName)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> {
                        pendingExportItem = item
                        suppressAutoLockOnce = true
                        exportLauncher.launch(item.displayName)
                    }
                    1 -> showRenameFileDialog(item)
                    2 -> {
                        ioExecutor.execute {
                            repo.deleteFile(item.id)
                            runOnUiThread {
                                Toast.makeText(this, "Securely deleted", Toast.LENGTH_SHORT).show()
                                selectTab(Tab.FILES)
                            }
                        }
                    }
                }
            }
            .show()
    }

    private fun showRenameFileDialog(item: VaultFileItem) {
        val input = EditText(this).apply {
            setText(item.displayName)
            setSelection(item.displayName.length)
        }
        MaterialAlertDialogBuilder(this)
            .setTitle("Rename File")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                ioExecutor.execute {
                    repo.renameFile(item.id, input.text.toString())
                    runOnUiThread { selectTab(Tab.FILES) }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun importFiles(uris: List<Uri>) {
        Toast.makeText(this, "Encrypting ${uris.size} file(s)…", Toast.LENGTH_SHORT).show()
        ioExecutor.execute {
            var ok = 0
            for (u in uris) {
                try {
                    repo.importFromUri(u)
                    ok++
                } catch (_: Throwable) {
                }
            }
            runOnUiThread {
                Toast.makeText(
                    this,
                    "Encrypted $ok of ${uris.size} file(s). You can now delete the original(s) from your gallery if desired.",
                    Toast.LENGTH_LONG
                ).show()
                if (activeTab == Tab.FILES) selectTab(Tab.FILES)
            }
        }
    }

    // ---- TAB 2: Encrypted Notes ----

    private fun renderNotesTab() {
        val cardBg = if (isDark) Color.parseColor("#1E293B") else Color.WHITE
        val textPrimary = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
        val textSecondary = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")
        val accent = if (isDark) Color.parseColor("#3B82F6") else Color.parseColor("#2563EB")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(12))
        }
        layout.addView(makePillButton("+ New Encrypted Note", accent, Color.WHITE) {
            showNoteEditorDialog(null)
        }.apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(12) }
        })

        val scroll = ScrollView(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        val listCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(listCol)
        layout.addView(scroll)
        contentContainer.addView(layout)

        ioExecutor.execute {
            val notes = repo.listNotes()
            runOnUiThread {
                if (activeTab != Tab.NOTES) return@runOnUiThread
                listCol.removeAllViews()
                if (notes.isEmpty()) {
                    listCol.addView(makeEmptyState("No private notes yet.\nEverything you write here is encrypted with AES-256-GCM."))
                    return@runOnUiThread
                }
                for (note in notes) {
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        background = roundedRect(cardBg, dp(16))
                        setPadding(dp(14), dp(12), dp(14), dp(12))
                        layoutParams = LinearLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.WRAP_CONTENT
                        ).apply { bottomMargin = dp(8) }
                    }
                    card.addView(TextView(this).apply {
                        text = note.title
                        setTextColor(textPrimary)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                    })
                    card.addView(TextView(this).apply {
                        text = note.body.take(140)
                        setTextColor(textSecondary)
                        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                        maxLines = 2
                        setPadding(0, dp(4), 0, 0)
                    })
                    card.setOnClickListener { showNoteEditorDialog(note) }
                    listCol.addView(card)
                }
            }
        }
    }

    private fun showNoteEditorDialog(existing: VaultNote?) {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(4))
        }
        val titleEt = EditText(this).apply {
            hint = "Title"
            setText(existing?.title ?: "")
        }
        val bodyEt = EditText(this).apply {
            hint = "Write your private note..."
            minLines = 5
            gravity = Gravity.TOP or Gravity.START
            setText(existing?.body ?: "")
        }
        container.addView(titleEt)
        container.addView(bodyEt)

        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "New Note" else "Edit Note")
            .setView(container)
            .setPositiveButton("Save") { _, _ ->
                ioExecutor.execute {
                    repo.saveNote(existing?.id, titleEt.text.toString(), bodyEt.text.toString())
                    runOnUiThread { selectTab(Tab.NOTES) }
                }
            }
            .setNegativeButton("Cancel", null)

        if (existing != null) {
            builder.setNeutralButton("Delete") { _, _ ->
                ioExecutor.execute {
                    repo.deleteNote(existing.id)
                    runOnUiThread { selectTab(Tab.NOTES) }
                }
            }
        }
        builder.show()
    }

    // ---- TAB 3: Play-Compliant Private Apps (Android Native Private Space + Isolated Web Apps) ----

    private fun renderPrivateAppsTab() {
        val cardBg = if (isDark) Color.parseColor("#1E293B") else Color.WHITE
        val highlightBg = if (isDark) Color.parseColor("#172554") else Color.parseColor("#EFF6FF")
        val textPrimary = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
        val textSecondary = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")
        val accent = if (isDark) Color.parseColor("#3B82F6") else Color.parseColor("#2563EB")

        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(20))
        }
        scroll.addView(col)
        contentContainer.addView(scroll)

        // Section 1: Android Native Private Space (Play-compliant OS-level app hiding!)
        val osCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedRect(highlightBg, dp(18))
            setPadding(dp(16), dp(14), dp(16), dp(14))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(14) }
        }
        val osTitle = if (Build.VERSION.SDK_INT >= 35) {
            "Android Native Private Space (Available on Your Device)"
        } else {
            "System App Hiding (Secure Folder / Work Profile)"
        }
        val osBody = if (Build.VERSION.SDK_INT >= 35) {
            "Android 15+ includes built-in OS-level Private Space that hides installed apps, notifications, and recents behind a separate lock—with zero crashes and full Google Play Services support. Open Security & Privacy → Private space to set it up."
        } else {
            "For native Android apps, use your phone's built-in Secure Folder or App Lock in Security Settings. For second accounts inside this vault, use Isolated Web Apps below."
        }
        osCard.addView(TextView(this).apply {
            text = osTitle
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        osCard.addView(TextView(this).apply {
            text = osBody
            setTextColor(textSecondary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setPadding(0, dp(6), 0, dp(10))
        })
        osCard.addView(makePillButton("Open Device Security Settings", accent, Color.WHITE) {
            suppressAutoLockOnce = true
            try {
                startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS))
            } catch (_: Throwable) {
                startActivity(Intent(Settings.ACTION_SETTINGS))
            }
        })
        col.addView(osCard)

        // Section 2: Isolated Web Apps (Sandboxed inside the vault)
        val headerRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(0, dp(4), 0, dp(10))
        }
        headerRow.addView(TextView(this).apply {
            text = "Isolated Web Apps"
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        headerRow.addView(makePillButton("+ Add URL", accent, Color.WHITE) {
            showAddWebAppDialog()
        })
        col.addView(headerRow)

        val appsCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(appsCol)

        ioExecutor.execute {
            val apps = repo.listWebApps()
            runOnUiThread {
                if (activeTab != Tab.APPS) return@runOnUiThread
                appsCol.removeAllViews()
                for (app in apps) {
                    appsCol.addView(buildWebAppCard(app, cardBg, textPrimary, textSecondary))
                }
            }
        }
    }

    private fun buildWebAppCard(app: PrivateWebApp, cardBg: Int, textPrimary: Int, textSecondary: Int): View {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = roundedRect(cardBg, dp(14))
            setPadding(dp(14), dp(12), dp(14), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }
        card.addView(TextView(this).apply {
            text = app.name
            setTextColor(textPrimary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        card.addView(TextView(this).apply {
            text = app.url
            setTextColor(textSecondary)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
        })
        card.setOnClickListener {
            suppressAutoLockOnce = true
            startActivity(Intent(this, PrivateWebActivity::class.java).apply {
                putExtra(PrivateWebActivity.EXTRA_TITLE, app.name)
                putExtra(PrivateWebActivity.EXTRA_URL, app.url)
            })
        }
        card.setOnLongClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("Remove ${app.name}?")
                .setPositiveButton("Remove") { _, _ ->
                    ioExecutor.execute {
                        repo.deleteWebApp(app.id)
                        runOnUiThread { selectTab(Tab.APPS) }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
            true
        }
        return card
    }

    private fun showAddWebAppDialog() {
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(10), dp(20), dp(4))
        }
        val nameEt = EditText(this).apply { hint = "App Name (e.g., Instagram 2)" }
        val urlEt = EditText(this).apply {
            hint = "https://..."
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        container.addView(nameEt)
        container.addView(urlEt)

        MaterialAlertDialogBuilder(this)
            .setTitle("Add Isolated Web App")
            .setView(container)
            .setPositiveButton("Add") { _, _ ->
                val rawUrl = urlEt.text.toString().trim()
                if (rawUrl.isEmpty()) return@setPositiveButton
                ioExecutor.execute {
                    repo.addWebApp(nameEt.text.toString(), rawUrl)
                    runOnUiThread { selectTab(Tab.APPS) }
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---- TAB 4: Settings & Privacy ----

    private fun renderSettingsTab() {
        val cardBg = if (isDark) Color.parseColor("#1E293B") else Color.WHITE
        val textPrimary = if (isDark) Color.parseColor("#F8FAFC") else Color.parseColor("#0F172A")
        val textSecondary = if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B")

        val scroll = ScrollView(this)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(12), dp(14), dp(20))
        }
        scroll.addView(col)
        contentContainer.addView(scroll)

        fun addSettingRow(title: String, subtitle: String, onClick: () -> Unit) {
            val card = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = roundedRect(cardBg, dp(14))
                setPadding(dp(16), dp(14), dp(16), dp(14))
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { bottomMargin = dp(8) }
                setOnClickListener { onClick() }
            }
            card.addView(TextView(this).apply {
                text = title
                setTextColor(textPrimary)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
                typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            })
            card.addView(TextView(this).apply {
                text = subtitle
                setTextColor(textSecondary)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setPadding(0, dp(3), 0, 0)
            })
            col.addView(card)
        }

        if (profile == VaultProfile.MAIN) {
            addSettingRow("Change Primary PIN", "Update the 4–8 digit PIN that unlocks your main vault") {
                showChangePinDialog(isDecoy = false)
            }
            addSettingRow(
                "Decoy Vault PIN",
                if (VaultCrypto.hasDecoyPin(this)) "Active — tap to change or remove decoy PIN"
                else "Set a secondary PIN that opens a separate empty decoy vault"
            ) {
                showChangePinDialog(isDecoy = true)
            }
            val bioState = if (VaultCrypto.isBiometricEnabled(this)) "Enabled" else "Disabled"
            addSettingRow("Biometric Quick Unlock ($bioState)", "Show an optional Unlock button on the calculator top bar") {
                VaultCrypto.setBiometricEnabled(this, !VaultCrypto.isBiometricEnabled(this))
                selectTab(Tab.SETTINGS)
            }
        }

        addSettingRow("Clear Private Web Data", "Wipe all cookies, logins, cache, and storage from Private Web Apps") {
            CookieManager.getInstance().removeAllCookies(null)
            CookieManager.getInstance().flush()
            WebStorage.getInstance().deleteAllData()
            Toast.makeText(this, "All Private Web App data cleared", Toast.LENGTH_SHORT).show()
        }

        addSettingRow("Privacy Policy", "View offline storage, encryption, and zero-data-collection policy") {
            MaterialAlertDialogBuilder(this)
                .setTitle(R.string.privacy_policy_title)
                .setMessage(R.string.privacy_policy_body)
                .setPositiveButton("Close", null)
                .show()
        }

        addSettingRow("Wipe Current Vault", "Securely erase all encrypted files, notes, and web bookmarks in this vault") {
            MaterialAlertDialogBuilder(this)
                .setTitle("Wipe Vault?")
                .setMessage("This permanently overwrites and deletes all files and notes in this vault. This cannot be undone.")
                .setPositiveButton("Wipe") { _, _ ->
                    ioExecutor.execute {
                        repo.wipeAll()
                        runOnUiThread {
                            Toast.makeText(this, "Vault wiped", Toast.LENGTH_SHORT).show()
                            selectTab(Tab.FILES)
                        }
                    }
                }
                .setNegativeButton("Cancel", null)
                .show()
        }
    }

    private fun showChangePinDialog(isDecoy: Boolean) {
        val input = EditText(this).apply {
            hint = "Enter 4–8 digit PIN"
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(8))
        }
        val builder = MaterialAlertDialogBuilder(this)
            .setTitle(if (isDecoy) "Set Decoy PIN" else "Change Primary PIN")
            .setView(input)
            .setPositiveButton("Save") { _, _ ->
                val pin = input.text.toString().trim()
                if (pin.length !in 4..8 || !pin.all { it.isDigit() }) {
                    Toast.makeText(this, "PIN must be 4–8 digits", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                if (isDecoy) {
                    if (VaultCrypto.verifyPin(this, pin) == VaultCrypto.PinMatch.MAIN) {
                        Toast.makeText(this, "Decoy PIN must differ from Primary PIN", Toast.LENGTH_LONG).show()
                        return@setPositiveButton
                    }
                    VaultCrypto.setDecoyPin(this, pin)
                } else {
                    VaultCrypto.setMainPin(this, pin)
                }
                Toast.makeText(this, "PIN updated", Toast.LENGTH_SHORT).show()
                selectTab(Tab.SETTINGS)
            }
            .setNegativeButton("Cancel", null)

        if (isDecoy && VaultCrypto.hasDecoyPin(this)) {
            builder.setNeutralButton("Remove Decoy") { _, _ ->
                VaultCrypto.setDecoyPin(this, null)
                Toast.makeText(this, "Decoy PIN removed", Toast.LENGTH_SHORT).show()
                selectTab(Tab.SETTINGS)
            }
        }
        builder.show()
    }

    private fun makeEmptyState(message: String): TextView = TextView(this).apply {
        text = message
        gravity = Gravity.CENTER
        setTextColor(if (isDark) Color.parseColor("#94A3B8") else Color.parseColor("#64748B"))
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        setPadding(dp(24), dp(48), dp(24), dp(48))
    }

    private fun makePillButton(label: String, bg: Int, fg: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(fg)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        background = roundedRect(bg, dp(14))
        setPadding(dp(14), dp(9), dp(14), dp(9))
        setOnClickListener { onClick() }
    }

    private fun roundedRect(color: Int, radiusPx: Int): GradientDrawable = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radiusPx.toFloat()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
