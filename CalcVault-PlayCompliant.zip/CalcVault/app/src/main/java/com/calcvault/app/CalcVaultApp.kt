package com.calcvault.app

import android.app.Application

class CalcVaultApp : Application()
