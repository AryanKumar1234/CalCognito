package com.calcvault.app.ui

import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.annotation.OptIn
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ProgressiveMediaSource
import androidx.media3.ui.PlayerView
import com.calcvault.app.crypto.VaultCrypto
import com.calcvault.app.vault.EncryptedDataSource
import com.calcvault.app.vault.VaultMediaType
import com.calcvault.app.vault.VaultProfile
import com.calcvault.app.vault.VaultRepository
import java.util.concurrent.Executors
import kotlin.math.roundToInt

/**
 * FLAG_SECURE viewer for encrypted photos (decoded in memory) and encrypted videos/audio
 * (streamed directly via Media3 ExoPlayer + EncryptedDataSource with zero unencrypted temp files).
 */
class MediaViewerActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PROFILE = "extra_profile"
        const val EXTRA_FILE_ID = "extra_file_id"
        const val EXTRA_DISPLAY_NAME = "extra_display_name"
        const val EXTRA_MEDIA_TYPE = "extra_media_type"
    }

    private var player: ExoPlayer? = null
    private val ioExecutor = Executors.newSingleThreadExecutor()

    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        enableEdgeToEdge()

        val profileName = intent.getStringExtra(EXTRA_PROFILE) ?: VaultProfile.MAIN.name
        val fileId = intent.getStringExtra(EXTRA_FILE_ID) ?: run { finish(); return }
        val displayName = intent.getStringExtra(EXTRA_DISPLAY_NAME) ?: "Media"
        val mediaTypeName = intent.getStringExtra(EXTRA_MEDIA_TYPE) ?: VaultMediaType.PHOTO.name
        val profile = try { VaultProfile.valueOf(profileName) } catch (_: Throwable) { VaultProfile.MAIN }
        val mediaType = try { VaultMediaType.valueOf(mediaTypeName) } catch (_: Throwable) { VaultMediaType.PHOTO }

        val repo = VaultRepository(applicationContext, profile)
        val encryptedFile = repo.encryptedFileFor(fileId)
        if (!encryptedFile.exists()) {
            Toast.makeText(this, "Encrypted file not found", Toast.LENGTH_SHORT).show()
            finish()
            return
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val backBtn = TextView(this).apply {
            text = "← Back"
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            setPadding(dp(8), dp(6), dp(12), dp(6))
            setOnClickListener { finish() }
        }
        topBar.addView(backBtn)
        topBar.addView(TextView(this).apply {
            text = displayName
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 1
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        })
        root.addView(topBar)

        val stage = FrameLayout(this).apply {
            layoutParams = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        }
        root.addView(stage)
        setContentView(root)

        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            insets
        }

        when (mediaType) {
            VaultMediaType.PHOTO -> {
                val imageView = ImageView(this).apply {
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
                stage.addView(imageView)
                ioExecutor.execute {
                    try {
                        val bytes = VaultCrypto.decryptFileToBytes(encryptedFile)
                        val bm = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        runOnUiThread {
                            if (bm != null) imageView.setImageBitmap(bm)
                            else Toast.makeText(this, "Unable to decode image", Toast.LENGTH_SHORT).show()
                        }
                    } catch (e: Throwable) {
                        runOnUiThread {
                            Toast.makeText(this, "Decryption failed: ${e.message}", Toast.LENGTH_LONG).show()
                            finish()
                        }
                    }
                }
            }
            VaultMediaType.VIDEO, VaultMediaType.AUDIO -> {
                val playerView = PlayerView(this).apply {
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                }
                stage.addView(playerView)
                val exo = ExoPlayer.Builder(this).build()
                player = exo
                playerView.player = exo
                val dataSourceFactory = EncryptedDataSource.Factory(encryptedFile)
                val mediaSource = ProgressiveMediaSource.Factory(dataSourceFactory)
                    .createMediaSource(MediaItem.fromUri(Uri.parse("cvlt://vault/$fileId")))
                exo.setMediaSource(mediaSource)
                exo.prepare()
                exo.playWhenReady = true
            }
            else -> finish()
        }
    }

    override fun onStop() {
        super.onStop()
        player?.pause()
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
        ioExecutor.shutdownNow()
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).roundToInt()
}
