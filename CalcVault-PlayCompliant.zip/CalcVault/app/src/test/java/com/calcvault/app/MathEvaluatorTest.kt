package com.calcvault.app

import com.calcvault.app.calc.MathEvaluator
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class MathEvaluatorTest {

    @Test
    fun basicArithmeticAndPrecedence() {
        assertEquals("14", MathEvaluator.formatResult(MathEvaluator.evaluate("2+3×4")!!))
        assertEquals("20", MathEvaluator.formatResult(MathEvaluator.evaluate("(2+3)×4")!!))
        assertEquals("0.3", MathEvaluator.formatResult(MathEvaluator.evaluate("0.1+0.2")!!))
        assertEquals("2.5", MathEvaluator.formatResult(MathEvaluator.evaluate("5÷2")!!))
    }

    @Test
    fun scientificFunctionsAndConstants() {
        assertEquals("0.5", MathEvaluator.formatResult(MathEvaluator.evaluate("sin(30)", useDegrees = true)!!))
        assertEquals("1", MathEvaluator.formatResult(MathEvaluator.evaluate("cos(0)", useDegrees = true)!!))
        assertEquals("120", MathEvaluator.formatResult(MathEvaluator.evaluate("5!")!!))
        assertEquals("8", MathEvaluator.formatResult(MathEvaluator.evaluate("2^3")!!))
        assertEquals("4", MathEvaluator.formatResult(MathEvaluator.evaluate("√(16)")!!))
        assertEquals("0.25", MathEvaluator.formatResult(MathEvaluator.evaluate("25%")!!))
    }

    @Test
    fun invalidExpressionsReturnNull() {
        assertNull(MathEvaluator.evaluate("1÷0"))
        assertNull(MathEvaluator.evaluate("(2+3"))
        assertNull(MathEvaluator.evaluate(""))
    }
}
