# CalcVault — Play-Compliant Calculator & Encrypted Private Vault

A clean, crash-free Android application built from scratch with **standard AndroidX APIs**, **hardware-backed AES-256-GCM encryption**, and full compliance with current Google Play policies (Android 16 / API 36, 16 KB memory page sizes, mandatory edge-to-edge, zero restricted permissions, and zero native ART hooking).

## What Was Replaced & Why
Traditional "Parallel Space" / BlackBox engines inject native C++ ART/JNI hooks into system frameworks and dynamically execute third-party APKs inside the host process. That approach constantly crashes on Android 14–16 and violates Google Play's [Device and Network Abuse policy](https://support.google.com/googleplay/android-developer/answer/16559646?hl=en).

**CalcVault** replaces all fragile and non-compliant components with clean, policy-compliant Android architecture:

| Feature | How CalcVault Handles It |
| --- | --- |
| **Calculator Disguise** | Full Material 3 scientific calculator (`+`, `−`, `×`, `÷`, `%`, `^`, `!`, `sin`, `cos`, `tan`, `log`, `ln`, `√`, `π`, history, DEG/RAD). Type your 4–8 digit PIN and press `=` to unlock. |
| **Encrypted Files, Photos & Videos** | Streaming chunked **AES-256-GCM** encryption backed by `AndroidKeyStore`. Imported via Android's Storage Access Framework (`OpenMultipleDocuments`) with **zero storage permissions**. |
| **Zero-Temp-File Video Playback** | Custom seekable Media3 `EncryptedDataSource` decrypts chunks on the fly in ExoPlayer without writing unencrypted temp files to storage. |
| **Encrypted Private Notes** | Local AES-256-GCM encrypted notes stored strictly inside app-private storage. |
| **Decoy Vault & Biometrics** | Optional secondary Decoy PIN opens a completely separate vault space (`vault_decoy`). Optional `BiometricPrompt` quick unlock. |
| **Play-Compliant Private Apps** | 1. **Isolated Web Apps**: Sandboxed `FLAG_SECURE` WebView container (HTTPS-only, separate session, one-tap "Burn" wipe for Instagram, X, Reddit, Telegram Web, Discord, Gmail, or custom URLs).<br>2. **Android Native Private Space**: Guides Android 15+ users directly to [Android's built-in Private Space](https://source.android.com/docs/security/features/private-space) in system Security Settings for true OS-level native app hiding with zero crashes. |

## Google Play Policy Compliance Checklist
- **Target API 36 (Android 16)**: Meets [Google Play's target API level requirement](https://developer.android.com/google/play/requirements/target-sdk) (`compileSdk = 36`, `targetSdk = 36`).
- **16 KB Memory Page Sizes**: Pure Kotlin/AndroidX with zero custom `.so` native libraries — automatically compliant with [Google Play's 16 KB page size requirement](https://developer.android.com/guide/practices/page-sizes).
- **Mandatory Edge-to-Edge**: Calls `enableEdgeToEdge()` and handles `WindowInsetsCompat` across all activities per [Android 16 behavior changes](https://developer.android.com/about/versions/16/behavior-changes-16).
- **Minimal Permissions**: Declares only `android.permission.INTERNET` (for Private Web Apps). Zero `MANAGE_EXTERNAL_STORAGE`, zero `QUERY_ALL_PACKAGES` ([policy](https://support.google.com/googleplay/android-developer/answer/10158779?hl=en)), zero `REQUEST_INSTALL_PACKAGES`, zero Shizuku/privileged binders, zero self-updating outside Play.
- **User Data & Privacy Policy**: Built-in in-app Privacy Policy screen in **Settings → Privacy Policy** ([User Data policy](https://support.google.com/googleplay/android-developer/answer/10144311?hl=en)), `allowBackup="false"`, and `data_extraction_rules.xml` excluding all vault data from cloud backup.
- **Security**: `FLAG_SECURE` + `excludeFromRecents="true"` on all vault screens, automatic lock on background, PBKDF2-HMAC-SHA256 (120,000 iterations) PIN hashing, R8 minification & resource shrinking on release builds.

## Building

### GitHub Actions (Recommended)
Push this repository to GitHub. The workflow in `.github/workflows/build.yml` runs unit tests and produces:
- `CalcVault-debug-apk`
- `CalcVault-release-apk` (R8 minified)
- `CalcVault-play-store-aab` (Android App Bundle for Google Play Console)

### Signing for Google Play Console
Set these environment variables (or GitHub Actions secrets) when building `bundleRelease`:
- `KEYSTORE_PATH`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`
