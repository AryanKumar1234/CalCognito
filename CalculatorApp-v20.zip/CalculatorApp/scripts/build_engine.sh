#!/usr/bin/env bash
# Builds the BlackBox virtual-engine AAR and copies it to app/libs so the app gets real "hide app" support.
#
# Needs: git, JDK 21 (the engine is written for Java 21), the Android SDK (ANDROID_HOME set) and the NDK version the engine asks for
# (its README currently says NDK 29.0.13846066; install it in Android Studio > SDK Manager > SDK Tools).
#
#   ./scripts/build_engine.sh                      # uses ALEX5402/NewBlackbox
#   ENGINE_REPO=<git url> ENGINE_MODULE=BCore ./scripts/build_engine.sh
#   ENGINE_REF=<commit | tag | branch> ./scripts/build_engine.sh   # pin the engine; default is the repo's latest
#   ENGINE_MINIFY=1 ./scripts/build_engine.sh                      # keep the engine's own R8 step (off by default)
set -euo pipefail

REPO="${ENGINE_REPO:-https://github.com/ALEX5402/NewBlackbox.git}"
MODULE="${ENGINE_MODULE:-Bcore}"     # some forks spell it BCore
HERE="$(cd "$(dirname "$0")" && pwd)"
WORK="$(mktemp -d)"
trap 'rm -rf "$WORK"' EXIT

git clone --depth 1 --recurse-submodules --shallow-submodules "$REPO" "$WORK/engine"
cd "$WORK/engine"

# Pin the engine to one commit / tag / branch when ENGINE_REF is set. Without it the latest commit is built, which can
# change between two builds of the same app.
if [ -n "${ENGINE_REF:-}" ]; then
  echo "Checking out engine ref: $ENGINE_REF"
  git fetch --depth 1 origin "$ENGINE_REF"
  git checkout --force FETCH_HEAD
  git submodule update --init --recursive --depth 1
fi
ENGINE_COMMIT="$(git rev-parse HEAD)"
echo "Engine commit: $ENGINE_COMMIT"
chmod +x ./gradlew
export ENGINE_MINIFY="${ENGINE_MINIFY:-0}"

# Forks spell the core module Bcore / BCore / bcore: use whichever folder actually exists.
found="$(find . -mindepth 1 -maxdepth 1 -type d -iname "$MODULE" | head -n 1)"
if [ -z "$found" ]; then
  echo "Could not find a module called '$MODULE' in $REPO. Folders in the repo:"
  find . -mindepth 1 -maxdepth 1 -type d -not -name '.*' | sed 's|^\./|  |'
  echo "Set ENGINE_MODULE to the right one and run again."
  exit 1
fi
MODULE="$(basename "$found")"
echo "Building engine module :$MODULE from $REPO"

# The init script (also used by the export step below) switches off R8 for the engine module unless ENGINE_MINIFY=1.
ENGINE_MODULE_NAME="$MODULE" ENGINE_DEPS_OUT="$WORK/unused" \
  ./gradlew -I "$HERE/export-engine-deps.init.gradle" ":${MODULE}:assembleRelease" --stacktrace

# An AAR does not carry the libraries its module depends on. Print them so a "class not found" failure when the
# engine starts inside the app can be traced to the missing library.
echo "---- :${MODULE} runtime dependencies ----"
./gradlew ":${MODULE}:dependencies" --configuration releaseRuntimeClasspath -q 2>&1 | head -n 150 || true
echo "---- end of dependencies ----"

AAR="$(find "$MODULE" -path '*outputs/aar/*' -name '*release*.aar' | head -n 1)"
if [ -z "$AAR" ]; then
  # Some forks name it differently (no "release" in the file name): take any AAR the build produced.
  AAR="$(find "$MODULE" -path '*outputs/aar/*' -name '*.aar' | head -n 1)"
fi
if [ -z "$AAR" ]; then
  echo "No AAR found under $MODULE/build/outputs/aar. Files the build produced:"
  find "$MODULE" -path '*build/outputs*' -type f | head -n 40
  exit 1
fi

LIBS="$HERE/../app/libs"
mkdir -p "$LIBS"
rm -f "$LIBS"/engine-dep-*.jar "$LIBS"/engine-dep-*.aar
cp "$AAR" "$LIBS/blackbox-core.aar"

# The AAR does not contain the libraries the engine depends on: BlackReflection (a module of the engine repo),
# FreeReflection, the hidden-API bypass, and so on. Without them the engine crashes when it starts inside the app
# with NoClassDefFoundError. Export them next to the AAR; the app picks up every jar / aar in app/libs.
echo "---- exporting the engine's library dependencies ----"
ENGINE_MODULE_NAME="$MODULE" ENGINE_DEPS_OUT="$LIBS" \
  ./gradlew -I "$HERE/export-engine-deps.init.gradle" ":${MODULE}:exportEngineDeps" --stacktrace

# Is this class in the engine AAR or in one of the exported libraries?
has_class() {
  local f
  for f in "$LIBS"/blackbox-core.aar "$LIBS"/engine-dep-*.jar "$LIBS"/engine-dep-*.aar; do
    [ -f "$f" ] || continue
    if [ "${f##*.}" = "aar" ]; then
      if unzip -p "$f" classes.jar > "$WORK/check-classes.jar" 2>/dev/null && unzip -l "$WORK/check-classes.jar" | grep -q "$1"; then
        return 0
      fi
    else
      if unzip -l "$f" | grep -q "$1"; then return 0; fi
    fi
  done
  return 1
}

# The class named in the crash report. If the export did not find it, build the engine's reflection module(s)
# directly (the engine repo calls it black-reflection) and copy what they produce.
CLASS="top/niunaijun/blackreflection/BlackReflection.class"
if ! has_class "$CLASS"; then
  echo "BlackReflection was not in the exported libraries; building the reflection module directly..."
  for dir in $(find . -mindepth 1 -maxdepth 1 -type d -iname '*reflection*' -not -name '.*'); do
    name="$(basename "$dir")"
    ./gradlew ":${name}:assemble" --stacktrace || continue
    jar="$(find "$dir/build/libs" -name '*.jar' ! -name '*sources*' ! -name '*javadoc*' 2>/dev/null | head -n 1 || true)"
    aar="$(find "$dir/build/outputs/aar" -name '*release*.aar' 2>/dev/null | head -n 1 || true)"
    [ -n "$jar" ] && cp "$jar" "$LIBS/engine-dep-module-${name}.jar"
    [ -n "$aar" ] && cp "$aar" "$LIBS/engine-dep-module-${name}.aar"
  done
fi

if ! has_class "$CLASS"; then
  echo "ERROR: $CLASS is not in the engine AAR or in any exported library."
  echo "Look at the dependency list printed above to see where BlackReflection comes from and add it to the export."
  echo "The app would crash at engine start-up without it."
  exit 1
fi

# ---- Facts about this engine build, for the CI log and for bug reports (written to app/libs/engine-dep-info.txt) ----
INFO="$LIBS/engine-dep-info.txt"
{
  echo "engine repo:   $REPO"
  echo "engine commit: $ENGINE_COMMIT"
  echo "engine ref:    ${ENGINE_REF:-<default branch>}"
  echo "R8 on engine:  $([ "$ENGINE_MINIFY" = "1" ] && echo kept || echo switched off)"
  echo
  echo "---- native libraries inside the AAR ----"
  unzip -l "$LIBS/blackbox-core.aar" | grep -E 'jni/.*\.so' || echo "NONE FOUND"
  echo
  echo "---- native methods declared by NativeCore (Java side; note static or not) ----"
  if unzip -p "$LIBS/blackbox-core.aar" classes.jar > "$WORK/info-classes.jar" 2>/dev/null && command -v javap >/dev/null; then
    javap -p -cp "$WORK/info-classes.jar" top.niunaijun.blackbox.core.NativeCore 2>&1 | grep -i native || echo "(none listed)"
  else
    echo "(javap not available)"
  fi
  echo
  echo "---- JNI symbols exported by libblackbox.so for NativeCore (native side) ----"
  if unzip -p "$LIBS/blackbox-core.aar" jni/arm64-v8a/libblackbox.so > "$WORK/info-libblackbox.so" 2>/dev/null; then
    NM="$(command -v llvm-nm || command -v nm || true)"
    if [ -n "$NM" ]; then
      "$NM" -D --defined-only "$WORK/info-libblackbox.so" 2>/dev/null | grep 'NativeCore' || echo "(no Java_..._NativeCore_ symbols: the methods are registered with RegisterNatives)"
    else
      echo "(nm not available)"
    fi
  else
    echo "jni/arm64-v8a/libblackbox.so is NOT in the AAR"
  fi
} | tee "$INFO"

echo "Copied the engine AAR and its libraries to app/libs:"
ls -l "$LIBS"
echo "Now rebuild the app."
