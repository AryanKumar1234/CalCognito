# Intentionally empty: release builds do not shrink or obfuscate (see app/build.gradle.kts).
