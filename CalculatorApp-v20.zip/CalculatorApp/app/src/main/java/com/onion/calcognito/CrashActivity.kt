package com.onion.calcognito

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/**
 * Shows what went wrong when the app closes unexpectedly. It runs in its own process (":crash") with the plainest
 * possible screen, so it still works when the main app crashes every time it opens. No log access is needed: the
 * text comes from the crash handler in [CrashReport] or from Android's own exit records.
 */
class CrashActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val report = intent?.getStringExtra("report") ?: "No details were recorded."
        val d = resources.displayMetrics.density
        val pad = (16 * d).toInt()

        val title = TextView(this).apply {
            text = "The app closed unexpectedly"
            textSize = 18f
            setTypeface(null, Typeface.BOLD)
            setPadding(pad, pad, pad, pad / 2)
        }
        val body = TextView(this).apply {
            text = report
            typeface = Typeface.MONOSPACE
            textSize = 11f
            setTextIsSelectable(true)
            setPadding(pad, 0, pad, pad)
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad / 2, 0, pad / 2, pad / 2)
            addView(Button(this@CrashActivity).apply {
                text = "Copy"
                setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("crash report", report))
                    Toast.makeText(this@CrashActivity, "Copied", Toast.LENGTH_SHORT).show()
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Button(this@CrashActivity).apply {
                text = "Share"
                setOnClickListener {
                    val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, report)
                    try { startActivity(Intent.createChooser(send, "Share crash report")) } catch (_: Exception) {}
                }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
            addView(Button(this@CrashActivity).apply {
                text = "Close"
                setOnClickListener { finish() }
            }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            fitsSystemWindows = true   // stay clear of the system bars (edge-to-edge is forced on newer Android)
            addView(title)
            addView(ScrollView(this@CrashActivity).apply { addView(body) }, LinearLayout.LayoutParams(-1, 0, 1f))
            addView(buttons)
        }
        setContentView(root)
    }
}
