package com.onion.calcognito

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.IBinder
import android.system.Os
import android.util.Log
import org.json.JSONObject
import rikka.shizuku.Shizuku
import rikka.shizuku.ShizukuBinderWrapper
import rikka.shizuku.SystemServiceHelper
import java.io.File
import java.io.FileOutputStream
import java.lang.reflect.Method

/**
 * Hiding apps with Shizuku or Sui (they offer the same API; Sui is started by the Shizuku provider automatically).
 *
 * Unlike the parallel engine, this hides the REAL app: it is disabled and hidden for the current user, so it
 * disappears from the home screen, app drawer, search and the system app list until it is unhidden again. It needs
 * Shizuku (or Sui) to be running both when hiding and when unhiding, which is why every hidden app is remembered here
 * (name and icon too, since a hidden app can no longer be looked up).
 *
 * The way the package manager is called through Shizuku's binder follows Amarok-Hider (Apache License 2.0,
 * github.com/deltazefiro/Amarok-Hider): IPackageManager.setApplicationEnabledSetting and
 * setApplicationHiddenSettingAsUser. On phones that block that reflection, the same is done with the shell commands
 * "pm disable-user / pm hide" (and the reverse) run with Shizuku's privileges.
 */
object ShizukuHider {
    const val MANAGER_PACKAGE = "moe.shizuku.privileged.api"
    private const val TAG = "ShizukuHider"
    private const val PREF = "shizuku_hidden"
    private const val ICON_DIR = "shizuku_hidden_icons"
    private const val REQ_CODE = 4601

    enum class Status { READY, NEEDS_PERMISSION, DENIED, NOT_RUNNING, TOO_OLD }

    // ---------------------------------------------------------------------------------------------
    // Is Shizuku / Sui there?
    // ---------------------------------------------------------------------------------------------

    fun status(): Status = try {
        when {
            !Shizuku.pingBinder() -> Status.NOT_RUNNING
            Shizuku.isPreV11() -> Status.TOO_OLD
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED -> Status.READY
            Shizuku.shouldShowRequestPermissionRationale() -> Status.DENIED
            else -> Status.NEEDS_PERMISSION
        }
    } catch (_: Throwable) {
        Status.NOT_RUNNING
    }

    fun statusLine(): String = when (status()) {
        Status.READY -> "Ready"
        Status.NEEDS_PERMISSION -> "Running · will ask for your permission"
        Status.DENIED -> "Permission was denied"
        Status.NOT_RUNNING -> "Not running"
        Status.TOO_OLD -> "Version too old (needs 11 or later)"
    }

    fun managerInstalled(ctx: Context): Boolean = try {
        ctx.packageManager.getPackageInfo(MANAGER_PACKAGE, 0)
        true
    } catch (_: Throwable) {
        false
    }

    /** Asks Shizuku / Sui to let this app use it. [onResult] runs on the main thread. */
    fun requestPermission(onResult: (Boolean) -> Unit) {
        try {
            val listener = object : Shizuku.OnRequestPermissionResultListener {
                override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
                    if (requestCode != REQ_CODE) return
                    Shizuku.removeRequestPermissionResultListener(this)
                    onResult(grantResult == PackageManager.PERMISSION_GRANTED)
                }
            }
            Shizuku.addRequestPermissionResultListener(listener)
            Shizuku.requestPermission(REQ_CODE)
        } catch (_: Throwable) {
            onResult(false)
        }
    }

    // ---------------------------------------------------------------------------------------------
    // Hiding and unhiding (blocking: call from a worker thread)
    // ---------------------------------------------------------------------------------------------

    private class Pm(val instance: Any, val setEnabled: Method, val setHidden: Method)

    /** Newer Android blocks reflection on hidden classes; ask the runtime to allow it (best effort, can't hurt). */
    private fun exemptHiddenApis() {
        if (Build.VERSION.SDK_INT < 28) return
        try {
            val forName = Class::class.java.getDeclaredMethod("forName", String::class.java)
            val getDeclaredMethod = Class::class.java.getDeclaredMethod(
                "getDeclaredMethod", String::class.java, arrayOf<Class<*>>()::class.java
            )
            val vmRuntime = forName.invoke(null, "dalvik.system.VMRuntime") as Class<*>
            val getRuntime = getDeclaredMethod.invoke(vmRuntime, "getRuntime", null) as Method
            val setExemptions = getDeclaredMethod.invoke(
                vmRuntime, "setHiddenApiExemptions", arrayOf<Class<*>>(Array<String>::class.java)
            ) as Method
            setExemptions.invoke(getRuntime.invoke(null), arrayOf("L"))
        } catch (_: Throwable) {
        }
    }

    @SuppressLint("PrivateApi")
    private fun packageManager(): Pm? = try {
        exemptHiddenApis()
        val iPm = Class.forName("android.content.pm.IPackageManager")
        val stub = Class.forName("android.content.pm.IPackageManager\$Stub")
        val binder = ShizukuBinderWrapper(SystemServiceHelper.getSystemService("package"))
        val instance = stub.getMethod("asInterface", IBinder::class.java).invoke(null, binder)
        val int = Int::class.javaPrimitiveType
        Pm(
            instance!!,
            iPm.getMethod("setApplicationEnabledSetting", String::class.java, int, int, int, String::class.java),
            iPm.getMethod("setApplicationHiddenSettingAsUser", String::class.java, Boolean::class.javaPrimitiveType, int)
        )
    } catch (t: Throwable) {
        Log.w(TAG, "IPackageManager through Shizuku is not usable here: $t")
        null
    }

    /** Runs a shell command with Shizuku's privileges (newProcess is private in the API, so it is reached by reflection). */
    private fun shell(vararg cmd: String): Pair<Int, String> = try {
        val m = Shizuku::class.java.getDeclaredMethod(
            "newProcess", Array<String>::class.java, Array<String>::class.java, String::class.java
        )
        m.isAccessible = true
        val proc = m.invoke(null, arrayOf(*cmd), null, null) as Process
        val out = proc.inputStream.bufferedReader().readText() + proc.errorStream.bufferedReader().readText()
        proc.waitFor() to out.trim()
    } catch (t: Throwable) {
        -1 to (t.message ?: t.javaClass.simpleName)
    }

    /** Hides ([hidden] = true) or unhides [pkg] for the current user. Null = done, otherwise why it didn't work. */
    private fun setHiddenState(ctx: Context, pkg: String, hidden: Boolean): String? {
        if (status() != Status.READY) return "Shizuku / Sui isn't ready"
        val userId = Os.getuid() / 100000

        val pm = packageManager()
        if (pm != null) {
            try {
                // Same order as Amarok-Hider: disable first, then hide; the reverse when unhiding.
                if (hidden) {
                    pm.setEnabled.invoke(pm.instance, pkg, PackageManager.COMPONENT_ENABLED_STATE_DISABLED_USER, 0, userId, ctx.packageName)
                    pm.setHidden.invoke(pm.instance, pkg, true, userId)
                } else {
                    pm.setEnabled.invoke(pm.instance, pkg, PackageManager.COMPONENT_ENABLED_STATE_DEFAULT, 0, userId, ctx.packageName)
                    pm.setHidden.invoke(pm.instance, pkg, false, userId)
                }
                return null
            } catch (t: Throwable) {
                Log.w(TAG, "binder call failed, trying the shell: $t")
            }
        }

        val u = userId.toString()
        val steps = if (hidden) {
            listOf(arrayOf("pm", "disable-user", "--user", u, pkg), arrayOf("pm", "hide", "--user", u, pkg))
        } else {
            listOf(arrayOf("pm", "enable", "--user", u, pkg), arrayOf("pm", "unhide", "--user", u, pkg))
        }
        for (step in steps) {
            val (code, out) = shell(*step)
            if (code != 0) return "Shizuku couldn't run \"${step.drop(1).first()}\": ${out.ifEmpty { "exit code $code" }.take(160)}"
        }
        return null
    }

    // ---------------------------------------------------------------------------------------------
    // What is hidden (name and icon are kept, a hidden app can no longer be looked up)
    // ---------------------------------------------------------------------------------------------

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    private fun records(ctx: Context): JSONObject = try {
        JSONObject(prefs(ctx).getString("apps", "{}") ?: "{}")
    } catch (_: Throwable) {
        JSONObject()
    }

    private fun iconFile(ctx: Context, pkg: String) =
        File(File(ctx.filesDir, ICON_DIR).apply { mkdirs() }, "$pkg.png")

    fun contains(ctx: Context, pkg: String): Boolean = records(ctx).has(pkg)

    fun list(ctx: Context): List<VirtualSpace.VApp> {
        val r = records(ctx)
        return r.keys().asSequence().map { pkg ->
            val icon = try {
                val f = iconFile(ctx, pkg)
                if (f.exists()) android.graphics.BitmapFactory.decodeFile(f.path) else null
            } catch (_: Throwable) {
                null
            }
            VirtualSpace.VApp(pkg, r.optString(pkg, pkg), icon)
        }.sortedBy { it.label.lowercase() }.toList()
    }

    private fun toBitmap(d: Drawable): Bitmap {
        val w = d.intrinsicWidth.coerceIn(1, 192)
        val h = d.intrinsicHeight.coerceIn(1, 192)
        val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        d.setBounds(0, 0, w, h)
        d.draw(Canvas(bm))
        return bm
    }

    /** Apps that can be hidden this way: the usual candidates, minus anything that would lock the person out. */
    fun candidates(ctx: Context): List<HiddenApps.Candidate> {
        val protectedPackages = HashSet<String>()
        protectedPackages.add(MANAGER_PACKAGE)
        protectedPackages.add(ctx.packageName)
        protectedPackages.add("com.android.settings")
        protectedPackages.add("com.android.systemui")
        try {
            val home = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
            for (ri in ctx.packageManager.queryIntentActivities(home, 0)) ri.activityInfo?.packageName?.let { protectedPackages.add(it) }
        } catch (_: Throwable) {
        }
        return HiddenApps.listCandidates(ctx).filter {
            it.pkg !in protectedPackages && !contains(ctx, it.pkg) && !VirtualSpace.contains(ctx, it.pkg)
        }
    }

    /** Hides [pkg] and remembers it. Blocking. Null = done, otherwise a short reason. */
    fun add(ctx: Context, pkg: String, label: String, icon: Drawable?): String? {
        // The name and icon have to be saved first: once the app is hidden they can't be read any more.
        val bm = try { icon?.let { toBitmap(it) } } catch (_: Throwable) { null }
        val error = setHiddenState(ctx, pkg, true)
        if (error != null) return error
        val r = records(ctx).put(pkg, label)
        prefs(ctx).edit().putString("apps", r.toString()).apply()
        bm?.let {
            try { FileOutputStream(iconFile(ctx, pkg)).use { o -> it.compress(Bitmap.CompressFormat.PNG, 100, o) } } catch (_: Throwable) {}
        }
        return null
    }

    /** Unhides [pkg] and forgets it. Blocking. Null = done, otherwise a short reason. */
    fun unhide(ctx: Context, pkg: String): String? {
        val error = setHiddenState(ctx, pkg, false)
        if (error != null) return error
        forget(ctx, pkg)
        return null
    }

    /** Stops listing [pkg] here without changing it (it stays hidden on the phone). */
    fun forget(ctx: Context, pkg: String) {
        val r = records(ctx)
        r.remove(pkg)
        prefs(ctx).edit().putString("apps", r.toString()).apply()
        iconFile(ctx, pkg).delete()
    }

    /** Waits briefly for an unhidden app to show up again, then returns the intent that opens it. Blocking. */
    fun launchIntent(ctx: Context, pkg: String): Intent? {
        for (i in 0 until 10) {
            ctx.packageManager.getLaunchIntentForPackage(pkg)?.let { return it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
            try { Thread.sleep(200) } catch (_: InterruptedException) { return null }
        }
        return null
    }

    /** Used when the vault is reset: puts everything back so no app is left hidden with nobody to unhide it. */
    fun restoreAll(ctx: Context) {
        val app = ctx.applicationContext
        val pkgs = records(app).keys().asSequence().toList()
        if (pkgs.isEmpty()) return
        Thread {
            for (pkg in pkgs) {
                if (setHiddenState(app, pkg, false) == null) forget(app, pkg)
            }
        }.start()
    }
}
