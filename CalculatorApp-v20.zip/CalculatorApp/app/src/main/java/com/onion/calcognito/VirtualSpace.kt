package com.onion.calcognito

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Hidden apps that work like Parallel Space.
 *
 * The app is cloned into a virtual space run by an embedded engine (see [EngineBridge]): it runs inside this app
 * without being installed on the phone, with its own private data, and the clone is never re-installed or archived
 * as an .apks file. The engine keeps its own internal copy of the app's APK, like every app of this kind.
 *
 * This object only remembers each app's name and icon (taken from the real app while it is still installed) so the
 * vault list can draw them; the engine itself is the source of truth for what actually runs.
 */
object VirtualSpace {
    const val USER_ID = 0
    private const val PREF = "virtual_space"
    private const val ICON_DIR = "virtual_space_icons"

    class VApp(val pkg: String, val label: String, val icon: Bitmap?)

    val available: Boolean get() = EngineBridge.available

    /** The engine starts the first time hidden apps are used, not when the app opens. Blocking: worker thread. */
    fun ensureStarted(ctx: Context): Boolean = EngineBridge.start(ctx.applicationContext)

    /** Why hiding apps isn't possible right now: no engine in this build, switched off after a crash, or failed to start. */
    val unavailableReason: String
        get() = when {
            !EngineBridge.compiledIn ->
                "This build has no hidden-app engine yet. Build it with the GitHub workflow or scripts/build_engine.sh " +
                    "(see the README) and install that build"
            EngineBridge.failure != null ->
                "The engine is part of this build but couldn't start.\n\n${EngineBridge.failure}\n\n" +
                    "Send this message to whoever maintains the app."
            else -> "The engine hasn't started yet. Try again."
        }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun iconFile(ctx: Context, pkg: String) =
        File(File(ctx.filesDir, ICON_DIR).apply { mkdirs() }, "$pkg.png")

    private fun records(ctx: Context): JSONObject = try {
        JSONObject(prefs(ctx).getString("apps", "{}") ?: "{}")
    } catch (_: Throwable) {
        JSONObject()
    }

    fun list(ctx: Context): List<VApp> {
        val r = records(ctx)
        val out = ArrayList<VApp>()
        for (pkg in r.keys()) {
            val icon = try { BitmapFactory.decodeFile(iconFile(ctx, pkg).absolutePath) } catch (_: Throwable) { null }
            out.add(VApp(pkg, r.optString(pkg, pkg), icon))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun contains(ctx: Context, pkg: String) = records(ctx).has(pkg)

    private fun toBitmap(d: Drawable, size: Int = 144): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null && d.bitmap.width <= size * 2) return d.bitmap
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return bm
    }

    // ----- Google Play services -----
    //
    // Apps that sign in with Google, use push notifications, Maps, ads or in-app purchases talk to Google Play
    // services. Inside the space such an app is seen under this app's identity, not its own, so the phone's own
    // Play services often refuses it. The way virtual spaces solve this (Parallel Space, VirtualApp) is to copy
    // Google's own apps from the phone into the space, where they see the cloned apps as their neighbours.
    // Experimental: it depends on the engine being able to copy those apps (many phones install Play services in
    // several parts) and on the Play services version.

    class GmsResult(val ok: Boolean, val message: String)

    private const val GMS = "com.google.android.gms"
    private const val GMS_KEY = "gms"
    private val GMS_PACKAGES = listOf("com.google.android.gsf", GMS, "com.android.vending")

    private fun gmsLabel(pkg: String) = when (pkg) {
        "com.google.android.gsf" -> "Google Services Framework"
        GMS -> "Google Play services"
        else -> "Google Play Store"
    }

    private fun hostHas(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Throwable) {
        false
    }

    /** True when the phone has Google Play services (the copy is made from it). */
    fun hostHasGms(ctx: Context): Boolean = hostHas(ctx, GMS)

    /** Does [pkg] use Google Play services? Firebase, Maps, Google sign-in and ads all add this marker to the app. */
    fun usesGms(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getApplicationInfo(pkg, PackageManager.GET_META_DATA)
            .metaData?.containsKey("com.google.android.gms.version") == true
    } catch (_: Throwable) {
        false
    }

    /** The Google apps that have been copied into the space. */
    fun gmsInstalled(ctx: Context): List<String> = try {
        val a = JSONArray(prefs(ctx).getString(GMS_KEY, "[]") ?: "[]")
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Throwable) {
        emptyList()
    }

    fun gmsEnabled(ctx: Context): Boolean = GMS in gmsInstalled(ctx)

    private fun saveGms(ctx: Context, list: List<String>) {
        prefs(ctx).edit().putString(GMS_KEY, JSONArray(list).toString()).apply()
    }

    /**
     * Copies Google Play services (and the Services Framework and Play Store, whichever the phone has) into the
     * space. Blocking: worker thread. [progress] is told the name of the app being copied.
     */
    fun enableGms(ctx: Context, progress: (String) -> Unit = {}): GmsResult {
        if (!ensureStarted(ctx)) return GmsResult(false, unavailableReason)
        if (!hostHasGms(ctx)) {
            return GmsResult(false, "Google Play services isn't installed on this phone, so there is nothing to copy.")
        }
        val done = gmsInstalled(ctx).toMutableList()
        val failed = ArrayList<String>()
        for (pkg in GMS_PACKAGES) {
            if (!hostHas(ctx, pkg) || pkg in done) continue
            progress(gmsLabel(pkg))
            if (EngineBridge.install(pkg, USER_ID)) {
                done.add(pkg)
                saveGms(ctx, done)   // keep progress even if a later one fails
            } else {
                failed.add(gmsLabel(pkg))
            }
        }
        if (GMS !in done) {
            return GmsResult(
                false,
                "The engine couldn't copy Google Play services. Many phones install it in several parts, which this " +
                    "engine may not support. Apps that need Google sign-in or notifications will keep failing."
            )
        }
        val extra = if (failed.isEmpty()) "" else "\n\nCouldn't copy: ${failed.joinToString(", ")}."
        return GmsResult(
            true,
            "Google Play services is now inside the hidden space. Open an app that needs Google and sign in there; " +
                "it can take a moment the first time. Support is experimental, so some apps may still not sign in.$extra"
        )
    }

    /** Removes the copied Google apps again. Blocking. True if everything is gone. */
    fun disableGms(ctx: Context): Boolean {
        if (gmsInstalled(ctx).isNotEmpty() && !ensureStarted(ctx)) return false
        val left = ArrayList<String>()
        for (pkg in gmsInstalled(ctx)) {
            val gone = EngineBridge.uninstall(pkg, USER_ID) || !EngineBridge.isInstalled(pkg, USER_ID)
            if (!gone) left.add(pkg)
        }
        saveGms(ctx, left)
        return left.isEmpty()
    }

    /** Clones [pkg] into the space. Blocking (worker thread). Returns null on success, else a short reason. */
    fun add(ctx: Context, pkg: String): String? {
        if (!ensureStarted(ctx)) return unavailableReason
        val pm = ctx.packageManager
        val label: String
        var icon: Bitmap? = null
        try {
            val ai = pm.getApplicationInfo(pkg, 0)
            label = pm.getApplicationLabel(ai).toString()
            icon = try { toBitmap(pm.getApplicationIcon(ai)) } catch (_: Throwable) { null }
        } catch (_: Throwable) {
            return "That app is no longer installed"
        }
        if (!EngineBridge.install(pkg, USER_ID)) {
            return "The engine couldn't run this app (some apps, for example ones installed as split APKs, may not be supported)"
        }
        val r = records(ctx).put(pkg, label)
        prefs(ctx).edit().putString("apps", r.toString()).apply()
        icon?.let {
            try { FileOutputStream(iconFile(ctx, pkg)).use { o -> it.compress(Bitmap.CompressFormat.PNG, 100, o) } } catch (_: Throwable) {}
        }
        return null
    }

    /** Main thread. */
    fun launch(activity: Activity, pkg: String): Boolean = EngineBridge.launch(activity, pkg, USER_ID)

    /** Removes the clone and all its data. Blocking (worker thread). */
    fun remove(ctx: Context, pkg: String): Boolean {
        // Without a running engine nothing can be erased, and it would wrongly look as if the clone was already gone.
        if (!ensureStarted(ctx)) return false
        val gone = EngineBridge.uninstall(pkg, USER_ID) || !EngineBridge.isInstalled(pkg, USER_ID)
        if (gone) {
            val r = records(ctx)
            r.remove(pkg)
            prefs(ctx).edit().putString("apps", r.toString()).apply()
            iconFile(ctx, pkg).delete()
        }
        return gone
    }

    /** Used when the vault is reset: wipes every clone. Runs in the background. */
    fun clearAll(ctx: Context) {
        val app = ctx.applicationContext
        val pkgs = records(app).keys().asSequence().toList() + gmsInstalled(app)
        prefs(app).edit().clear().apply()
        File(app.filesDir, ICON_DIR).deleteRecursively()
        if (pkgs.isNotEmpty()) Thread {
            if (ensureStarted(app)) pkgs.forEach { try { EngineBridge.uninstall(it, USER_ID) } catch (_: Throwable) {} }
        }.start()
    }
}
