package com.example.calculator

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

class MainActivity : Activity() {

    private var currentExpression = ""
    private var isShowingFinalResult = false
    private var currentPrecision = 35
    private var isInfiniteResult = false
    private var isScientificExpanded = false

    private val historyItems = mutableListOf<Pair<String, String>>()

    private lateinit var expressionScroll: HorizontalScrollView
    private lateinit var expressionText: TextView
    private lateinit var previewScroll: HorizontalScrollView
    private lateinit var previewText: TextView
    private lateinit var historyScroll: ScrollView
    private lateinit var historyContainer: LinearLayout
    private lateinit var scientificGrid: GridLayout
    private lateinit var toggleSciBtn: ImageButton

    private lateinit var fontDisplay: Typeface
    private lateinit var fontKey: Typeface
    private lateinit var fontOp: Typeface
    private lateinit var fontLabel: Typeface

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        loadCustomFonts()
        setContentView(buildCalculatorUI())
        setupInfiniteHorizontalScroll()
    }

    private fun loadCustomFonts() {
        fontDisplay = loadFontSafe("fonts/GoogleSansFlex-Display.ttf")
        fontKey = loadFontSafe("fonts/GoogleSansFlex-Key.ttf")
        fontOp = loadFontSafe("fonts/GoogleSansFlex-Op.ttf")
        fontLabel = loadFontSafe("fonts/GoogleSansFlex-Label.ttf")
    }

    private fun loadFontSafe(path: String): Typeface {
        return try {
            Typeface.createFromAsset(assets, path)
        } catch (e: Exception) {
            Typeface.DEFAULT
        }
    }

    private fun setupInfiniteHorizontalScroll() {
        // Infinite decimal loader on main expression display (after pressing '=')
        expressionScroll.viewTreeObserver.addOnScrollChangedListener {
            if (isShowingFinalResult && isInfiniteResult) {
                val child = expressionScroll.getChildAt(0) ?: return@addOnScrollChangedListener
                val maxScroll = child.width - expressionScroll.width
                if (maxScroll > 0 && expressionScroll.scrollX >= maxScroll - dp(60)) {
                    currentPrecision += 30
                    val expandedResult = Evaluator.evaluate(currentExpression, currentPrecision)
                    if (expandedResult.isNotEmpty()) {
                        expressionText.text = expandedResult
                    }
                }
            }
        }

        // Infinite decimal loader on live preview bar (before pressing '=')
        previewScroll.viewTreeObserver.addOnScrollChangedListener {
            if (!isShowingFinalResult && isInfiniteResult) {
                val child = previewScroll.getChildAt(0) ?: return@addOnScrollChangedListener
                val maxScroll = child.width - previewScroll.width
                if (maxScroll > 0 && previewScroll.scrollX >= maxScroll - dp(60)) {
                    currentPrecision += 30
                    val expandedPreview = Evaluator.evaluate(currentExpression, currentPrecision)
                    if (expandedPreview.isNotEmpty()) {
                        previewText.text = expandedPreview
                    }
                }
            }
        }
    }

    private fun buildCalculatorUI(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.parseColor("#111318"))
            layoutParams = ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        }

        // 1. Display Container (Top bar + Scrollable History + Horizontal Expression & Preview)
        val displayCard = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                setColor(Color.parseColor("#1E222B"))
                cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, dpF(28), dpF(28), dpF(28), dpF(28))
            }
            setPadding(dp(16), dp(12), dp(16), dp(16))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.15f
            )
        }

        // Top Bar (History & More icons)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
        }

        val historyBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_history)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.parseColor("#C4C6D0"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { toggleHistoryView() }
        }

        val moreBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_more_vert)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.parseColor("#C4C6D0"))
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener {
                historyItems.clear()
                refreshHistoryUI()
                Toast.makeText(this@MainActivity, "History cleared", Toast.LENGTH_SHORT).show()
            }
        }

        topBar.addView(historyBtn)
        topBar.addView(moreBtn)
        displayCard.addView(topBar)

        // Vertical Scrollable History List (Hidden by default, toggles on History button tap)
        historyContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
        }
        historyScroll = ScrollView(this).apply {
            visibility = View.GONE
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
            addView(historyContainer)
        }
        displayCard.addView(historyScroll)

        // Spacer pushes expression & preview to bottom of the display card
        val spacer = Space(this).apply {
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1f
            )
        }
        displayCard.addView(spacer)

        // Main Expression HorizontalScrollView
        expressionText = TextView(this).apply {
            typeface = fontDisplay
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 52f)
            setTextColor(Color.parseColor("#E2E2E9"))
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            setSingleLine(true)
        }
        expressionScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(expressionText)
        }
        displayCard.addView(expressionScroll)

        // Live Preview / Infinite Decimal Preview HorizontalScrollView
        previewText = TextView(this).apply {
            typeface = fontDisplay
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 28f)
            setTextColor(Color.parseColor("#8E9099"))
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            setSingleLine(true)
        }
        previewScroll = HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            isFillViewport = true
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            )
            addView(previewText)
        }
        displayCard.addView(previewScroll)

        root.addView(displayCard)

        // 2. Scientific Row + Expand/Collapse Bar
        val sciRowWrapper = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(8), dp(12), dp(4))
        }

        scientificGrid = GridLayout(this).apply {
            columnCount = 4
            layoutParams = LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f)
        }
        updateScientificButtons()

        toggleSciBtn = ImageButton(this).apply {
            setImageResource(R.drawable.ic_unfold_more)
            setBackgroundColor(Color.TRANSPARENT)
            setColorFilter(Color.parseColor("#C4C6D0"))
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setOnClickListener {
                isScientificExpanded = !isScientificExpanded
                setImageResource(
                    if (isScientificExpanded) R.drawable.ic_unfold_less
                    else R.drawable.ic_unfold_more
                )
                updateScientificButtons()
            }
        }

        sciRowWrapper.addView(scientificGrid)
        sciRowWrapper.addView(toggleSciBtn)
        root.addView(sciRowWrapper)

        // 3. Main Keypad Grid (5x4)
        val keypad = GridLayout(this).apply {
            rowCount = 5
            columnCount = 4
            setPadding(dp(10), dp(4), dp(10), dp(12))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                0,
                1.85f
            )
        }

        val buttons = listOf(
            "AC", "( )", "%", "÷",
            "7", "8", "9", "×",
            "4", "5", "6", "−",
            "1", "2", "3", "+",
            "0", ".", "⌫", "="
        )

        for (label in buttons) {
            val btnView = createKeypadButton(label)
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = 0
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                rowSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(dp(5), dp(5), dp(5), dp(5))
            }
            btnView.layoutParams = params
            keypad.addView(btnView)
        }

        root.addView(keypad)
        return root
    }

    private fun updateScientificButtons() {
        scientificGrid.removeAllViews()
        val basicSci = listOf("√", "π", "^", "!")
        val expandedSci = listOf("√", "π", "^", "!", "sin", "cos", "tan", "ln", "log", "e")
        val items = if (isScientificExpanded) expandedSci else basicSci

        for (label in items) {
            val btn = Button(this).apply {
                text = label
                typeface = fontLabel
                isAllCaps = false
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                setTextColor(Color.parseColor("#E2E2E9"))
                background = null
                setOnClickListener { onInput(label) }
            }
            val params = GridLayout.LayoutParams().apply {
                width = 0
                height = dp(40)
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
            }
            btn.layoutParams = params
            scientificGrid.addView(btn)
        }
    }

    private fun createKeypadButton(label: String): View {
        val bgColor = when (label) {
            "AC" -> Color.parseColor("#5C3F1E")
            "( )", "%", "÷", "×", "−", "+" -> Color.parseColor("#2B3548")
            "=" -> Color.parseColor("#004A77")
            else -> Color.parseColor("#1E222B")
        }

        val shape = GradientDrawable().apply {
            setColor(bgColor)
            cornerRadius = dpF(100)
        }

        if (label == "⌫") {
            return ImageButton(this).apply {
                setImageResource(R.drawable.ic_backspace)
                background = shape
                setColorFilter(Color.parseColor("#E2E2E9"))
                setOnClickListener { onBackspace() }
                setOnLongClickListener {
                    onClear()
                    true
                }
            }
        }

        return Button(this).apply {
            text = label
            isAllCaps = false
            typeface = if (label in listOf("÷", "×", "−", "+", "=")) fontOp else fontKey
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 26f)
            setTextColor(Color.parseColor("#E2E2E9"))
            background = shape
            setOnClickListener {
                when (label) {
                    "AC" -> onClear()
                    "=" -> onEquals()
                    "( )" -> onParenthesis()
                    else -> onInput(label)
                }
            }
        }
    }

    private fun onInput(token: String) {
        if (isShowingFinalResult) {
            if (token in listOf("+", "−", "×", "÷", "%", "^")) {
                // Continue operating on the evaluated result
                currentExpression = Evaluator.evaluate(currentExpression, 35)
            } else {
                currentExpression = ""
            }
            isShowingFinalResult = false
        }

        currentExpression += if (token in listOf("sin", "cos", "tan", "ln", "log")) "$token(" else token
        currentPrecision = 35
        updateDisplay(scrollToEnd = true)
    }

    private fun onParenthesis() {
        val openCount = currentExpression.count { it == '(' }
        val closeCount = currentExpression.count { it == ')' }
        val lastChar = currentExpression.lastOrNull()
        val shouldClose = openCount > closeCount && (lastChar?.isDigit() == true || lastChar == ')' || lastChar == 'π' || lastChar == 'e')
        onInput(if (shouldClose) ")" else "(")
    }

    private fun onBackspace() {
        if (isShowingFinalResult) {
            isShowingFinalResult = false
        }
        if (currentExpression.isNotEmpty()) {
            currentExpression = currentExpression.dropLast(1)
            currentPrecision = 35
            updateDisplay(scrollToEnd = true)
        }
    }

    private fun onClear() {
        currentExpression = ""
        isShowingFinalResult = false
        currentPrecision = 35
        isInfiniteResult = false
        expressionText.text = ""
        previewText.text = ""
    }

    private fun onEquals() {
        if (currentExpression.isBlank()) return
        currentPrecision = 35
        val evaluated = Evaluator.evaluate(currentExpression, currentPrecision)
        if (evaluated.isNotEmpty()) {
            isInfiniteResult = Evaluator.hasInfiniteDecimals(currentExpression, currentPrecision)
            historyItems.add(currentExpression to evaluated)
            refreshHistoryUI()

            isShowingFinalResult = true
            expressionText.text = evaluated
            previewText.text = if (isInfiniteResult) "Scroll right for more digits →" else ""

            // For infinite decimals like 1÷3 or π, start at the left (0.333...) so the user can scroll right
            expressionScroll.post {
                if (isInfiniteResult) {
                    expressionScroll.scrollTo(0, 0)
                } else {
                    expressionScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
                }
            }
        }
    }

    private fun updateDisplay(scrollToEnd: Boolean) {
        expressionText.text = currentExpression
        val preview = Evaluator.evaluate(currentExpression, currentPrecision)
        isInfiniteResult = Evaluator.hasInfiniteDecimals(currentExpression, currentPrecision)
        previewText.text = preview

        if (scrollToEnd) {
            expressionScroll.post {
                expressionScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
            }
            previewScroll.post {
                if (isInfiniteResult) {
                    previewScroll.scrollTo(0, 0)
                } else {
                    previewScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT)
                }
            }
        }
    }

    private fun toggleHistoryView() {
        historyScroll.visibility = if (historyScroll.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        if (historyScroll.visibility == View.VISIBLE) {
            historyScroll.post { historyScroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    private fun refreshHistoryUI() {
        historyContainer.removeAllViews()
        for ((expr, res) in historyItems) {
            val itemLayout = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.END
                setPadding(dp(8), dp(6), dp(8), dp(6))
                setOnClickListener {
                    currentExpression = expr
                    isShowingFinalResult = false
                    updateDisplay(scrollToEnd = true)
                }
            }
            val exprView = TextView(this).apply {
                text = expr
                typeface = fontDisplay
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                setTextColor(Color.parseColor("#8E9099"))
                gravity = Gravity.END
            }
            val resView = TextView(this).apply {
                text = "= $res"
                typeface = fontDisplay
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
                setTextColor(Color.parseColor("#E2E2E9"))
                gravity = Gravity.END
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }
            itemLayout.addView(exprView)
            itemLayout.addView(resView)
            historyContainer.addView(itemLayout)
        }
    }

    private fun dp(value: Int): Int =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        ).toInt()

    private fun dpF(value: Int): Float =
        TypedValue.applyDimension(
            TypedValue.COMPLEX_UNIT_DIP,
            value.toFloat(),
            resources.displayMetrics
        )
}
