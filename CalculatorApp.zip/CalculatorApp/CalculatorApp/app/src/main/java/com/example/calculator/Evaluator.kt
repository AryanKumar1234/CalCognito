package com.example.calculator

import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode
import kotlin.math.*

object Evaluator {

    fun evaluate(expression: String, precision: Int = 35): String {
        if (expression.isBlank()) return ""
        return try {
            val sanitized = expression
                .replace("×", "*")
                .replace("÷", "/")
                .replace("−", "-")
                .replace(",", "")
                .trim()

            val mc = MathContext(precision, RoundingMode.HALF_UP)
            val result = parseExpression(sanitized, mc)
            formatResult(result, precision)
        } catch (e: Exception) {
            ""
        }
    }

    // Checks if increasing precision produces additional decimal digits (e.g., 1÷3, π, √2)
    fun hasInfiniteDecimals(expression: String, currentPrecision: Int = 35): Boolean {
        val r1 = evaluate(expression, currentPrecision)
        val r2 = evaluate(expression, currentPrecision + 10)
        return r1.isNotEmpty() && r2.isNotEmpty() && r1.contains(".") && r2.length > r1.length
    }

    private fun formatResult(value: BigDecimal, precision: Int): String {
        val stripped = value.stripTrailingZeros()
        val plain = stripped.toPlainString()
        return if (plain.length > precision + 2 && plain.contains(".")) {
            value.round(MathContext(precision, RoundingMode.HALF_UP)).toPlainString()
        } else {
            plain
        }
    }

    private fun parseExpression(expr: String, mc: MathContext): BigDecimal {
        return object {
            var pos = -1
            var ch = 0

            fun nextChar() {
                ch = if (++pos < expr.length) expr[pos].code else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.code) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): BigDecimal {
                nextChar()
                val x = parseAddSub()
                if (pos < expr.length) throw RuntimeException("Unexpected: " + ch.toChar())
                return x
            }

            fun parseAddSub(): BigDecimal {
                var x = parseMulDiv()
                while (true) {
                    when {
                        eat('+'.code) -> x = x.add(parseMulDiv(), mc)
                        eat('-'.code) -> x = x.subtract(parseMulDiv(), mc)
                        else -> return x
                    }
                }
            }

            fun parseMulDiv(): BigDecimal {
                var x = parseFactor()
                while (true) {
                    when {
                        eat('*'.code) -> x = x.multiply(parseFactor(), mc)
                        eat('/'.code) -> {
                            val divisor = parseFactor()
                            if (divisor.compareTo(BigDecimal.ZERO) == 0) throw ArithmeticException("Div by 0")
                            x = x.divide(divisor, mc)
                        }
                        eat('%'.code) -> x = x.divide(BigDecimal(100), mc)
                        else -> return x
                    }
                }
            }

            fun parseFactor(): BigDecimal {
                if (eat('+'.code)) return parseFactor()
                if (eat('-'.code)) return parseFactor().negate(mc)

                var x: BigDecimal
                val startPos = pos

                if (eat('('.code)) {
                    x = parseAddSub()
                    eat(')'.code)
                } else if (ch == 'π'.code) {
                    nextChar()
                    x = computePi(mc.precision)
                } else if (ch == 'e'.code) {
                    nextChar()
                    x = BigDecimal(Math.E, mc)
                } else if (ch == '√'.code) {
                    nextChar()
                    x = bigSqrt(parseFactor(), mc)
                } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                    while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                    x = BigDecimal(expr.substring(startPos, pos), mc)
                } else if (ch in 'a'.code..'z'.code) {
                    while (ch in 'a'.code..'z'.code) nextChar()
                    val func = expr.substring(startPos, pos)
                    val arg = parseFactor().toDouble()
                    x = when (func) {
                        "sin" -> BigDecimal(sin(arg), mc)
                        "cos" -> BigDecimal(cos(arg), mc)
                        "tan" -> BigDecimal(tan(arg), mc)
                        "ln" -> BigDecimal(ln(arg), mc)
                        "log" -> BigDecimal(log10(arg), mc)
                        else -> throw RuntimeException("Unknown function: $func")
                    }
                } else {
                    throw RuntimeException("Unexpected: " + ch.toChar())
                }

                if (eat('^'.code)) {
                    val exp = parseFactor()
                    x = BigDecimal(x.toDouble().pow(exp.toDouble()), mc)
                }
                return x
            }
        }.parse()
    }

    // Newton-Raphson square root for arbitrary precision
    private fun bigSqrt(value: BigDecimal, mc: MathContext): BigDecimal {
        if (value.compareTo(BigDecimal.ZERO) == 0) return BigDecimal.ZERO
        if (value.signum() < 0) throw ArithmeticException("Negative sqrt")
        val two = BigDecimal.valueOf(2)
        var x = BigDecimal(sqrt(value.toDouble()), mc)
        for (i in 0 until 8) {
            x = x.add(value.divide(x, mc), mc).divide(two, mc)
        }
        return x
    }

    // Nilakantha / Machin-like formula for arbitrary-precision Pi
    private fun computePi(digits: Int): BigDecimal {
        val mc = MathContext(digits + 5, RoundingMode.HALF_UP)
        val four = BigDecimal.valueOf(4)
        val sixteen = BigDecimal.valueOf(16)
        return sixteen.multiply(arctanInverse(5, mc), mc)
            .subtract(four.multiply(arctanInverse(239, mc), mc), mc)
            .round(MathContext(digits, RoundingMode.HALF_UP))
    }

    private fun arctanInverse(inverseX: Int, mc: MathContext): BigDecimal {
        val x = BigDecimal.valueOf(inverseX.toLong())
        val xSquared = x.multiply(x, mc)
        var term = BigDecimal.ONE.divide(x, mc)
        var sum = term
        var n = 1
        while (term.abs().compareTo(BigDecimal.ONE.movePointLeft(mc.precision)) > 0) {
            term = term.divide(xSquared, mc)
            val divisor = BigDecimal.valueOf((2 * n + 1).toLong())
            val step = term.divide(divisor, mc)
            sum = if (n % 2 == 1) sum.subtract(step, mc) else sum.add(step, mc)
            n++
        }
        return sum
    }
}
