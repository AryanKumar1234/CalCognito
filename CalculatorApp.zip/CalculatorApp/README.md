# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI with round keys and warm Material You colors (light/dark follows system): basic + scientific (expand-arrow toggle: sin/cos/tan, ln/log, sqrt, x^y, x^2, n!, pi, e, Deg/Rad), calculation history (history icon, top left, or drag the display down; the sheet follows your finger, snaps open/closed, wraps long expressions and shows a scroll indicator), overflow menu (top right: deg/rad, clear history), landscape layout (scientific keys always visible, like Pixel Calculator), About screen in the vault (info icon, top right), implicit multiplication shown as typed (5√2, not 5×√(2), long-press result to copy, long-press expression to paste, Pixel-style context percent, thousands separators, Pixel-style adaptive launcher icon.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.13, AGP 8.11, JDK 17 or newer; targets Android 16 / API 36).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).


v1.1: multi-select in the vault (tap a thumbnail to select, long-press for Delete / Unhide / Move / Create folder), and a new video player with seek bar, play/pause, playback speed (0.5x–2x), double-tap skip/pause, swipe volume/brightness, hold for 2x, and a help button; Pixel-style dialogs throughout; Encrypt / Decrypt / Rename for selected vault files, add-menu (Upload / Folder), lock tile for encrypted files.

v1.2: built-in .txt viewer/editor in the vault (tap a .txt file to open; edits are saved automatically when you leave, share or encrypt/decrypt). All vault viewers now have a top bar with a back arrow (left), the file name (centre, first 18 characters + "..."), and a three-dot menu (right): Share, Encrypt/Decrypt, plus Unhide and Delete (red) in the text editor only.

v1.3: bolder (Medium) expression/result text and larger scientific key labels, like Google Calculator; irrational results (π, e, √2, ...) scroll pixel-smoothly as plain text with equal-width digits and a fixed "E-n" counter showing how many digits are in view, extra digits are computed on a background thread (π/e/√ use fast binary-splitting, so 100,000 digits take well under a second) and the old 1200-digit limit is gone (new limit: 100,000 digits).

- Calculator engine: `-2^2` = -4, exact sin/cos/tan at special angles (sin 30° = 0.5, tan 45° = 1, sin π = 0), "Can't calculate" for domain errors (tan 90°, √-1, ln 0), and `%` now works after a bracket or function, e.g. `(50+50)+10%`.

First launch: an animated, dynamically themed "How to use" guide shows how to set the vault password (type 1234, hold = for 3 seconds, enter 1234 again, vault opens). It can be replayed any time from the ⋮ menu → How to use. The guide has five slides you can swipe (or jump to with the dots); the last one, in red, is **Forgot PIN?**: type 0000, hold = for 3 seconds, press = to confirm. That erases every vault file and relaunches the app.

Large files: adding to the vault shows a Pixel-style "Adding…" card with a progress ring (instantly for 100 MB+ or unknown sizes, after a short delay for small ones) that turns into a tick and fades away. Plain files now open in other apps instantly (hard link instead of a full copy), and slow opens/shares/encrypted-video decrypts show a wavy "Opening…" card with live progress (back cancels).

Background transfers (v1.3). Adding files to the vault, unhiding them, and encrypting / decrypting them (the card appears straight away for 100 MB+ in total) now use the same wavy progress card as "Opening…", with **Cancel** and **Hide** buttons (back = Hide).
- Hide closes the card only; the transfer keeps running, and the card comes back if you reopen the vault while it is still going.
- The work runs in a foreground service (`TransferService`), so it carries on when you leave or close the app. Jobs queue up and run one at a time; a partial wake lock keeps the CPU awake while the screen is off.
- Cancel stops cleanly: the half-written file is deleted, the original stays untouched, and files already finished stay done. Adding, encrypting and decrypting write to a hidden `.part` file and rename it only when complete, so an interrupted job never leaves a half-finished file in the vault (leftovers are cleaned on the next launch). Encrypting / decrypting also keeps the "original folder" record, so Unhide still restores to where the file came from.
- The notification is deliberately bland ("Calculator - Working… 42%", hidden on the lock screen, with a Cancel action); it never mentions the vault or file names. Android 13+ asks for notification permission once; transfers run either way. Results (and Android's "delete the originals?" prompt) wait until the vault is opened again if the transfer finished while you were away.
- Code: `TransferManager` (queue + worker thread), `TransferService`, `TransferJobs` (the add / unhide / encrypt / decrypt work), `PixelProgressDialog` (buttons).

Expand animation (v1.3). The scientific keys now animate like Pixel Calculator: in portrait (phone and tablet) the extra rows grow from a flat sliver while the whole keypad squeezes together and the key labels shrink with the keys; in landscape (phone and tablet) the scientific panel slides open sideways. One progress value drives all layouts (`animateSci` / `applySciProgress`), tapping again mid-way reverses smoothly, and rotation or window resizing keeps the state.

0000 is reserved and cannot be set as a password. Confirming Forgot PIN plays the same red erase/relaunch animation as the guide, and the relaunched app shows the How to use guide again.

Forgot PIN (v1.3). Holding = on "0000" (when 0000 is not the real PIN) now shows the confirmation inside the calculator's result line, in red ("Press = to erase & reset PIN"), like the "Enter new password" prompt, instead of a popup. Pressing = erases the PIN and all vault files and relaunches the app; any other key (or leaving the app) cancels.

Package name changed to `com.onion.calcognito`. Android treats this as a different app: it installs next to the old `com.android.calcognito` build and does not see its vault, so unhide or export anything you need from the old app first.


v1.4: swipe through the vault, like Photos.
- **"Hidden-app engine didn't start".** If the engine is inside the build but fails when the app starts, tapping Hide app now shows the actual error (also written to logcat with the tag `CalEngine`) instead of claiming the engine is missing. The usual cause is a library the engine needs that is not inside its AAR; the CI log's "runtime dependencies" section lists them.
- **Search.** The magnifier in the vault header opens a search bar that filters by name across the whole vault, every folder at once, together with the tab you are on (All / Images / Videos / Files) and hidden apps. Results say which folder they are in, tab counts follow the search, and back or the clear button closes it.
- **Random video thumbnails.** Videos that are not encrypted show a frame from a random moment (between 5% and 95% of the video), picked again each time the vault is opened and kept steady while it stays open. The stored thumbnail is shown until the frame is ready. Encrypted videos keep their lock icon, so nothing readable is shown.
- **About screen** now says whether this build's hidden-app engine is running, failed to start, or is not in the build at all.
- **Screenshots and screen recording are allowed** everywhere, including the vault and the viewer (the secure-window flag is no longer set; `setSecure` and `applySecurityFlags` only clear it).
- **Vault look.** A gradient summary card at the top (item count, total size, folders, hidden apps, and an Images / Videos / Files bar), files and folders as rounded cards with bigger rounded thumbnails and a lock badge on encrypted files, section labels, tab chips with counts (All · 12), a pill Close button, rows that fade in one after another when a folder opens, a press-down effect on rows, and friendly empty states. The + button turns into an x with a quarter turn and its options pop up one by one. Code: `renderVaultPage` and the helpers above it in `MainActivity`.
- **Hidden apps look.** Inside the Apps folder the hidden apps are a launcher-style grid of rounded icons (tap to open, hold for options) ending with a dashed **Hide app** tile. "Hide app" opens a picker with a search box and rounded icons, and the confirmation shows the app's icon. Code: `appGrid` / `appTile`, `showAppPicker`, `confirmHideApp`.
- **Built-in file picker** (vault > + > Upload). A full-screen file browser instead of Android's picker: folders with thumbnails, quick chips for Internal storage / SD card / Download / DCIM / Pictures / Movies / Music / Documents, Sort (A-Z, Newest, Largest), and a select-all button for the open folder. Tap files to tick them (the ticks stay while you move between folders; a **Clear (N)** chip empties them), then press the round **tick button at the bottom right** to add them. The usual "Add N file(s)" confirmation (with the Encrypt option) follows, and originals are moved into the vault and removed, like before. Back goes up a folder; at the top it asks to press back again if files are still ticked.
  - **Permission.** Browsing real folders needs **All files access** on Android 11+ (`MANAGE_EXTERNAL_STORAGE`, now in the manifest) or the normal storage permission on Android 9 and older. The first time, a dialog explains this and offers **Open settings** or **System picker**; if access is declined the app keeps using Android's own picker, which also stays available from a **System picker** chip. Android 10 has no way to allow browsing, so it always uses the system picker. Because of the permission, this build is for sideloading (it would need Play's all-files declaration to be published there).
  - Picked files are passed to the existing add job as `file://` URIs: `VaultManager.resolveOriginalLocation` records the folder for Unhide, `tryDeleteOriginal` deletes the file and rescans it out of the gallery. Code: `FilePicker.kt`, `pickFileForVault` / `showFilePicker` in `MainActivity`.
- **Selection mode** (select a file in the vault): the "i" button at the top right turns into a three-dot menu with **Select all** and **Invert selection**. Both act on the files shown on the current tab of the open folder. When the selection ends the "i" (About) comes back. Code: `updateVaultInfoButton`, `selectAllVisible`, `invertSelection`, `showSelectionMenu`.
- The vault's file list is now a pager: swipe left / right to move between **All, Images, Videos and Files** (the list follows your finger; tapping a chip slides to that tab too). Each tab scrolls up and down on its own, and a selection is carried over only for the files that exist on the tab you land on.
- Opening an image or video now opens a gallery of the images and videos in the list you opened it from (same tab, same sort order): **swipe left / right to go to the next / previous one**, with a small gap between pages. Zoomed-in images keep their pan until you reach the image's edge, then the next swipe changes page. The title and the three-dot menu always act on the file you are looking at.
- Videos show their thumbnail while you swipe and start playing only once the page has settled; the one you left stops (and its temporary decrypted copy is deleted). Encrypted videos decrypt inside their page with a progress ring, and swiping away cancels it. Scrubbing the seek bar, holding for 2x and the brightness / volume drags never turn into a page swipe.
- Code: `VaultTabsAdapter` / `renderVaultPage` (tabs), `showGallery` / `GalleryAdapter` / `GalleryPage` / `buildPlayerView` (viewer). Uses `androidx.viewpager2` (already pulled in by Material; now listed explicitly).

v1.5: new video / audio player and hidden apps.

**Player (Media3 ExoPlayer instead of Android's VideoView).** Plays MP4, MKV, WebM, MOV, 3GP, TS, FLV, MPEG-PS, MP3, AAC, FLAC, OGG / Opus, WAV, AMR, MIDI and more (the exact list is whatever your phone's codecs + ExoPlayer can decode). Controls, VLC / MX style:
- Seek bar, play / pause, -10 s / +10 s buttons, double-tap left / right to skip, double-tap centre to pause, hold for 2x.
- Speed 0.25x - 4x with natural pitch.
- **Audio** (pick the audio track) and **Subtitles** (embedded tracks, or Off). A `.srt` / `.vtt` / `.ass` / `.ssa` / `.ttml` file with the same name in the same vault folder (e.g. `Movie.mp4` + `Movie.en.srt`) loads automatically.
- **Fit / Fill / Zoom**, **Loop**, **Rotate**, **Lock** (ignores touches until you tap Unlock).
- Swipe right side = volume, and keep going past 100% to boost up to 200%; swipe left side = brightness.
- Audio-only files get a music-note screen; the controls stay visible.
- **Auto-hiding controls.** While a video plays, the controls, the chip row and the viewer's title bar (back arrow, name, menu) fade away together after 3 seconds. One tap on the picture brings them back or hides them again (playing or paused). They stay up while the title-bar menu is open, while you drag the seek bar, and after a swipe to another file. Lock hides them too. Everything fades / slides instead of snapping; play <-> pause pops, buttons dip when pressed, the seek thumb glides, and the poster cross-fades into the first frame. Code: `setChrome` / `scheduleHide` in `buildPlayerView`, `animateShown`, `viewerChrome` and the title bar in `showViewer`.
- If a file can't be decoded (e.g. AVI / WMV, or a DTS audio track on a phone without that codec) a dialog offers **Open with** another player app (VLC, MX Player...).
- More extensions are now recognised as audio / video when you add them to the vault (see `VaultManager.EXTRA_MIME`).
- Code: `buildPlayerView`, `sidecarSubtitles` in `MainActivity`.

**Hidden apps** (add menu -> **Hide app**). Android does not allow an app to run another app inside itself, or to uninstall another app silently, so this works as an archive:
1. Pick an app. Its APK files (base + splits) are packed into one encrypted `<App>.apks` file in the vault's pre-created **Apps** folder (the folder can't be renamed or deleted).
2. Android shows its own "Uninstall?" screen for the original; you confirm.
3. Tap the app in the Apps folder -> **Install & open**: it is installed from the vault (Android asks to confirm; the first time you must allow this app under "Install unknown apps") and launched. While installed it shows on the home screen; **Hide again** uninstalls it again.
- The app's **data is not kept** (logins, chats, game saves are private to that app and can't be copied). A re-installed app starts fresh.
- Only apps you installed yourself can be hidden (not system apps). Apps that Android refuses to read, or that you cancel the uninstall for, stay installed.
- Code: `HiddenApps.kt` + the "Hidden apps" section of `MainActivity`. New manifest permissions: `REQUEST_INSTALL_PACKAGES`, `REQUEST_DELETE_PACKAGES`, and a `<queries>` entry for launcher apps.

## Updates

About (info icon) → **Check for updates** asks the GitHub API for the latest release of
`AryanKumar1234/CalCognito`. If its tag (e.g. `v1.7`) is newer than the installed version and the release has an `.apk`
attached, an "Update available" dialog shows the release notes. Tapping **Update** downloads the APK and hands it to
Android's installer (needs the "Install unknown apps" switch for this app; the app sends you to that screen if it is off).

To publish an update: raise `versionCode` / `versionName` in `app/build.gradle.kts`, build an APK signed with the **same
key** as the installed app (the committed `debug.keystore` does this), and attach it to a new GitHub release tagged with
the new version number.

## Hidden apps (Parallel Space style)

**The engine starts on first use, not when the app opens.** Its low-level hooks can crash some phones (seen on Android 16), and a native crash can't be caught, so starting it in `Application.onCreate` could make the whole app crash every time it opens. `CalApp` therefore starts it only in the processes the engine creates for hidden apps; the main process starts it the first time you tap Hide app, open a hidden app or set up Google services (`EngineBridge.start`, always off the main thread). `start` writes a marker first. If the app dies while that marker is set, the next launch (`checkPreviousCrash`) switches the engine off and says so (a "Try again" button resets it), and the calculator keeps opening normally.

**Crash report.** `CrashReport` writes down Java crashes and, on Android 11+, reads Android's own exit records for native crashes and not-responding errors. The next time the app opens it shows what it found (selectable, with a Copy button). Send that text to get the real cause of a crash fixed.

**Google Play services (experimental).** Apps that sign in with Google, use push notifications, Maps or in-app purchases talk to Google Play services; inside the space they are seen under this app's identity, so the phone's own copy often refuses them. Like Parallel Space / VirtualApp, the Apps folder has a **Google Play services** card (and the Hide app dialog offers it for apps that use Google services) that copies Google Play services, the Services Framework and the Play Store from the phone into the hidden space (`VirtualSpace.enableGms`). Limits: the phone must have Play services; it depends on the engine being able to copy them (many phones install Play services in several parts, which the engine may not support); it needs extra storage; signing in happens separately inside the space. Not available on phones without Google services.

**Why an engine AAR alone is not enough.** The engine module (`Bcore`) depends on other modules and libraries of its repository: `:black-reflection` (the `top.niunaijun.blackreflection` classes), FreeReflection and the hidden-API bypass. An AAR does not contain them, so an app that only gets the AAR crashes when the engine starts, with `NoClassDefFoundError ... BlackReflection` (the app shows this under "Hidden-app engine didn't start"). `scripts/build_engine.sh` therefore also exports those libraries next to the AAR as `app/libs/engine-dep-*.jar` / `.aar` (via `scripts/export-engine-deps.init.gradle`; runtime libraries only), builds the `black-reflection` module directly if the export misses it, and stops with an error if `BlackReflection` is still not there. `app/build.gradle.kts` adds every jar and aar in `app/libs`, and the workflow fails unless `BlackReflection` is inside the finished APK. Source for this: the engine's own build files (`Bcore` depends on `:black-reflection` and FreeReflection; modules `app`, `Bcore`, `black-reflection`, `compiler`).


**Vault → + → Hide app** clones an installed app into a hidden space that runs *inside* this app through an embedded
virtual engine ([BlackBox](https://github.com/ALEX5402/NewBlackbox)). The app is not installed on the phone and is not
archived or re-installed; it appears at the top of the vault's **Apps** folder, where you open it (tap) or remove it
(⋮ / long-press). After cloning you can optionally uninstall the original so the app only exists in here.

The engine is native code and has to be built once (it is not on Maven):

1. Install JDK 21 (the engine needs it; the app itself compiles for Java 17), the Android SDK and the NDK version the engine README asks for.
2. Run `./scripts/build_engine.sh` (or build the engine's `Bcore` module yourself and copy the AAR to `app/libs/`).
   No NDK on your machine? Push to GitHub instead: `.github/workflows/build.yml` builds the engine AAR (cached after the
   first run) and then the app, and attaches both the APK and `blackbox-core.aar` as workflow artifacts.
3. Rebuild the app. With an AAR in `app/libs` Gradle compiles `src/engine`, otherwise `src/noengine`, so the app still
   builds without the engine; Hide app then explains that the engine is missing.

If the engine's classes live in other packages than `top.niunaijun.blackbox`, change the two imports in
`app/src/engine/java/.../EngineBridge.kt`. If the engine AAR is not self-contained, add the dependencies listed in its
`build.gradle` to `app/build.gradle.kts`. A virtual engine's notes apply: the clone starts signed out, apps that depend
on Google Play services or use split APKs can fail, and its authors advise a low `targetSdkVersion` for best compatibility.

The old encrypted `.apks` entries from earlier versions still open and re-install as before.
