# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI with round keys and warm Material You colors (light/dark follows system): basic + scientific (expand-arrow toggle: sin/cos/tan, ln/log, sqrt, x^y, x^2, n!, pi, e, Deg/Rad), calculation history (history icon, top left), overflow menu (top right: deg/rad, clear history), landscape layout (scientific keys always visible, like Pixel Calculator), About screen in the vault (info icon, top right), implicit multiplication shown as typed (5√2, not 5×√(2), long-press result to copy, long-press expression to paste, Pixel-style context percent, thousands separators, Pixel-style adaptive launcher icon.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.7, JDK 17).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).
