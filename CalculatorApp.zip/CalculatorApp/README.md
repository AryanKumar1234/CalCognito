# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI with round keys and warm Material You colors (light/dark follows system): basic + scientific (expand-arrow toggle: sin/cos/tan, ln/log, sqrt, x^y, x^2, n!, pi, e, Deg/Rad), calculation history (history icon, top left, or drag the display down; the sheet follows your finger, snaps open/closed, wraps long expressions and shows a scroll indicator), overflow menu (top right: deg/rad, clear history), landscape layout (scientific keys always visible, like Pixel Calculator), About screen in the vault (info icon, top right), implicit multiplication shown as typed (5√2, not 5×√(2), long-press result to copy, long-press expression to paste, Pixel-style context percent, thousands separators, Pixel-style adaptive launcher icon.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.13, AGP 8.11, JDK 17; targets Android 16 / API 36).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).


v1.1: multi-select in the vault (tap a thumbnail to select, long-press for Delete / Unhide / Move / Create folder), and a new video player with seek bar, play/pause, playback speed (0.5x–2x), double-tap skip/pause, swipe volume/brightness, hold for 2x, and a help button; Pixel-style dialogs throughout; Encrypt / Decrypt / Rename for selected vault files, add-menu (Upload / Folder), lock tile for encrypted files.

v1.2: built-in .txt viewer/editor in the vault (tap a .txt file to open; edits are saved automatically when you leave, share or encrypt/decrypt). All vault viewers now have a top bar with a back arrow (left), the file name (centre, first 18 characters + "..."), and a three-dot menu (right): Share, Encrypt/Decrypt, plus Unhide and Delete (red) in the text editor only.

v1.3: bolder (Medium) expression/result text and larger scientific key labels, like Google Calculator; irrational results (π, e, √2, ...) scroll pixel-smoothly as plain text with equal-width digits, extra digits are computed on a background thread (π/e/√ use fast binary-splitting, so 100,000 digits take well under a second) and the old 1200-digit limit is gone (new limit: 100,000 digits).

- Calculator engine: `-2^2` = -4, exact sin/cos/tan at special angles (sin 30° = 0.5, tan 45° = 1, sin π = 0), "Can't calculate" for domain errors (tan 90°, √-1, ln 0), and `%` now works after a bracket or function, e.g. `(50+50)+10%`.
