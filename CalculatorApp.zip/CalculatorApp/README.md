# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI (light/dark follows system): basic + scientific (fx toggle: sin/cos/tan, ln/log, sqrt, x^y, x^2, n!, pi, e, Deg/Rad), calculation history (tap clock icon), long-press result to copy, long-press expression to paste, Pixel-style context percent, thousands separators, Pixel-style adaptive launcher icon.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.7, JDK 17).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).
