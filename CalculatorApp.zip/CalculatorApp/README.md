# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI with round keys and warm Material You colors (light/dark follows system): basic + scientific (expand-arrow toggle: sin/cos/tan, ln/log, sqrt, x^y, x^2, n!, pi, e, Deg/Rad), calculation history (history icon, top left, or drag the display down; the sheet follows your finger, snaps open/closed, wraps long expressions and shows a scroll indicator), overflow menu (top right: deg/rad, clear history), landscape layout (scientific keys always visible, like Pixel Calculator), About screen in the vault (info icon, top right), implicit multiplication shown as typed (5√2, not 5×√(2), long-press result to copy, long-press expression to paste, Pixel-style context percent, thousands separators, Pixel-style adaptive launcher icon.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.13, AGP 8.11, JDK 17; targets Android 16 / API 36).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).


v1.1: multi-select in the vault (tap a thumbnail to select, long-press for Delete / Unhide / Move / Create folder), and a new video player with seek bar, play/pause, playback speed (0.5x–2x), double-tap skip/pause, swipe volume/brightness, hold for 2x, and a help button; Pixel-style dialogs throughout; Encrypt / Decrypt / Rename for selected vault files, add-menu (Upload / Folder), lock tile for encrypted files.

v1.2: built-in .txt viewer/editor in the vault (tap a .txt file to open; edits are saved automatically when you leave, share or encrypt/decrypt). All vault viewers now have a top bar with a back arrow (left), the file name (centre, first 18 characters + "..."), and a three-dot menu (right): Share, Encrypt/Decrypt, plus Unhide and Delete (red) in the text editor only.

v1.3: bolder (Medium) expression/result text and larger scientific key labels, like Google Calculator; irrational results (π, e, √2, ...) scroll pixel-smoothly as plain text with equal-width digits and a fixed "E-n" counter showing how many digits are in view, extra digits are computed on a background thread (π/e/√ use fast binary-splitting, so 100,000 digits take well under a second) and the old 1200-digit limit is gone (new limit: 100,000 digits).

- Calculator engine: `-2^2` = -4, exact sin/cos/tan at special angles (sin 30° = 0.5, tan 45° = 1, sin π = 0), "Can't calculate" for domain errors (tan 90°, √-1, ln 0), and `%` now works after a bracket or function, e.g. `(50+50)+10%`.

First launch: an animated, dynamically themed "How to use" guide shows how to set the vault password (type 1234, hold = for 3 seconds, enter 1234 again, vault opens). It can be replayed any time from the ⋮ menu → How to use. The guide has five slides you can swipe (or jump to with the dots); the last one, in red, is **Forgot PIN?**: type 0000, hold = for 3 seconds, press = to confirm. That erases every vault file and relaunches the app.

Large files: adding to the vault shows a Pixel-style "Adding…" card with a progress ring (instantly for 100 MB+ or unknown sizes, after a short delay for small ones) that turns into a tick and fades away. Plain files now open in other apps instantly (hard link instead of a full copy), and slow opens/shares/encrypted-video decrypts show a wavy "Opening…" card with live progress (back cancels).

Background transfers (v1.3). Adding files to the vault, unhiding them, and encrypting / decrypting them (the card appears straight away for 100 MB+ in total) now use the same wavy progress card as "Opening…", with **Cancel** and **Hide** buttons (back = Hide).
- Hide closes the card only; the transfer keeps running, and the card comes back if you reopen the vault while it is still going.
- The work runs in a foreground service (`TransferService`), so it carries on when you leave or close the app. Jobs queue up and run one at a time; a partial wake lock keeps the CPU awake while the screen is off.
- Cancel stops cleanly: the half-written file is deleted, the original stays untouched, and files already finished stay done. Adding, encrypting and decrypting write to a hidden `.part` file and rename it only when complete, so an interrupted job never leaves a half-finished file in the vault (leftovers are cleaned on the next launch). Encrypting / decrypting also keeps the "original folder" record, so Unhide still restores to where the file came from.
- The notification is deliberately bland ("Calculator - Working… 42%", hidden on the lock screen, with a Cancel action); it never mentions the vault or file names. Android 13+ asks for notification permission once; transfers run either way. Results (and Android's "delete the originals?" prompt) wait until the vault is opened again if the transfer finished while you were away.
- Code: `TransferManager` (queue + worker thread), `TransferService`, `TransferJobs` (the add / unhide / encrypt / decrypt work), `PixelProgressDialog` (buttons).

Expand animation (v1.3). The scientific keys now animate like Pixel Calculator: in portrait (phone and tablet) the extra rows grow from a flat sliver while the whole keypad squeezes together and the key labels shrink with the keys; in landscape (phone and tablet) the scientific panel slides open sideways. One progress value drives all layouts (`animateSci` / `applySciProgress`), tapping again mid-way reverses smoothly, and rotation or window resizing keeps the state.

0000 is reserved and cannot be set as a password. Confirming Forgot PIN plays the same red erase/relaunch animation as the guide, and the relaunched app shows the How to use guide again.

Forgot PIN (v1.3). Holding = on "0000" (when 0000 is not the real PIN) now shows the confirmation inside the calculator's result line, in red ("Press = to erase & reset PIN"), like the "Enter new password" prompt, instead of a popup. Pressing = erases the PIN and all vault files and relaunches the app; any other key (or leaving the app) cancels.

Package name changed to `com.onion.calcognito`. Android treats this as a different app: it installs next to the old `com.android.calcognito` build and does not see its vault, so unhide or export anything you need from the old app first.


v1.4: swipe through the vault, like Photos.
- The vault's file list is now a pager: swipe left / right to move between **All, Images, Videos and Files** (the list follows your finger; tapping a chip slides to that tab too). Each tab scrolls up and down on its own, and a selection is carried over only for the files that exist on the tab you land on.
- Opening an image or video now opens a gallery of the images and videos in the list you opened it from (same tab, same sort order): **swipe left / right to go to the next / previous one**, with a small gap between pages. Zoomed-in images keep their pan until you reach the image's edge, then the next swipe changes page. The title and the three-dot menu always act on the file you are looking at.
- Videos show their thumbnail while you swipe and start playing only once the page has settled; the one you left stops (and its temporary decrypted copy is deleted). Encrypted videos decrypt inside their page with a progress ring, and swiping away cancels it. Scrubbing the seek bar, holding for 2x and the brightness / volume drags never turn into a page swipe.
- Code: `VaultTabsAdapter` / `renderVaultPage` (tabs), `showGallery` / `GalleryAdapter` / `GalleryPage` / `buildPlayerView` (viewer). Uses `androidx.viewpager2` (already pulled in by Material; now listed explicitly).

v1.5: new video / audio player and hidden apps.

**Player (Media3 ExoPlayer instead of Android's VideoView).** Plays MP4, MKV, WebM, MOV, 3GP, TS, FLV, MPEG-PS, MP3, AAC, FLAC, OGG / Opus, WAV, AMR, MIDI and more (the exact list is whatever your phone's codecs + ExoPlayer can decode). Controls, VLC / MX style:
- Seek bar, play / pause, -10 s / +10 s buttons, double-tap left / right to skip, double-tap centre to pause, hold for 2x.
- Speed 0.25x - 4x with natural pitch.
- **Audio** (pick the audio track) and **Subtitles** (embedded tracks, or Off). A `.srt` / `.vtt` / `.ass` / `.ssa` / `.ttml` file with the same name in the same vault folder (e.g. `Movie.mp4` + `Movie.en.srt`) loads automatically.
- **Fit / Fill / Zoom**, **Loop**, **Rotate**, **Lock** (ignores touches until you tap Unlock).
- Swipe right side = volume, and keep going past 100% to boost up to 200%; swipe left side = brightness.
- Audio-only files get a music-note screen; the controls stay visible.
- If a file can't be decoded (e.g. AVI / WMV, or a DTS audio track on a phone without that codec) a dialog offers **Open with** another player app (VLC, MX Player...).
- More extensions are now recognised as audio / video when you add them to the vault (see `VaultManager.EXTRA_MIME`).
- Code: `buildPlayerView`, `sidecarSubtitles` in `MainActivity`.

**Hidden apps** (add menu -> **Hide app**). Android does not allow an app to run another app inside itself, or to uninstall another app silently, so this works as an archive:
1. Pick an app. Its APK files (base + splits) are packed into one encrypted `<App>.apks` file in the vault's pre-created **Apps** folder (the folder can't be renamed or deleted).
2. Android shows its own "Uninstall?" screen for the original; you confirm.
3. Tap the app in the Apps folder -> **Install & open**: it is installed from the vault (Android asks to confirm; the first time you must allow this app under "Install unknown apps") and launched. While installed it shows on the home screen; **Hide again** uninstalls it again.
- The app's **data is not kept** (logins, chats, game saves are private to that app and can't be copied). A re-installed app starts fresh.
- Only apps you installed yourself can be hidden (not system apps). Apps that Android refuses to read, or that you cancel the uninstall for, stay installed.
- Code: `HiddenApps.kt` + the "Hidden apps" section of `MainActivity`. New manifest permissions: `REQUEST_INSTALL_PACKAGES`, `REQUEST_DELETE_PACKAGES`, and a `<queries>` entry for launcher apps.

## Updates

About (info icon) → **Check for updates** asks the GitHub API for the latest release of
`AryanKumar1234/CalCognito`. If its tag (e.g. `v1.7`) is newer than the installed version and the release has an `.apk`
attached, an "Update available" dialog shows the release notes. Tapping **Update** downloads the APK and hands it to
Android's installer (needs the "Install unknown apps" switch for this app; the app sends you to that screen if it is off).

To publish an update: raise `versionCode` / `versionName` in `app/build.gradle.kts`, build an APK signed with the **same
key** as the installed app (the committed `debug.keystore` does this), and attach it to a new GitHub release tagged with
the new version number.

## Hidden apps (Parallel Space style)

**Vault → + → Hide app** clones an installed app into a hidden space that runs *inside* this app through an embedded
virtual engine ([BlackBox](https://github.com/ALEX5402/NewBlackbox)). The app is not installed on the phone and is not
archived or re-installed; it appears at the top of the vault's **Apps** folder, where you open it (tap) or remove it
(⋮ / long-press). After cloning you can optionally uninstall the original so the app only exists in here.

The engine is native code and has to be built once (it is not on Maven):

1. Install JDK 17, the Android SDK and the NDK version the engine README asks for.
2. Run `./scripts/build_engine.sh` (or build the engine's `Bcore` module yourself and copy the AAR to `app/libs/`).
3. Rebuild the app. With an AAR in `app/libs` Gradle compiles `src/engine`, otherwise `src/noengine`, so the app still
   builds without the engine; Hide app then explains that the engine is missing.

If the engine's classes live in other packages than `top.niunaijun.blackbox`, change the two imports in
`app/src/engine/java/.../EngineBridge.kt`. If the engine AAR is not self-contained, add the dependencies listed in its
`build.gradle` to `app/build.gradle.kts`. A virtual engine's notes apply: the clone starts signed out, apps that depend
on Google Play services or use split APKs can fail, and its authors advise a low `targetSdkVersion` for best compatibility.

The old encrypted `.apks` entries from earlier versions still open and re-install as before.
