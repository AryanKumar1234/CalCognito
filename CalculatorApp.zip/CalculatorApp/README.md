# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI (light/dark follows system): + − × ÷ % ( ), AC, backspace (long-press = clear), thousands separators, live result preview.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.7, JDK 17).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).
