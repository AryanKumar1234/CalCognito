# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI with round keys and warm Material You colors (light/dark follows system): basic + scientific (expand-arrow toggle: sin/cos/tan, ln/log, sqrt, x^y, x^2, n!, pi, e, Deg/Rad), calculation history (history icon, top left, or drag the display down; the sheet follows your finger, snaps open/closed, wraps long expressions and shows a scroll indicator), overflow menu (top right: deg/rad, clear history), landscape layout (scientific keys always visible, like Pixel Calculator), About screen in the vault (info icon, top right), implicit multiplication shown as typed (5√2, not 5×√(2), long-press result to copy, long-press expression to paste, Pixel-style context percent, thousands separators, Pixel-style adaptive launcher icon.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.13, AGP 8.11, JDK 17; targets Android 16 / API 36).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).


v1.1: multi-select in the vault (tap a thumbnail to select, long-press for Delete / Unhide / Move / Create folder), and a new video player with seek bar, play/pause, playback speed (0.5x–2x), double-tap skip/pause, swipe volume/brightness, hold for 2x, and a help button; Pixel-style dialogs throughout; Encrypt / Decrypt / Rename for selected vault files, add-menu (Upload / Folder), lock tile for encrypted files.

v1.2: built-in .txt viewer/editor in the vault (tap a .txt file to open; edits are saved automatically when you leave, share or encrypt/decrypt). All vault viewers now have a top bar with a back arrow (left), the file name (centre, first 18 characters + "..."), and a three-dot menu (right): Share, Encrypt/Decrypt, plus Unhide and Delete (red) in the text editor only.

v1.3: bolder (Medium) expression/result text and larger scientific key labels, like Google Calculator; irrational results (π, e, √2, ...) scroll pixel-smoothly as plain text with equal-width digits and a fixed "E-n" counter showing how many digits are in view, extra digits are computed on a background thread (π/e/√ use fast binary-splitting, so 100,000 digits take well under a second) and the old 1200-digit limit is gone (new limit: 100,000 digits).

- Calculator engine: `-2^2` = -4, exact sin/cos/tan at special angles (sin 30° = 0.5, tan 45° = 1, sin π = 0), "Can't calculate" for domain errors (tan 90°, √-1, ln 0), and `%` now works after a bracket or function, e.g. `(50+50)+10%`.

First launch: an animated, dynamically themed "How to use" guide shows how to set the vault password (type 1234, hold = for 3 seconds, enter 1234 again, vault opens). It can be replayed any time from the ⋮ menu → How to use. The guide has five slides you can swipe (or jump to with the dots); the last one, in red, is **Forgot PIN?**: type 0000, hold = for 3 seconds, press = to confirm. That erases every vault file and relaunches the app.

Large files: adding to the vault shows a Pixel-style "Adding…" card with a progress ring (instantly for 100 MB+ or unknown sizes, after a short delay for small ones) that turns into a tick and fades away. Plain files now open in other apps instantly (hard link instead of a full copy), and slow opens/shares/encrypted-video decrypts show a wavy "Opening…" card with live progress (back cancels).

Background transfers (v1.3). Adding files to the vault, unhiding them, and encrypting / decrypting them (the card appears straight away for 100 MB+ in total) now use the same wavy progress card as "Opening…", with **Cancel** and **Hide** buttons (back = Hide).
- Hide closes the card only; the transfer keeps running, and the card comes back if you reopen the vault while it is still going.
- The work runs in a foreground service (`TransferService`), so it carries on when you leave or close the app. Jobs queue up and run one at a time; a partial wake lock keeps the CPU awake while the screen is off.
- Cancel stops cleanly: the half-written file is deleted, the original stays untouched, and files already finished stay done. Adding, encrypting and decrypting write to a hidden `.part` file and rename it only when complete, so an interrupted job never leaves a half-finished file in the vault (leftovers are cleaned on the next launch). Encrypting / decrypting also keeps the "original folder" record, so Unhide still restores to where the file came from.
- The notification is deliberately bland ("Calculator - Working… 42%", hidden on the lock screen, with a Cancel action); it never mentions the vault or file names. Android 13+ asks for notification permission once; transfers run either way. Results (and Android's "delete the originals?" prompt) wait until the vault is opened again if the transfer finished while you were away.
- Code: `TransferManager` (queue + worker thread), `TransferService`, `TransferJobs` (the add / unhide / encrypt / decrypt work), `PixelProgressDialog` (buttons).

Expand animation (v1.3). The scientific keys now animate like Pixel Calculator: in portrait (phone and tablet) the extra rows grow from a flat sliver while the whole keypad squeezes together and the key labels shrink with the keys; in landscape (phone and tablet) the scientific panel slides open sideways. One progress value drives all layouts (`animateSci` / `applySciProgress`), tapping again mid-way reverses smoothly, and rotation or window resizing keeps the state.

Forgot PIN (v1.3). Holding = on "0000" (when 0000 is not the real PIN) now shows the confirmation inside the calculator's result line, in red ("Press = to erase & reset PIN"), like the "Enter new password" prompt, instead of a popup. Pressing = erases the PIN and all vault files and relaunches the app; any other key (or leaving the app) cancels.

Package name changed to `com.onion.calcognito`. Android treats this as a different app: it installs next to the old `com.android.calcognito` build and does not see its vault, so unhide or export anything you need from the old app first.
