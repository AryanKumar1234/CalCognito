# Calculator (Android)
Kotlin calculator, no third-party dependencies. Google-Calculator-style UI with round keys and warm Material You colors (light/dark follows system): basic + scientific (expand-arrow toggle: sin/cos/tan, ln/log, sqrt, x^y, x^2, n!, pi, e, Deg/Rad), calculation history (history icon, top left, or drag the display down; the sheet follows your finger, snaps open/closed, wraps long expressions and shows a scroll indicator), overflow menu (top right: deg/rad, clear history), landscape layout (scientific keys always visible, like Pixel Calculator), About screen in the vault (info icon, top right), implicit multiplication shown as typed (5√2, not 5×√(2), long-press result to copy, long-press expression to paste, Pixel-style context percent, thousands separators, Pixel-style adaptive launcher icon.

Build locally: open in Android Studio, or run `gradle assembleDebug` (Gradle 8.13, AGP 8.11, JDK 17; targets Android 16 / API 36).
CI: push to GitHub; the APK is attached as a workflow artifact (`.github/workflows/build.yml`).


v1.1: multi-select in the vault (tap a thumbnail to select, long-press for Delete / Unhide / Move / Create folder), and a new video player with seek bar, play/pause, playback speed (0.5x–2x), double-tap skip/pause, swipe volume/brightness, hold for 2x, and a help button; Pixel-style dialogs throughout; Encrypt / Decrypt / Rename for selected vault files, add-menu (Upload / Folder), lock tile for encrypted files.
