#!/usr/bin/env python3
"""
Patches the cloned BlackBox engine C++ sources before building :Bcore:assembleRelease.

Root cause fixed:
On Android 16 (API 36), java.io.UnixFileSystem.canonicalize0 was changed from a native method
to a non-native Java method. BlackBox's JniHook::HookJniFun calls RegisterNatives on it,
which fails and leaves a pending java.lang.NoSuchMethodError on JNIEnv. Because JniHook does
not call ExceptionClear(), the very next JNI call triggers ART's AssertNoPendingException /
CheckJNI abort ("JNI DETECTED ERROR ... NoSuchMethodError in NativeCore.init").

This script patches JniHook (HookJniFun / InitJniHook) and NativeCore init paths so that
any pending JNI exception is cleared on every failure/return path rather than aborting.
"""

from __future__ import annotations

import pathlib
import re
import sys


CPP_EXTS = {".cpp", ".cc", ".cxx", ".c"}
TARGET_FUNCS = ("HookJniFun", "InitJniHook")
PATCH_MARKER = "/* calcognito_jni_fix */"


def find_matching_brace(text: str, open_idx: int) -> int:
    depth = 0
    i = open_idx
    n = len(text)
    in_str: str | None = None
    in_line_comment = False
    in_block_comment = False
    while i < n:
        ch = text[i]
        nxt = text[i + 1] if i + 1 < n else ""
        if in_line_comment:
            if ch == "\n":
                in_line_comment = False
        elif in_block_comment:
            if ch == "*" and nxt == "/":
                in_block_comment = False
                i += 1
        elif in_str is not None:
            if ch == "\\":
                i += 1
            elif ch == in_str:
                in_str = None
        else:
            if ch == "/" and nxt == "/":
                in_line_comment = True
                i += 1
            elif ch == "/" and nxt == "*":
                in_block_comment = True
                i += 1
            elif ch in ('"', "'"):
                in_str = ch
            elif ch == "{":
                depth += 1
            elif ch == "}":
                depth -= 1
                if depth == 0:
                    return i
        i += 1
    return -1


def patch_function_returns(body: str, env_name: str) -> tuple[str, int]:
    """Wrap every `return ...;` inside a C++ function body with ExceptionClear()."""
    if PATCH_MARKER in body:
        return body, 0

    count = 0
    pattern = re.compile(r"\breturn(?:\s+[^;{}]+)?\s*;")

    def repl(m: re.Match[str]) -> str:
        nonlocal count
        stmt = m.group(0)
        count += 1
        return f"{{ {PATCH_MARKER} if ({env_name} && {env_name}->ExceptionCheck()) {env_name}->ExceptionClear(); {stmt} }}"

    new_body = pattern.sub(repl, body)
    tail = f"\n    {PATCH_MARKER} if ({env_name} && {env_name}->ExceptionCheck()) {env_name}->ExceptionClear();\n"
    new_body = new_body[:-1] + tail + "}"
    return new_body, count + 1


def patch_file(path: pathlib.Path) -> bool:
    text = path.read_text(encoding="utf-8", errors="replace")
    if not any(fn in text for fn in TARGET_FUNCS) and "NativeCore" not in path.name:
        return False

    func_sig_re = re.compile(
        r"([A-Za-z_][A-Za-z0-9_:*&\s]*?\b(?:"
        + "|".join(TARGET_FUNCS)
        + r"|init|Java_top_niunaijun_blackbox_core_NativeCore_init)\s*\([^)]*\bJNIEnv\s*\*\s*([A-Za-z_][A-Za-z0-9_]*)[^)]*\)\s*)\{",
        re.MULTILINE,
    )

    edits: list[tuple[int, int, str]] = []
    for m in func_sig_re.finditer(text):
        env_name = m.group(2)
        brace_open = m.end() - 1
        brace_close = find_matching_brace(text, brace_open)
        if brace_close == -1:
            continue
        body = text[brace_open : brace_close + 1]
        new_body, changes = patch_function_returns(body, env_name)
        if changes > 0:
            edits.append((brace_open, brace_close + 1, new_body))

    if not edits:
        return False

    out = text
    for start, end, replacement in reversed(edits):
        out = out[:start] + replacement + out[end:]

    path.write_text(out, encoding="utf-8")
    print(f"patch_engine: patched {len(edits)} function(s) in {path}")
    return True


def main() -> int:
    if len(sys.argv) != 2:
        print(f"Usage: {sys.argv[0]} <engine_root>", file=sys.stderr)
        return 2

    root = pathlib.Path(sys.argv[1])
    if not root.is_dir():
        print(f"patch_engine: directory not found: {root}", file=sys.stderr)
        return 2

    patched_files = 0
    for path in sorted(root.rglob("*")):
        if path.is_file() and path.suffix in CPP_EXTS:
            if patch_file(path):
                patched_files += 1

    print(f"patch_engine: done ({patched_files} file(s) patched)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
