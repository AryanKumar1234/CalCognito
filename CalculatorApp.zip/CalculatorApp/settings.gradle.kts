pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Only for the engine's FreeReflection library (com.github.tiann), which is published on JitPack.
        maven {
            url = uri("https://www.jitpack.io")
            content { includeGroup("com.github.tiann") }
        }
    }
}
rootProject.name = "Calculator"
include(":app")
// The hidden-app engine (BlackBox), built from source together with the app.
include(":Bcore", ":black-reflection", ":compiler")
