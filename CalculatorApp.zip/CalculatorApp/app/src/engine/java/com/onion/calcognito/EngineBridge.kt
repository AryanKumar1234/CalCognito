package com.onion.calcognito

import android.content.Context
import android.content.Intent
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.app.configuration.ClientConfiguration

/**
 * The ONLY file that touches the BlackBox virtual-engine classes. It is compiled when an engine AAR is present in
 * app/libs (see app/build.gradle.kts); otherwise src/noengine/.../EngineBridge.kt (same API, always "unavailable")
 * is used so the app still builds. Every call is wrapped so an engine problem can never crash the calculator.
 *
 * If your engine build uses different package names, only the two imports above need changing.
 */
object EngineBridge {
    @Volatile private var attached = false

    val available: Boolean get() = attached

    fun attach(base: Context) {
        try {
            BlackBoxCore.get().doAttachBaseContext(base, object : ClientConfiguration() {
                override fun getHostPackageName(): String = base.packageName
            })
            attached = true
        } catch (_: Throwable) {
            attached = false
        }
    }

    fun create() {
        if (!attached) return
        try {
            BlackBoxCore.get().doCreate()
        } catch (_: Throwable) {
            attached = false
        }
    }

    /** null = could not tell. */
    private fun queryInstalled(pkg: String, userId: Int): Boolean? = try {
        BlackBoxCore.get().getInstalledPackages(0, userId).any { it.packageName == pkg }
    } catch (_: Throwable) {
        null
    }

    fun isInstalled(pkg: String, userId: Int): Boolean = attached && queryInstalled(pkg, userId) == true

    /** Some engine versions return a boolean, some a result object, some nothing: accept all of them. */
    private fun reportedOk(r: Any?): Boolean = when (r) {
        null, Unit -> true
        is Boolean -> r
        else -> try {
            r.javaClass.getMethod("isSuccess").invoke(r) as? Boolean ?: true
        } catch (_: Throwable) {
            true
        }
    }

    /** Clones the installed app [pkg] into the virtual space. Blocking: call from a worker thread. */
    fun install(pkg: String, userId: Int): Boolean {
        if (!attached) return false
        return try {
            val r: Any? = BlackBoxCore.get().installPackageAsUser(pkg, userId)
            reportedOk(r) && queryInstalled(pkg, userId) != false
        } catch (_: Throwable) {
            false
        }
    }

    /** Starts the cloned app inside the virtual space. Call on the main thread. */
    fun launch(ctx: Context, pkg: String, userId: Int): Boolean {
        if (!attached) return false
        return try {
            val r: Any? = BlackBoxCore.get().launchApk(pkg, userId)
            when (r) {
                is Intent -> {
                    r.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(r)
                    true
                }
                is Boolean -> r
                else -> true
            }
        } catch (_: Throwable) {
            false
        }
    }

    /** Removes the clone and its data from the virtual space. Blocking. */
    fun uninstall(pkg: String, userId: Int): Boolean {
        if (!attached) return false
        val core = BlackBoxCore.get()
        val str = String::class.java
        val int = Int::class.javaPrimitiveType
        try {
            val withUser = core.javaClass.methods.firstOrNull {
                it.name == "uninstallPackageAsUser" && it.parameterTypes.contentEquals(arrayOf(str, int))
            }
            val plain = core.javaClass.methods.firstOrNull {
                it.name == "uninstallPackage" && it.parameterTypes.contentEquals(arrayOf(str))
            }
            when {
                withUser != null -> withUser.invoke(core, pkg, userId)
                plain != null -> plain.invoke(core, pkg)
                else -> return false
            }
        } catch (_: Throwable) {
            return false
        }
        return queryInstalled(pkg, userId) != true
    }
}
