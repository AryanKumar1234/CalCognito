package com.onion.calcognito

import android.app.Application
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.app.configuration.ClientConfiguration

/**
 * The ONLY file that touches the BlackBox virtual-engine classes. It is compiled when an engine AAR is present in
 * app/libs (see app/build.gradle.kts); otherwise src/noengine/.../EngineBridge.kt (same API, always "unavailable")
 * is used so the app still builds. Every call is wrapped so an engine problem can never crash the calculator.
 *
 * The engine is NOT started when the app opens. Its low-level hooks can crash some phones (that would make the whole
 * app crash every time it opens), so the main process only starts it the first time hidden apps are used ([start]),
 * and remembers if that start ever killed the app so it can be switched off. The processes the engine creates for the
 * hidden apps themselves start it straight away, as the engine requires.
 *
 * If your engine build uses different package names, only the two imports above need changing.
 */
object EngineBridge {
    private const val TAG = "CalEngine"
    private const val GUARD = "engine_guard"
    @Volatile private var attached = false
    @Volatile private var created = false
    @Volatile private var lastFailure: String? = null
    @Volatile private var appBase: Context? = null

    /** The engine is running in this process. */
    val available: Boolean get() = attached && created

    /** True when the engine classes are part of this build (so "not available" means it failed to start). */
    val compiledIn: Boolean get() = true

    /** Why the engine did not start (shown in the app and written to logcat as "CalEngine"); null if no error was seen. */
    val failure: String? get() = lastFailure

    private fun processName(): String? = try {
        if (Build.VERSION.SDK_INT >= 28) Application.getProcessName()
        else java.io.File("/proc/self/cmdline").readText().trim('\u0000', ' ')
    } catch (_: Throwable) {
        null
    }

    private fun isMainProcess(ctx: Context): Boolean {
        val name = processName() ?: return true
        return name == ctx.packageName
    }

    private fun describe(t: Throwable): String {
        val parts = ArrayList<String>()
        var cur: Throwable? = t
        var depth = 0
        while (cur != null && depth < 4) {
            parts.add(cur.javaClass.name + (cur.message?.let { ": " + it.take(160) } ?: ""))
            cur = cur.cause
            depth++
        }
        return parts.joinToString("  <-  ")
    }

    private fun fail(stage: String, t: Throwable) {
        attached = false
        created = false
        val text = "$stage failed: ${describe(t)}"
        lastFailure = text
        try { Log.e(TAG, text, t) } catch (_: Throwable) {}
    }

    private fun attachNow(base: Context) {
        try {
            BlackBoxCore.get().doAttachBaseContext(base, object : ClientConfiguration() {
                override fun getHostPackageName(): String = base.packageName
            })
            attached = true
            lastFailure = null
        } catch (t: Throwable) {
            fail("Attach", t)
        }
    }

    private fun createNow() {
        if (!attached) return
        try {
            BlackBoxCore.get().doCreate()
            created = true
        } catch (t: Throwable) {
            fail("Start", t)
        }
    }

    /** Application.attachBaseContext. Hidden-app processes start the engine now; the main process waits for [start]. */
    fun attach(base: Context) {
        appBase = base
        if (isMainProcess(base)) return
        attachNow(base)
    }

    /** Application.onCreate (same rule as [attach]). */
    fun create() {
        val ctx = appBase ?: return
        if (isMainProcess(ctx)) return
        createNow()
    }

    /**
     * Starts the engine in the main process if it isn't running yet. Blocking: call from a worker thread. If the
     * process dies natively while this runs, [checkPreviousCrash] sees the marker on the next launch and turns the
     * engine off, so the app still opens. Returns whether the engine is running.
     */
    @Synchronized
    fun start(ctx: Context): Boolean {
        if (available) return true
        val p = ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE)
        if (p.getBoolean("disabled", false)) {
            lastFailure = p.getString("note", null)
            return false
        }
        p.edit().putString("inflight", "start").commit()   // synchronous, so it survives a crash right after
        try {
            if (!attached) attachNow(appBase ?: ctx.applicationContext)
            createNow()
        } catch (t: Throwable) {
            fail("Start", t)
        } finally {
            p.edit().remove("inflight").commit()
        }
        return available
    }

    /** Call once when the app opens: if the last start of the engine never finished, it crashed the app. */
    fun checkPreviousCrash(ctx: Context) {
        if (!isMainProcess(ctx)) return
        val p = ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE)
        val op = p.getString("inflight", null) ?: return
        val e = p.edit().remove("inflight")
        if (op == "start") {
            val note = "The hidden-app engine crashed this app while starting on this phone (Android " +
                "${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT}). It has been switched off so the app keeps " +
                "opening normally."
            e.putBoolean("disabled", true).putString("note", note)
            lastFailure = note
        }
        e.commit()
    }

    fun disabledByCrash(ctx: Context): Boolean =
        ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE).getBoolean("disabled", false)

    /** Lets the engine try to start again after it was switched off. */
    fun resetGuard(ctx: Context) {
        ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE).edit().clear().commit()
        lastFailure = null
    }

    /** null = could not tell. */
    private fun queryInstalled(pkg: String, userId: Int): Boolean? = try {
        BlackBoxCore.get().getInstalledPackages(0, userId).any { it.packageName == pkg }
    } catch (_: Throwable) {
        null
    }

    fun isInstalled(pkg: String, userId: Int): Boolean = available && queryInstalled(pkg, userId) == true

    /** Some engine versions return a boolean, some a result object, some nothing: accept all of them. */
    private fun reportedOk(r: Any?): Boolean = when (r) {
        null, Unit -> true
        is Boolean -> r
        else -> try {
            r.javaClass.getMethod("isSuccess").invoke(r) as? Boolean ?: true
        } catch (_: Throwable) {
            true
        }
    }

    /** Clones the installed app [pkg] into the virtual space. Blocking: call from a worker thread. */
    fun install(pkg: String, userId: Int): Boolean {
        if (!available) return false
        return try {
            val r: Any? = BlackBoxCore.get().installPackageAsUser(pkg, userId)
            reportedOk(r) && queryInstalled(pkg, userId) != false
        } catch (_: Throwable) {
            false
        }
    }

    /** Starts the cloned app inside the virtual space. Call on the main thread. */
    fun launch(ctx: Context, pkg: String, userId: Int): Boolean {
        if (!available) return false
        return try {
            val r: Any? = BlackBoxCore.get().launchApk(pkg, userId)
            when (r) {
                is Intent -> {
                    r.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    ctx.startActivity(r)
                    true
                }
                is Boolean -> r
                else -> true
            }
        } catch (_: Throwable) {
            false
        }
    }

    /** Removes the clone and its data from the virtual space. Blocking. */
    fun uninstall(pkg: String, userId: Int): Boolean {
        if (!available) return false
        val core = BlackBoxCore.get()
        val str = String::class.java
        val int = Int::class.javaPrimitiveType
        try {
            val withUser = core.javaClass.methods.firstOrNull {
                it.name == "uninstallPackageAsUser" && it.parameterTypes.contentEquals(arrayOf(str, int))
            }
            val plain = core.javaClass.methods.firstOrNull {
                it.name == "uninstallPackage" && it.parameterTypes.contentEquals(arrayOf(str))
            }
            when {
                withUser != null -> withUser.invoke(core, pkg, userId)
                plain != null -> plain.invoke(core, pkg)
                else -> return false
            }
        } catch (_: Throwable) {
            return false
        }
        return queryInstalled(pkg, userId) != true
    }
}
