package com.android.calcognito

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PathMeasure
import android.graphics.RectF
import android.os.SystemClock
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin

/**
 * Pixel-style circular progress indicator.
 *
 *  - smooth ring (like Quick Share) or wavy ring (like the Play Store's Material 3 Expressive indicator)
 *  - determinate ([setProgress] with 0..1) or indeterminate (negative value)
 *  - [finish] morphs the ring into a filled circle with an animated tick, then calls back.
 */
class ProgressRingView(
    ctx: Context,
    private val wavy: Boolean,
    private val activeColor: Int,
    private val trackColor: Int,
    private val tickFill: Int,
    private val tickColor: Int
) : View(ctx) {

    private companion object {
        const val WAVES = 10
        const val SPIN_MS = 1500f
        const val SWEEP_MS = 2000f
        const val RING_DONE_MS = 260L
        const val FILL_MS = 220L
        const val TICK_MS = 320L
        const val HOLD_MS = 650L
    }

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val path = Path()
    private val tickPath = Path()
    private val tickSeg = Path()
    private val oval = RectF()

    private var target = -1f          // < 0 means indeterminate
    private var shown = 0f            // smoothed value that is actually drawn
    private var running = false
    private var t0 = 0L
    private var lastFrame = 0L

    private var finishing = false
    private var finishStart = 0L
    private var onFinished: (() -> Unit)? = null
    private var finishedCalled = false

    /** 0..1 for a determinate ring, any negative value for indeterminate. */
    fun setProgress(p: Float) {
        target = if (p < 0f) -1f else p.coerceIn(0f, 1f)
    }

    /** Fill the ring, morph it into a tick, then run [end] (about one second later). */
    fun finish(end: () -> Unit) {
        if (finishing) return
        finishing = true
        finishedCalled = false
        onFinished = end
        finishStart = SystemClock.uptimeMillis()
        target = 1f
        if (!running) start()
    }

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            invalidate()
            postOnAnimation(this)
        }
    }

    fun start() {
        if (running) return
        running = true
        t0 = SystemClock.uptimeMillis()
        lastFrame = t0
        postOnAnimation(ticker)
    }

    fun stop() {
        running = false
        removeCallbacks(ticker)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        start()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    private fun easeOut(f: Float): Float {
        val x = 1f - f.coerceIn(0f, 1f)
        return 1f - x * x * x
    }

    private fun overshoot(f: Float): Float {
        val x = f.coerceIn(0f, 1f) - 1f
        return x * x * (3.0f * x + 2.0f) + 1f   // OvershootInterpolator(1.5)-like
    }

    override fun onDraw(canvas: Canvas) {
        val now = SystemClock.uptimeMillis()
        val dt = (now - lastFrame).coerceIn(0L, 64L)
        lastFrame = now
        val el = (now - t0).toFloat()

        val size = min(width, height).toFloat()
        if (size <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        val stroke = size * 0.085f
        val amp = if (wavy) size * 0.04f else 0f
        val r = size / 2f - stroke / 2f - amp - size * 0.01f

        // Ease the drawn value toward the target so progress never jumps.
        if (target >= 0f) {
            val k = if (finishing) 0.35f else min(1f, dt / 140f)
            shown += (target - shown) * k
            if (target - shown < 0.002f) shown = target
        }

        // Finish timeline
        var ringAlpha = 1f
        var fillScale = 0f
        var tickP = 0f
        if (finishing) {
            val f = now - finishStart
            val ringEnd = RING_DONE_MS
            ringAlpha = 1f - ((f - ringEnd + 80L).toFloat() / FILL_MS).coerceIn(0f, 1f)
            fillScale = overshoot(((f - ringEnd).toFloat() / FILL_MS))
            tickP = easeOut(((f - ringEnd - FILL_MS / 2).toFloat() / TICK_MS))
            if (f >= ringEnd + FILL_MS + TICK_MS + HOLD_MS && !finishedCalled) {
                finishedCalled = true
                val cb = onFinished
                onFinished = null
                post { cb?.invoke() }
            }
        }

        paint.strokeWidth = stroke

        if (ringAlpha > 0f) {
            val wavePhase = -el / 1100f * (2f * PI.toFloat())

            // Track
            paint.color = ColorUtils.setAlphaComponent(trackColor, (alphaOf(trackColor) * ringAlpha).toInt())
            drawRing(canvas, cx, cy, r, amp, 0f, 360f, wavePhase)

            // Active arc
            paint.color = ColorUtils.setAlphaComponent(activeColor, (255 * ringAlpha).toInt())
            if (target >= 0f || finishing) {
                val sweep = max(2f, 360f * shown)
                drawRing(canvas, cx, cy, r, amp, -90f, sweep, wavePhase)
            } else {
                val spin = (el / SPIN_MS) * 360f
                val ph = (el % SWEEP_MS) / SWEEP_MS
                val sweep = 40f + 210f * (0.5f - 0.5f * cos(2f * PI.toFloat() * ph))
                drawRing(canvas, cx, cy, r, amp, -90f + spin, sweep, wavePhase)
            }
        }

        if (finishing && fillScale > 0f) {
            val fr = (size / 2f - size * 0.01f) * fillScale
            fillPaint.color = tickFill
            canvas.drawCircle(cx, cy, max(0f, fr), fillPaint)

            if (tickP > 0f) {
                tickPath.reset()
                tickPath.moveTo(cx - size * 0.20f, cy + size * 0.01f)
                tickPath.lineTo(cx - size * 0.06f, cy + size * 0.15f)
                tickPath.lineTo(cx + size * 0.21f, cy - size * 0.14f)
                val pm = PathMeasure(tickPath, false)
                tickSeg.reset()
                pm.getSegment(0f, pm.length * tickP, tickSeg, true)
                paint.color = tickColor
                paint.strokeWidth = size * 0.085f
                canvas.drawPath(tickSeg, paint)
            }
        }
    }

    private fun alphaOf(color: Int): Int = (color ushr 24) and 0xFF

    /** Draws [sweep] degrees of the ring starting at [startDeg]; wavy rings ripple around the base radius. */
    private fun drawRing(canvas: Canvas, cx: Float, cy: Float, r: Float, amp: Float, startDeg: Float, sweep: Float, phase: Float) {
        if (!wavy || amp <= 0f) {
            oval.set(cx - r, cy - r, cx + r, cy + r)
            canvas.drawArc(oval, startDeg, sweep, false, paint)
            return
        }
        path.reset()
        val step = 2f
        var a = 0f
        var first = true
        while (true) {
            val deg = startDeg + min(a, sweep)
            val rad = (deg * PI / 180.0).toFloat()
            val rr = r + amp * sin(WAVES * rad + phase)
            val x = cx + rr * cos(rad)
            val y = cy + rr * sin(rad)
            if (first) { path.moveTo(x, y); first = false } else path.lineTo(x, y)
            if (a >= sweep) break
            a += step
        }
        canvas.drawPath(path, paint)
    }
}
