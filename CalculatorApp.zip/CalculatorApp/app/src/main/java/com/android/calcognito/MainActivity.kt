package com.android.calcognito

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.RecoverableSecurityException
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.RectF
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.media.ExifInterface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.TextUtils
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.ReplacementSpan
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.ScaleGestureDetector
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.ViewConfiguration
import android.view.animation.PathInterpolator
import android.view.WindowManager
import android.window.OnBackInvokedCallback
import android.window.OnBackInvokedDispatcher
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.OverScroller
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class Palette(
        val bg: Int, val text: Int, val icon: Int,
        val numBg: Int, val numFg: Int,
        val opBg: Int, val opFg: Int,
        val acBg: Int, val acFg: Int,
        val eqBg: Int, val eqFg: Int,
        val sciBg: Int, val sciFg: Int,
        val result: Int, val cursor: Int,
        val clearFg: Int, val ripple: Int, val divider: Int,
        val histBg: Int, val dialogBg: Int
    )

    private fun c(hex: String) = Color.parseColor(hex)

    private val light = Palette(
        bg = c("#FFF8F6"), text = c("#231917"), icon = c("#53433F"),
        numBg = c("#F1DFDA"), numFg = c("#231917"),
        opBg = c("#E7BDB2"), opFg = c("#442A22"),
        acBg = c("#FFDAD6"), acFg = c("#410002"),
        eqBg = c("#8B5000"), eqFg = c("#FFFFFF"),
        sciBg = c("#F1DFDA"), sciFg = c("#442A22"),
        result = c("#6B5E2F"), cursor = c("#9A4026"),
        clearFg = c("#BA1A1A"), ripple = c("#33000000"), divider = c("#E7D6D1"), histBg = c("#F8EBE7"), dialogBg = c("#F6E6E1")
    )
    private val dark = Palette(
        bg = c("#1D100D"), text = c("#EEE0DD"), icon = c("#D7C3BD"),
        numBg = c("#43302E"), numFg = c("#EEE0DD"),
        opBg = c("#5D4038"), opFg = c("#FFDBD2"),
        acBg = c("#93000A"), acFg = c("#FFDAD6"),
        eqBg = c("#F8BD85"), eqFg = c("#4A2800"),
        sciBg = c("#40332D"), sciFg = c("#FFDBD2"),
        result = c("#DAC58E"), cursor = c("#FFB5A2"),
        clearFg = c("#FFB5A2"), ripple = c("#33FFFFFF"), divider = c("#3A2C27"), histBg = c("#271C18"), dialogBg = c("#322621")
    )
    private lateinit var pal: Palette

    /** Whether to derive the palette from the system's Material You / wallpaper colors (Android 12+). */
    private fun dynamicColorAvailable(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    private fun useDynamicColor(): Boolean = dynamicColorAvailable() && prefs.getBoolean("dynamic_theme", true)

    private fun resolvePalette(night: Boolean): Palette {
        if (useDynamicColor()) buildDynamicPalette(night)?.let { return it }
        return if (night) dark else light
    }

    private fun sysColor(resId: Int): Int? = try { resources.getColor(resId, theme) } catch (_: Exception) { null }

    /**
     * Android 14+ exposes the real Material 3 color roles of the wallpaper scheme
     * (android.R.color.system_surface_dark, system_tertiary_dark, ...), the same ones Pixel
     * Calculator is themed with. They are looked up by name so older systems simply fall back
     * to the tonal-palette mapping below.
     */
    private fun buildRolePalette(night: Boolean): Palette? {
        val suffix = if (night) "dark" else "light"
        fun role(name: String): Int? {
            val id = resources.getIdentifier("system_${name}_$suffix", "color", "android")
            return if (id == 0) null else sysColor(id)
        }
        return try {
            val surface = role("surface") ?: return null
            val onSurface = role("on_surface") ?: return null
            val onSurfaceVar = role("on_surface_variant") ?: return null
            val keyBg = (if (night) sysColor(android.R.color.system_neutral1_800) else null) ?: role("surface_container_highest") ?: return null
            val primC = role("primary_container") ?: return null
            val onPrimC = role("on_primary_container") ?: return null
            val secC = role("secondary_container") ?: return null
            val onSecC = role("on_secondary_container") ?: return null
            val tert = role("tertiary") ?: return null
            val onTert = role("on_tertiary") ?: return null
            val primary = role("primary") ?: return null
            val low = role("surface_container") ?: keyBg
            val high = role("surface_container_high") ?: keyBg
            Palette(
                bg = surface, text = onSurface, icon = onSurfaceVar,
                numBg = keyBg, numFg = onSurface,
                opBg = secC, opFg = onSecC,
                // Pixel Calculator tints AC with the wallpaper's primary container
                acBg = primC, acFg = onPrimC,
                eqBg = tert, eqFg = onTert,
                sciBg = keyBg, sciFg = onSecC,
                result = primary, cursor = primary,
                clearFg = if (night) Color.parseColor("#FFB4AB") else Color.parseColor("#BA1A1A"),
                ripple = Color.parseColor(if (night) "#33FFFFFF" else "#33000000"),
                divider = role("outline_variant") ?: role("surface_variant") ?: keyBg,
                histBg = low, dialogBg = high
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Maps the framework's wallpaper-derived tonal palette (system_accent1/2, system_neutral1/2) onto our Palette shape. */
    @RequiresApi(Build.VERSION_CODES.S)
    private fun buildDynamicPalette(night: Boolean): Palette? {
        buildRolePalette(night)?.let { return it }
        fun cc(resId: Int): Int = sysColor(resId) ?: throw IllegalStateException("missing dynamic color")
        return try {
            if (!night) {
                Palette(
                    bg = cc(android.R.color.system_neutral1_10), text = cc(android.R.color.system_neutral1_900), icon = cc(android.R.color.system_neutral2_700),
                    numBg = cc(android.R.color.system_neutral1_100), numFg = cc(android.R.color.system_neutral1_900),
                    opBg = cc(android.R.color.system_accent2_100), opFg = cc(android.R.color.system_accent2_900),
                    acBg = cc(android.R.color.system_accent1_100), acFg = cc(android.R.color.system_accent1_900),
                    eqBg = cc(android.R.color.system_accent3_600), eqFg = Color.WHITE,
                    sciBg = cc(android.R.color.system_neutral1_100), sciFg = cc(android.R.color.system_accent1_800),
                    result = cc(android.R.color.system_accent1_600), cursor = cc(android.R.color.system_accent1_600),
                    clearFg = Color.parseColor("#BA1A1A"), ripple = Color.parseColor("#33000000"),
                    divider = cc(android.R.color.system_neutral2_200), histBg = cc(android.R.color.system_neutral1_50), dialogBg = cc(android.R.color.system_neutral1_50)
                )
            } else {
                Palette(
                    bg = androidx.core.graphics.ColorUtils.blendARGB(cc(android.R.color.system_neutral1_1000), cc(android.R.color.system_neutral1_900), 0.6f), text = cc(android.R.color.system_neutral1_100), icon = cc(android.R.color.system_neutral2_200),
                    numBg = cc(android.R.color.system_neutral1_800), numFg = cc(android.R.color.system_neutral1_100),
                    opBg = cc(android.R.color.system_accent2_700), opFg = cc(android.R.color.system_accent2_100),
                    acBg = cc(android.R.color.system_accent1_700), acFg = cc(android.R.color.system_accent1_100),
                    eqBg = cc(android.R.color.system_accent3_200), eqFg = cc(android.R.color.system_accent3_900),
                    sciBg = cc(android.R.color.system_neutral1_700), sciFg = cc(android.R.color.system_accent1_100),
                    result = cc(android.R.color.system_accent1_200), cursor = cc(android.R.color.system_accent1_200),
                    clearFg = Color.parseColor("#FFB5A2"), ripple = Color.parseColor("#33FFFFFF"),
                    divider = cc(android.R.color.system_neutral2_700), histBg = cc(android.R.color.system_neutral1_800), dialogBg = cc(android.R.color.system_neutral1_800)
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    private class CursorSpan(
        private val widthPx: Int, private val barPx: Int, private val color: Int
    ) : ReplacementSpan() {
        var visible = true
        override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int = widthPx
        override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
            if (!visible) return
            val p = Paint(paint)
            p.color = color
            p.style = Paint.Style.FILL
            val left = x + (widthPx - barPx) / 2f
            canvas.drawRect(left, top.toFloat(), left + barPx, bottom.toFloat(), p)
        }
    }

    private lateinit var topScroll: HorizontalScrollView
    private lateinit var topView: TextView
    private lateinit var bottomView: TextView
    private lateinit var bottomScroll: HorizontalScrollView
    private lateinit var histContainer: LinearLayout
    private lateinit var histScroll: ScrollView
    private lateinit var histHandle: LinearLayout
    private lateinit var histHost: FrameLayout
    private lateinit var histThumb: View
    private lateinit var displayHost: View
    private var contentW = 0
    private var uiScale = 1f
    private var bottomBaseH = 0
    private lateinit var histBgDrawable: GradientDrawable
    private lateinit var histBtnFill: GradientDrawable
    private var histHeightPx = 0
    private var histMaxCache = 0
    private var histTotal = 0
    private var histAnim: ValueAnimator? = null
    private var pendingReopen = false
    private var pinBottom = true
    private val argb = ArgbEvaluator()
    private val histHandleHeight by lazy { dp(44) }
    private var toolRowView: View? = null
    private val hideThumb = Runnable {
        if (::histThumb.isInitialized) histThumb.animate().alpha(0f).setDuration(250).start()
    }

    private enum class DragZone { NONE, EDGE, LIST }
    private var dragZone = DragZone.NONE
    private var histDragging = false
    private var dragDownX = 0f
    private var dragDownY = 0f
    private var dragStartH = 0
    private var velocity: VelocityTracker? = null
    private var historyBtn: ImageView? = null
    private lateinit var historyList: LinearLayout
    private lateinit var vaultPanel: LinearLayout
    private lateinit var vaultFabHost: FrameLayout
    private lateinit var vaultFilesList: LinearLayout
    private lateinit var vaultTitle: TextView
    private lateinit var vaultChipsRow: LinearLayout
    private lateinit var vaultCloseBtn: TextView
    private lateinit var fabShape: GradientDrawable
    private lateinit var fabIcon: ImageView
    private lateinit var fabScrim: View
    private lateinit var fabMenu: LinearLayout
    private lateinit var folderPill: View
    private var fabMenuOpen = false
    private val selected = LinkedHashSet<String>()
    private val rowUpdaters = HashMap<String, () -> Unit>()
    private var currentFolder: String? = null
    private var vaultFilter = 0
    private var vaultSort = 0
    private var expandBtn: ImageView? = null
    private lateinit var radKey: TextView
    private val sciLines = mutableListOf<View>()
    private val sciKeys = mutableMapOf<String, TextView>()
    private val keyTexts = mutableListOf<Pair<TextView, Float>>()
    private var backspaceIcon: ImageView? = null
    private var inverse = false

    private val cursorSpan by lazy { CursorSpan(dp(8), dp(2), pal.cursor) }
    private val handler = Handler(Looper.getMainLooper())
    private val blink = object : Runnable {
        override fun run() {
            cursorSpan.visible = !cursorSpan.visible
            topView.invalidate()
            handler.postDelayed(this, 530)
        }
    }

    private var expression = ""
    private var previousExpression = ""
    private var justEvaluated = false
    private var errorText: String? = null
    private var sciVisible = false
    private var historyVisible = false
    private var vaultVisible = false

    private companion object {
        const val REQ_PICK = 1001
        const val REQ_PERM = 1002
        const val REQ_DELETE_BATCH = 9999
        const val REQ_DELETE_LEGACY = 9998
        const val REPO_URL = "https://github.com/AryanKumar1234/CalCognito"
        const val PROFILE_URL = "https://github.com/AryanKumar1234"
    }

    private var changeMode = false
    private var holdFired = false
    private var pinResetPending = false

    private var leavingForTask = false

    private var externalViewing = false
    private var afterPermission: (() -> Unit)? = null
    private var viewerDialog: Dialog? = null
    private var aboutDialog: Dialog? = null
    /** Vault dialogs/sheets (selection sheet, confirmations, prompts) that must close whenever the vault locks. */
    private val vaultDialogs = ArrayList<Dialog>()

    private fun trackVaultDialog(d: Dialog) {
        vaultDialogs.add(d)
        d.setOnDismissListener { vaultDialogs.remove(d) }
    }

    private fun dismissVaultDialogs() {
        for (d in vaultDialogs.toList()) try { d.dismiss() } catch (_: Exception) {}
        vaultDialogs.clear()
    }
    private var lastDisplayWidth = 0
    private var lastDisplayHeight = 0
    private val thumbCache = ConcurrentHashMap<String, Bitmap>()
    private val thumbExecutor = Executors.newSingleThreadExecutor()
    private val migrateExecutor = Executors.newSingleThreadExecutor()
    private val migrating = ConcurrentHashMap.newKeySet<String>()
    private var hideHidden = 0
    private var hideFailed = 0
    private var hideNotRemoved = 0
    private var batchDeleteCount = 0
    private val legacyDeleteQueue = mutableListOf<Uri>()
    private var legacyCurrent: Uri? = null

    private var currentPrecision = 120
    private var isInfiniteResult = false
    private var activeEvalExpr = ""
    private var cachedRawResult = ""
    private var scrollOffsetPx = 0f
    private lateinit var scroller: OverScroller
    private lateinit var gestureDetector: GestureDetector

    private val flingRunnable = object : Runnable {
        override fun run() {
            if (scroller.computeScrollOffset()) {
                scrollOffsetPx = scroller.currX.toFloat().coerceAtLeast(0f)
                renderBottomResult()
                bottomView.postOnAnimation(this)
            }
        }
    }

    private val operators = setOf('+', '−', '×', '÷')
    private val prefs by lazy { getSharedPreferences("calc_history", Context.MODE_PRIVATE) }

    private fun loadFont(file: String, fallback: Typeface): Typeface = try {
        Typeface.createFromAsset(assets, "fonts/$file")
    } catch (e: Exception) { fallback }

    private val displayFont: Typeface by lazy { loadFont("GoogleSansFlex-Display.ttf", Typeface.create("sans-serif-light", Typeface.NORMAL)) }
    private val keyFont: Typeface by lazy { loadFont("GoogleSansFlex-Key.ttf", Typeface.create("sans-serif-medium", Typeface.NORMAL)) }
    private val opFont: Typeface by lazy { loadFont("GoogleSansFlex-Op.ttf", Typeface.create("sans-serif-medium", Typeface.NORMAL)) }
    private val sciFont: Typeface by lazy { loadFont("GoogleSansFlex-Label.ttf", Typeface.create("sans-serif", Typeface.NORMAL)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        val night = isNightMode()
        setTheme(if (night) R.style.AppThemeDark else R.style.AppThemeLight)
        super.onCreate(savedInstanceState)
        pal = resolvePalette(night)
        Evaluator.degrees = prefs.getBoolean("deg", true)

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        // Draw into the camera-cutout area in landscape instead of leaving a black bar there.
        if (Build.VERSION.SDK_INT >= 28) {
            window.attributes = window.attributes.apply {
                layoutInDisplayCutoutMode = if (Build.VERSION.SDK_INT >= 30)
                    WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                else WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (night) 0
            else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        VaultManager.clearTemp(applicationContext)
        VaultManager.cleanStaleMigrations(applicationContext)
        scroller = OverScroller(this)
        setContentView(buildUi())
        registerBackCallback()
        setupResultScrollGesture()

        expression = savedInstanceState?.getString("expr") ?: ""
        previousExpression = savedInstanceState?.getString("prev") ?: ""
        justEvaluated = savedInstanceState?.getBoolean("done") ?: false
        refresh()
    }

    override fun onResume() {
        super.onResume()
        setSecure(vaultVisible)
        handler.removeCallbacks(blink)
        handler.postDelayed(blink, 530)
        if (externalViewing) {
            externalViewing = false
            VaultManager.clearTemp(applicationContext)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(blink)

        if (leavingForTask) {
            leavingForTask = false
            return
        }
        if (changeMode) {
            changeMode = false
            expression = ""
            justEvaluated = false
            refresh()
        }
        viewerDialog?.dismiss()
        aboutDialog?.dismiss()
        if (vaultVisible) {
            toggleVault()
            setSecure(true)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        thumbExecutor.shutdownNow()
        migrateExecutor.shutdownNow()
        viewerDialog?.dismiss()
        VaultManager.clearTemp(applicationContext)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuildUi()
    }

    private fun rebuildUi() {
        histAnim?.cancel()
        histHeightPx = 0
        pendingReopen = historyVisible
        historyVisible = false
        window.statusBarColor = pal.bg
        window.setBackgroundDrawable(ColorDrawable(pal.bg))
        sciLines.clear(); sciKeys.clear(); keyTexts.clear()
        expandBtn = null; backspaceIcon = null
        lastDisplayWidth = 0
        lastDisplayHeight = 0
        setContentView(buildUi())
        setupResultScrollGesture()
        if (sciVisible) {
            for (line in sciLines) line.visibility = View.VISIBLE
            updateExpandIcon()
        }
        updateSciLabels()
        if (vaultVisible) { renderVaultFiles(); vaultPanel.visibility = View.VISIBLE; updateSelectionUi() }
        refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("expr", expression)
        outState.putString("prev", previousExpression)
        outState.putBoolean("done", justEvaluated)
    }

    private fun setSecure(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun isNightMode(): Boolean = when (prefs.getInt("theme", 2)) {
        0 -> false
        1 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun winW(): Int =
        if (resources.configuration.screenWidthDp > 0) (resources.configuration.screenWidthDp * resources.displayMetrics.density).toInt()
        else resources.displayMetrics.widthPixels

    private fun winH(): Int =
        if (resources.configuration.screenHeightDp > 0) (resources.configuration.screenHeightDp * resources.displayMetrics.density).toInt()
        else resources.displayMetrics.heightPixels

    private fun isLand() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun rippleBg(radiusDp: Int = 0): RippleDrawable {
        val mask = GradientDrawable().apply { cornerRadius = dpf(radiusDp); setColor(Color.BLACK) }
        return RippleDrawable(ColorStateList.valueOf(pal.ripple), null, mask)
    }

    private fun showStyledDialog(
        title: String, body: View?, positive: String, negative: String?, onPositive: () -> Unit
    ): Dialog {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.dialogBg) }
            setPadding(0, dp(24), 0, dp(16))
        }
        card.addView(TextView(this).apply {
            text = title
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            setPadding(dp(24), 0, dp(24), dp(16))
        })
        if (body != null) {
            // Keep the buttons reachable in short windows (landscape, split-screen): the body scrolls
            // inside whatever height is left after the title and button row.
            val maxBodyH = (winH() - dp(210)).coerceAtLeast(dp(96))
            val scroller = object : ScrollView(this@MainActivity) {
                override fun onMeasure(widthSpec: Int, heightSpec: Int) {
                    super.onMeasure(widthSpec, View.MeasureSpec.makeMeasureSpec(maxBodyH, View.MeasureSpec.AT_MOST))
                }
            }.apply {
                isVerticalScrollBarEnabled = false
                overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
                addView(body, FrameLayout.LayoutParams(-1, -2))
            }
            card.addView(scroller, LinearLayout.LayoutParams(-1, -2))
        }
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(dp(16), dp(16), dp(16), 0)
        }
        fun button(label: String, action: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(pal.cursor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            minWidth = dp(64)
            background = rippleBg(20)
            setOnClickListener { dialog.dismiss(); action() }
        }
        if (negative != null) buttons.addView(button(negative) {})
        buttons.addView(button(positive, onPositive))
        card.addView(buttons, LinearLayout.LayoutParams(-1, -2))
        dialog.setContentView(card)
        val w = minOf(winW() - dp(66), dp(560))
        dialog.window?.setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
        trackVaultDialog(dialog)
        dialog.show()
        return dialog
    }

    private fun msgBody(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(pal.icon)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setLineSpacing(0f, 1.15f)
        setPadding(dp(24), 0, dp(24), 0)
    }

    private fun showProgress(msg: String): Dialog {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.dialogBg) }
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        card.addView(TextView(this).apply {
            text = msg
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        })
        dialog.setContentView(card)
        dialog.window?.setLayout(minOf(winW() - dp(66), dp(560)), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
        return dialog
    }

    /** Pixel-style list dialog: rows with an icon and label; tapping a row closes the dialog and runs it. */
    private fun showListDialog(title: String, rows: List<Triple<Int, String, () -> Unit>>, cancelLabel: String = "Cancel") {
        var dlg: Dialog? = null
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((icon, label, action) in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(52)
                setPadding(dp(24), 0, dp(24), 0)
                background = rippleBg()
                isClickable = true
                setOnClickListener { dlg?.dismiss(); action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(pal.icon)
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(20) })
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -2, 1f))
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        dlg = showStyledDialog(title, ScrollView(this).apply { addView(list) }, cancelLabel, null) {}
    }

    private fun radioRows(labels: List<String>, initial: Int, onPick: (Int) -> Unit): View {
        val group = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val radios = mutableListOf<RadioButton>()
        val tint = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(pal.cursor, pal.text)
        )
        labels.forEachIndexed { i, label ->
            val rb = RadioButton(this).apply {
                isChecked = i == initial
                isClickable = false
                isFocusable = false
                buttonTintList = tint
            }
            radios.add(rb)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(20), 0, dp(24), 0)
                background = rippleBg()
                setOnClickListener {
                    radios.forEachIndexed { j, r -> r.isChecked = j == i }
                    onPick(i)
                }
            }
            row.addView(rb, LinearLayout.LayoutParams(-2, -2))
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
            group.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        return group
    }

    private fun showVideoHelp() {
        val items = listOf(
            "Tap" to "Show or hide controls",
            "Double tap left / right" to "Back / forward 10 seconds",
            "Double tap centre" to "Pause or resume",
            "Swipe up / down on right" to "Volume",
            "Swipe up / down on left" to "Brightness",
            "Hold anywhere" to "Play at 2x while held"
        )
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((gesture, action) in items) {
            list.addView(TextView(this).apply {
                text = gesture
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(24), dp(10), dp(24), 0)
            })
            list.addView(TextView(this).apply {
                text = action
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(dp(24), dp(2), dp(24), dp(10))
            })
        }
        val scroll = ScrollView(this).apply { addView(list) }
        showStyledDialog("Video controls", scroll, "Got it", null) {}
    }

    private fun showThemeDialog() {
        var choice = prefs.getInt("theme", 2)
        val group = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val radios = mutableListOf<RadioButton>()
        val tint = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(pal.cursor, pal.text)
        )
        listOf("Light", "Dark", "System default").forEachIndexed { i, label ->
            val rb = RadioButton(this).apply {
                isChecked = i == choice
                isClickable = false
                isFocusable = false
                buttonTintList = tint
            }
            radios.add(rb)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(20), 0, dp(24), 0)
                background = rippleBg()
                setOnClickListener {
                    choice = i
                    radios.forEachIndexed { j, r -> r.isChecked = j == i }
                }
            }
            row.addView(rb, LinearLayout.LayoutParams(-2, -2))
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
            group.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        var dynamicChoice = useDynamicColor()
        if (dynamicColorAvailable()) {
            val dynCheck = CheckBox(this).apply {
                text = "Match wallpaper colors"
                isChecked = dynamicChoice
                setTextColor(pal.text)
                buttonTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(pal.cursor, pal.text)
                )
                setOnCheckedChangeListener { _, checked -> dynamicChoice = checked }
            }
            group.addView(dynCheck, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(20), dp(8), dp(24), dp(4)) })
        }
        showStyledDialog("Choose theme", group, "OK", "Cancel") {
            val themeChanged = choice != prefs.getInt("theme", 2)
            val dynamicChanged = dynamicColorAvailable() && dynamicChoice != prefs.getBoolean("dynamic_theme", true)
            if (themeChanged || dynamicChanged) {
                prefs.edit().putInt("theme", choice).putBoolean("dynamic_theme", dynamicChoice).apply()
                recreate()
            }
        }
    }

    private fun appVersion(): String = try {
        @Suppress("DEPRECATION")
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.1"
    } catch (_: Exception) { "1.1" }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * resources.displayMetrics.density

    private fun setupResultScrollGesture() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scroller.forceFinished(true)
                bottomView.removeCallbacks(flingRunnable)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (!isInfiniteResult || errorText != null) return false
                scrollOffsetPx = (scrollOffsetPx + distanceX).coerceAtLeast(0f)
                renderBottomResult()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (!isInfiniteResult || errorText != null) return false
                scroller.fling(scrollOffsetPx.toInt(), 0, (-velocityX).toInt(), 0, 0, Int.MAX_VALUE / 4, 0, 0)
                bottomView.postOnAnimation(flingRunnable)
                return true
            }
            override fun onLongPress(e: MotionEvent) { copyResult() }
        })
        bottomScroll.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            isInfiniteResult && errorText == null
        }
    }

    private fun buildUi(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(pal.bg) }
        val wDp = resources.configuration.screenWidthDp
        val hDp = resources.configuration.screenHeightDp
        // Always use the compact 4-column Pixel-style keypad (AC row first), stretched to the
        // full window width in every orientation / window size.
        val land = wDp > hDp
        // Old side-by-side landscape layout is for phones only; tablets keep the full-width 4-column keypad.
        val phoneLand = land && resources.configuration.smallestScreenWidthDp < 600
        contentW = if (phoneLand) minOf(winW(), dp(900)) else winW()
        uiScale = if (land) (hDp / 411f).coerceIn(1f, 1.4f) else (minOf(wDp, 600) / 411f).coerceIn(1f, 1.4f)
        bottomBaseH = dp(((if (land) 44 else 72) * uiScale).toInt())

        if (phoneLand) {
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(pal.bg)
                fitsSystemWindows = true
            }
            val topBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), 0, dp(8), 0)
            }
            historyBtn = iconButton(R.drawable.ic_history, "History") { toggleHistory() }
            topBar.addView(historyBtn, LinearLayout.LayoutParams(dp(40), dp(40)))
            topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            topBar.addView(iconButton(R.drawable.ic_more_vert, "More options") { showMenu(it) }, LinearLayout.LayoutParams(dp(40), dp(40)))
            addTopArea(column, topBar)

            val display = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.END
                setPadding(dp(24), dp(4), dp(24), 0)
            }
            topView = TextView(this).apply {
                gravity = Gravity.END or Gravity.BOTTOM
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
                setOnLongClickListener { pasteIntoExpression(); true }
            }
            topScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(topView, FrameLayout.LayoutParams(-2, -1))
            }
            bottomView = TextView(this).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
            }
            bottomScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(bottomView, FrameLayout.LayoutParams(-2, -1))
            }
            display.addView(topScroll, LinearLayout.LayoutParams(-1, 0, 1f))
            display.addView(bottomScroll, LinearLayout.LayoutParams(-1, bottomBaseH))
            display.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
                if (r - l != lastDisplayWidth) {
                    lastDisplayWidth = r - l
                    display.post { refresh() }
                }
            }

            val expBtn = iconButton(R.drawable.ic_code, "Scientific functions") { toggleScientific() }
            expandBtn = expBtn
            val displayBox = FrameLayout(this)
            displayBox.addView(display, FrameLayout.LayoutParams(-1, -1))
            displayBox.addView(expBtn, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.START).apply {
                setMargins(dp(14), 0, 0, dp(6))
            })
            toolRowView = null
            attachDisplayHost(displayBox)
            column.addView(displayBox, LinearLayout.LayoutParams(-1, 0, 1f))

            val keypad = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(8), 0, dp(8), dp(4))
            }
            val sciPanel = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                visibility = View.GONE
            }
            val sciGrid = listOf(
                listOf("Inv", if (Evaluator.degrees) "Rad" else "Deg", "!"),
                listOf("sin", "cos", "tan"),
                listOf("ln", "log", "e"),
                listOf("√", "π", "^")
            )
            for (row in sciGrid) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (label in row) {
                    line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                sciPanel.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }
            sciLines.add(sciPanel)
            keypad.addView(sciPanel, LinearLayout.LayoutParams(0, -1, 3f))

            val mainPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            val basicRows = listOf(
                listOf("7", "8", "9", "AC", "×"),
                listOf("4", "5", "6", "( )", "−"),
                listOf("1", "2", "3", "%", "+"),
                listOf("0", ".", "⌫", "÷", "=")
            )
            for (row in basicRows) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (label in row) {
                    line.addView(makeKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                mainPanel.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }

            for ((tv, sz) in keyTexts) tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sz * 0.7f * uiScale)
            for ((_, tv) in sciKeys) tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f * uiScale)
            keypad.addView(mainPanel, LinearLayout.LayoutParams(0, -1, 5f))
            column.addView(keypad, LinearLayout.LayoutParams(-1, 0, 2.4f))
            root.addView(column, FrameLayout.LayoutParams(contentW, -1, Gravity.CENTER_HORIZONTAL))
        } else {
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(pal.bg)
                fitsSystemWindows = true
            }
            val topBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(6), dp(3), 0)
            }
            historyBtn = iconButton(R.drawable.ic_history, "History") { toggleHistory() }
            topBar.addView(historyBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
            topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            topBar.addView(iconButton(R.drawable.ic_more_vert, "More options") { showMenu(it) }, LinearLayout.LayoutParams(dp(48), dp(48)))
            addTopArea(column, topBar)

            val display = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.END
                setPadding(dp(24), dp(8), dp(24), 0)
            }
            topView = TextView(this).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
                setOnLongClickListener { pasteIntoExpression(); true }
            }
            topScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(topView, FrameLayout.LayoutParams(-2, -1))
            }
            bottomView = TextView(this).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
            }
            bottomScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(bottomView, FrameLayout.LayoutParams(-2, -1))
            }
            display.addView(topScroll, LinearLayout.LayoutParams(-1, 0, 1f))
            display.addView(bottomScroll, LinearLayout.LayoutParams(-1, bottomBaseH))
            // Pixel keeps the expression in the upper-middle of the display with free space under the result line
            val spacer = View(this)
            display.addView(spacer, LinearLayout.LayoutParams(-1, 0, 0.4f))
            // Re-fit the text whenever the window is resized (split-screen, freeform, rotation, short landscape).
            display.addOnLayoutChangeListener { v, l, t, r, b, _, _, _, _ ->
                val w = r - l
                val h = b - t
                if (w != lastDisplayWidth || h != lastDisplayHeight) {
                    lastDisplayWidth = w
                    lastDisplayHeight = h
                    v.post {
                        if (land) {
                            val blp = bottomScroll.layoutParams
                            blp.height = minOf(bottomBaseH, (h * 0.3f).toInt())
                            bottomScroll.layoutParams = blp
                        }
                        val slp = spacer.layoutParams as LinearLayout.LayoutParams
                        slp.weight = if (h < dp(200)) 0f else 0.4f
                        spacer.layoutParams = slp
                    }
                }
            }
            // Re-fit the text once the lines have their *final* size. The adjustments above change the
            // line heights after the first layout pass, so fitting only at that moment used stale (small)
            // heights, which left the digits tiny after rotating until the next keypress.
            val refit = View.OnLayoutChangeListener { v, l, t, r, b, ol, ot, or2, ob ->
                if (r - l != or2 - ol || b - t != ob - ot) v.post { refresh() }
            }
            topScroll.addOnLayoutChangeListener(refit)
            bottomScroll.addOnLayoutChangeListener(refit)
            val expBtn = iconButton(R.drawable.ic_code, "Scientific functions") { toggleScientific() }
            expandBtn = expBtn
            if (land) {
                // Landscape: keep the expander inside the display area to save vertical space.
                val displayBox = FrameLayout(this)
                displayBox.addView(display, FrameLayout.LayoutParams(-1, -1))
                displayBox.addView(expBtn, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.START).apply {
                    setMargins(dp(14), 0, 0, dp(6))
                })
                toolRowView = null
                attachDisplayHost(displayBox)
                column.addView(displayBox, LinearLayout.LayoutParams(-1, 0, 1f))
            } else {
                attachDisplayHost(display)
                column.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))
                val toolRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(4), dp(24), dp(12))
                }
                toolRow.addView(expBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
                toolRowView = toolRow
                column.addView(toolRow, LinearLayout.LayoutParams(-1, -2))
            }

            // Pixel-style side margins on wide landscape windows so no key touches the screen edge
            val kpSide = if (land) dp(24) else dp(2)
            val cell = (contentW - 2 * kpSide) / 4
            val keypadH = minOf(cell * 5, (winH() * 0.5f).toInt())

            // Tablet landscape: the scientific keys open as a panel to the LEFT of the keypad (sideways),
            // instead of adding rows on top. Portrait keeps the stacked rows.
            val sideSci = land
            val keypad = LinearLayout(this).apply {
                orientation = if (sideSci) LinearLayout.HORIZONTAL else LinearLayout.VERTICAL
                setPadding(kpSide, 0, kpSide, dp(8))
            }
            val mainPanel: LinearLayout
            val sciRows = listOf(
                listOf("√", "π", "^", "!"),
                listOf(if (Evaluator.degrees) "Rad" else "Deg", "sin", "cos", "tan"),
                listOf("Inv", "e", "ln", "log")
            )
            if (sideSci) {
                val sciPanel = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    visibility = View.GONE
                }
                for (row in sciRows) {
                    val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                    for (label in row) {
                        line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                    }
                    sciPanel.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
                }
                sciLines.add(sciPanel)
                keypad.addView(sciPanel, LinearLayout.LayoutParams(0, -1, 1f).apply { rightMargin = dp(8) })
                mainPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
                keypad.addView(mainPanel, LinearLayout.LayoutParams(0, -1, 1f))
            } else {
                for (row in sciRows) {
                    val line = LinearLayout(this).apply {
                        orientation = LinearLayout.HORIZONTAL
                        visibility = View.GONE
                    }
                    for (label in row) {
                        line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                    }
                    sciLines.add(line)
                    keypad.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
                }
                mainPanel = keypad
            }

            val basicRows = listOf(
                listOf("AC", "( )", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+"),
                listOf("0", ".", "⌫", "=")
            )
            for (row in basicRows) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (label in row) {
                    line.addView(makeKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                mainPanel.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }
            // Scale glyphs to the real key height so tall/wide windows and short landscape ones both fit.
            val rowDp = keypadH / resources.displayMetrics.density / 5f
            val keyScale = minOf(uiScale, rowDp / 80f).coerceAtLeast(0.6f)
            // Tablet landscape (like Google's calculator): slightly larger, bolder key labels.
            val tabBoost = if (land) 1.25f else 1f
            fun semiBold(tf: Typeface?): Typeface =
                if (Build.VERSION.SDK_INT >= 28) Typeface.create(tf ?: Typeface.DEFAULT, 600, false)
                else Typeface.create(tf ?: Typeface.DEFAULT, Typeface.BOLD)
            for ((tv, sz) in keyTexts) {
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sz * keyScale * tabBoost)
                if (land) tv.typeface = semiBold(tv.typeface)
            }
            for ((_, tv) in sciKeys) {
                tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * keyScale * tabBoost)
                if (land) tv.typeface = semiBold(tv.typeface)
            }
            column.addView(keypad, LinearLayout.LayoutParams(-1, keypadH))
            root.addView(column, FrameLayout.LayoutParams(contentW, -1, Gravity.CENTER_HORIZONTAL))
        }

        val headerTop = if (land) dp(4) else dp(20)

        vaultPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
            isClickable = true
            isFocusable = true
        }
        val vHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), headerTop, dp(8), dp(8))
            gravity = Gravity.CENTER_VERTICAL
        }
        vaultTitle = TextView(this).apply {
            text = "Secure Vault"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), dp(8), dp(8))
            setOnClickListener {
                if (selected.isEmpty() && currentFolder != null) {
                    currentFolder = null
                    renderVaultFiles()
                }
            }
        }
        vHeader.addView(vaultTitle, LinearLayout.LayoutParams(0, -2, 1f))
        vaultCloseBtn = TextView(this).apply {
            text = "Close"
            setTextColor(pal.sciFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { if (selected.isNotEmpty()) clearSelection() else toggleVault() }
        }
        vHeader.addView(vaultCloseBtn)
        vHeader.addView(
            iconButton(R.drawable.ic_info, "About") { showAbout() },
            LinearLayout.LayoutParams(dp(48), dp(48)).apply { leftMargin = dp(4) }
        )
        vaultPanel.addView(vHeader)
        vaultChipsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(4), dp(8), dp(8))
        }
        vaultPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(vaultChipsRow)
        }, LinearLayout.LayoutParams(-1, -2))
        val vScroll = ScrollView(this)
        vaultFilesList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        vScroll.addView(vaultFilesList, LinearLayout.LayoutParams(-1, -2))
        vaultPanel.addView(vScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(vaultPanel, FrameLayout.LayoutParams(-1, -1))

        fabMenuOpen = false
        fabShape = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.acBg) }
        val fabMask = GradientDrawable().apply { cornerRadius = dpf(28); setColor(Color.BLACK) }
        fabIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_add)
            setColorFilter(pal.acFg)
        }
        val fab = FrameLayout(this).apply {
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), fabShape, fabMask)
            elevation = dpf(6)
            isClickable = true
            isFocusable = true
            contentDescription = "Add"
            setOnClickListener { setFabMenu(!fabMenuOpen) }
            addView(fabIcon, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        }
        fabScrim = View(this).apply {
            setBackgroundColor((pal.bg and 0xFFFFFF) or (0xE6 shl 24))
            visibility = View.GONE
            isClickable = true
            setOnClickListener { setFabMenu(false) }
        }
        fun fabPill(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
            val shape = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.acBg) }
            val mask = GradientDrawable().apply { cornerRadius = dpf(28); setColor(Color.BLACK) }
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(24), 0, dp(28), 0)
                background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
                elevation = dpf(4)
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(icon)
                    setColorFilter(pal.acFg)
                }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(12) })
                addView(TextView(this@MainActivity).apply {
                    text = label
                    setTextColor(pal.acFg)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                })
            }
        }
        val uploadPill = fabPill(R.drawable.ic_upload, "Upload") { setFabMenu(false); pickFileForVault() }
        folderPill = fabPill(R.drawable.ic_create_folder, "Folder") { setFabMenu(false); promptNewFolder() }
        fabMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            visibility = View.GONE
            addView(folderPill, LinearLayout.LayoutParams(-2, dp(56)).apply { topMargin = dp(12) })
            addView(uploadPill, LinearLayout.LayoutParams(-2, dp(56)).apply { topMargin = dp(12); bottomMargin = dp(8) })
        }
        vaultFabHost = FrameLayout(this).apply {
            visibility = View.GONE
            fitsSystemWindows = true
            addView(fabScrim, FrameLayout.LayoutParams(-1, -1))
            addView(fabMenu, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(16), dp(32) + dp(80) + dp(4))
            })
            addView(fab, FrameLayout.LayoutParams(dp(80), dp(80), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(16), dp(32))
            })
        }
        root.addView(vaultFabHost, FrameLayout.LayoutParams(-1, -1))
        vaultFilesList.setPadding(0, 0, 0, dp(136))

        return root
    }

    private fun addTopArea(column: LinearLayout, topBar: View) {

        val r = dpf(28)
        histBgDrawable = GradientDrawable().apply {
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            setColor(pal.bg)
        }
        histContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = histBgDrawable
        }
        histContainer.addView(topBar, LinearLayout.LayoutParams(-1, -2))

        histScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        historyList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
        }
        histScroll.addView(historyList, FrameLayout.LayoutParams(-1, -2))

        histThumb = View(this).apply {
            background = GradientDrawable().apply { cornerRadius = dpf(4); setColor(pal.icon) }
            alpha = 0f
        }
        histHost = FrameLayout(this).apply { visibility = View.GONE }
        histHost.addView(histScroll, FrameLayout.LayoutParams(-1, -1))
        histHost.addView(histThumb, FrameLayout.LayoutParams(dp(4), dp(36), Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(4)
        })
        histContainer.addView(histHost, LinearLayout.LayoutParams(-1, 0))
        column.addView(histContainer, LinearLayout.LayoutParams(-1, -2))

        histScroll.setOnScrollChangeListener { _, _, y, _, _ ->
            pinBottom = y >= (historyList.height - histScroll.height) - dp(4)
            updateHistThumb(true)
        }
        histScroll.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (pinBottom) {
                val bottom = (historyList.height - histScroll.height).coerceAtLeast(0)
                if (histScroll.scrollY != bottom) histScroll.scrollTo(0, bottom)
            }
            updateHistThumb(histDragging || histAnim?.isRunning == true)
        }

        histBtnFill = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pal.opBg); alpha = 0 }
        val btnMask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
        historyBtn?.background = RippleDrawable(ColorStateList.valueOf(pal.ripple), histBtnFill, btnMask)

        histHandle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            alpha = 0f
            setPadding(dp(24), dp(10), dp(24), 0)
            isClickable = true
            setOnClickListener { toggleHistory() }
        }
        histHandle.addView(View(this).apply {
            background = GradientDrawable().apply { cornerRadius = dpf(4); setColor(pal.icon) }
        }, LinearLayout.LayoutParams(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(8) })
        histHandle.addView(TextView(this).apply {
            text = "Current expression"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        })
        column.addView(histHandle, LinearLayout.LayoutParams(-1, 0))
    }

    private fun attachDisplayHost(v: View) {
        displayHost = v
        v.addOnLayoutChangeListener { view, _, top, _, bottom, _, _, _, _ ->
            if (histHeightPx == 0 && histAnim?.isRunning != true) {
                histTotal = (bottom - top) + (if (toolRowView != null) dp(64) else 0)
                if (pendingReopen && histTotal > 0) {
                    pendingReopen = false
                    view.post {
                        histMaxCache = computeHistMax()
                        if (histMaxCache > 0) {
                            renderHistory()
                            historyVisible = true
                            setHistHeight(histMaxCache)
                        }
                    }
                }
            }
        }
    }

    private fun computeHistMax(): Int {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val minDisplay = if (land) dp(64) else dp((104 * uiScale).toInt())
        if (histTotal <= 0) return 0

        return (histTotal - histHandleHeight - minDisplay).coerceAtLeast(dp(80))
    }

    private fun setHistHeight(h: Int) {
        val hh = h.coerceIn(0, histMaxCache)
        histHeightPx = hh
        val frac = if (histMaxCache > 0) hh.toFloat() / histMaxCache else 0f
        val show = hh > 0
        histHost.visibility = if (show) View.VISIBLE else View.GONE
        histHandle.visibility = if (show) View.VISIBLE else View.GONE
        histHost.layoutParams.height = hh
        histHandle.layoutParams.height = (histHandleHeight * frac).toInt()
        histHost.requestLayout()
        histHandle.requestLayout()
        histHandle.alpha = frac
        val c = argb.evaluate(frac, pal.bg, pal.histBg) as Int
        histBgDrawable.setColor(c)
        window.statusBarColor = c
        histBtnFill.alpha = (255 * frac).toInt()
        toolRowView?.let { v ->
            val lp = v.layoutParams
            lp.height = if (hh == 0) LinearLayout.LayoutParams.WRAP_CONTENT else (dp(64) * (1f - frac)).toInt()
            v.layoutParams = lp
            v.alpha = 1f - frac
            val blp = bottomScroll.layoutParams
            blp.height = (bottomBaseH - dp((16 * uiScale).toInt()) * frac).toInt()
            bottomScroll.layoutParams = blp
        }
    }

    private fun animateHist(target: Int, velocityY: Float = 0f) {
        histAnim?.cancel()
        historyVisible = target > 0
        val from = histHeightPx
        if (from == target || histMaxCache <= 0) return
        val dist = Math.abs(target - from).toFloat()
        val a = ValueAnimator.ofInt(from, target)

        var dur = 200f + 180f * dist / histMaxCache
        if (Math.abs(velocityY) > dpf(1500)) dur *= 0.75f
        a.duration = dur.toLong()
        a.interpolator = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
        a.addUpdateListener { setHistHeight(it.animatedValue as Int) }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (!cancelled) refresh()
            }
        })
        a.start()
        histAnim = a
    }

    private fun openHistory() {
        histAnim?.cancel()
        histMaxCache = computeHistMax()
        if (histMaxCache <= 0) return
        if (histHeightPx == 0) renderHistory()
        animateHist(histMaxCache)
    }

    private fun updateHistThumb(show: Boolean) {
        if (!::histThumb.isInitialized) return
        val content = historyList.height
        val view = histScroll.height
        if (view <= 0 || content <= view) { histThumb.alpha = 0f; return }
        val range = content - view
        val thumbH = Math.max(dp(36), (view.toLong() * view / content).toInt())
        val lp = histThumb.layoutParams
        if (lp.height != thumbH) { lp.height = thumbH; histThumb.layoutParams = lp }
        histThumb.translationY = histScroll.scrollY.toFloat() / range * (view - thumbH)
        if (show) {
            histThumb.animate().cancel()
            histThumb.alpha = 1f
            histThumb.removeCallbacks(hideThumb)
            histThumb.postDelayed(hideThumb, 900)
        }
    }

    private fun viewRect(v: View): Rect {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (vaultVisible || !::histHost.isInitialized || !::displayHost.isInitialized) return super.dispatchTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                histDragging = false
                dragZone = DragZone.NONE
                velocity?.recycle()
                velocity = null
                val x = ev.rawX.toInt()
                val y = ev.rawY.toInt()
                val inList = histHost.visibility == View.VISIBLE && viewRect(histHost).contains(x, y)
                val top = viewRect(histContainer).top
                val bottom = viewRect(displayHost).bottom
                dragZone = when {
                    inList -> DragZone.LIST
                    y in top..bottom -> DragZone.EDGE
                    else -> DragZone.NONE
                }
                if (dragZone != DragZone.NONE) {
                    dragDownX = ev.rawX
                    dragDownY = ev.rawY
                    velocity = VelocityTracker.obtain().also { it.addMovement(ev) }

                    if (dragZone == DragZone.EDGE && histAnim?.isRunning == true) {
                        histAnim?.cancel()
                        histDragging = true
                        dragStartH = histHeightPx
                        return true
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragZone == DragZone.NONE) return super.dispatchTouchEvent(ev)
                velocity?.addMovement(ev)
                if (!histDragging) {
                    val dy = ev.rawY - dragDownY
                    val dx = ev.rawX - dragDownX
                    val slop = ViewConfiguration.get(this).scaledTouchSlop
                    val vertical = Math.abs(dy) > slop && Math.abs(dy) > Math.abs(dx) * 1.2f
                    val canStart = vertical && when (dragZone) {
                        DragZone.EDGE -> when {
                            histHeightPx <= 0 -> dy > 0
                            histHeightPx >= histMaxCache -> dy < 0
                            else -> true
                        }
                        DragZone.LIST -> dy < 0 && !histScroll.canScrollVertically(1)
                        else -> false
                    }
                    if (!canStart) return super.dispatchTouchEvent(ev)
                    histAnim?.cancel()
                    histMaxCache = computeHistMax()
                    if (histMaxCache <= 0) { dragZone = DragZone.NONE; return super.dispatchTouchEvent(ev) }
                    if (histHeightPx == 0) renderHistory()
                    histDragging = true
                    dragStartH = histHeightPx
                    dragDownY = ev.rawY
                    val cancel = MotionEvent.obtain(ev)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                    return true
                }
                setHistHeight(dragStartH + (ev.rawY - dragDownY).toInt())
                historyVisible = histHeightPx > 0
                updateHistThumb(true)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val wasDragging = histDragging
                var vy = 0f
                velocity?.let {
                    it.addMovement(ev)
                    it.computeCurrentVelocity(1000)
                    vy = it.yVelocity
                    it.recycle()
                }
                velocity = null
                histDragging = false
                dragZone = DragZone.NONE
                if (wasDragging) {
                    val flick = dpf(600)
                    val target = when {
                        vy > flick -> histMaxCache
                        vy < -flick -> 0
                        histHeightPx > histMaxCache / 2 -> histMaxCache
                        else -> 0
                    }
                    animateHist(target, vy)
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun iconButton(res: Int, desc: String, onClick: (View) -> Unit): ImageView {
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
        return ImageView(this).apply {
            setImageResource(res)
            setColorFilter(pal.icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(10), dp(10), dp(10), dp(10))
            contentDescription = desc
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), null, mask)
            setOnClickListener { onClick(it) }
        }
    }

    private fun makeKey(label: String): View {
        val isOp = label in setOf("÷", "×", "−", "+", "%", "( )")
        val bg: Int
        val fg: Int
        when {
            label == "=" -> { bg = pal.eqBg; fg = pal.eqFg }
            label == "AC" -> { bg = pal.acBg; fg = pal.acFg }
            isOp -> { bg = pal.opBg; fg = pal.opFg }
            else -> { bg = pal.numBg; fg = pal.numFg }
        }
        val content: View = if (label == "⌫") {
            ImageView(this).apply {
                setImageResource(R.drawable.ic_backspace)
                setColorFilter(fg)
                layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
                backspaceIcon = this
            }
        } else {
            val bigOp = label in setOf("÷", "×", "−", "+", "=")
            val lightGlyph = label in setOf("÷", "×", "−", "+", "%", "( )")
            val size = when {
                label == "AC" -> 30f
                bigOp -> 40f
                else -> 34f
            }
            TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                typeface = if (label == "=") opFont else if (lightGlyph) displayFont else keyFont
                includeFontPadding = false
                layoutParams = FrameLayout.LayoutParams(-1, -1)
                keyTexts.add(this to size)
            }
        }
        val button = makeButton(content, bg) { onPress(label) }
        if (label == "=") {

            val holdRunnable = Runnable {
                holdFired = true
                button.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onEqualsHeld()
            }
            button.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        holdFired = false
                        handler.postDelayed(holdRunnable, 3000)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (ev.x < 0f || ev.y < 0f || ev.x > v.width || ev.y > v.height) handler.removeCallbacks(holdRunnable)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(holdRunnable)
                }
                false
            }

            button.setOnClickListener {
                if (holdFired) holdFired = false else onPress("=")
            }
        }
        if (label == "⌫") button.setOnLongClickListener { onPress("AC"); true }
        return button
    }

    private fun makeSciKey(label: String): View {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(pal.opFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = sciFont
            includeFontPadding = false
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        sciKeys[label] = tv
        if (label == "Rad" || label == "Deg") radKey = tv
        return makeButton(tv, pal.opBg) { onSciPress(label) }
    }

    private fun makeButton(content: View, bg: Int, onClick: () -> Unit): FrameLayout {
        val radius = dpf(200)
        val shape = GradientDrawable().apply { cornerRadius = radius; setColor(bg) }
        val mask = GradientDrawable().apply { cornerRadius = radius; setColor(Color.BLACK) }
        return FrameLayout(this).apply {
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            addView(content)
        }
    }

    private fun showMenu(anchor: View) {
        var popup: PopupWindow? = null
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.numBg) }
            setPadding(0, dp(8), 0, dp(8))
            minimumWidth = dp(200)
        }
        fun item(icon: Int, label: String, action: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(18), 0, dp(24), 0)
                background = rippleBg()
                setOnClickListener { popup?.dismiss(); action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(pal.icon)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                setPadding(dp(16), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
            card.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        item(R.drawable.ic_delete_history, "Clear history") { confirmClearHistory() }
        item(R.drawable.ic_palette, "Choose theme") { showThemeDialog() }

        val p = PopupWindow(card, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        p.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        p.isOutsideTouchable = true
        popup = p
        card.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = card.measuredWidth
        card.pivotX = w.toFloat()
        card.pivotY = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        card.alpha = 0f
        p.showAsDropDown(anchor, anchor.width - w - dp(8), dp(2))
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(160)
            .setInterpolator(PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
    }

    private fun toggleDegrees() {
        Evaluator.degrees = !Evaluator.degrees
        prefs.edit().putBoolean("deg", Evaluator.degrees).apply()
        radKey.text = if (Evaluator.degrees) "Rad" else "Deg"
        refresh()
    }

    private fun onSciPress(key: String) {
        if (key == "Rad" || key == "Deg") { toggleDegrees(); return }
        if (key == "Inv") { inverse = !inverse; updateSciLabels(); return }
        val inv = inverse
        val postfix = key == "^" || key == "!" || (key == "√" && inv)
        if (justEvaluated) {
            if (!postfix) expression = ""
            justEvaluated = false
        }
        when (key) {
            "√" -> expression += if (inv) "²" else "√"
            "π" -> expression += "π"
            "^" -> expression += "^"
            "!" -> expression += "!"
            "e" -> expression += "e"
            "sin" -> expression += if (inv) "arcsin(" else "sin("
            "cos" -> expression += if (inv) "arccos(" else "cos("
            "tan" -> expression += if (inv) "arctan(" else "tan("
            "ln" -> expression += if (inv) "e^(" else "ln("
            "log" -> expression += if (inv) withTimes("10^(") else "log("
        }
        if (inverse && key != "π" && key != "^" && key != "!" && key != "e") {
            inverse = false
            updateSciLabels()
        }
        refresh()
    }

    private fun withTimes(token: String): String =
        if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²!πe.")) "×$token" else token

    private fun updateSciLabels() {
        sciKeys["sin"]?.text = if (inverse) "sin⁻¹" else "sin"
        sciKeys["cos"]?.text = if (inverse) "cos⁻¹" else "cos"
        sciKeys["tan"]?.text = if (inverse) "tan⁻¹" else "tan"
        sciKeys["ln"]?.text = if (inverse) "eˣ" else "ln"
        sciKeys["log"]?.text = if (inverse) "10ˣ" else "log"
        sciKeys["√"]?.text = if (inverse) "x²" else "√"
        val tabletLand = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE &&
            resources.configuration.smallestScreenWidthDp >= 600
        sciKeys["Inv"]?.typeface = when {
            inverse -> Typeface.DEFAULT_BOLD
            tabletLand && Build.VERSION.SDK_INT >= 28 -> Typeface.create(sciFont, 600, false)
            else -> sciFont
        }
    }

    private fun updateExpandIcon() {
        expandBtn?.setImageResource(R.drawable.ic_code)
    }

    private fun toggleScientific() {
        sciVisible = !sciVisible
        for (line in sciLines) line.visibility = if (sciVisible) View.VISIBLE else View.GONE
        updateExpandIcon()
    }

    private fun toggleHistory() {
        if (historyVisible) animateHist(0) else openHistory()
    }

    private fun toggleVault() {
        vaultVisible = !vaultVisible
        if (vaultVisible) {
            renderVaultFiles()
        } else {
            setFabMenu(false)
            selected.clear()
            rowUpdaters.clear()
            thumbCache.clear()
            currentFolder = null
            vaultFilter = 0
            viewerDialog?.dismiss()
            dismissVaultDialogs()
        }
        vaultPanel.visibility = if (vaultVisible) View.VISIBLE else View.GONE
        vaultFabHost.visibility = if (vaultVisible) View.VISIBLE else View.GONE
        setSecure(vaultVisible)
    }

    private fun openUrl(url: String) {
        leavingForTask = true
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            leavingForTask = false
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAbout() {
        val sb = SpannableStringBuilder()
        fun link(text: String, url: String) {
            val start = sb.length
            sb.append(text)
            sb.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) { openUrl(url) }
                override fun updateDrawState(ds: TextPaint) {
                    ds.color = pal.result
                    ds.isUnderlineText = true
                }
            }, start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        sb.append("How to Use → ")
        link("CalCognito", REPO_URL)
        sb.append("\n\nCreated by The AryanOnion · ")
        link("GitHub", PROFILE_URL)
        sb.append("\n\nVersion ${appVersion()}")

        val body = TextView(this).apply {
            text = sb
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(pal.text)
            setLineSpacing(0f, 1.2f)
            movementMethod = LinkMovementMethod.getInstance()
            highlightColor = Color.TRANSPARENT
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), 0, dp(24), 0)
            addView(body)
        }
        aboutDialog?.dismiss()
        aboutDialog = showStyledDialog("About", box, "Close", null) {}
    }

    private fun isValidPin(s: String) = s.length >= 4 && s.all { it.isDigit() }

    private fun onEqualsHeld() {
        if (changeMode || justEvaluated) return
        if (VaultManager.isPinSet(this) && expression == "0000") {
            pinResetPending = true
            expression = ""
            refresh()
            Toast.makeText(this, "Press = again to reset PIN (erases existing files)", Toast.LENGTH_LONG).show()
            return
        }
        if (!VaultManager.isPinSet(this)) {
            if (isValidPin(expression)) {
                VaultManager.setPin(this, expression)
                expression = ""
                refresh()
                Toast.makeText(this, "Password set", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Type at least 4 digits, then hold = for 3 seconds", Toast.LENGTH_LONG).show()
            }
        } else if (VaultManager.checkPin(this, expression)) {

            expression = ""
            changeMode = true
            refresh()
        }

    }

    private fun getFileName(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1) result = cursor.getString(idx)
                }
            } finally {
                cursor?.close()
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != -1 && cut != null) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }

    private fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            afterPermission = action
            leavingForTask = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_PERM)
        } else {
            action()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            val action = afterPermission
            afterPermission = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                action?.invoke()
            } else {
                Toast.makeText(this, "Storage permission is needed to move files", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun pickFileForVault() = withStoragePermission {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        leavingForTask = true
        try {
            startActivityForResult(intent, REQ_PICK)
        } catch (e: Exception) {
            leavingForTask = false
            Toast.makeText(this, "No file picker available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun collectUris(data: Intent): List<Uri> {
        val list = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i).uri?.let { list.add(it) }
            }
        } else {
            data.data?.let { list.add(it) }
        }
        return list
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_PICK -> if (resultCode == RESULT_OK && data != null) confirmAdd(collectUris(data))
            REQ_DELETE_BATCH -> {
                if (resultCode != RESULT_OK) hideNotRemoved += batchDeleteCount
                finishHide()
            }
            REQ_DELETE_LEGACY -> {
                val uri = legacyCurrent
                legacyCurrent = null
                if (resultCode == RESULT_OK && uri != null) {
                    try {
                        if (contentResolver.delete(uri, null, null) <= 0) hideNotRemoved++
                    } catch (_: Exception) {
                        hideNotRemoved++
                    }
                } else {
                    hideNotRemoved++
                }
                processLegacyDeleteQueue()
            }
        }
    }

    private fun confirmAdd(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val check = CheckBox(this).apply {
            text = "Encrypt the files"
            isChecked = false
            setTextColor(pal.text)
            buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(pal.cursor, pal.text)
            )
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(msgBody(
                "Files are moved into the vault and removed from your gallery and file manager.\n\n" +
                "Not encrypted: opens instantly, and other apps can't see it, but the file itself isn't scrambled.\n" +
                "Encrypted: fully protected, but a bit slower to add and open."
            ))
            addView(check, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(20), dp(12), dp(24), 0) })
        }
        showStyledDialog("Add ${uris.size} file(s) to vault", ScrollView(this).apply { addView(box) }, "Add", "Cancel") {
            hideSelectedFiles(uris, check.isChecked)
        }
    }

    private fun hideSelectedFiles(uris: List<Uri>, encrypt: Boolean) {
        if (uris.isEmpty()) return
        hideHidden = 0
        hideFailed = 0
        hideNotRemoved = 0
        val targetFolder = currentFolder
        val progress = showProgress("Moving ${uris.size} file(s) into the vault…")

        Thread {
            val needConfirm = mutableListOf<Uri>()
            for ((i, uri) in uris.withIndex()) {
                val name = getFileName(uri) ?: "file_${System.currentTimeMillis()}_$i"
                if (!VaultManager.addToVault(applicationContext, uri, name, targetFolder, encrypt)) {
                    hideFailed++
                    continue
                }
                hideHidden++

                if (!VaultManager.tryDeleteOriginal(applicationContext, uri)) {
                    val media = VaultManager.toMediaStoreUri(applicationContext, uri)
                    if (media != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) needConfirm.add(media)
                    else hideNotRemoved++
                }
            }
            runOnUiThread {
                try { progress.dismiss() } catch (_: Exception) {}
                renderVaultFiles()
                when {
                    needConfirm.isEmpty() -> finishHide()
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> requestBatchDelete(needConfirm)
                    else -> {
                        legacyDeleteQueue.addAll(needConfirm)
                        processLegacyDeleteQueue()
                    }
                }
            }
        }.start()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun requestBatchDelete(uris: List<Uri>) {
        batchDeleteCount = uris.size
        try {
            val request = MediaStore.createDeleteRequest(contentResolver, uris)
            leavingForTask = true
            startIntentSenderForResult(request.intentSender, REQ_DELETE_BATCH, null, 0, 0, 0)
        } catch (e: Exception) {
            leavingForTask = false
            hideNotRemoved += uris.size
            finishHide()
        }
    }

    private fun processLegacyDeleteQueue() {
        while (legacyDeleteQueue.isNotEmpty()) {
            val uri = legacyDeleteQueue.removeAt(0)
            try {
                if (contentResolver.delete(uri, null, null) <= 0) hideNotRemoved++
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && e is RecoverableSecurityException) {
                    legacyCurrent = uri
                    leavingForTask = true
                    try {
                        startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ_DELETE_LEGACY, null, 0, 0, 0)
                        return
                    } catch (_: Exception) {
                        leavingForTask = false
                        legacyCurrent = null
                        hideNotRemoved++
                    }
                } else {
                    hideNotRemoved++
                }
            } catch (_: Exception) {
                hideNotRemoved++
            }
        }
        finishHide()
    }

    private fun finishHide() {
        renderVaultFiles()
        if (hideFailed == 0 && hideNotRemoved == 0) {
            if (hideHidden > 0) Toast.makeText(this, "$hideHidden file(s) hidden in the vault", Toast.LENGTH_SHORT).show()
            return
        }
        val msg = StringBuilder()
        if (hideHidden > 0) msg.append("$hideHidden file(s) are now in the vault.\n\n")
        if (hideNotRemoved > 0) {
            msg.append("$hideNotRemoved original(s) could not be removed from their old location, so they are still visible there. ")
            msg.append("Delete them manually, or allow the deletion request when Android asks.\n\n")
        }
        if (hideFailed > 0) msg.append("$hideFailed file(s) could not be copied into the vault and were left untouched.")
        showStyledDialog("Hide result", msgBody(msg.toString().trim()), "OK", null) {}
    }

    private fun openVaultFile(file: File) {
        val name = VaultManager.displayName(file)
        val mime = VaultManager.mimeFor(name)
        when {
            name.endsWith(".txt", ignoreCase = true) -> showTextEditor(file)
            mime.startsWith("image/") -> showImageViewer(file)
            mime.startsWith("video/") || mime.startsWith("audio/") -> showMediaViewer(file)
            else -> openExternally(file, mime)
        }
    }

    /** The vault file currently shown in a viewer; it changes when the file is encrypted/decrypted from the viewer. */
    private class ViewerState(var file: File)

    private class MenuRow(val icon: Int, val label: String, val color: Int, val action: () -> Unit)

    private fun shortName(name: String): String = if (name.length > 18) name.take(18) + "..." else name

    /**
     * Full-screen viewer. Top bar: back arrow (left), file name (centre, first 18 characters + "..."),
     * three-dot menu (right). The menu is the same in every viewer, in this order:
     * Open with, Encrypt/Decrypt, Unhide, Share, Delete (red).
     * [beforeAction] runs before Open with / Encrypt / Decrypt / Unhide / Share (the editor uses it to save pending edits).
     */
    private fun showViewer(
        state: ViewerState,
        content: View,
        editor: Boolean = false,
        beforeAction: () -> Unit = {},
        onClose: () -> Unit = {}
    ) {
        viewerDialog?.dismiss()
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val fg = if (editor) pal.text else Color.WHITE
        val rippleColor = if (editor) pal.ripple else Color.parseColor("#33FFFFFF")
        val root = FrameLayout(this).apply { setBackgroundColor(if (editor) pal.bg else Color.BLACK) }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(if (editor) pal.bg else Color.parseColor("#B3000000"))
            setPadding(dp(4), 0, dp(4), 0)
        }
        fun barButton(icon: Int, desc: String, onClick: (View) -> Unit): ImageView = ImageView(this).apply {
            setImageResource(icon)
            setColorFilter(fg)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            contentDescription = desc
            background = RippleDrawable(
                ColorStateList.valueOf(rippleColor), null,
                GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            )
            setOnClickListener { onClick(it) }
        }
        val title = TextView(this).apply {
            text = shortName(VaultManager.displayName(state.file))
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            maxLines = 1
            gravity = Gravity.CENTER
        }
        bar.addView(barButton(R.drawable.ic_arrow_back, "Close") { dialog.dismiss() }, LinearLayout.LayoutParams(dp(48), dp(48)))
        bar.addView(title, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(barButton(R.drawable.ic_more_vert, "More options") { anchor ->
            val encrypted = VaultManager.isEncrypted(state.file)
            val rows = ArrayList<MenuRow>()
            rows.add(MenuRow(R.drawable.ic_open_in_new, "Open with", pal.text) {
                beforeAction()
                openExternally(state.file, VaultManager.mimeFor(VaultManager.displayName(state.file)), chooser = true, keepTemp = true)
            })
            rows.add(MenuRow(
                if (encrypted) R.drawable.ic_lock_open else R.drawable.ic_lock,
                if (encrypted) "Decrypt" else "Encrypt", pal.text
            ) {
                beforeAction()
                cryptViewerFile(state, !encrypted) { title.text = shortName(VaultManager.displayName(state.file)) }
            })
            rows.add(MenuRow(R.drawable.ic_unhide, "Unhide", pal.text) {
                beforeAction()
                dialog.dismiss()
                unhideFile(state.file)
            })
            rows.add(MenuRow(R.drawable.ic_share, "Share", pal.text) {
                beforeAction()
                shareFiles(listOf(state.file), keepTemp = true)
            })
            rows.add(MenuRow(R.drawable.ic_delete, "Delete", if (isNightMode()) Color.parseColor("#FF6B5E") else Color.parseColor("#D93025")) {
                dialog.dismiss()
                confirmDelete(state.file)
            })
            showViewerMenu(anchor, rows)
        }, LinearLayout.LayoutParams(dp(48), dp(48)))
        root.addView(bar, FrameLayout.LayoutParams(-1, dp(56), Gravity.TOP))

        dialog.setContentView(root)
        if (editor) {
            // Keep the text clear of the keyboard (adjustResize is ignored by fullscreen windows).
            dialog.window?.let { w ->
                w.setSoftInputMode(
                    WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE or
                        WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
                )
                if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(false)
            }
            root.setOnApplyWindowInsetsListener { v, ins ->
                val bottom = if (Build.VERSION.SDK_INT >= 30) {
                    maxOf(
                        ins.getInsets(android.view.WindowInsets.Type.ime()).bottom,
                        ins.getInsets(android.view.WindowInsets.Type.navigationBars()).bottom
                    )
                } else {
                    @Suppress("DEPRECATION") ins.systemWindowInsetBottom
                }
                v.setPadding(0, 0, 0, bottom)
                ins
            }
        }
        dialog.setOnDismissListener {
            onClose()
            if (viewerDialog === dialog) viewerDialog = null
            VaultManager.clearTemp(applicationContext)
        }
        viewerDialog = dialog
        dialog.show()
    }

    private fun showViewerMenu(anchor: View, rows: List<MenuRow>) {
        var popup: PopupWindow? = null
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.numBg) }
            setPadding(0, dp(8), 0, dp(8))
            minimumWidth = dp(200)
        }
        for (r in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(18), 0, dp(24), 0)
                background = rippleBg()
                setOnClickListener { popup?.dismiss(); r.action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(r.icon)
                setColorFilter(r.color)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            row.addView(TextView(this).apply {
                text = r.label
                setTextColor(r.color)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                setPadding(dp(16), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
            card.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        val p = PopupWindow(card, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        p.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        p.isOutsideTouchable = true
        popup = p
        card.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = card.measuredWidth
        card.pivotX = w.toFloat()
        card.pivotY = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        card.alpha = 0f
        p.showAsDropDown(anchor, anchor.width - w - dp(8), dp(2))
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(160)
            .setInterpolator(PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
    }

    /** Encrypts/decrypts the file shown in a viewer, then points the viewer at the renamed file. */
    private fun cryptViewerFile(state: ViewerState, encrypt: Boolean, onDone: () -> Unit) {
        val src = state.file
        val progress = showProgress(if (encrypt) "Encrypting…" else "Decrypting…")
        Thread {
            val r = if (encrypt) VaultManager.encryptInVault(applicationContext, src)
                    else VaultManager.decryptInVault(applicationContext, src)
            runOnUiThread {
                try { progress.dismiss() } catch (_: Exception) {}
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (r != null) {
                    state.file = r
                    thumbCache.clear()
                    onDone()
                    if (vaultVisible) renderVaultFiles()
                }
                Toast.makeText(
                    this,
                    when {
                        r != null && encrypt -> "Encrypted"
                        r != null -> "Decrypted"
                        encrypt -> "Couldn't encrypt (file left unchanged)"
                        else -> "Couldn't decrypt (file left unchanged)"
                    },
                    Toast.LENGTH_SHORT
                ).show()
            }
        }.start()
    }

    private fun showTextEditor(file: File) {
        if (file.length() > 1_100_000L) {
            Toast.makeText(this, "Too large for the built-in editor", Toast.LENGTH_SHORT).show()
            openExternally(file, "text/plain")
            return
        }
        Thread {
            val bytes = VaultManager.readDecrypted(file)
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (bytes == null) {
                    Toast.makeText(this, "Unable to open this file", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                // Keep the file's own encoding so saving never alters bytes the user didn't touch.
                val cs = try {
                    Charsets.UTF_8.newDecoder()
                        .onMalformedInput(java.nio.charset.CodingErrorAction.REPORT)
                        .decode(java.nio.ByteBuffer.wrap(bytes))
                    Charsets.UTF_8
                } catch (_: Exception) {
                    Charsets.ISO_8859_1
                }
                buildTextEditor(file, String(bytes, cs), cs)
            }
        }.start()
    }

    private fun buildTextEditor(file: File, initial: String, cs: java.nio.charset.Charset) {
        val state = ViewerState(file)
        var dirty = false
        val et = EditText(this).apply {
            setText(initial)
            setTextColor(pal.text)
            setHintTextColor(pal.icon)
            hint = "Tap to start typing"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setLineSpacing(0f, 1.15f)
            gravity = Gravity.TOP or Gravity.START
            background = null
            setPadding(dp(16), dp(12), dp(16), dp(24))
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE
            imeOptions = android.view.inputmethod.EditorInfo.IME_FLAG_NO_PERSONALIZED_LEARNING
            isVerticalScrollBarEnabled = true
            isSaveEnabled = false
        }
        et.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) { dirty = true }
        })
        fun save(announce: Boolean) {
            if (!dirty) return
            val ok = VaultManager.overwriteContent(applicationContext, state.file, et.text.toString().toByteArray(cs))
            if (ok) {
                dirty = false
                thumbCache.clear()
                if (announce) Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Couldn't save changes", Toast.LENGTH_SHORT).show()
            }
        }
        // Edits are saved automatically: on back arrow / system back / leaving the app, and before share or encrypt/decrypt.
        val holder = FrameLayout(this).apply {
            setPadding(0, dp(56), 0, 0)
            addView(et, FrameLayout.LayoutParams(-1, -1))
        }
        showViewer(state, holder, editor = true, beforeAction = { save(false) }, onClose = { save(true) })
    }

    private fun showImageViewer(file: File) {
        val dm = resources.displayMetrics
        Thread {
            val bm = try {
                VaultManager.readDecrypted(file)?.let { VaultManager.decodeBitmap(it, (dm.widthPixels * 1.5f).toInt(), (dm.heightPixels * 1.5f).toInt()) }
            } catch (_: Throwable) {
                null
            }
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (bm == null) {
                    Toast.makeText(this, "Unable to open this image", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val iv = ZoomImageView(this, dp(56)).apply { setImageBitmap(bm) }
                showViewer(ViewerState(file), iv)
            }
        }.start()
    }

    private fun showMediaViewer(file: File) {
        Toast.makeText(this, "Opening…", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp: File? = if (VaultManager.isEncrypted(file)) VaultManager.decryptToTemp(applicationContext, file) else file
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (tmp == null) {
                    Toast.makeText(this, "Decryption failed", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                buildPlayer(file, tmp)
            }
        }.start()
    }

    private fun buildPlayer(file: File, media: File) {
        val ui = Handler(Looper.getMainLooper())
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val speedLabels = arrayOf("0.5x", "0.75x", "1x (Normal)", "1.25x", "1.5x", "2x")
        var speedIdx = 2
        var player: MediaPlayer? = null
        var prepared = false
        var dragging = false
        var holdBoost = false
        var gesture = 0

        val vv = VideoView(this)
        val white = Color.WHITE
        val soft = Color.parseColor("#B3FFFFFF")

        fun fmt(ms: Int): String {
            val t = (ms / 1000).coerceAtLeast(0)
            val h = t / 3600
            val m = (t % 3600) / 60
            val sec = t % 60
            return if (h > 0) java.lang.String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
            else java.lang.String.format(java.util.Locale.US, "%d:%02d", m, sec)
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.parseColor("#CC000000"))
            )
            setPadding(dp(16), dp(32), dp(16), dp(28))
        }
        val cur = TextView(this).apply {
            text = "0:00"; setTextColor(white); setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        }
        val total = TextView(this).apply {
            text = "0:00"; setTextColor(soft); setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        }
        val seek = SeekBar(this).apply {
            max = 1
            progressTintList = ColorStateList.valueOf(pal.result)
            thumbTintList = ColorStateList.valueOf(pal.result)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#55FFFFFF"))
        }
        val playIcon = ImageView(this).apply {
            setColorFilter(white)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }

        val hide = Runnable {
            if (vv.isPlaying && !dragging) controls.visibility = View.GONE
        }
        fun showControls() {
            controls.visibility = View.VISIBLE
            ui.removeCallbacks(hide)
            if (vv.isPlaying) ui.postDelayed(hide, 3000)
        }
        fun updatePlayIcon() {
            playIcon.setImageResource(if (vv.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        }
        fun applySpeed() {
            val mp = player ?: return
            try {
                val playing = vv.isPlaying
                mp.playbackParams = mp.playbackParams.setSpeed(if (holdBoost) 2f else speeds[speedIdx])
                if (!playing) vv.pause()
            } catch (_: Exception) {
                Toast.makeText(this, "Speed change isn't supported for this file", Toast.LENGTH_SHORT).show()
            }
        }
        fun togglePlay() {
            if (!prepared) return
            if (vv.isPlaying) {
                vv.pause()
            } else {
                if (vv.currentPosition >= vv.duration - 200) vv.seekTo(0)
                vv.start()
                applySpeed()
            }
            updatePlayIcon()
            showControls()
        }
        val pill = TextView(this).apply {
            setTextColor(white)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dpf(100)
                setColor(Color.parseColor("#99000000"))
            }
            visibility = View.GONE
        }
        val hidePill = Runnable { pill.visibility = View.GONE }
        fun showPill(msg: String, grav: Int, sticky: Boolean = false) {
            pill.text = msg
            val lp = pill.layoutParams as FrameLayout.LayoutParams
            lp.gravity = grav
            lp.topMargin = if ((grav and Gravity.VERTICAL_GRAVITY_MASK) == Gravity.TOP) dp(88) else dp(24)
            pill.layoutParams = lp
            pill.visibility = View.VISIBLE
            ui.removeCallbacks(hidePill)
            if (!sticky) ui.postDelayed(hidePill, 800)
        }
        fun skip(deltaMs: Int) {
            if (!prepared) return
            val t = (vv.currentPosition + deltaMs).coerceIn(0, vv.duration)
            vv.seekTo(t)
            seek.progress = t
            cur.text = fmt(t)
            val label = (if (deltaMs < 0) "−10s" else "+10s") + " (" + fmt(t) + ")"
            showPill(label, (if (deltaMs < 0) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL)
        }
        fun circle(sizeDp: Int, onClick: () -> Unit): FrameLayout = FrameLayout(this).apply {
            val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), null, mask)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { setMargins(dp(6), 0, dp(6), 0) }
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) cur.text = fmt(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                ui.removeCallbacks(hide)
            }
            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                if (prepared) vv.seekTo(sb.progress)
                showControls()
            }
        })

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(cur)
            addView(seek, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
            addView(total)
        }

        val speedBtn = TextView(this).apply {
            text = "1x"
            setTextColor(white)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = dpf(100)
                setColor(Color.parseColor("#33FFFFFF"))
            }
            setOnClickListener {
                var pick = speedIdx
                val body = radioRows(speedLabels.toList(), speedIdx) { pick = it }
                showStyledDialog("Playback speed", body, "OK", "Cancel") {
                    speedIdx = pick
                    applySpeed()
                    text = if (speeds[pick] == 1f) "1x" else speedLabels[pick]
                    showControls()
                }
            }
        }
        val playBtn = circle(64) { togglePlay() }.apply {
            addView(playIcon, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        }
        val helpBtn = TextView(this).apply {
            text = "?"
            setTextColor(white)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#33FFFFFF"))
            }
            setOnClickListener { showVideoHelp() }
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(FrameLayout(this@MainActivity).apply {
                addView(speedBtn, FrameLayout.LayoutParams(dp(64), dp(34), Gravity.START or Gravity.CENTER_VERTICAL))
            }, LinearLayout.LayoutParams(0, dp(64), 1f))
            addView(playBtn)
            addView(FrameLayout(this@MainActivity).apply {
                addView(helpBtn, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.CENTER_VERTICAL))
            }, LinearLayout.LayoutParams(0, dp(64), 1f))
        }
        controls.addView(row1, LinearLayout.LayoutParams(-1, -2))
        controls.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val tick = object : Runnable {
            override fun run() {
                if (prepared && !dragging) {
                    val pos = vv.currentPosition
                    seek.progress = pos
                    cur.text = fmt(pos)
                }
                updatePlayIcon()
                ui.postDelayed(this, 250)
            }
        }

        vv.setOnPreparedListener { mp ->
            player = mp
            prepared = true
            val d = vv.duration.coerceAtLeast(1)
            seek.max = d
            total.text = fmt(d)
            vv.start()
            applySpeed()
            updatePlayIcon()
            showControls()
        }
        vv.setOnCompletionListener {
            seek.progress = seek.max
            cur.text = fmt(vv.duration)
            updatePlayIcon()
            ui.removeCallbacks(hide)
            controls.visibility = View.VISIBLE
        }
        vv.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Couldn't play this file", Toast.LENGTH_SHORT).show()
            true
        }
        vv.setVideoPath(media.absolutePath)

        val holder = FrameLayout(this).apply {
            addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }

        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startLevel = 0f

        fun curBrightness(): Float {
            val b = viewerDialog?.window?.attributes?.screenBrightness ?: -1f
            if (b >= 0f) return b
            return try {
                Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
            } catch (_: Exception) { 0.5f }
        }
        fun setBrightness(v: Float) {
            val w = viewerDialog?.window ?: return
            val lp = w.attributes
            lp.screenBrightness = v.coerceIn(0.01f, 1f)
            w.attributes = lp
        }

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (controls.visibility == View.VISIBLE && vv.isPlaying) {
                    ui.removeCallbacks(hide)
                    controls.visibility = View.GONE
                } else {
                    showControls()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val w = holder.width.toFloat()
                when {
                    e.x < w / 3f -> skip(-10_000)
                    e.x > w * 2f / 3f -> skip(10_000)
                    else -> {
                        togglePlay()
                        showPill(if (vv.isPlaying) "Playing" else "Paused", Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                    }
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!prepared || !vv.isPlaying || gesture != 0) return
                holdBoost = true
                applySpeed()
                holder.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showPill("2x", Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (holdBoost || e1 == null) return false
                val w = holder.width.toFloat()
                val h = holder.height.toFloat()
                if (gesture == 0) {
                    val dx = Math.abs(e2.x - e1.x)
                    val dy = Math.abs(e2.y - e1.y)
                    if (dy > slop && dy > dx) {
                        if (e1.x < w / 2f) {
                            gesture = 1
                            startLevel = curBrightness()
                        } else {
                            gesture = 2
                            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                            startLevel = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                        }
                        ui.removeCallbacks(hide)
                    } else if (dx > slop) {
                        gesture = 3
                        return false
                    } else {
                        return false
                    }
                }
                if (gesture == 1 || gesture == 2) {
                    val level = (startLevel + (e1.y - e2.y) / (h * 0.7f)).coerceIn(0f, 1f)
                    val pct = Math.round(level * 100)
                    if (gesture == 1) {
                        setBrightness(level)
                        showPill("Brightness $pct%", Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
                    } else {
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(level * max), 0)
                        showPill("Volume $pct%", Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
                    }
                    return true
                }
                return false
            }
        })
        holder.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (holdBoost) {
                    holdBoost = false
                    applySpeed()
                    ui.removeCallbacks(hidePill)
                    pill.visibility = View.GONE
                }
                if (gesture != 0) {
                    gesture = 0
                    ui.removeCallbacks(hidePill)
                    ui.postDelayed(hidePill, 600)
                }
            }
            true
        }
        ui.post(tick)
        showViewer(ViewerState(file), holder, onClose = {
            ui.removeCallbacksAndMessages(null)
            try { vv.stopPlayback() } catch (_: Exception) {}
        })
    }

    private fun openExternally(file: File, mime: String, chooser: Boolean = false, keepTemp: Boolean = false) {
        Toast.makeText(this, "Opening…", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp = if (keepTemp) VaultManager.decryptForShare(applicationContext, file)
                else VaultManager.decryptToTemp(applicationContext, file)
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (tmp == null) {
                    Toast.makeText(this, "Decryption failed", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", tmp)
                val viewMime = if (mime == "application/octet-stream") "*/*" else mime
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, viewMime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                leavingForTask = true
                externalViewing = true
                try {
                    startActivity(if (chooser) Intent.createChooser(viewIntent, "Open with") else viewIntent)
                } catch (e: Exception) {
                    leavingForTask = false
                    externalViewing = false
                    if (!keepTemp) VaultManager.clearTemp(applicationContext)
                    Toast.makeText(this, "No app can open this file. Use Unhide to restore it.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    /** [keepTemp] is set when sharing from a viewer, so the temp copy a video is playing from isn't deleted. */
    private fun shareFiles(files: List<File>, keepTemp: Boolean = false) {
        if (files.isEmpty()) return
        Toast.makeText(this, "Preparing…", Toast.LENGTH_SHORT).show()
        Thread {
            if (!keepTemp) VaultManager.clearTemp(applicationContext)
            val temps = ArrayList<File>()
            for (f in files) VaultManager.decryptForShare(applicationContext, f)?.let { temps.add(it) }
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (temps.isEmpty()) {
                    Toast.makeText(this, "Couldn't prepare files for sharing", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                if (temps.size < files.size) {
                    Toast.makeText(this, "Some files couldn't be shared", Toast.LENGTH_SHORT).show()
                }
                val uris = ArrayList(temps.map { FileProvider.getUriForFile(this, "$packageName.fileprovider", it) })
                val mimes = temps.map { VaultManager.mimeFor(it.name) }.distinct()
                val type = when {
                    mimes.size == 1 -> mimes[0]
                    mimes.map { it.substringBefore('/') }.distinct().size == 1 -> mimes[0].substringBefore('/') + "/*"
                    else -> "*/*"
                }
                val send = if (uris.size == 1) {
                    Intent(Intent.ACTION_SEND).apply { putExtra(Intent.EXTRA_STREAM, uris[0]) }
                } else {
                    Intent(Intent.ACTION_SEND_MULTIPLE).apply { putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris) }
                }
                send.type = type
                send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                val clip = ClipData.newUri(contentResolver, "files", uris[0])
                for (i in 1 until uris.size) clip.addItem(ClipData.Item(uris[i]))
                send.clipData = clip
                leavingForTask = true
                try {
                    startActivity(Intent.createChooser(send, "Share"))
                } catch (e: Exception) {
                    leavingForTask = false
                    if (!keepTemp) VaultManager.clearTemp(applicationContext)
                    Toast.makeText(this, "No app available to share with", Toast.LENGTH_SHORT).show()
                }
            }
        }.start()
    }

    private fun unhideFile(file: File) = withStoragePermission {
        Toast.makeText(this, "Unhiding…", Toast.LENGTH_SHORT).show()
        Thread {
            val folder = VaultManager.restoreToPublic(applicationContext, file)
            if (folder != null) VaultManager.deleteFile(this, file)
            runOnUiThread {
                if (folder != null) {
                    Toast.makeText(this, "Restored to $folder", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Couldn't unhide this file (it is still safe in the vault)", Toast.LENGTH_LONG).show()
                }
                renderVaultFiles()
            }
        }.start()
    }

    private fun confirmDelete(file: File) {
        showStyledDialog(
            "Delete permanently?",
            msgBody("\"${VaultManager.displayName(file)}\" will be deleted from the vault and cannot be recovered."),
            "Delete", "Cancel"
        ) {
            VaultManager.deleteFile(this, file)
            renderVaultFiles()
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
        }
    }

    private fun categoryOf(name: String): Int {
        val mime = VaultManager.mimeFor(name)
        return when {
            mime.startsWith("image/") -> 1
            mime.startsWith("video/") -> 2
            else -> 3
        }
    }

    private fun filterChip(label: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(if (selected) pal.eqFg else pal.sciFg)
        typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = GradientDrawable().apply {
            cornerRadius = dpf(100)
            setColor(if (selected) pal.eqBg else pal.numBg)
        }
        setOnClickListener { onClick() }
    }

    private fun chipParams() = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }

    private fun renderVaultChips() {
        vaultChipsRow.removeAllViews()
        listOf("All", "Images", "Videos", "Files").forEachIndexed { i, label ->
            vaultChipsRow.addView(filterChip(label, vaultFilter == i) {
                vaultFilter = i
                renderVaultFiles()
            }, chipParams())
        }
        val sortLabels = listOf("A–Z", "Newest", "Largest")
        vaultChipsRow.addView(filterChip("Sort: ${sortLabels[vaultSort]}", false) {
            vaultSort = (vaultSort + 1) % 3
            renderVaultFiles()
        }, chipParams())
        if (currentFolder == null) {
            vaultChipsRow.addView(filterChip("+ Folder", false) { promptNewFolder() }, chipParams())
        }
    }

    private fun promptText(title: String, initial: String, positive: String, hint: String = "Folder name", onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            this.hint = hint
            setSingleLine(true)
            setText(initial)
            setSelection(text.length)
            setTextColor(pal.text)
            setHintTextColor(pal.icon)
            backgroundTintList = ColorStateList.valueOf(pal.cursor)
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), 0, dp(24), 0)
            addView(input)
        }
        val d = showStyledDialog(title, box, positive, "Cancel") { onOk(input.text.toString()) }
        d.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        input.requestFocus()
    }

    private fun promptNewFolder(onCreated: ((String) -> Unit)? = null) {
        promptText("New folder", "", "Create") { raw ->
            val name = VaultManager.cleanFolderName(raw)
            if (name == null) {
                Toast.makeText(this, "Enter a folder name", Toast.LENGTH_SHORT).show()
            } else if (VaultManager.folderExists(this, name)) {
                if (onCreated != null) onCreated(name)
                else Toast.makeText(this, "A folder with that name already exists", Toast.LENGTH_SHORT).show()
            } else if (VaultManager.createFolder(this, name)) {
                if (onCreated != null) {
                    onCreated(name)
                } else {
                    renderVaultFiles()
                    Toast.makeText(this, "Folder created", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Couldn't create folder", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showFolderMenu(anchor: View, folder: String) {
        showListDialog(folder, listOf(
            Triple(R.drawable.ic_edit, "Rename", {
                promptText("Rename folder", folder, "Rename") { raw ->
                    val newName = VaultManager.cleanFolderName(raw)
                    if (newName == null) {
                        Toast.makeText(this, "Enter a folder name", Toast.LENGTH_SHORT).show()
                    } else if (newName != folder) {
                        if (VaultManager.renameFolder(this, folder, newName)) renderVaultFiles()
                        else Toast.makeText(this, "Couldn't rename (that name may already exist)", Toast.LENGTH_SHORT).show()
                    }
                }
            }),
            Triple(R.drawable.ic_delete, "Delete folder", { confirmDeleteFolder(folder) })
        ))
    }

    private fun confirmDeleteFolder(folder: String) {
        showStyledDialog(
            "Delete folder?",
            msgBody("\"$folder\" will be removed. Any files inside move back to the main vault, nothing is deleted."),
            "Delete folder", "Cancel"
        ) {
            VaultManager.deleteFolder(this, folder)
            renderVaultFiles()
        }
    }

    private fun showMoveDialog(files: List<File>) {
        val rows = mutableListOf<Triple<Int, String, () -> Unit>>()
        if (currentFolder != null) rows.add(Triple(R.drawable.ic_folder, "Main vault", { moveInto(files, null) }))
        for (f in VaultManager.listFolders(this)) {
            if (f != currentFolder) rows.add(Triple(R.drawable.ic_folder, f, { moveInto(files, f) }))
        }
        rows.add(Triple(R.drawable.ic_create_folder, "New folder…", { promptNewFolder { name -> moveInto(files, name) } }))
        showListDialog("Move to", rows)
    }

    private fun moveInto(files: List<File>, folder: String?) {
        var ok = 0
        for (f in files) if (VaultManager.moveFile(this, f, folder) != null) ok++
        selected.clear()
        renderVaultFiles()
        val where = folder ?: "main vault"
        Toast.makeText(
            this,
            when {
                ok == 0 -> "Couldn't move"
                ok < files.size -> "Moved $ok of ${files.size} to $where"
                ok == 1 -> "Moved to $where"
                else -> "Moved $ok files to $where"
            },
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun toggleSelect(path: String) {
        if (!selected.add(path)) selected.remove(path)
        rowUpdaters[path]?.invoke()
        updateSelectionUi()
    }

    private fun clearSelection() {
        val old = selected.toList()
        selected.clear()
        old.forEach { rowUpdaters[it]?.invoke() }
        updateSelectionUi()
    }

    private fun selectedFiles(): List<File> = selected.map { File(it) }.filter { it.exists() }

    private fun setFabMenu(open: Boolean) {
        fabMenuOpen = open
        fabScrim.visibility = if (open) View.VISIBLE else View.GONE
        fabMenu.visibility = if (open) View.VISIBLE else View.GONE
        folderPill.visibility = if (currentFolder == null) View.VISIBLE else View.GONE
        fabShape.setColor(if (open) pal.cursor else pal.acBg)
        fabIcon.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_add)
        fabIcon.setColorFilter(if (open) pal.bg else pal.acFg)
        fabMenu.animate().cancel()
        fabScrim.animate().cancel()
        if (open) {
            fabMenu.alpha = 0f
            fabScrim.alpha = 0f
            fabMenu.animate().alpha(1f).setDuration(150).start()
            fabScrim.animate().alpha(1f).setDuration(150).start()
        }
    }

    private fun updateSelectionUi() {
        val n = selected.size
        if (n > 0 && fabMenuOpen) setFabMenu(false)
        vaultTitle.text = when {
            n > 0 -> "$n selected"
            currentFolder == null -> "Secure Vault"
            else -> "‹  $currentFolder"
        }
        vaultCloseBtn.text = if (n > 0) "Cancel" else "Close"
        vaultFabHost.visibility = if (vaultVisible && n == 0) View.VISIBLE else View.GONE
    }

    private fun onFileLongPress(file: File) {
        if (file.absolutePath !in selected) toggleSelect(file.absolutePath)
        showSelectionSheet()
    }

    private fun showSelectionSheet() {
        if (selectedFiles().isEmpty()) return
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val r = dpf(28)
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setColor(pal.dialogBg)
            }
            setPadding(0, dp(20), 0, dp(16))
        }
        sheet.addView(TextView(this).apply {
            text = "Selected files"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setPadding(dp(24), 0, dp(24), dp(16))
        })
        sheet.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sheet.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, -2))
        val current = selectedFiles()

        fun item(icon: Int, label: String, color: Int, action: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(24), 0, dp(24), 0)
                background = rippleBg()
                isClickable = true
                setOnClickListener { dialog.dismiss(); action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(color)
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(24) })
            row.addView(TextView(this).apply {
                text = label
                setTextColor(color)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            })
            list.addView(row, LinearLayout.LayoutParams(-1, dp(60)))
        }
        item(R.drawable.ic_open_in_new, "Open with", pal.text) {
            val files = selectedFiles()
            if (files.size == 1) openExternally(files[0], VaultManager.mimeFor(VaultManager.displayName(files[0])), chooser = true)
            else Toast.makeText(this, "Select a single file to use Open with", Toast.LENGTH_SHORT).show()
        }
        item(R.drawable.ic_unhide, "Unhide", pal.text) { unhideFiles(selectedFiles()) }
        if (current.any { !VaultManager.isEncrypted(it) }) {
            item(R.drawable.ic_lock, "Encrypt", pal.text) { cryptFiles(selectedFiles(), true) }
        }
        if (current.any { VaultManager.isEncrypted(it) }) {
            item(R.drawable.ic_lock_open, "Decrypt", pal.text) { cryptFiles(selectedFiles(), false) }
        }
        item(R.drawable.ic_open_with, "Move", pal.text) { showMoveDialog(selectedFiles()) }
        item(R.drawable.ic_share, "Share", pal.text) { shareFiles(selectedFiles()) }
        item(R.drawable.ic_delete, "Delete", pal.clearFg) { confirmDeleteSelected(selectedFiles()) }

        if (current.size == 1) {
            item(R.drawable.ic_edit, "Rename", pal.text) { renameSelected(current[0]) }
        }

        dialog.setContentView(sheet)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
        }
        trackVaultDialog(dialog)
        dialog.show()
    }

    private fun confirmDeleteSelected(files: List<File>) {
        if (files.isEmpty()) return
        val n = files.size
        showStyledDialog(
            "Delete permanently?",
            msgBody(
                if (n == 1) "\"${VaultManager.displayName(files[0])}\" will be deleted from the vault and cannot be recovered."
                else "$n files will be deleted from the vault and cannot be recovered."
            ),
            "Delete", "Cancel"
        ) {
            files.forEach { VaultManager.deleteFile(this, it) }
            selected.clear()
            renderVaultFiles()
            Toast.makeText(this, if (n == 1) "Deleted" else "Deleted $n files", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renameSelected(file: File) {
        promptText("Rename", VaultManager.displayName(file), "Rename", "Name") { raw ->
            val name = raw.trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
            } else if (name != VaultManager.displayName(file)) {
                if (VaultManager.renameFile(this, file, name) != null) {
                    selected.clear()
                    renderVaultFiles()
                    Toast.makeText(this, "Renamed", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Couldn't rename (that name may already exist)", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun cryptFiles(files: List<File>, encrypt: Boolean) {
        val todo = files.filter { VaultManager.isEncrypted(it) != encrypt }
        if (todo.isEmpty()) {
            Toast.makeText(this, if (encrypt) "Already encrypted" else "Already decrypted", Toast.LENGTH_SHORT).show()
            return
        }
        val progress = showProgress(if (encrypt) "Encrypting ${todo.size} file(s)…" else "Decrypting ${todo.size} file(s)…")
        Thread {
            var ok = 0
            for (f in todo) {
                val r = if (encrypt) VaultManager.encryptInVault(applicationContext, f)
                        else VaultManager.decryptInVault(applicationContext, f)
                if (r != null) ok++
            }
            runOnUiThread {
                try { progress.dismiss() } catch (_: Exception) {}
                selected.clear()
                thumbCache.clear()
                if (vaultVisible) renderVaultFiles()
                val verb = if (encrypt) "Encrypted" else "Decrypted"
                Toast.makeText(
                    this,
                    when {
                        ok == 0 -> "Couldn't ${verb.lowercase().removeSuffix("ed")} (files left unchanged)"
                        ok < todo.size -> "$verb $ok of ${todo.size} files"
                        ok == 1 -> "$verb 1 file"
                        else -> "$verb $ok files"
                    },
                    Toast.LENGTH_SHORT
                ).show()
            }
        }.start()
    }

    private fun unhideFiles(files: List<File>) = withStoragePermission {
        if (files.isEmpty()) return@withStoragePermission
        Toast.makeText(this, "Unhiding…", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var lastFolder: String? = null
            for (f in files) {
                val folder = VaultManager.restoreToPublic(applicationContext, f)
                if (folder != null) {
                    VaultManager.deleteFile(this, f)
                    ok++
                    lastFolder = folder
                }
            }
            runOnUiThread {
                selected.clear()
                val msg = when {
                    ok == 0 -> "Couldn't unhide (still safe in the vault)"
                    ok == files.size && ok == 1 -> "Restored to $lastFolder"
                    ok == files.size -> "Restored $ok files"
                    else -> "Restored $ok of ${files.size} files (the rest are still safe in the vault)"
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (vaultVisible) renderVaultFiles()
            }
        }.start()
    }

    private fun upgradeInBackground(file: File, wantThumb: Boolean, applyThumb: (Bitmap) -> Unit) {
        val path = file.absolutePath
        if (!migrating.add(path)) return
        try {
            migrateExecutor.execute {
                try {
                    if (VaultManager.isLegacy(file) && VaultManager.migrateLegacy(file) && wantThumb) {
                        val bm = VaultManager.readThumb(file)
                        if (bm != null) {
                            thumbCache[path + file.lastModified()] = bm
                            runOnUiThread { applyThumb(bm) }
                        }
                    }
                } finally {
                    migrating.remove(path)
                }
            }
        } catch (_: Exception) {
            migrating.remove(path)
        }
    }

    private fun renderVaultFiles() {
        val folder = currentFolder
        rowUpdaters.clear()
        renderVaultChips()
        vaultFilesList.removeAllViews()

        val folders = if (folder == null) VaultManager.listFolders(this) else emptyList()
        val all = VaultManager.listFiles(this, folder)
        val filtered = all.filter { vaultFilter == 0 || categoryOf(VaultManager.displayName(it)) == vaultFilter }
        val files = when (vaultSort) {
            1 -> filtered.sortedByDescending { it.lastModified() }
            2 -> filtered.sortedByDescending { it.length() }
            else -> filtered.sortedBy { VaultManager.displayName(it).lowercase() }
        }
        selected.retainAll(files.map { it.absolutePath }.toSet())
        updateSelectionUi()

        if (folders.isEmpty() && files.isEmpty()) {
            val msg = when {
                all.isNotEmpty() -> "No ${listOf("files", "images", "videos", "files")[vaultFilter].lowercase()} here"
                folder == null -> "No files in vault"
                else -> "This folder is empty"
            }
            vaultFilesList.addView(TextView(this).apply {
                text = msg
                setTextColor(pal.icon)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            })
            return
        }

        for (f in folders) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(16), dp(8), dp(4), dp(8))
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                setOnClickListener {
                    selected.clear()
                    currentFolder = f
                    renderVaultFiles()
                }
                setOnLongClickListener { v -> showFolderMenu(v, f); true }
            }
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_folder)
                setColorFilter(pal.result)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                text = f
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(TextView(this).apply {
                text = "${VaultManager.countFiles(this@MainActivity, f)} file(s)"
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(iconButton(R.drawable.ic_more_vert, "Folder options") { showFolderMenu(it, f) }, LinearLayout.LayoutParams(dp(44), dp(44)))
            vaultFilesList.addView(row)
            vaultFilesList.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        }

        for (file in files) {
            val name = VaultManager.displayName(file)
            val mime = VaultManager.mimeFor(name)
            val isImage = mime.startsWith("image/")

            val path = file.absolutePath
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(8), dp(8), dp(8))
                isClickable = true
                setOnClickListener {
                    if (selected.isNotEmpty()) toggleSelect(path) else openVaultFile(file)
                }
                setOnLongClickListener {
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onFileLongPress(file)
                    true
                }
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val thumb = ImageView(this).apply {
                layoutParams = FrameLayout.LayoutParams(-1, -1)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setColorFilter(pal.icon)
                setImageResource(
                    when {
                        isImage -> R.drawable.ic_image
                        mime.startsWith("video/") || mime.startsWith("audio/") -> R.drawable.ic_play
                        else -> R.drawable.ic_file
                    }
                )
                tag = file.absolutePath
            }
            val selOverlay = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dpf(8)
                    setColor((pal.eqBg and 0xFFFFFF) or (0xCC shl 24))
                }
                visibility = View.GONE
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_check)
                    setColorFilter(pal.eqFg)
                }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
            }
            val thumbBox = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) }
                isClickable = true
                setOnClickListener { toggleSelect(path) }
                setOnLongClickListener {
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onFileLongPress(file)
                    true
                }
                addView(thumb)
                addView(selOverlay, FrameLayout.LayoutParams(-1, -1))
            }
            top.addView(thumbBox)
            if (VaultManager.isEncrypted(file)) {
                thumb.setImageResource(R.drawable.ic_lock)
                thumb.setColorFilter(pal.result)
                thumb.setPadding(dp(12), dp(12), dp(12), dp(12))
                thumbBox.background = GradientDrawable().apply { cornerRadius = dpf(12); setColor(pal.numBg) }
            }
            val selTint = (pal.opBg and 0xFFFFFF) or (0x55 shl 24)
            val updateRow = {
                val on = path in selected
                selOverlay.visibility = if (on) View.VISIBLE else View.GONE
                row.setBackgroundColor(if (on) selTint else Color.TRANSPARENT)
            }
            rowUpdaters[path] = updateRow
            updateRow()

            val isVideo = mime.startsWith("video/")
            val applyThumb = { bm: Bitmap ->
                if (thumb.tag == file.absolutePath) {
                    thumb.clearColorFilter()
                    thumb.setPadding(0, 0, 0, 0)
                    thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                    thumb.setImageBitmap(bm)
                }
            }
            if ((isImage || isVideo) && !VaultManager.isEncrypted(file)) {
                val key = file.absolutePath + file.lastModified()
                val cached = thumbCache[key]
                if (cached != null) {
                    applyThumb(cached)
                } else {
                    try {
                        thumbExecutor.execute {
                            val bm = VaultManager.readThumb(file)
                            if (bm != null) {
                                thumbCache[key] = bm
                                runOnUiThread { applyThumb(bm) }
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
            }
            if (VaultManager.isEncrypted(file)) upgradeInBackground(file, false, applyThumb)

            val nameCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            nameCol.addView(TextView(this).apply {
                text = name
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            nameCol.addView(TextView(this).apply {
                text = if (VaultManager.isEncrypted(file)) "Encrypted" else "Not encrypted"
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            })
            top.addView(nameCol, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(top, LinearLayout.LayoutParams(-1, -2))

            vaultFilesList.addView(row)
            vaultFilesList.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("entries", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split("\u0002").mapNotNull {
            val parts = it.split("\u0001")
            if (parts.size == 2) parts[0] to parts[1] else null
        }
    }

    private fun saveHistoryEntry(expr: String, result: String) {
        val entries = (listOf(expr to result) + loadHistory()).take(100)
        val raw = entries.joinToString("\u0002") { "${it.first}\u0001${it.second}" }
        prefs.edit().putString("entries", raw).apply()
    }

    private fun confirmClearHistory() {
        showStyledDialog("Clear history and memory?", null, "Clear", "Dismiss") { clearHistory() }
    }

    private fun clearHistory() {
        prefs.edit().remove("entries").apply()
        renderHistory()
        Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        pinBottom = true
        val entries = loadHistory().reversed()
        if (entries.isEmpty()) {
            historyList.addView(TextView(this).apply {
                text = "No history yet"
                setTextColor(pal.icon)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2))
            return
        }
        for ((expr, result) in entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(24), dp(12), dp(24), dp(12))
                isClickable = true
                background = RippleDrawable(ColorStateList.valueOf(pal.ripple), null, ColorDrawable(Color.BLACK))
                setOnClickListener {
                    expression = result
                    previousExpression = expr
                    justEvaluated = true
                    toggleHistory()
                    refresh()
                }
            }

            row.addView(TextView(this).apply {
                text = group(expr) + " ="
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = displayFont
                gravity = Gravity.END
                setLineSpacing(0f, 1.1f)
            }, LinearLayout.LayoutParams(-1, -2))

            val resultView = TextView(this).apply {
                typeface = displayFont
                gravity = Gravity.END
            }
            val grouped = group(result)
            resultView.text = grouped
            style(resultView, 20, 34, pal.text, grouped)
            row.addView(resultView, LinearLayout.LayoutParams(-1, -2))
            historyList.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        histScroll.post { histScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyResult() {
        if (!justEvaluated && cachedRawResult.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val toCopy = (if (isInfiniteResult && cachedRawResult.isNotEmpty()) cachedRawResult else expression)
            .replace(",", "").replace('−', '-')
        cm.setPrimaryClip(ClipData.newPlainText("result", toCopy))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun pasteIntoExpression() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val sanitized = text.filter { it.isDigit() || it in "+-×÷.%()^!√" }.replace('-', '−')
        if (sanitized.isEmpty()) return
        if (justEvaluated) { expression = ""; justEvaluated = false }
        expression += sanitized
        refresh()
    }

    private fun onPress(key: String) {
        errorText = null
        if (key != "=" && pinResetPending) pinResetPending = false
        when (key) {
            in "0".."9" -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                expression += key
            }
            "." -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                val lastNumber = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!lastNumber.contains('.')) expression += if (lastNumber.isEmpty()) "0." else "."
            }
            "+", "×", "÷", "−" -> {
                justEvaluated = false
                val op = key[0]
                if (expression.isEmpty() || expression.last() == '(') {
                    if (op == '−') expression += "−"
                } else if (expression.last() in operators) {
                    expression = if (expression.length > 1 && expression[expression.length - 2] != '(')
                        expression.dropLast(1) + op
                    else if (op == '−') expression else expression.dropLast(1)
                } else {
                    expression += op
                }
            }
            "%" -> {
                justEvaluated = false
                if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²")) expression += "%"
            }
            "( )" -> {
                justEvaluated = false
                val open = expression.count { it == '(' }
                val close = expression.count { it == ')' }
                val last = expression.lastOrNull()
                val canClose = open > close && last != null && (last.isDigit() || last in ")%²πe!")
                expression += if (canClose) ")" else "("
            }
            "⌫" -> {
                if (justEvaluated) { justEvaluated = false; previousExpression = "" }
                else {
                    val hadOpen = expression.endsWith("(")
                    expression = expression.dropLast(1)
                    if (hadOpen) {
                        for (f in listOf("arcsin", "arccos", "arctan", "asin", "acos", "atan", "sin", "cos", "tan", "ln", "log")) {
                            if (expression.endsWith(f)) { expression = expression.dropLast(f.length); break }
                        }
                    }
                }
            }
            "AC" -> { expression = ""; previousExpression = ""; justEvaluated = false }
            "=" -> {
                if (pinResetPending) {
                    pinResetPending = false
                    VaultManager.resetVault(this)
                    expression = ""
                    justEvaluated = false
                    Toast.makeText(this, "PIN and vault files erased. Type a new PIN, then hold = for 3 seconds.", Toast.LENGTH_LONG).show()
                    refresh()
                    return
                }
                if (changeMode) {
                    if (isValidPin(expression)) {
                        VaultManager.setPin(this, expression)
                        changeMode = false
                        expression = ""
                        justEvaluated = false
                        Toast.makeText(this, "Password changed", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Password must be at least 4 digits", Toast.LENGTH_SHORT).show()
                    }
                    refresh()
                    return
                }
                if (VaultManager.isPinSet(this) && VaultManager.checkPin(this, expression)) {
                    expression = ""
                    justEvaluated = false
                    toggleVault()
                    refresh()
                    return
                }
                if (expression.isNotEmpty() && !justEvaluated) {
                    try {
                        val cleaned = closeParens(trimTrailingOps(expression))
                        val result = Evaluator.formatExpr(cleaned)
                        previousExpression = expression
                        expression = result
                        justEvaluated = true
                        saveHistoryEntry(previousExpression, expression)
                        if (histHeightPx > 0) renderHistory()
                    } catch (e: ArithmeticException) {
                        errorText = e.message ?: "Value too large"
                    } catch (e: Exception) {
                        errorText = "Format error"
                    }
                }
            }
        }
        refresh()
    }

    private fun trimTrailingOps(s: String): String {
        var t = s
        while (t.isNotEmpty() && (t.last() in operators || t.last() == '(')) t = t.dropLast(1)
        return t
    }

    private fun closeParens(s: String): String {
        val missing = s.count { it == '(' } - s.count { it == ')' }
        return if (missing > 0) s + ")".repeat(missing) else s
    }

    private val numberRegex = Regex("(\\d+)(\\.\\d*)?")
    private val plainNumberRegex = Regex("^−?[\\d.]+$")
    private val measurePaint = Paint()

    private fun group(s: String): String =
        numberRegex.replace(s) { m ->
            val int = m.groupValues[1].reversed().chunked(3).joinToString(",").reversed()
            int + m.groupValues[2]
        }

    private fun availWidthFor(view: TextView): Float {
        val w = when {
            view === topView -> topScroll.width
            view === bottomView -> bottomScroll.width
            else -> view.width
        }
        if (w > 0) return w.toFloat()
        return ((if (contentW > 0) contentW else winW()) - dp(48)).toFloat()
    }

    private fun style(view: TextView, minSp: Int, maxSp: Int, color: Int, sampleText: CharSequence) {
        view.setTextColor(color)
        val compact = histHeightPx > 0 && (view === topView || view === bottomView)
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var cap = (maxSp * uiScale).toInt()
        if (compact) cap = minOf(cap, (40 * uiScale).toInt())
        if (land && view === topView) cap = minOf(cap, (resources.configuration.screenHeightDp * 0.11f).toInt())
        if (land && view === bottomView) cap = minOf(cap, (resources.configuration.screenHeightDp * 0.11f).toInt())
        cap = minOf(cap, 100)
        val maxSp = cap
        val minSp = minOf(minSp, maxSp)
        val availWidth = availWidthFor(view)
        val availHeight = when {
            view === topView -> topScroll.height
            view === bottomView -> bottomScroll.height
            else -> 0
        }
        val paint = measurePaint
        paint.set(view.paint)
        // Fit by width first; if the window is too short for the line, keep shrinking until it fits
        // vertically too (down to 10sp) so text is never clipped in small / landscape windows.
        val floorSp = if (availHeight > 0) minOf(10, minSp) else minSp
        var chosenSp = floorSp
        for (sp in maxSp downTo floorSp step 2) {
            paint.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp.toFloat(), resources.displayMetrics)
            val fm = paint.fontMetrics
            val heightOk = availHeight <= 0 || (fm.bottom - fm.top) <= availHeight
            val widthOk = paint.measureText(sampleText, 0, sampleText.length) <= availWidth
            if (heightOk && (widthOk || sp <= minSp)) {
                chosenSp = sp
                break
            }
        }
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, chosenSp.toFloat())
    }

    private fun refresh() {
        scroller.forceFinished(true)
        bottomView.removeCallbacks(flingRunnable)
        scrollOffsetPx = 0f
        bottomScroll.scrollTo(0, 0)
        currentPrecision = 120

        topView.gravity = if (justEvaluated) Gravity.END or Gravity.BOTTOM else Gravity.END or Gravity.CENTER_VERTICAL
        if (justEvaluated) {
            val topStr = group(previousExpression) + " ="
            style(topView, 16, 26, pal.icon, topStr)
            topView.text = topStr
            topScroll.post { topScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }

            val cleanedPrev = closeParens(trimTrailingOps(previousExpression))
            activeEvalExpr = cleanedPrev
            isInfiniteResult = cleanedPrev.isNotEmpty() && try { Evaluator.hasInfiniteDecimals(cleanedPrev) } catch (_: Exception) { false }
            cachedRawResult = if (isInfiniteResult) {
                try { Evaluator.evalBig(cleanedPrev, currentPrecision) }
                catch (e: Exception) {
                    errorText = e.message ?: "Value too large"
                    expression
                }
            } else {
                expression
            }
        } else {
            val groupedExpr = group(expression)
            style(topView, 28, 76, pal.text, groupedExpr)
            val sb = SpannableStringBuilder(groupedExpr)
            sb.append("\u200B")
            cursorSpan.visible = true
            sb.setSpan(cursorSpan, sb.length - 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            topView.text = sb
            topScroll.post { topScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }

            preparePreviewState()
        }

        renderBottomResult()
    }

    private fun preparePreviewState() {
        val e = trimTrailingOps(expression)
        if (e.isEmpty() || plainNumberRegex.matches(e)) {
            isInfiniteResult = false
            activeEvalExpr = ""
            cachedRawResult = ""
            return
        }
        try {
            val cleaned = closeParens(e)
            activeEvalExpr = cleaned
            isInfiniteResult = Evaluator.hasInfiniteDecimals(cleaned)
            cachedRawResult = if (isInfiniteResult) {
                Evaluator.evalBig(cleaned, currentPrecision)
            } else {
                Evaluator.formatExpr(cleaned)
            }
        } catch (ex: Exception) {
            isInfiniteResult = false
            cachedRawResult = ""
        }
    }

    private fun renderBottomResult() {
        if (changeMode) {
            val msg = "Enter new password, press ="
            style(bottomView, 16, 26, pal.result, msg)
            bottomView.text = msg
            return
        }
        val minSp = if (justEvaluated) 28 else 16
        val maxSp = if (justEvaluated) 64 else 26
        val mainColor = if (justEvaluated) pal.text else pal.result

        if (errorText != null) {
            style(bottomView, minSp, maxSp, pal.clearFg, errorText!!)
            bottomView.text = errorText
            return
        }

        if (!isInfiniteResult || !cachedRawResult.contains('.')) {
            val grouped = group(cachedRawResult)
            style(bottomView, minSp, maxSp, mainColor, grouped)
            bottomView.text = grouped
            return
        }

        bottomView.setTextColor(mainColor)
        bottomView.setTextSize(TypedValue.COMPLEX_UNIT_SP, minSp.toFloat())

        val availWidth = availWidthFor(bottomView)
        val paint = bottomView.paint
        val digitWidth = paint.measureText("0").coerceAtLeast(1f)
        val charOffset = (scrollOffsetPx / digitWidth).toInt()

        val dotIdx = cachedRawResult.indexOf('.')
        val intPartGrouped = group(cachedRawResult.substring(0, dotIdx)) + "."
        var frac = cachedRawResult.substring(dotIdx + 1)

        if (charOffset <= 0) {
            var count = 1
            while (count < frac.length && paint.measureText(intPartGrouped + frac.substring(0, count + 1)) <= availWidth) {
                count++
            }
            bottomView.text = intPartGrouped + frac.substring(0, count)
            return
        }

        val sampleOverhead = paint.measureText("...E-100")
        val baseVisibleDigits = ((availWidth - sampleOverhead) / digitWidth).toInt().coerceAtLeast(6)
        val endIdx = baseVisibleDigits + charOffset

        if (endIdx + 35 > frac.length && currentPrecision < 1200) {
            currentPrecision = (endIdx + 120).coerceAtMost(1200)
            try {
                cachedRawResult = Evaluator.evalBig(activeEvalExpr, currentPrecision)
                val newDot = cachedRawResult.indexOf('.')
                if (newDot != -1) frac = cachedRawResult.substring(newDot + 1)
            } catch (_: Exception) {}
        }

        val clampedEnd = endIdx.coerceAtMost(frac.length)
        val prefix = "..."
        val suffix = "E-$clampedEnd"
        val remainingForDigits = availWidth - paint.measureText(prefix) - paint.measureText(suffix)

        var startIdx = clampedEnd - 1
        while (startIdx > 0 && paint.measureText(frac, startIdx - 1, clampedEnd) <= remainingForDigits) {
            startIdx--
        }

        val visibleDigits = frac.substring(startIdx.coerceAtLeast(0), clampedEnd)
        val sb = SpannableStringBuilder()
        sb.append(prefix)
        sb.append(visibleDigits)
        val expStart = sb.length
        sb.append(suffix)
        sb.setSpan(ForegroundColorSpan(pal.icon), expStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        bottomView.text = sb
    }

    /** Handles back inside the app. Returns true if it consumed the press. */
    private fun handleBack(): Boolean {
        when {
            historyVisible -> toggleHistory()
            vaultVisible && fabMenuOpen -> setFabMenu(false)
            vaultVisible && selected.isNotEmpty() -> clearSelection()
            vaultVisible -> {
                if (currentFolder != null) {
                    currentFolder = null
                    renderVaultFiles()
                } else {
                    toggleVault()
                }
            }
            else -> return false
        }
        return true
    }

    // Android 13+ (and always when targeting API 36) delivers back through the predictive-back
    // dispatcher; onBackPressed() is only called on older versions.
    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (!handleBack()) super.onBackPressed()
    }

    @Suppress("DEPRECATION")
    private fun registerBackCallback() {
        if (Build.VERSION.SDK_INT >= 33) {
            onBackInvokedDispatcher.registerOnBackInvokedCallback(
                OnBackInvokedDispatcher.PRIORITY_DEFAULT,
                OnBackInvokedCallback { if (!handleBack()) super@MainActivity.onBackPressed() }
            )
        }
    }
}

/** Image view with pinch-to-zoom, drag-to-pan and double-tap zoom. [topInsetPx] keeps the image clear of the top bar. */
private class ZoomImageView(ctx: Context, private val topInsetPx: Int) : ImageView(ctx) {
    private val m = Matrix()
    private val vals = FloatArray(9)
    private val rect = RectF()
    private var minScale = 1f
    private var maxScale = 1f

    private val scaleDetector = ScaleGestureDetector(ctx, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
        override fun onScale(d: ScaleGestureDetector): Boolean {
            zoomBy(d.scaleFactor, d.focusX, d.focusY)
            return true
        }
    })
    private val gestures = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDown(e: MotionEvent): Boolean = true
        override fun onScroll(e1: MotionEvent?, e2: MotionEvent, dx: Float, dy: Float): Boolean {
            m.postTranslate(-dx, -dy)
            clampAndApply()
            return true
        }
        override fun onDoubleTap(e: MotionEvent): Boolean {
            val cur = currentScale()
            if (cur > minScale * 1.05f) zoomBy(minScale / cur, e.x, e.y) else zoomBy(2.5f, e.x, e.y)
            return true
        }
    })

    init { scaleType = ScaleType.MATRIX }

    override fun setImageBitmap(bm: Bitmap?) {
        super.setImageBitmap(bm)
        fit()
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        fit()
    }

    private fun currentScale(): Float {
        m.getValues(vals)
        return vals[Matrix.MSCALE_X]
    }

    private fun fit() {
        val d = drawable ?: return
        val aw = width.toFloat()
        val ah = (height - topInsetPx).toFloat()
        if (aw <= 0f || ah <= 0f || d.intrinsicWidth <= 0 || d.intrinsicHeight <= 0) return
        val s = minOf(aw / d.intrinsicWidth, ah / d.intrinsicHeight)
        m.reset()
        m.postScale(s, s)
        m.postTranslate((aw - d.intrinsicWidth * s) / 2f, topInsetPx + (ah - d.intrinsicHeight * s) / 2f)
        minScale = s
        maxScale = s * 6f
        imageMatrix = m
    }

    private fun zoomBy(factor: Float, fx: Float, fy: Float) {
        val cur = currentScale()
        if (cur <= 0f) return
        val target = (cur * factor).coerceIn(minScale, maxScale)
        val f = target / cur
        m.postScale(f, f, fx, fy)
        clampAndApply()
    }

    private fun clampAndApply() {
        val d = drawable ?: return
        rect.set(0f, 0f, d.intrinsicWidth.toFloat(), d.intrinsicHeight.toFloat())
        m.mapRect(rect)
        val left = 0f
        val top = topInsetPx.toFloat()
        val right = width.toFloat()
        val bottom = height.toFloat()
        var dx = 0f
        var dy = 0f
        dx = if (rect.width() <= right - left) (left + right) / 2f - rect.centerX()
             else if (rect.left > left) left - rect.left
             else if (rect.right < right) right - rect.right else 0f
        dy = if (rect.height() <= bottom - top) (top + bottom) / 2f - rect.centerY()
             else if (rect.top > top) top - rect.top
             else if (rect.bottom < bottom) bottom - rect.bottom else 0f
        m.postTranslate(dx, dy)
        imageMatrix = m
    }

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        scaleDetector.onTouchEvent(ev)
        if (!scaleDetector.isInProgress) gestures.onTouchEvent(ev)
        parent?.requestDisallowInterceptTouchEvent(ev.pointerCount > 1 || currentScale() > minScale * 1.01f)
        return true
    }
}
