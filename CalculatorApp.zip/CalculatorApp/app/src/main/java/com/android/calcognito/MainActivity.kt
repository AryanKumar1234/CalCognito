package com.android.calcognito

import android.Manifest
import android.animation.ArgbEvaluator
import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.RecoverableSecurityException
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.AudioManager
import android.media.ExifInterface
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.provider.Settings
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.TextUtils
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.ReplacementSpan
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.ViewConfiguration
import android.view.animation.PathInterpolator
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.OverScroller
import android.widget.PopupMenu
import android.widget.PopupWindow
import android.widget.RadioButton
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class Palette(
        val bg: Int, val text: Int, val icon: Int,
        val numBg: Int, val numFg: Int,
        val opBg: Int, val opFg: Int,
        val acBg: Int, val acFg: Int,
        val eqBg: Int, val eqFg: Int,
        val sciBg: Int, val sciFg: Int,
        val result: Int, val cursor: Int,
        val clearFg: Int, val ripple: Int, val divider: Int,
        val histBg: Int, val dialogBg: Int
    )

    private fun c(hex: String) = Color.parseColor(hex)

    private val light = Palette(
        bg = c("#FFF8F6"), text = c("#231917"), icon = c("#53433F"),
        numBg = c("#F1DFDA"), numFg = c("#231917"),
        opBg = c("#E7BDB2"), opFg = c("#442A22"),
        acBg = c("#FFDAD6"), acFg = c("#410002"),
        eqBg = c("#8B5000"), eqFg = c("#FFFFFF"),
        sciBg = c("#F1DFDA"), sciFg = c("#442A22"),
        result = c("#6B5E2F"), cursor = c("#9A4026"),
        clearFg = c("#BA1A1A"), ripple = c("#33000000"), divider = c("#E7D6D1"), histBg = c("#F8EBE7"), dialogBg = c("#F6E6E1")
    )
    private val dark = Palette(
        bg = c("#1D100D"), text = c("#EEE0DD"), icon = c("#D7C3BD"),
        numBg = c("#43302E"), numFg = c("#EEE0DD"),
        opBg = c("#5D4038"), opFg = c("#FFDBD2"),
        acBg = c("#93000A"), acFg = c("#FFDAD6"),
        eqBg = c("#F8BD85"), eqFg = c("#4A2800"),
        sciBg = c("#40332D"), sciFg = c("#FFDBD2"),
        result = c("#DAC58E"), cursor = c("#FFB5A2"),
        clearFg = c("#FFB5A2"), ripple = c("#33FFFFFF"), divider = c("#3A2C27"), histBg = c("#271C18"), dialogBg = c("#322621")
    )
    private lateinit var pal: Palette

    /** Whether to derive the palette from the system's Material You / wallpaper colors (Android 12+). */
    private fun dynamicColorAvailable(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S

    private fun useDynamicColor(): Boolean = dynamicColorAvailable() && prefs.getBoolean("dynamic_theme", true)

    private fun resolvePalette(night: Boolean): Palette {
        if (useDynamicColor()) buildDynamicPalette(night)?.let { return it }
        return if (night) dark else light
    }

    private fun sysColor(resId: Int): Int? = try { resources.getColor(resId, theme) } catch (_: Exception) { null }

    /**
     * Android 14+ exposes the real Material 3 color roles of the wallpaper scheme
     * (android.R.color.system_surface_dark, system_tertiary_dark, ...), the same ones Pixel
     * Calculator is themed with. They are looked up by name so older systems simply fall back
     * to the tonal-palette mapping below.
     */
    private fun buildRolePalette(night: Boolean): Palette? {
        val suffix = if (night) "dark" else "light"
        fun role(name: String): Int? {
            val id = resources.getIdentifier("system_${name}_$suffix", "color", "android")
            return if (id == 0) null else sysColor(id)
        }
        return try {
            val surface = role("surface") ?: return null
            val onSurface = role("on_surface") ?: return null
            val onSurfaceVar = role("on_surface_variant") ?: return null
            val keyBg = (if (night) sysColor(android.R.color.system_neutral1_800) else null) ?: role("surface_container_highest") ?: return null
            val primC = role("primary_container") ?: return null
            val onPrimC = role("on_primary_container") ?: return null
            val secC = role("secondary_container") ?: return null
            val onSecC = role("on_secondary_container") ?: return null
            val tert = role("tertiary") ?: return null
            val onTert = role("on_tertiary") ?: return null
            val primary = role("primary") ?: return null
            val low = role("surface_container") ?: keyBg
            val high = role("surface_container_high") ?: keyBg
            Palette(
                bg = surface, text = onSurface, icon = onSurfaceVar,
                numBg = keyBg, numFg = onSurface,
                opBg = secC, opFg = onSecC,
                // Pixel Calculator tints AC with the wallpaper's primary container
                acBg = primC, acFg = onPrimC,
                eqBg = tert, eqFg = onTert,
                sciBg = keyBg, sciFg = onSecC,
                result = primary, cursor = primary,
                clearFg = if (night) Color.parseColor("#FFB4AB") else Color.parseColor("#BA1A1A"),
                ripple = Color.parseColor(if (night) "#33FFFFFF" else "#33000000"),
                divider = role("outline_variant") ?: role("surface_variant") ?: keyBg,
                histBg = low, dialogBg = high
            )
        } catch (e: Exception) {
            null
        }
    }

    /** Maps the framework's wallpaper-derived tonal palette (system_accent1/2, system_neutral1/2) onto our Palette shape. */
    @RequiresApi(Build.VERSION_CODES.S)
    private fun buildDynamicPalette(night: Boolean): Palette? {
        buildRolePalette(night)?.let { return it }
        fun cc(resId: Int): Int = sysColor(resId) ?: throw IllegalStateException("missing dynamic color")
        return try {
            if (!night) {
                Palette(
                    bg = cc(android.R.color.system_neutral1_10), text = cc(android.R.color.system_neutral1_900), icon = cc(android.R.color.system_neutral2_700),
                    numBg = cc(android.R.color.system_neutral1_100), numFg = cc(android.R.color.system_neutral1_900),
                    opBg = cc(android.R.color.system_accent2_100), opFg = cc(android.R.color.system_accent2_900),
                    acBg = cc(android.R.color.system_accent1_100), acFg = cc(android.R.color.system_accent1_900),
                    eqBg = cc(android.R.color.system_accent3_600), eqFg = Color.WHITE,
                    sciBg = cc(android.R.color.system_neutral1_100), sciFg = cc(android.R.color.system_accent1_800),
                    result = cc(android.R.color.system_accent1_600), cursor = cc(android.R.color.system_accent1_600),
                    clearFg = Color.parseColor("#BA1A1A"), ripple = Color.parseColor("#33000000"),
                    divider = cc(android.R.color.system_neutral2_200), histBg = cc(android.R.color.system_neutral1_50), dialogBg = cc(android.R.color.system_neutral1_50)
                )
            } else {
                Palette(
                    bg = androidx.core.graphics.ColorUtils.blendARGB(cc(android.R.color.system_neutral1_1000), cc(android.R.color.system_neutral1_900), 0.6f), text = cc(android.R.color.system_neutral1_100), icon = cc(android.R.color.system_neutral2_200),
                    numBg = cc(android.R.color.system_neutral1_800), numFg = cc(android.R.color.system_neutral1_100),
                    opBg = cc(android.R.color.system_accent2_700), opFg = cc(android.R.color.system_accent2_100),
                    acBg = cc(android.R.color.system_accent1_700), acFg = cc(android.R.color.system_accent1_100),
                    eqBg = cc(android.R.color.system_accent3_200), eqFg = cc(android.R.color.system_accent3_900),
                    sciBg = cc(android.R.color.system_neutral1_700), sciFg = cc(android.R.color.system_accent1_100),
                    result = cc(android.R.color.system_accent1_200), cursor = cc(android.R.color.system_accent1_200),
                    clearFg = Color.parseColor("#FFB5A2"), ripple = Color.parseColor("#33FFFFFF"),
                    divider = cc(android.R.color.system_neutral2_700), histBg = cc(android.R.color.system_neutral1_800), dialogBg = cc(android.R.color.system_neutral1_800)
                )
            }
        } catch (e: Exception) {
            null
        }
    }

    private class CursorSpan(
        private val widthPx: Int, private val barPx: Int, private val color: Int
    ) : ReplacementSpan() {
        var visible = true
        override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int = widthPx
        override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
            if (!visible) return
            val p = Paint(paint)
            p.color = color
            p.style = Paint.Style.FILL
            val left = x + (widthPx - barPx) / 2f
            canvas.drawRect(left, top.toFloat(), left + barPx, bottom.toFloat(), p)
        }
    }

    private lateinit var topScroll: HorizontalScrollView
    private lateinit var topView: TextView
    private lateinit var bottomView: TextView
    private lateinit var bottomScroll: HorizontalScrollView
    private lateinit var histContainer: LinearLayout
    private lateinit var histScroll: ScrollView
    private lateinit var histHandle: LinearLayout
    private lateinit var histHost: FrameLayout
    private lateinit var histThumb: View
    private lateinit var displayHost: View
    private var keypadView: View? = null
    private var keypadBaseH = 0
    private var kpH = 1f
    private var kpW = 1f
    private var kpShift = 0f
    private var kpLiftPx = 0
    private var resizing = false
    private var contentW = 0
    private var uiScale = 1f
    private var bottomBaseH = 0
    private lateinit var resizeOverlay: FrameLayout
    private lateinit var rzOutline: View
    private lateinit var rzTop: View
    private lateinit var rzBottom: View
    private lateinit var rzLeft: View
    private lateinit var rzRight: View
    private lateinit var rzMove: View
    private lateinit var rzReset: View
    private lateinit var rzDone: View
    private lateinit var histBgDrawable: GradientDrawable
    private lateinit var histBtnFill: GradientDrawable
    private var histHeightPx = 0
    private var histMaxCache = 0
    private var histTotal = 0
    private var histAnim: ValueAnimator? = null
    private var pendingReopen = false
    private var pinBottom = true
    private val argb = ArgbEvaluator()
    private val histHandleHeight by lazy { dp(44) }
    private var toolRowView: View? = null
    private val hideThumb = Runnable {
        if (::histThumb.isInitialized) histThumb.animate().alpha(0f).setDuration(250).start()
    }

    private enum class DragZone { NONE, EDGE, LIST }
    private var dragZone = DragZone.NONE
    private var histDragging = false
    private var dragDownX = 0f
    private var dragDownY = 0f
    private var dragStartH = 0
    private var velocity: VelocityTracker? = null
    private var historyBtn: ImageView? = null
    private lateinit var historyList: LinearLayout
    private lateinit var vaultPanel: LinearLayout
    private lateinit var vaultFabHost: FrameLayout
    private lateinit var vaultFilesList: LinearLayout
    private lateinit var vaultTitle: TextView
    private lateinit var vaultChipsRow: LinearLayout
    private lateinit var vaultCloseBtn: TextView
    private lateinit var fabShape: GradientDrawable
    private lateinit var fabIcon: ImageView
    private lateinit var fabScrim: View
    private lateinit var fabMenu: LinearLayout
    private lateinit var folderPill: View
    private var fabMenuOpen = false
    private val selected = LinkedHashSet<String>()
    private val rowUpdaters = HashMap<String, () -> Unit>()
    private var currentFolder: String? = null
    private var vaultFilter = 0
    private var vaultSort = 0
    private var expandBtn: ImageView? = null
    private lateinit var radKey: TextView
    private val sciLines = mutableListOf<View>()
    private val sciKeys = mutableMapOf<String, TextView>()
    private val keyTexts = mutableListOf<Pair<TextView, Float>>()
    private var backspaceIcon: ImageView? = null
    private var inverse = false

    private val cursorSpan by lazy { CursorSpan(dp(8), dp(2), pal.cursor) }
    private val handler = Handler(Looper.getMainLooper())
    private val blink = object : Runnable {
        override fun run() {
            cursorSpan.visible = !cursorSpan.visible
            topView.invalidate()
            handler.postDelayed(this, 530)
        }
    }

    private var expression = ""
    private var previousExpression = ""
    private var justEvaluated = false
    private var errorText: String? = null
    private var sciVisible = false
    private var historyVisible = false
    private var vaultVisible = false

    private companion object {
        const val REQ_PICK = 1001
        const val REQ_PERM = 1002
        const val REQ_DELETE_BATCH = 9999
        const val REQ_DELETE_LEGACY = 9998
        const val REPO_URL = "https://github.com/AryanKumar1234/CalCognito"
        const val PROFILE_URL = "https://github.com/AryanKumar1234"
    }

    private var changeMode = false
    private var holdFired = false
    private var pinResetPending = false

    private var leavingForTask = false

    private var externalViewing = false
    private var afterPermission: (() -> Unit)? = null
    private var viewerDialog: Dialog? = null
    private var aboutDialog: Dialog? = null
    private var lastDisplayWidth = 0
    private val thumbCache = ConcurrentHashMap<String, Bitmap>()
    private val thumbExecutor = Executors.newSingleThreadExecutor()
    private val migrateExecutor = Executors.newSingleThreadExecutor()
    private val migrating = ConcurrentHashMap.newKeySet<String>()
    private var hideHidden = 0
    private var hideFailed = 0
    private var hideNotRemoved = 0
    private var batchDeleteCount = 0
    private val legacyDeleteQueue = mutableListOf<Uri>()
    private var legacyCurrent: Uri? = null

    private var currentPrecision = 120
    private var isInfiniteResult = false
    private var activeEvalExpr = ""
    private var cachedRawResult = ""
    private var scrollOffsetPx = 0f
    private lateinit var scroller: OverScroller
    private lateinit var gestureDetector: GestureDetector

    private val flingRunnable = object : Runnable {
        override fun run() {
            if (scroller.computeScrollOffset()) {
                scrollOffsetPx = scroller.currX.toFloat().coerceAtLeast(0f)
                renderBottomResult()
                bottomView.postOnAnimation(this)
            }
        }
    }

    private val operators = setOf('+', '−', '×', '÷')
    private val prefs by lazy { getSharedPreferences("calc_history", Context.MODE_PRIVATE) }

    private fun loadFont(file: String, fallback: Typeface): Typeface = try {
        Typeface.createFromAsset(assets, "fonts/$file")
    } catch (e: Exception) { fallback }

    private val displayFont: Typeface by lazy { loadFont("GoogleSansFlex-Display.ttf", Typeface.create("sans-serif-light", Typeface.NORMAL)) }
    private val keyFont: Typeface by lazy { loadFont("GoogleSansFlex-Key.ttf", Typeface.create("sans-serif-medium", Typeface.NORMAL)) }
    private val opFont: Typeface by lazy { loadFont("GoogleSansFlex-Op.ttf", Typeface.create("sans-serif-medium", Typeface.NORMAL)) }
    private val sciFont: Typeface by lazy { loadFont("GoogleSansFlex-Label.ttf", Typeface.create("sans-serif", Typeface.NORMAL)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        val night = isNightMode()
        setTheme(if (night) R.style.AppThemeDark else R.style.AppThemeLight)
        super.onCreate(savedInstanceState)
        pal = resolvePalette(night)
        Evaluator.degrees = prefs.getBoolean("deg", true)

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = if (night) 0
            else View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        VaultManager.clearTemp(applicationContext)
        VaultManager.cleanStaleMigrations(applicationContext)
        scroller = OverScroller(this)
        setContentView(buildUi())
        setupResultScrollGesture()

        expression = savedInstanceState?.getString("expr") ?: ""
        previousExpression = savedInstanceState?.getString("prev") ?: ""
        justEvaluated = savedInstanceState?.getBoolean("done") ?: false
        refresh()
    }

    override fun onResume() {
        super.onResume()
        setSecure(vaultVisible)
        handler.removeCallbacks(blink)
        handler.postDelayed(blink, 530)
        if (externalViewing) {
            externalViewing = false
            VaultManager.clearTemp(applicationContext)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(blink)

        if (leavingForTask) {
            leavingForTask = false
            return
        }
        if (changeMode) {
            changeMode = false
            expression = ""
            justEvaluated = false
            refresh()
        }
        viewerDialog?.dismiss()
        aboutDialog?.dismiss()
        if (vaultVisible) {
            toggleVault()
            setSecure(true)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        thumbExecutor.shutdownNow()
        migrateExecutor.shutdownNow()
        viewerDialog?.dismiss()
        VaultManager.clearTemp(applicationContext)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuildUi()
    }

    private fun rebuildUi() {
        resizing = false
        histAnim?.cancel()
        histHeightPx = 0
        pendingReopen = historyVisible
        historyVisible = false
        window.statusBarColor = pal.bg
        sciLines.clear(); sciKeys.clear(); keyTexts.clear()
        expandBtn = null; backspaceIcon = null
        lastDisplayWidth = 0
        setContentView(buildUi())
        setupResultScrollGesture()
        if (sciVisible) {
            for (line in sciLines) line.visibility = View.VISIBLE
            updateExpandIcon()
        }
        updateSciLabels()
        if (vaultVisible) { renderVaultFiles(); vaultPanel.visibility = View.VISIBLE; updateSelectionUi() }
        refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("expr", expression)
        outState.putString("prev", previousExpression)
        outState.putBoolean("done", justEvaluated)
    }

    private fun setSecure(on: Boolean) {
        if (on) window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
    }

    private fun isNightMode(): Boolean = when (prefs.getInt("theme", 2)) {
        0 -> false
        1 -> true
        else -> (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
    }

    private fun winW(): Int =
        if (resources.configuration.screenWidthDp > 0) (resources.configuration.screenWidthDp * resources.displayMetrics.density).toInt()
        else resources.displayMetrics.widthPixels

    private fun winH(): Int =
        if (resources.configuration.screenHeightDp > 0) (resources.configuration.screenHeightDp * resources.displayMetrics.density).toInt()
        else resources.displayMetrics.heightPixels

    private fun isLand() = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

    private fun kpKey(name: String) = if (isLand()) "kpl_$name" else "kp_$name"

    private fun loadKeypadPrefs() {
        kpH = prefs.getFloat(kpKey("h"), 1f)
        kpW = prefs.getFloat(kpKey("w"), 1f)
        kpShift = prefs.getFloat(kpKey("s"), 0f)
        kpLiftPx = prefs.getInt(kpKey("l"), 0)
    }

    private fun applyKeypadLayout() {
        val kp = keypadView ?: return
        if (keypadBaseH <= 0) return
        val lp = kp.layoutParams as LinearLayout.LayoutParams
        lp.weight = 0f
        val sw = contentW
        lp.height = (keypadBaseH * kpH).toInt()
        lp.width = if (kpW >= 0.999f) ViewGroup.LayoutParams.MATCH_PARENT else (sw * kpW).toInt()
        lp.gravity = Gravity.CENTER_HORIZONTAL
        val shiftPx = (kpShift * sw).toInt()
        lp.leftMargin = Math.max(0, 2 * shiftPx)
        lp.rightMargin = Math.max(0, -2 * shiftPx)
        lp.bottomMargin = kpLiftPx
        kp.layoutParams = lp
    }

    private fun attachDrag(v: View, onStart: () -> Unit, onMove: (Float, Float) -> Unit) {
        var downX = 0f
        var downY = 0f
        v.setOnTouchListener { view, ev ->
            when (ev.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downX = ev.rawX
                    downY = ev.rawY
                    onStart()
                    view.parent.requestDisallowInterceptTouchEvent(true)
                }
                MotionEvent.ACTION_MOVE -> onMove(ev.rawX - downX, ev.rawY - downY)
            }
            true
        }
    }

    private fun buildResizeOverlay(): View {
        val ov = FrameLayout(this).apply {
            visibility = View.GONE
            isClickable = true
        }
        resizeOverlay = ov
        rzOutline = View(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dpf(28)
                setColor((pal.bg and 0x00FFFFFF) or (0x99 shl 24))
                setStroke(dp(3), pal.cursor)
            }
        }
        ov.addView(rzOutline, FrameLayout.LayoutParams(0, 0))

        fun handle(top: Boolean): FrameLayout {
            val box = FrameLayout(this)
            val pill = View(this).apply {
                background = GradientDrawable().apply { cornerRadius = dpf(3); setColor(pal.cursor) }
            }
            val g = (if (top) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
            box.addView(pill, FrameLayout.LayoutParams(dp(60), dp(5), g).apply {
                if (top) topMargin = dp(12) else bottomMargin = dp(12)
            })
            return box
        }
        rzTop = handle(true)
        rzBottom = handle(false)
        rzLeft = View(this)
        rzRight = View(this)
        for (v in listOf(rzTop, rzBottom, rzLeft, rzRight)) ov.addView(v, FrameLayout.LayoutParams(0, 0))

        fun pill(icon: Int, label: String, action: () -> Unit): LinearLayout {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { cornerRadius = dpf(100); setColor(pal.opBg) }
                setOnClickListener { action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(pal.opFg)
            }, LinearLayout.LayoutParams(dp(22), dp(22)))
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.opFg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                setPadding(dp(10), 0, 0, 0)
            })
            return row
        }
        rzReset = pill(R.drawable.ic_refresh, "Reset") {
            kpH = 1f
            kpW = 1f
            kpShift = 0f
            kpLiftPx = 0
            applyKeypadLayout()
        }
        rzDone = pill(R.drawable.ic_check, "Done") { exitResize() }
        val move = FrameLayout(this).apply {
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pal.numBg) }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_open_with)
                setColorFilter(pal.text)
            }, FrameLayout.LayoutParams(dp(26), dp(26), Gravity.CENTER))
        }
        rzMove = move
        ov.addView(rzReset, FrameLayout.LayoutParams(0, 0))
        ov.addView(rzDone, FrameLayout.LayoutParams(0, 0))
        ov.addView(rzMove, FrameLayout.LayoutParams(0, 0))

        val sw = contentW
        var startH = 0
        var startLift = 0
        var startW = 0
        var startC = 0f
        var space = 0
        val snapshot = {
            val kp = keypadView
            if (kp != null) {
                startH = kp.height
                startLift = kpLiftPx
                startW = kp.width
                startC = kpShift * sw
                space = displayHost.height + kpLiftPx + kp.height
            }
            Unit
        }
        val setWidth = { nw: Int, c: Float ->
            kpW = nw.toFloat() / sw
            val lim = (sw - nw) / 2f
            kpShift = c.coerceIn(-lim, lim) / sw
            applyKeypadLayout()
        }
        val keepDisplay = if (isLand()) dp(70) else dp(150)
        attachDrag(rzTop, snapshot) { _, dy ->
            val minH = (keypadBaseH * 0.6f).toInt()
            val maxH = Math.max(minH, Math.min((keypadBaseH * 1.35f).toInt(), space - keepDisplay - startLift))
            val nh = (startH - dy).toInt().coerceIn(minH, maxH)
            kpH = nh.toFloat() / keypadBaseH
            applyKeypadLayout()
        }
        attachDrag(rzBottom, snapshot) { _, dy ->
            val maxL = Math.max(0, Math.min(dp(200), space - keepDisplay - startH))
            kpLiftPx = (startLift - dy).toInt().coerceIn(0, maxL)
            applyKeypadLayout()
        }
        attachDrag(rzLeft, snapshot) { dx, _ ->
            val nw = (startW - dx).toInt().coerceIn((sw * 0.6f).toInt(), sw)
            setWidth(nw, startC + (startW - nw) / 2f)
        }
        attachDrag(rzRight, snapshot) { dx, _ ->
            val nw = (startW + dx).toInt().coerceIn((sw * 0.6f).toInt(), sw)
            setWidth(nw, startC + (nw - startW) / 2f)
        }
        attachDrag(rzMove, snapshot) { dx, _ ->
            val lim = (sw - startW) / 2f
            kpShift = (startC + dx).coerceIn(-lim, lim) / sw
            applyKeypadLayout()
        }
        return ov
    }

    private fun place(v: View, x: Int, y: Int, w: Int, h: Int) {
        val lp = v.layoutParams as FrameLayout.LayoutParams
        lp.gravity = Gravity.TOP or Gravity.START
        lp.leftMargin = x
        lp.topMargin = y
        lp.width = w
        lp.height = h
        v.layoutParams = lp
    }

    private fun layoutResizeOverlay() {
        val kp = keypadView ?: return
        if (!::resizeOverlay.isInitialized || resizeOverlay.visibility != View.VISIBLE) return
        val r = viewRect(kp)
        val o = viewRect(resizeOverlay)
        val l = r.left - o.left
        val t = r.top - o.top
        val w = r.width()
        val h = r.height()
        place(rzOutline, l, t, w, h)
        val grab = dp(40)
        val handleW = dp(140)
        place(rzTop, l + (w - handleW) / 2, t, handleW, grab)
        place(rzBottom, l + (w - handleW) / 2, t + h - grab, handleW, grab)
        place(rzLeft, l, t + grab, dp(32), Math.max(0, h - 2 * grab))
        place(rzRight, l + w - dp(32), t + grab, dp(32), Math.max(0, h - 2 * grab))
        val cx = l + w / 2
        val cy = t + h / 2
        val mv = dp(56)
        val pw = dp(116)
        val ph = dp(48)
        place(rzMove, cx - mv / 2, cy - mv / 2, mv, mv)
        if (w >= dp(340)) {
            place(rzReset, cx - mv / 2 - dp(12) - pw, cy - ph / 2, pw, ph)
            place(rzDone, cx + mv / 2 + dp(12), cy - ph / 2, pw, ph)
        } else {
            place(rzReset, cx - pw / 2, cy - mv / 2 - dp(12) - ph, pw, ph)
            place(rzDone, cx - pw / 2, cy + mv / 2 + dp(12), pw, ph)
        }
    }

    private fun enterResize() {
        if (keypadView == null) return
        if (historyVisible) animateHist(0)
        resizing = true
        resizeOverlay.visibility = View.VISIBLE
        resizeOverlay.post { layoutResizeOverlay() }
    }

    private fun exitResize() {
        resizing = false
        resizeOverlay.visibility = View.GONE
        prefs.edit()
            .putFloat(kpKey("h"), kpH)
            .putFloat(kpKey("w"), kpW)
            .putFloat(kpKey("s"), kpShift)
            .putInt(kpKey("l"), kpLiftPx)
            .apply()
    }

    private fun rippleBg(radiusDp: Int = 0): RippleDrawable {
        val mask = GradientDrawable().apply { cornerRadius = dpf(radiusDp); setColor(Color.BLACK) }
        return RippleDrawable(ColorStateList.valueOf(pal.ripple), null, mask)
    }

    private fun showStyledDialog(
        title: String, body: View?, positive: String, negative: String?, onPositive: () -> Unit
    ): Dialog {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.dialogBg) }
            setPadding(0, dp(24), 0, dp(16))
        }
        card.addView(TextView(this).apply {
            text = title
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 24f)
            setPadding(dp(24), 0, dp(24), dp(16))
        })
        if (body != null) card.addView(body, LinearLayout.LayoutParams(-1, -2))
        val buttons = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
            setPadding(dp(16), dp(24), dp(16), 0)
        }
        fun button(label: String, action: () -> Unit) = TextView(this).apply {
            text = label
            setTextColor(pal.cursor)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(dp(12), dp(10), dp(12), dp(10))
            minWidth = dp(64)
            background = rippleBg(20)
            setOnClickListener { dialog.dismiss(); action() }
        }
        if (negative != null) buttons.addView(button(negative) {})
        buttons.addView(button(positive, onPositive))
        card.addView(buttons, LinearLayout.LayoutParams(-1, -2))
        dialog.setContentView(card)
        val w = minOf(winW() - dp(66), dp(560))
        dialog.window?.setLayout(w, ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
        return dialog
    }

    private fun msgBody(text: String): TextView = TextView(this).apply {
        this.text = text
        setTextColor(pal.icon)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        setLineSpacing(0f, 1.15f)
        setPadding(dp(24), 0, dp(24), 0)
    }

    private fun showProgress(msg: String): Dialog {
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        dialog.setCancelable(false)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.dialogBg) }
            setPadding(dp(24), dp(24), dp(24), dp(24))
        }
        card.addView(TextView(this).apply {
            text = msg
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        })
        dialog.setContentView(card)
        dialog.window?.setLayout(minOf(winW() - dp(66), dp(560)), ViewGroup.LayoutParams.WRAP_CONTENT)
        dialog.show()
        return dialog
    }

    /** Pixel-style list dialog: rows with an icon and label; tapping a row closes the dialog and runs it. */
    private fun showListDialog(title: String, rows: List<Triple<Int, String, () -> Unit>>, cancelLabel: String = "Cancel") {
        var dlg: Dialog? = null
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((icon, label, action) in rows) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(52)
                setPadding(dp(24), 0, dp(24), 0)
                background = rippleBg()
                isClickable = true
                setOnClickListener { dlg?.dismiss(); action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(pal.icon)
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(20) })
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            }, LinearLayout.LayoutParams(0, -2, 1f))
            list.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        dlg = showStyledDialog(title, ScrollView(this).apply { addView(list) }, cancelLabel, null) {}
    }

    private fun radioRows(labels: List<String>, initial: Int, onPick: (Int) -> Unit): View {
        val group = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val radios = mutableListOf<RadioButton>()
        val tint = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(pal.cursor, pal.text)
        )
        labels.forEachIndexed { i, label ->
            val rb = RadioButton(this).apply {
                isChecked = i == initial
                isClickable = false
                isFocusable = false
                buttonTintList = tint
            }
            radios.add(rb)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(20), 0, dp(24), 0)
                background = rippleBg()
                setOnClickListener {
                    radios.forEachIndexed { j, r -> r.isChecked = j == i }
                    onPick(i)
                }
            }
            row.addView(rb, LinearLayout.LayoutParams(-2, -2))
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
            group.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        return group
    }

    private fun showVideoHelp() {
        val items = listOf(
            "Tap" to "Show or hide controls",
            "Double tap left / right" to "Back / forward 10 seconds",
            "Double tap centre" to "Pause or resume",
            "Swipe up / down on right" to "Volume",
            "Swipe up / down on left" to "Brightness",
            "Hold anywhere" to "Play at 2x while held"
        )
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for ((gesture, action) in items) {
            list.addView(TextView(this).apply {
                text = gesture
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(24), dp(10), dp(24), 0)
            })
            list.addView(TextView(this).apply {
                text = action
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(dp(24), dp(2), dp(24), dp(10))
            })
        }
        val scroll = ScrollView(this).apply { addView(list) }
        showStyledDialog("Video controls", scroll, "Got it", null) {}
    }

    private fun showThemeDialog() {
        var choice = prefs.getInt("theme", 2)
        val group = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val radios = mutableListOf<RadioButton>()
        val tint = ColorStateList(
            arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
            intArrayOf(pal.cursor, pal.text)
        )
        listOf("Light", "Dark", "System default").forEachIndexed { i, label ->
            val rb = RadioButton(this).apply {
                isChecked = i == choice
                isClickable = false
                isFocusable = false
                buttonTintList = tint
            }
            radios.add(rb)
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(20), 0, dp(24), 0)
                background = rippleBg()
                setOnClickListener {
                    choice = i
                    radios.forEachIndexed { j, r -> r.isChecked = j == i }
                }
            }
            row.addView(rb, LinearLayout.LayoutParams(-2, -2))
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                setPadding(dp(12), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
            group.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        var dynamicChoice = useDynamicColor()
        if (dynamicColorAvailable()) {
            val dynCheck = CheckBox(this).apply {
                text = "Match wallpaper colors"
                isChecked = dynamicChoice
                setTextColor(pal.text)
                buttonTintList = ColorStateList(
                    arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                    intArrayOf(pal.cursor, pal.text)
                )
                setOnCheckedChangeListener { _, checked -> dynamicChoice = checked }
            }
            group.addView(dynCheck, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(20), dp(8), dp(24), dp(4)) })
        }
        showStyledDialog("Choose theme", group, "OK", "Cancel") {
            val themeChanged = choice != prefs.getInt("theme", 2)
            val dynamicChanged = dynamicColorAvailable() && dynamicChoice != prefs.getBoolean("dynamic_theme", true)
            if (themeChanged || dynamicChanged) {
                prefs.edit().putInt("theme", choice).putBoolean("dynamic_theme", dynamicChoice).apply()
                recreate()
            }
        }
    }

    private fun appVersion(): String = try {
        @Suppress("DEPRECATION")
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.1"
    } catch (_: Exception) { "1.1" }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * resources.displayMetrics.density

    private fun setupResultScrollGesture() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scroller.forceFinished(true)
                bottomView.removeCallbacks(flingRunnable)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (!isInfiniteResult || errorText != null) return false
                scrollOffsetPx = (scrollOffsetPx + distanceX).coerceAtLeast(0f)
                renderBottomResult()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (!isInfiniteResult || errorText != null) return false
                scroller.fling(scrollOffsetPx.toInt(), 0, (-velocityX).toInt(), 0, 0, Int.MAX_VALUE / 4, 0, 0)
                bottomView.postOnAnimation(flingRunnable)
                return true
            }
            override fun onLongPress(e: MotionEvent) { copyResult() }
        })
        bottomScroll.setOnTouchListener { _, event ->
            gestureDetector.onTouchEvent(event)
            isInfiniteResult && errorText == null
        }
    }

    private fun buildUi(): View {
        val root = FrameLayout(this).apply { setBackgroundColor(pal.bg) }
        val wDp = resources.configuration.screenWidthDp
        val hDp = resources.configuration.screenHeightDp
        // Always use the compact 4-column Pixel-style keypad (AC row first), stretched to the
        // full window width in every orientation / window size.
        val land = wDp > hDp
        contentW = winW()
        uiScale = if (land) (hDp / 411f).coerceIn(1f, 1.4f) else (minOf(wDp, 600) / 411f).coerceIn(1f, 1.4f)
        bottomBaseH = dp(((if (land) 48 else 72) * uiScale).toInt())

        run {
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(pal.bg)
                fitsSystemWindows = true
            }
            val topBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(6), dp(3), 0)
            }
            historyBtn = iconButton(R.drawable.ic_history, "History") { toggleHistory() }
            topBar.addView(historyBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
            topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            topBar.addView(iconButton(R.drawable.ic_more_vert, "More options") { showMenu(it) }, LinearLayout.LayoutParams(dp(48), dp(48)))
            addTopArea(column, topBar)

            val display = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.END
                setPadding(dp(24), dp(8), dp(24), 0)
            }
            topView = TextView(this).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
                setOnLongClickListener { pasteIntoExpression(); true }
            }
            topScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(topView, FrameLayout.LayoutParams(-2, -1))
            }
            bottomView = TextView(this).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
            }
            bottomScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(bottomView, FrameLayout.LayoutParams(-2, -1))
            }
            display.addView(topScroll, LinearLayout.LayoutParams(-1, 0, 1f))
            display.addView(bottomScroll, LinearLayout.LayoutParams(-1, bottomBaseH))
            // Pixel keeps the expression in the upper-middle of the display with free space under the result line
            display.addView(View(this), LinearLayout.LayoutParams(-1, 0, 0.4f))
            val expBtn = iconButton(R.drawable.ic_code, "Scientific functions") { toggleScientific() }
            expandBtn = expBtn
            if (land) {
                // Landscape: keep the expander inside the display area to save vertical space.
                val displayBox = FrameLayout(this)
                displayBox.addView(display, FrameLayout.LayoutParams(-1, -1))
                displayBox.addView(expBtn, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.BOTTOM or Gravity.START).apply {
                    setMargins(dp(14), 0, 0, dp(6))
                })
                toolRowView = null
                attachDisplayHost(displayBox)
                column.addView(displayBox, LinearLayout.LayoutParams(-1, 0, 1f))
            } else {
                attachDisplayHost(display)
                column.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))
                val toolRow = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    setPadding(dp(12), dp(4), dp(24), dp(12))
                }
                toolRow.addView(expBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
                toolRowView = toolRow
                column.addView(toolRow, LinearLayout.LayoutParams(-1, -2))
            }

            val cell = (contentW - dp(4)) / 4
            val keypadH = minOf(cell * 5, (winH() * 0.5f).toInt())

            val keypad = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(2), 0, dp(2), 0)
            }
            val sciRows = listOf(
                listOf("√", "π", "^", "!"),
                listOf(if (Evaluator.degrees) "Rad" else "Deg", "sin", "cos", "tan"),
                listOf("Inv", "e", "ln", "log")
            )
            for (row in sciRows) {
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    visibility = View.GONE
                }
                for (label in row) {
                    line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                sciLines.add(line)
                keypad.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }

            val basicRows = listOf(
                listOf("AC", "( )", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+"),
                listOf("0", ".", "⌫", "=")
            )
            for (row in basicRows) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (label in row) {
                    line.addView(makeKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                keypad.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }
            keypadBaseH = keypadH
            keypadView = keypad
            loadKeypadPrefs()
            // Scale glyphs to the real key height so tall/wide windows and short landscape ones both fit.
            val rowDp = keypadH / resources.displayMetrics.density / 5f
            val keyScale = minOf(uiScale, rowDp / 80f).coerceAtLeast(0.6f)
            for ((tv, sz) in keyTexts) tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sz * keyScale)
            for ((_, tv) in sciKeys) tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f * keyScale)
            column.addView(keypad, LinearLayout.LayoutParams(-1, keypadH))
            applyKeypadLayout()
            keypad.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
                if (resizing) resizeOverlay.post { layoutResizeOverlay() }
            }
            root.addView(column, FrameLayout.LayoutParams(contentW, -1, Gravity.CENTER_HORIZONTAL))
        }

        val headerTop = if (land) dp(4) else dp(20)

        vaultPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
            isClickable = true
            isFocusable = true
        }
        val vHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), headerTop, dp(8), dp(8))
            gravity = Gravity.CENTER_VERTICAL
        }
        vaultTitle = TextView(this).apply {
            text = "Secure Vault"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), dp(8), dp(8))
            setOnClickListener {
                if (selected.isEmpty() && currentFolder != null) {
                    currentFolder = null
                    renderVaultFiles()
                }
            }
        }
        vHeader.addView(vaultTitle, LinearLayout.LayoutParams(0, -2, 1f))
        vaultCloseBtn = TextView(this).apply {
            text = "Close"
            setTextColor(pal.sciFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { if (selected.isNotEmpty()) clearSelection() else toggleVault() }
        }
        vHeader.addView(vaultCloseBtn)
        vHeader.addView(
            iconButton(R.drawable.ic_info, "About") { showAbout() },
            LinearLayout.LayoutParams(dp(48), dp(48)).apply { leftMargin = dp(4) }
        )
        vaultPanel.addView(vHeader)
        vaultChipsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(4), dp(8), dp(8))
        }
        vaultPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(vaultChipsRow)
        }, LinearLayout.LayoutParams(-1, -2))
        val vScroll = ScrollView(this)
        vaultFilesList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        vScroll.addView(vaultFilesList, LinearLayout.LayoutParams(-1, -2))
        vaultPanel.addView(vScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(vaultPanel, FrameLayout.LayoutParams(-1, -1))

        fabMenuOpen = false
        fabShape = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.acBg) }
        val fabMask = GradientDrawable().apply { cornerRadius = dpf(28); setColor(Color.BLACK) }
        fabIcon = ImageView(this).apply {
            setImageResource(R.drawable.ic_add)
            setColorFilter(pal.acFg)
        }
        val fab = FrameLayout(this).apply {
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), fabShape, fabMask)
            elevation = dpf(6)
            isClickable = true
            isFocusable = true
            contentDescription = "Add"
            setOnClickListener { setFabMenu(!fabMenuOpen) }
            addView(fabIcon, FrameLayout.LayoutParams(dp(40), dp(40), Gravity.CENTER))
        }
        fabScrim = View(this).apply {
            setBackgroundColor((pal.bg and 0xFFFFFF) or (0xE6 shl 24))
            visibility = View.GONE
            isClickable = true
            setOnClickListener { setFabMenu(false) }
        }
        fun fabPill(icon: Int, label: String, onClick: () -> Unit): LinearLayout {
            val shape = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.acBg) }
            val mask = GradientDrawable().apply { cornerRadius = dpf(28); setColor(Color.BLACK) }
            return LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(24), 0, dp(28), 0)
                background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
                elevation = dpf(4)
                isClickable = true
                isFocusable = true
                setOnClickListener { onClick() }
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(icon)
                    setColorFilter(pal.acFg)
                }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(12) })
                addView(TextView(this@MainActivity).apply {
                    text = label
                    setTextColor(pal.acFg)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                    typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
                })
            }
        }
        val uploadPill = fabPill(R.drawable.ic_upload, "Upload") { setFabMenu(false); pickFileForVault() }
        folderPill = fabPill(R.drawable.ic_create_folder, "Folder") { setFabMenu(false); promptNewFolder() }
        fabMenu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.END
            visibility = View.GONE
            addView(folderPill, LinearLayout.LayoutParams(-2, dp(56)).apply { topMargin = dp(12) })
            addView(uploadPill, LinearLayout.LayoutParams(-2, dp(56)).apply { topMargin = dp(12); bottomMargin = dp(8) })
        }
        vaultFabHost = FrameLayout(this).apply {
            visibility = View.GONE
            fitsSystemWindows = true
            addView(fabScrim, FrameLayout.LayoutParams(-1, -1))
            addView(fabMenu, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(16), dp(32) + dp(80) + dp(4))
            })
            addView(fab, FrameLayout.LayoutParams(dp(80), dp(80), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(16), dp(32))
            })
        }
        root.addView(vaultFabHost, FrameLayout.LayoutParams(-1, -1))
        root.addView(buildResizeOverlay(), FrameLayout.LayoutParams(-1, -1))
        vaultFilesList.setPadding(0, 0, 0, dp(136))

        return root
    }

    private fun addTopArea(column: LinearLayout, topBar: View) {

        val r = dpf(28)
        histBgDrawable = GradientDrawable().apply {
            cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
            setColor(pal.bg)
        }
        histContainer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = histBgDrawable
        }
        histContainer.addView(topBar, LinearLayout.LayoutParams(-1, -2))

        histScroll = ScrollView(this).apply {
            isFillViewport = true
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        historyList = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM
        }
        histScroll.addView(historyList, FrameLayout.LayoutParams(-1, -2))

        histThumb = View(this).apply {
            background = GradientDrawable().apply { cornerRadius = dpf(4); setColor(pal.icon) }
            alpha = 0f
        }
        histHost = FrameLayout(this).apply { visibility = View.GONE }
        histHost.addView(histScroll, FrameLayout.LayoutParams(-1, -1))
        histHost.addView(histThumb, FrameLayout.LayoutParams(dp(4), dp(36), Gravity.TOP or Gravity.END).apply {
            rightMargin = dp(4)
        })
        histContainer.addView(histHost, LinearLayout.LayoutParams(-1, 0))
        column.addView(histContainer, LinearLayout.LayoutParams(-1, -2))

        histScroll.setOnScrollChangeListener { _, _, y, _, _ ->
            pinBottom = y >= (historyList.height - histScroll.height) - dp(4)
            updateHistThumb(true)
        }
        histScroll.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (pinBottom) {
                val bottom = (historyList.height - histScroll.height).coerceAtLeast(0)
                if (histScroll.scrollY != bottom) histScroll.scrollTo(0, bottom)
            }
            updateHistThumb(histDragging || histAnim?.isRunning == true)
        }

        histBtnFill = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(pal.opBg); alpha = 0 }
        val btnMask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
        historyBtn?.background = RippleDrawable(ColorStateList.valueOf(pal.ripple), histBtnFill, btnMask)

        histHandle = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            alpha = 0f
            setPadding(dp(24), dp(10), dp(24), 0)
            isClickable = true
            setOnClickListener { toggleHistory() }
        }
        histHandle.addView(View(this).apply {
            background = GradientDrawable().apply { cornerRadius = dpf(4); setColor(pal.icon) }
        }, LinearLayout.LayoutParams(dp(36), dp(4)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(8) })
        histHandle.addView(TextView(this).apply {
            text = "Current expression"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        })
        column.addView(histHandle, LinearLayout.LayoutParams(-1, 0))
    }

    private fun attachDisplayHost(v: View) {
        displayHost = v
        v.addOnLayoutChangeListener { view, _, top, _, bottom, _, _, _, _ ->
            if (histHeightPx == 0 && histAnim?.isRunning != true) {
                histTotal = (bottom - top) + (if (toolRowView != null) dp(64) else 0)
                if (pendingReopen && histTotal > 0) {
                    pendingReopen = false
                    view.post {
                        histMaxCache = computeHistMax()
                        if (histMaxCache > 0) {
                            renderHistory()
                            historyVisible = true
                            setHistHeight(histMaxCache)
                        }
                    }
                }
            }
        }
    }

    private fun computeHistMax(): Int {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val minDisplay = if (land) dp(64) else dp((104 * uiScale).toInt())
        if (histTotal <= 0) return 0

        return (histTotal - histHandleHeight - minDisplay).coerceAtLeast(dp(80))
    }

    private fun setHistHeight(h: Int) {
        val hh = h.coerceIn(0, histMaxCache)
        histHeightPx = hh
        val frac = if (histMaxCache > 0) hh.toFloat() / histMaxCache else 0f
        val show = hh > 0
        histHost.visibility = if (show) View.VISIBLE else View.GONE
        histHandle.visibility = if (show) View.VISIBLE else View.GONE
        histHost.layoutParams.height = hh
        histHandle.layoutParams.height = (histHandleHeight * frac).toInt()
        histHost.requestLayout()
        histHandle.requestLayout()
        histHandle.alpha = frac
        val c = argb.evaluate(frac, pal.bg, pal.histBg) as Int
        histBgDrawable.setColor(c)
        window.statusBarColor = c
        histBtnFill.alpha = (255 * frac).toInt()
        toolRowView?.let { v ->
            val lp = v.layoutParams
            lp.height = if (hh == 0) LinearLayout.LayoutParams.WRAP_CONTENT else (dp(64) * (1f - frac)).toInt()
            v.layoutParams = lp
            v.alpha = 1f - frac
            val blp = bottomScroll.layoutParams
            blp.height = (bottomBaseH - dp((16 * uiScale).toInt()) * frac).toInt()
            bottomScroll.layoutParams = blp
        }
    }

    private fun animateHist(target: Int, velocityY: Float = 0f) {
        histAnim?.cancel()
        historyVisible = target > 0
        val from = histHeightPx
        if (from == target || histMaxCache <= 0) return
        val dist = Math.abs(target - from).toFloat()
        val a = ValueAnimator.ofInt(from, target)

        var dur = 200f + 180f * dist / histMaxCache
        if (Math.abs(velocityY) > dpf(1500)) dur *= 0.75f
        a.duration = dur.toLong()
        a.interpolator = PathInterpolator(0.05f, 0.7f, 0.1f, 1f)
        a.addUpdateListener { setHistHeight(it.animatedValue as Int) }
        a.addListener(object : android.animation.AnimatorListenerAdapter() {
            private var cancelled = false
            override fun onAnimationCancel(animation: android.animation.Animator) { cancelled = true }
            override fun onAnimationEnd(animation: android.animation.Animator) {
                if (!cancelled) refresh()
            }
        })
        a.start()
        histAnim = a
    }

    private fun openHistory() {
        histAnim?.cancel()
        histMaxCache = computeHistMax()
        if (histMaxCache <= 0) return
        if (histHeightPx == 0) renderHistory()
        animateHist(histMaxCache)
    }

    private fun updateHistThumb(show: Boolean) {
        if (!::histThumb.isInitialized) return
        val content = historyList.height
        val view = histScroll.height
        if (view <= 0 || content <= view) { histThumb.alpha = 0f; return }
        val range = content - view
        val thumbH = Math.max(dp(36), (view.toLong() * view / content).toInt())
        val lp = histThumb.layoutParams
        if (lp.height != thumbH) { lp.height = thumbH; histThumb.layoutParams = lp }
        histThumb.translationY = histScroll.scrollY.toFloat() / range * (view - thumbH)
        if (show) {
            histThumb.animate().cancel()
            histThumb.alpha = 1f
            histThumb.removeCallbacks(hideThumb)
            histThumb.postDelayed(hideThumb, 900)
        }
    }

    private fun viewRect(v: View): Rect {
        val loc = IntArray(2)
        v.getLocationOnScreen(loc)
        return Rect(loc[0], loc[1], loc[0] + v.width, loc[1] + v.height)
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (vaultVisible || resizing || !::histHost.isInitialized || !::displayHost.isInitialized) return super.dispatchTouchEvent(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                histDragging = false
                dragZone = DragZone.NONE
                velocity?.recycle()
                velocity = null
                val x = ev.rawX.toInt()
                val y = ev.rawY.toInt()
                val inList = histHost.visibility == View.VISIBLE && viewRect(histHost).contains(x, y)
                val top = viewRect(histContainer).top
                val bottom = viewRect(displayHost).bottom
                dragZone = when {
                    inList -> DragZone.LIST
                    y in top..bottom -> DragZone.EDGE
                    else -> DragZone.NONE
                }
                if (dragZone != DragZone.NONE) {
                    dragDownX = ev.rawX
                    dragDownY = ev.rawY
                    velocity = VelocityTracker.obtain().also { it.addMovement(ev) }

                    if (dragZone == DragZone.EDGE && histAnim?.isRunning == true) {
                        histAnim?.cancel()
                        histDragging = true
                        dragStartH = histHeightPx
                        return true
                    }
                }
            }
            MotionEvent.ACTION_MOVE -> {
                if (dragZone == DragZone.NONE) return super.dispatchTouchEvent(ev)
                velocity?.addMovement(ev)
                if (!histDragging) {
                    val dy = ev.rawY - dragDownY
                    val dx = ev.rawX - dragDownX
                    val slop = ViewConfiguration.get(this).scaledTouchSlop
                    val vertical = Math.abs(dy) > slop && Math.abs(dy) > Math.abs(dx) * 1.2f
                    val canStart = vertical && when (dragZone) {
                        DragZone.EDGE -> when {
                            histHeightPx <= 0 -> dy > 0
                            histHeightPx >= histMaxCache -> dy < 0
                            else -> true
                        }
                        DragZone.LIST -> dy < 0 && !histScroll.canScrollVertically(1)
                        else -> false
                    }
                    if (!canStart) return super.dispatchTouchEvent(ev)
                    histAnim?.cancel()
                    histMaxCache = computeHistMax()
                    if (histMaxCache <= 0) { dragZone = DragZone.NONE; return super.dispatchTouchEvent(ev) }
                    if (histHeightPx == 0) renderHistory()
                    histDragging = true
                    dragStartH = histHeightPx
                    dragDownY = ev.rawY
                    val cancel = MotionEvent.obtain(ev)
                    cancel.action = MotionEvent.ACTION_CANCEL
                    super.dispatchTouchEvent(cancel)
                    cancel.recycle()
                    return true
                }
                setHistHeight(dragStartH + (ev.rawY - dragDownY).toInt())
                historyVisible = histHeightPx > 0
                updateHistThumb(true)
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val wasDragging = histDragging
                var vy = 0f
                velocity?.let {
                    it.addMovement(ev)
                    it.computeCurrentVelocity(1000)
                    vy = it.yVelocity
                    it.recycle()
                }
                velocity = null
                histDragging = false
                dragZone = DragZone.NONE
                if (wasDragging) {
                    val flick = dpf(600)
                    val target = when {
                        vy > flick -> histMaxCache
                        vy < -flick -> 0
                        histHeightPx > histMaxCache / 2 -> histMaxCache
                        else -> 0
                    }
                    animateHist(target, vy)
                    return true
                }
            }
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun iconButton(res: Int, desc: String, onClick: (View) -> Unit): ImageView {
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
        return ImageView(this).apply {
            setImageResource(res)
            setColorFilter(pal.icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(10), dp(10), dp(10), dp(10))
            contentDescription = desc
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), null, mask)
            setOnClickListener { onClick(it) }
        }
    }

    private fun makeKey(label: String): View {
        val isOp = label in setOf("÷", "×", "−", "+", "%", "( )")
        val bg: Int
        val fg: Int
        when {
            label == "=" -> { bg = pal.eqBg; fg = pal.eqFg }
            label == "AC" -> { bg = pal.acBg; fg = pal.acFg }
            isOp -> { bg = pal.opBg; fg = pal.opFg }
            else -> { bg = pal.numBg; fg = pal.numFg }
        }
        val content: View = if (label == "⌫") {
            ImageView(this).apply {
                setImageResource(R.drawable.ic_backspace)
                setColorFilter(fg)
                layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
                backspaceIcon = this
            }
        } else {
            val bigOp = label in setOf("÷", "×", "−", "+", "=")
            val lightGlyph = label in setOf("÷", "×", "−", "+", "%", "( )")
            val size = when {
                label == "AC" -> 30f
                bigOp -> 40f
                else -> 34f
            }
            TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                typeface = if (label == "=") opFont else if (lightGlyph) displayFont else keyFont
                includeFontPadding = false
                layoutParams = FrameLayout.LayoutParams(-1, -1)
                keyTexts.add(this to size)
            }
        }
        val button = makeButton(content, bg) { onPress(label) }
        if (label == "=") {

            val holdRunnable = Runnable {
                holdFired = true
                button.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onEqualsHeld()
            }
            button.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        holdFired = false
                        handler.postDelayed(holdRunnable, 3000)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (ev.x < 0f || ev.y < 0f || ev.x > v.width || ev.y > v.height) handler.removeCallbacks(holdRunnable)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(holdRunnable)
                }
                false
            }

            button.setOnClickListener {
                if (holdFired) holdFired = false else onPress("=")
            }
        }
        if (label == "⌫") button.setOnLongClickListener { onPress("AC"); true }
        return button
    }

    private fun makeSciKey(label: String): View {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(pal.opFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = sciFont
            includeFontPadding = false
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        sciKeys[label] = tv
        if (label == "Rad" || label == "Deg") radKey = tv
        return makeButton(tv, pal.opBg) { onSciPress(label) }
    }

    private fun makeButton(content: View, bg: Int, onClick: () -> Unit): FrameLayout {
        val radius = dpf(200)
        val shape = GradientDrawable().apply { cornerRadius = radius; setColor(bg) }
        val mask = GradientDrawable().apply { cornerRadius = radius; setColor(Color.BLACK) }
        return FrameLayout(this).apply {
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            addView(content)
        }
    }

    private fun showMenu(anchor: View) {
        var popup: PopupWindow? = null
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply { cornerRadius = dpf(28); setColor(pal.numBg) }
            setPadding(0, dp(8), 0, dp(8))
            minimumWidth = dp(200)
        }
        fun item(icon: Int, label: String, action: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                minimumHeight = dp(48)
                setPadding(dp(18), 0, dp(24), 0)
                background = rippleBg()
                setOnClickListener { popup?.dismiss(); action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(pal.icon)
            }, LinearLayout.LayoutParams(dp(24), dp(24)))
            row.addView(TextView(this).apply {
                text = label
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
                setPadding(dp(16), 0, 0, 0)
            }, LinearLayout.LayoutParams(-2, -2))
            card.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        item(R.drawable.ic_delete_history, "Clear history") { confirmClearHistory() }
        item(R.drawable.ic_palette, "Choose theme") { showThemeDialog() }
        if (keypadView != null) item(R.drawable.ic_resize, "Resize") { enterResize() }

        val p = PopupWindow(card, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, true)
        p.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        p.isOutsideTouchable = true
        popup = p
        card.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = card.measuredWidth
        card.pivotX = w.toFloat()
        card.pivotY = 0f
        card.scaleX = 0.85f
        card.scaleY = 0.85f
        card.alpha = 0f
        p.showAsDropDown(anchor, anchor.width - w - dp(8), dp(2))
        card.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(160)
            .setInterpolator(PathInterpolator(0.05f, 0.7f, 0.1f, 1f)).start()
    }

    private fun toggleDegrees() {
        Evaluator.degrees = !Evaluator.degrees
        prefs.edit().putBoolean("deg", Evaluator.degrees).apply()
        radKey.text = if (Evaluator.degrees) "Rad" else "Deg"
        refresh()
    }

    private fun onSciPress(key: String) {
        if (key == "Rad" || key == "Deg") { toggleDegrees(); return }
        if (key == "Inv") { inverse = !inverse; updateSciLabels(); return }
        val inv = inverse
        val postfix = key == "^" || key == "!" || (key == "√" && inv)
        if (justEvaluated) {
            if (!postfix) expression = ""
            justEvaluated = false
        }
        when (key) {
            "√" -> expression += if (inv) "²" else "√"
            "π" -> expression += "π"
            "^" -> expression += "^"
            "!" -> expression += "!"
            "e" -> expression += "e"
            "sin" -> expression += if (inv) "arcsin(" else "sin("
            "cos" -> expression += if (inv) "arccos(" else "cos("
            "tan" -> expression += if (inv) "arctan(" else "tan("
            "ln" -> expression += if (inv) "e^(" else "ln("
            "log" -> expression += if (inv) withTimes("10^(") else "log("
        }
        if (inverse && key != "π" && key != "^" && key != "!" && key != "e") {
            inverse = false
            updateSciLabels()
        }
        refresh()
    }

    private fun withTimes(token: String): String =
        if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²!πe.")) "×$token" else token

    private fun updateSciLabels() {
        sciKeys["sin"]?.text = if (inverse) "sin⁻¹" else "sin"
        sciKeys["cos"]?.text = if (inverse) "cos⁻¹" else "cos"
        sciKeys["tan"]?.text = if (inverse) "tan⁻¹" else "tan"
        sciKeys["ln"]?.text = if (inverse) "eˣ" else "ln"
        sciKeys["log"]?.text = if (inverse) "10ˣ" else "log"
        sciKeys["√"]?.text = if (inverse) "x²" else "√"
        sciKeys["Inv"]?.typeface = if (inverse) Typeface.DEFAULT_BOLD else sciFont
    }

    private fun updateExpandIcon() {
        expandBtn?.setImageResource(R.drawable.ic_code)
    }

    private fun toggleScientific() {
        sciVisible = !sciVisible
        for (line in sciLines) line.visibility = if (sciVisible) View.VISIBLE else View.GONE
        updateExpandIcon()
    }

    private fun toggleHistory() {
        if (historyVisible) animateHist(0) else openHistory()
    }

    private fun toggleVault() {
        vaultVisible = !vaultVisible
        if (vaultVisible) {
            renderVaultFiles()
        } else {
            setFabMenu(false)
            selected.clear()
            rowUpdaters.clear()
            thumbCache.clear()
            currentFolder = null
            vaultFilter = 0
            viewerDialog?.dismiss()
        }
        vaultPanel.visibility = if (vaultVisible) View.VISIBLE else View.GONE
        vaultFabHost.visibility = if (vaultVisible) View.VISIBLE else View.GONE
        setSecure(vaultVisible)
    }

    private fun openUrl(url: String) {
        leavingForTask = true
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            leavingForTask = false
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAbout() {
        val sb = SpannableStringBuilder()
        fun link(text: String, url: String) {
            val start = sb.length
            sb.append(text)
            sb.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) { openUrl(url) }
                override fun updateDrawState(ds: TextPaint) {
                    ds.color = pal.result
                    ds.isUnderlineText = true
                }
            }, start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        sb.append("How to Use → ")
        link("CalCognito", REPO_URL)
        sb.append("\n\nCreated by The AryanOnion · ")
        link("GitHub", PROFILE_URL)
        sb.append("\n\nVersion ${appVersion()}")

        val body = TextView(this).apply {
            text = sb
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(pal.text)
            setLineSpacing(0f, 1.2f)
            movementMethod = LinkMovementMethod.getInstance()
            highlightColor = Color.TRANSPARENT
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), 0, dp(24), 0)
            addView(body)
        }
        aboutDialog?.dismiss()
        aboutDialog = showStyledDialog("About", box, "Close", null) {}
    }

    private fun isValidPin(s: String) = s.length >= 4 && s.all { it.isDigit() }

    private fun onEqualsHeld() {
        if (changeMode || justEvaluated) return
        if (VaultManager.isPinSet(this) && expression == "0000") {
            pinResetPending = true
            expression = ""
            refresh()
            Toast.makeText(this, "Press = again to reset PIN (erases existing files)", Toast.LENGTH_LONG).show()
            return
        }
        if (!VaultManager.isPinSet(this)) {
            if (isValidPin(expression)) {
                VaultManager.setPin(this, expression)
                expression = ""
                refresh()
                Toast.makeText(this, "Password set", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Type at least 4 digits, then hold = for 3 seconds", Toast.LENGTH_LONG).show()
            }
        } else if (VaultManager.checkPin(this, expression)) {

            expression = ""
            changeMode = true
            refresh()
        }

    }

    private fun getFileName(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1) result = cursor.getString(idx)
                }
            } finally {
                cursor?.close()
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != -1 && cut != null) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }

    private fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            afterPermission = action
            leavingForTask = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_PERM)
        } else {
            action()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            val action = afterPermission
            afterPermission = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                action?.invoke()
            } else {
                Toast.makeText(this, "Storage permission is needed to move files", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun pickFileForVault() = withStoragePermission {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        leavingForTask = true
        try {
            startActivityForResult(intent, REQ_PICK)
        } catch (e: Exception) {
            leavingForTask = false
            Toast.makeText(this, "No file picker available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun collectUris(data: Intent): List<Uri> {
        val list = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i).uri?.let { list.add(it) }
            }
        } else {
            data.data?.let { list.add(it) }
        }
        return list
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_PICK -> if (resultCode == RESULT_OK && data != null) confirmAdd(collectUris(data))
            REQ_DELETE_BATCH -> {
                if (resultCode != RESULT_OK) hideNotRemoved += batchDeleteCount
                finishHide()
            }
            REQ_DELETE_LEGACY -> {
                val uri = legacyCurrent
                legacyCurrent = null
                if (resultCode == RESULT_OK && uri != null) {
                    try {
                        if (contentResolver.delete(uri, null, null) <= 0) hideNotRemoved++
                    } catch (_: Exception) {
                        hideNotRemoved++
                    }
                } else {
                    hideNotRemoved++
                }
                processLegacyDeleteQueue()
            }
        }
    }

    private fun confirmAdd(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val check = CheckBox(this).apply {
            text = "Encrypt the files"
            isChecked = false
            setTextColor(pal.text)
            buttonTintList = ColorStateList(
                arrayOf(intArrayOf(android.R.attr.state_checked), intArrayOf()),
                intArrayOf(pal.cursor, pal.text)
            )
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(msgBody(
                "Files are moved into the vault and removed from your gallery and file manager.\n\n" +
                "Not encrypted: opens instantly, and other apps can't see it, but the file itself isn't scrambled.\n" +
                "Encrypted: fully protected, but a bit slower to add and open."
            ))
            addView(check, LinearLayout.LayoutParams(-2, -2).apply { setMargins(dp(20), dp(12), dp(24), 0) })
        }
        showStyledDialog("Add ${uris.size} file(s) to vault", ScrollView(this).apply { addView(box) }, "Add", "Cancel") {
            hideSelectedFiles(uris, check.isChecked)
        }
    }

    private fun hideSelectedFiles(uris: List<Uri>, encrypt: Boolean) {
        if (uris.isEmpty()) return
        hideHidden = 0
        hideFailed = 0
        hideNotRemoved = 0
        val targetFolder = currentFolder
        val progress = showProgress("Moving ${uris.size} file(s) into the vault…")

        Thread {
            val needConfirm = mutableListOf<Uri>()
            for ((i, uri) in uris.withIndex()) {
                val name = getFileName(uri) ?: "file_${System.currentTimeMillis()}_$i"
                if (!VaultManager.addToVault(applicationContext, uri, name, targetFolder, encrypt)) {
                    hideFailed++
                    continue
                }
                hideHidden++

                if (!VaultManager.tryDeleteOriginal(applicationContext, uri)) {
                    val media = VaultManager.toMediaStoreUri(applicationContext, uri)
                    if (media != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) needConfirm.add(media)
                    else hideNotRemoved++
                }
            }
            runOnUiThread {
                try { progress.dismiss() } catch (_: Exception) {}
                renderVaultFiles()
                when {
                    needConfirm.isEmpty() -> finishHide()
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> requestBatchDelete(needConfirm)
                    else -> {
                        legacyDeleteQueue.addAll(needConfirm)
                        processLegacyDeleteQueue()
                    }
                }
            }
        }.start()
    }

    @RequiresApi(Build.VERSION_CODES.R)
    private fun requestBatchDelete(uris: List<Uri>) {
        batchDeleteCount = uris.size
        try {
            val request = MediaStore.createDeleteRequest(contentResolver, uris)
            leavingForTask = true
            startIntentSenderForResult(request.intentSender, REQ_DELETE_BATCH, null, 0, 0, 0)
        } catch (e: Exception) {
            leavingForTask = false
            hideNotRemoved += uris.size
            finishHide()
        }
    }

    private fun processLegacyDeleteQueue() {
        while (legacyDeleteQueue.isNotEmpty()) {
            val uri = legacyDeleteQueue.removeAt(0)
            try {
                if (contentResolver.delete(uri, null, null) <= 0) hideNotRemoved++
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && e is RecoverableSecurityException) {
                    legacyCurrent = uri
                    leavingForTask = true
                    try {
                        startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ_DELETE_LEGACY, null, 0, 0, 0)
                        return
                    } catch (_: Exception) {
                        leavingForTask = false
                        legacyCurrent = null
                        hideNotRemoved++
                    }
                } else {
                    hideNotRemoved++
                }
            } catch (_: Exception) {
                hideNotRemoved++
            }
        }
        finishHide()
    }

    private fun finishHide() {
        renderVaultFiles()
        if (hideFailed == 0 && hideNotRemoved == 0) {
            if (hideHidden > 0) Toast.makeText(this, "$hideHidden file(s) hidden in the vault", Toast.LENGTH_SHORT).show()
            return
        }
        val msg = StringBuilder()
        if (hideHidden > 0) msg.append("$hideHidden file(s) are now in the vault.\n\n")
        if (hideNotRemoved > 0) {
            msg.append("$hideNotRemoved original(s) could not be removed from their old location, so they are still visible there. ")
            msg.append("Delete them manually, or allow the deletion request when Android asks.\n\n")
        }
        if (hideFailed > 0) msg.append("$hideFailed file(s) could not be copied into the vault and were left untouched.")
        showStyledDialog("Hide result", msgBody(msg.toString().trim()), "OK", null) {}
    }

    private fun actionText(label: String, color: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { onClick() }
    }

    private fun openVaultFile(file: File) {
        val mime = VaultManager.mimeFor(VaultManager.displayName(file))
        when {
            mime.startsWith("image/") -> showImageViewer(file)
            mime.startsWith("video/") || mime.startsWith("audio/") -> showMediaViewer(file)
            else -> openExternally(file, mime)
        }
    }

    private fun showViewer(file: File, content: View, onClose: () -> Unit = {}) {
        viewerDialog?.dismiss()
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#B3000000"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        bar.addView(TextView(this).apply {
            text = VaultManager.displayName(file)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(actionText("Unhide", Color.WHITE) { dialog.dismiss(); unhideFile(file) })
        bar.addView(actionText("Delete", Color.parseColor("#FFB5A2")) { dialog.dismiss(); confirmDelete(file) })
        bar.addView(actionText("Close", Color.WHITE) { dialog.dismiss() })
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        dialog.setContentView(root)
        dialog.setOnDismissListener {
            onClose()
            if (viewerDialog === dialog) viewerDialog = null
            VaultManager.clearTemp(applicationContext)
        }
        viewerDialog = dialog
        dialog.show()
    }

    private fun showImageViewer(file: File) {
        val dm = resources.displayMetrics
        Thread {
            val bm = try {
                VaultManager.readDecrypted(file)?.let { VaultManager.decodeBitmap(it, dm.widthPixels, dm.heightPixels) }
            } catch (_: Throwable) {
                null
            }
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (bm == null) {
                    Toast.makeText(this, "Unable to open this image", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val iv = ImageView(this).apply {
                    setImageBitmap(bm)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(0, dp(56), 0, 0)
                }
                showViewer(file, iv)
            }
        }.start()
    }

    private fun showMediaViewer(file: File) {
        Toast.makeText(this, "Opening…", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp: File? = if (VaultManager.isEncrypted(file)) VaultManager.decryptToTemp(applicationContext, file) else file
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (tmp == null) {
                    Toast.makeText(this, "Decryption failed", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                buildPlayer(file, tmp)
            }
        }.start()
    }

    private fun buildPlayer(file: File, media: File) {
        val ui = Handler(Looper.getMainLooper())
        val speeds = floatArrayOf(0.5f, 0.75f, 1f, 1.25f, 1.5f, 2f)
        val speedLabels = arrayOf("0.5x", "0.75x", "1x (Normal)", "1.25x", "1.5x", "2x")
        var speedIdx = 2
        var player: MediaPlayer? = null
        var prepared = false
        var dragging = false
        var holdBoost = false
        var gesture = 0

        val vv = VideoView(this)
        val white = Color.WHITE
        val soft = Color.parseColor("#B3FFFFFF")

        fun fmt(ms: Int): String {
            val t = (ms / 1000).coerceAtLeast(0)
            val h = t / 3600
            val m = (t % 3600) / 60
            val sec = t % 60
            return if (h > 0) java.lang.String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec)
            else java.lang.String.format(java.util.Locale.US, "%d:%02d", m, sec)
        }

        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            isClickable = true
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Color.TRANSPARENT, Color.parseColor("#CC000000"))
            )
            setPadding(dp(16), dp(32), dp(16), dp(28))
        }
        val cur = TextView(this).apply {
            text = "0:00"; setTextColor(white); setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        }
        val total = TextView(this).apply {
            text = "0:00"; setTextColor(soft); setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        }
        val seek = SeekBar(this).apply {
            max = 1
            progressTintList = ColorStateList.valueOf(pal.result)
            thumbTintList = ColorStateList.valueOf(pal.result)
            progressBackgroundTintList = ColorStateList.valueOf(Color.parseColor("#55FFFFFF"))
        }
        val playIcon = ImageView(this).apply {
            setColorFilter(white)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
        }

        val hide = Runnable {
            if (vv.isPlaying && !dragging) controls.visibility = View.GONE
        }
        fun showControls() {
            controls.visibility = View.VISIBLE
            ui.removeCallbacks(hide)
            if (vv.isPlaying) ui.postDelayed(hide, 3000)
        }
        fun updatePlayIcon() {
            playIcon.setImageResource(if (vv.isPlaying) R.drawable.ic_pause else R.drawable.ic_play)
        }
        fun applySpeed() {
            val mp = player ?: return
            try {
                val playing = vv.isPlaying
                mp.playbackParams = mp.playbackParams.setSpeed(if (holdBoost) 2f else speeds[speedIdx])
                if (!playing) vv.pause()
            } catch (_: Exception) {
                Toast.makeText(this, "Speed change isn't supported for this file", Toast.LENGTH_SHORT).show()
            }
        }
        fun togglePlay() {
            if (!prepared) return
            if (vv.isPlaying) {
                vv.pause()
            } else {
                if (vv.currentPosition >= vv.duration - 200) vv.seekTo(0)
                vv.start()
                applySpeed()
            }
            updatePlayIcon()
            showControls()
        }
        val pill = TextView(this).apply {
            setTextColor(white)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            setPadding(dp(18), dp(10), dp(18), dp(10))
            background = GradientDrawable().apply {
                cornerRadius = dpf(100)
                setColor(Color.parseColor("#99000000"))
            }
            visibility = View.GONE
        }
        val hidePill = Runnable { pill.visibility = View.GONE }
        fun showPill(msg: String, grav: Int, sticky: Boolean = false) {
            pill.text = msg
            val lp = pill.layoutParams as FrameLayout.LayoutParams
            lp.gravity = grav
            lp.topMargin = if ((grav and Gravity.VERTICAL_GRAVITY_MASK) == Gravity.TOP) dp(88) else dp(24)
            pill.layoutParams = lp
            pill.visibility = View.VISIBLE
            ui.removeCallbacks(hidePill)
            if (!sticky) ui.postDelayed(hidePill, 800)
        }
        fun skip(deltaMs: Int) {
            if (!prepared) return
            val t = (vv.currentPosition + deltaMs).coerceIn(0, vv.duration)
            vv.seekTo(t)
            seek.progress = t
            cur.text = fmt(t)
            val label = (if (deltaMs < 0) "−10s" else "+10s") + " (" + fmt(t) + ")"
            showPill(label, (if (deltaMs < 0) Gravity.START else Gravity.END) or Gravity.CENTER_VERTICAL)
        }
        fun circle(sizeDp: Int, onClick: () -> Unit): FrameLayout = FrameLayout(this).apply {
            val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
            background = RippleDrawable(ColorStateList.valueOf(Color.parseColor("#33FFFFFF")), null, mask)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)).apply { setMargins(dp(6), 0, dp(6), 0) }
        }
        seek.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, progress: Int, fromUser: Boolean) {
                if (fromUser) cur.text = fmt(progress)
            }
            override fun onStartTrackingTouch(sb: SeekBar) {
                dragging = true
                ui.removeCallbacks(hide)
            }
            override fun onStopTrackingTouch(sb: SeekBar) {
                dragging = false
                if (prepared) vv.seekTo(sb.progress)
                showControls()
            }
        })

        val row1 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(cur)
            addView(seek, LinearLayout.LayoutParams(0, dp(40), 1f).apply { setMargins(dp(8), 0, dp(8), 0) })
            addView(total)
        }

        val speedBtn = TextView(this).apply {
            text = "1x"
            setTextColor(white)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                cornerRadius = dpf(100)
                setColor(Color.parseColor("#33FFFFFF"))
            }
            setOnClickListener {
                var pick = speedIdx
                val body = radioRows(speedLabels.toList(), speedIdx) { pick = it }
                showStyledDialog("Playback speed", body, "OK", "Cancel") {
                    speedIdx = pick
                    applySpeed()
                    text = if (speeds[pick] == 1f) "1x" else speedLabels[pick]
                    showControls()
                }
            }
        }
        val playBtn = circle(64) { togglePlay() }.apply {
            addView(playIcon, FrameLayout.LayoutParams(dp(44), dp(44), Gravity.CENTER))
        }
        val helpBtn = TextView(this).apply {
            text = "?"
            setTextColor(white)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#33FFFFFF"))
            }
            setOnClickListener { showVideoHelp() }
        }
        val row2 = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            addView(FrameLayout(this@MainActivity).apply {
                addView(speedBtn, FrameLayout.LayoutParams(dp(64), dp(34), Gravity.START or Gravity.CENTER_VERTICAL))
            }, LinearLayout.LayoutParams(0, dp(64), 1f))
            addView(playBtn)
            addView(FrameLayout(this@MainActivity).apply {
                addView(helpBtn, FrameLayout.LayoutParams(dp(36), dp(36), Gravity.END or Gravity.CENTER_VERTICAL))
            }, LinearLayout.LayoutParams(0, dp(64), 1f))
        }
        controls.addView(row1, LinearLayout.LayoutParams(-1, -2))
        controls.addView(row2, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        val tick = object : Runnable {
            override fun run() {
                if (prepared && !dragging) {
                    val pos = vv.currentPosition
                    seek.progress = pos
                    cur.text = fmt(pos)
                }
                updatePlayIcon()
                ui.postDelayed(this, 250)
            }
        }

        vv.setOnPreparedListener { mp ->
            player = mp
            prepared = true
            val d = vv.duration.coerceAtLeast(1)
            seek.max = d
            total.text = fmt(d)
            vv.start()
            applySpeed()
            updatePlayIcon()
            showControls()
        }
        vv.setOnCompletionListener {
            seek.progress = seek.max
            cur.text = fmt(vv.duration)
            updatePlayIcon()
            ui.removeCallbacks(hide)
            controls.visibility = View.VISIBLE
        }
        vv.setOnErrorListener { _, _, _ ->
            Toast.makeText(this, "Couldn't play this file", Toast.LENGTH_SHORT).show()
            true
        }
        vv.setVideoPath(media.absolutePath)

        val holder = FrameLayout(this).apply {
            addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
            addView(controls, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
            addView(pill, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
        }

        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var startLevel = 0f

        fun curBrightness(): Float {
            val b = viewerDialog?.window?.attributes?.screenBrightness ?: -1f
            if (b >= 0f) return b
            return try {
                Settings.System.getInt(contentResolver, Settings.System.SCREEN_BRIGHTNESS) / 255f
            } catch (_: Exception) { 0.5f }
        }
        fun setBrightness(v: Float) {
            val w = viewerDialog?.window ?: return
            val lp = w.attributes
            lp.screenBrightness = v.coerceIn(0.01f, 1f)
            w.attributes = lp
        }

        val detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean = true

            override fun onSingleTapConfirmed(e: MotionEvent): Boolean {
                if (controls.visibility == View.VISIBLE && vv.isPlaying) {
                    ui.removeCallbacks(hide)
                    controls.visibility = View.GONE
                } else {
                    showControls()
                }
                return true
            }

            override fun onDoubleTap(e: MotionEvent): Boolean {
                val w = holder.width.toFloat()
                when {
                    e.x < w / 3f -> skip(-10_000)
                    e.x > w * 2f / 3f -> skip(10_000)
                    else -> {
                        togglePlay()
                        showPill(if (vv.isPlaying) "Playing" else "Paused", Gravity.TOP or Gravity.CENTER_HORIZONTAL)
                    }
                }
                return true
            }

            override fun onLongPress(e: MotionEvent) {
                if (!prepared || !vv.isPlaying || gesture != 0) return
                holdBoost = true
                applySpeed()
                holder.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                showPill("2x", Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
            }

            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (holdBoost || e1 == null) return false
                val w = holder.width.toFloat()
                val h = holder.height.toFloat()
                if (gesture == 0) {
                    val dx = Math.abs(e2.x - e1.x)
                    val dy = Math.abs(e2.y - e1.y)
                    if (dy > slop && dy > dx) {
                        if (e1.x < w / 2f) {
                            gesture = 1
                            startLevel = curBrightness()
                        } else {
                            gesture = 2
                            val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                            startLevel = am.getStreamVolume(AudioManager.STREAM_MUSIC).toFloat() / max
                        }
                        ui.removeCallbacks(hide)
                    } else if (dx > slop) {
                        gesture = 3
                        return false
                    } else {
                        return false
                    }
                }
                if (gesture == 1 || gesture == 2) {
                    val level = (startLevel + (e1.y - e2.y) / (h * 0.7f)).coerceIn(0f, 1f)
                    val pct = Math.round(level * 100)
                    if (gesture == 1) {
                        setBrightness(level)
                        showPill("Brightness $pct%", Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
                    } else {
                        val max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC).coerceAtLeast(1)
                        am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(level * max), 0)
                        showPill("Volume $pct%", Gravity.TOP or Gravity.CENTER_HORIZONTAL, true)
                    }
                    return true
                }
                return false
            }
        })
        holder.setOnTouchListener { _, ev ->
            detector.onTouchEvent(ev)
            if (ev.actionMasked == MotionEvent.ACTION_UP || ev.actionMasked == MotionEvent.ACTION_CANCEL) {
                if (holdBoost) {
                    holdBoost = false
                    applySpeed()
                    ui.removeCallbacks(hidePill)
                    pill.visibility = View.GONE
                }
                if (gesture != 0) {
                    gesture = 0
                    ui.removeCallbacks(hidePill)
                    ui.postDelayed(hidePill, 600)
                }
            }
            true
        }
        ui.post(tick)
        showViewer(file, holder) {
            ui.removeCallbacksAndMessages(null)
            try { vv.stopPlayback() } catch (_: Exception) {}
        }
    }

    private fun openExternally(file: File, mime: String) {
        Toast.makeText(this, "Opening…", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp = VaultManager.decryptToTemp(applicationContext, file)
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (tmp == null) {
                    Toast.makeText(this, "Decryption failed", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", tmp)
                val viewMime = if (mime == "application/octet-stream") "*/*" else mime
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, viewMime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                leavingForTask = true
                externalViewing = true
                try {
                    startActivity(viewIntent)
                } catch (e: Exception) {
                    leavingForTask = false
                    externalViewing = false
                    VaultManager.clearTemp(applicationContext)
                    Toast.makeText(this, "No app can open this file. Use Unhide to restore it.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    private fun unhideFile(file: File) = withStoragePermission {
        Toast.makeText(this, "Unhiding…", Toast.LENGTH_SHORT).show()
        Thread {
            val folder = VaultManager.restoreToPublic(applicationContext, file)
            if (folder != null) VaultManager.deleteFile(this, file)
            runOnUiThread {
                if (folder != null) {
                    Toast.makeText(this, "Restored to $folder", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Couldn't unhide this file (it is still safe in the vault)", Toast.LENGTH_LONG).show()
                }
                renderVaultFiles()
            }
        }.start()
    }

    private fun confirmDelete(file: File) {
        showStyledDialog(
            "Delete permanently?",
            msgBody("\"${VaultManager.displayName(file)}\" will be deleted from the vault and cannot be recovered."),
            "Delete", "Cancel"
        ) {
            VaultManager.deleteFile(this, file)
            renderVaultFiles()
            Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
        }
    }

    private fun categoryOf(name: String): Int {
        val mime = VaultManager.mimeFor(name)
        return when {
            mime.startsWith("image/") -> 1
            mime.startsWith("video/") -> 2
            else -> 3
        }
    }

    private fun filterChip(label: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(if (selected) pal.eqFg else pal.sciFg)
        typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = GradientDrawable().apply {
            cornerRadius = dpf(100)
            setColor(if (selected) pal.eqBg else pal.numBg)
        }
        setOnClickListener { onClick() }
    }

    private fun chipParams() = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }

    private fun renderVaultChips() {
        vaultChipsRow.removeAllViews()
        listOf("All", "Images", "Videos", "Files").forEachIndexed { i, label ->
            vaultChipsRow.addView(filterChip(label, vaultFilter == i) {
                vaultFilter = i
                renderVaultFiles()
            }, chipParams())
        }
        val sortLabels = listOf("A–Z", "Newest", "Largest")
        vaultChipsRow.addView(filterChip("Sort: ${sortLabels[vaultSort]}", false) {
            vaultSort = (vaultSort + 1) % 3
            renderVaultFiles()
        }, chipParams())
        if (currentFolder == null) {
            vaultChipsRow.addView(filterChip("+ Folder", false) { promptNewFolder() }, chipParams())
        }
    }

    private fun promptText(title: String, initial: String, positive: String, hint: String = "Folder name", onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            this.hint = hint
            setSingleLine(true)
            setText(initial)
            setSelection(text.length)
            setTextColor(pal.text)
            setHintTextColor(pal.icon)
            backgroundTintList = ColorStateList.valueOf(pal.cursor)
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), 0, dp(24), 0)
            addView(input)
        }
        val d = showStyledDialog(title, box, positive, "Cancel") { onOk(input.text.toString()) }
        d.window?.setSoftInputMode(
            WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE
        )
        input.requestFocus()
    }

    private fun promptNewFolder(onCreated: ((String) -> Unit)? = null) {
        promptText("New folder", "", "Create") { raw ->
            val name = VaultManager.cleanFolderName(raw)
            if (name == null) {
                Toast.makeText(this, "Enter a folder name", Toast.LENGTH_SHORT).show()
            } else if (VaultManager.folderExists(this, name)) {
                if (onCreated != null) onCreated(name)
                else Toast.makeText(this, "A folder with that name already exists", Toast.LENGTH_SHORT).show()
            } else if (VaultManager.createFolder(this, name)) {
                if (onCreated != null) {
                    onCreated(name)
                } else {
                    renderVaultFiles()
                    Toast.makeText(this, "Folder created", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Couldn't create folder", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showFolderMenu(anchor: View, folder: String) {
        showListDialog(folder, listOf(
            Triple(R.drawable.ic_edit, "Rename", {
                promptText("Rename folder", folder, "Rename") { raw ->
                    val newName = VaultManager.cleanFolderName(raw)
                    if (newName == null) {
                        Toast.makeText(this, "Enter a folder name", Toast.LENGTH_SHORT).show()
                    } else if (newName != folder) {
                        if (VaultManager.renameFolder(this, folder, newName)) renderVaultFiles()
                        else Toast.makeText(this, "Couldn't rename (that name may already exist)", Toast.LENGTH_SHORT).show()
                    }
                }
            }),
            Triple(R.drawable.ic_delete, "Delete folder", { confirmDeleteFolder(folder) })
        ))
    }

    private fun confirmDeleteFolder(folder: String) {
        showStyledDialog(
            "Delete folder?",
            msgBody("\"$folder\" will be removed. Any files inside move back to the main vault, nothing is deleted."),
            "Delete folder", "Cancel"
        ) {
            VaultManager.deleteFolder(this, folder)
            renderVaultFiles()
        }
    }

    private fun showMoveDialog(files: List<File>) {
        val rows = mutableListOf<Triple<Int, String, () -> Unit>>()
        if (currentFolder != null) rows.add(Triple(R.drawable.ic_folder, "Main vault", { moveInto(files, null) }))
        for (f in VaultManager.listFolders(this)) {
            if (f != currentFolder) rows.add(Triple(R.drawable.ic_folder, f, { moveInto(files, f) }))
        }
        rows.add(Triple(R.drawable.ic_create_folder, "New folder…", { promptNewFolder { name -> moveInto(files, name) } }))
        showListDialog("Move to", rows)
    }

    private fun moveInto(files: List<File>, folder: String?) {
        var ok = 0
        for (f in files) if (VaultManager.moveFile(this, f, folder) != null) ok++
        selected.clear()
        renderVaultFiles()
        val where = folder ?: "main vault"
        Toast.makeText(
            this,
            when {
                ok == 0 -> "Couldn't move"
                ok < files.size -> "Moved $ok of ${files.size} to $where"
                ok == 1 -> "Moved to $where"
                else -> "Moved $ok files to $where"
            },
            Toast.LENGTH_SHORT
        ).show()
    }

    private fun toggleSelect(path: String) {
        if (!selected.add(path)) selected.remove(path)
        rowUpdaters[path]?.invoke()
        updateSelectionUi()
    }

    private fun clearSelection() {
        val old = selected.toList()
        selected.clear()
        old.forEach { rowUpdaters[it]?.invoke() }
        updateSelectionUi()
    }

    private fun selectedFiles(): List<File> = selected.map { File(it) }.filter { it.exists() }

    private fun setFabMenu(open: Boolean) {
        fabMenuOpen = open
        fabScrim.visibility = if (open) View.VISIBLE else View.GONE
        fabMenu.visibility = if (open) View.VISIBLE else View.GONE
        folderPill.visibility = if (currentFolder == null) View.VISIBLE else View.GONE
        fabShape.setColor(if (open) pal.cursor else pal.acBg)
        fabIcon.setImageResource(if (open) R.drawable.ic_close else R.drawable.ic_add)
        fabIcon.setColorFilter(if (open) pal.bg else pal.acFg)
        fabMenu.animate().cancel()
        fabScrim.animate().cancel()
        if (open) {
            fabMenu.alpha = 0f
            fabScrim.alpha = 0f
            fabMenu.animate().alpha(1f).setDuration(150).start()
            fabScrim.animate().alpha(1f).setDuration(150).start()
        }
    }

    private fun updateSelectionUi() {
        val n = selected.size
        if (n > 0 && fabMenuOpen) setFabMenu(false)
        vaultTitle.text = when {
            n > 0 -> "$n selected"
            currentFolder == null -> "Secure Vault"
            else -> "‹  $currentFolder"
        }
        vaultCloseBtn.text = if (n > 0) "Cancel" else "Close"
        vaultFabHost.visibility = if (vaultVisible && n == 0) View.VISIBLE else View.GONE
    }

    private fun onFileLongPress(file: File) {
        if (file.absolutePath !in selected) toggleSelect(file.absolutePath)
        showSelectionSheet()
    }

    private fun showSelectionSheet() {
        if (selectedFiles().isEmpty()) return
        val dialog = Dialog(this)
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        dialog.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)
        val sheet = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val r = dpf(28)
            background = GradientDrawable().apply {
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
                setColor(pal.dialogBg)
            }
            setPadding(0, dp(20), 0, dp(16))
        }
        sheet.addView(TextView(this).apply {
            text = "Selected files"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setPadding(dp(24), 0, dp(24), dp(16))
        })
        sheet.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        sheet.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, -2))
        val current = selectedFiles()

        fun item(icon: Int, label: String, color: Int, action: () -> Unit) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(24), 0, dp(24), 0)
                background = rippleBg()
                isClickable = true
                setOnClickListener { dialog.dismiss(); action() }
            }
            row.addView(ImageView(this).apply {
                setImageResource(icon)
                setColorFilter(color)
            }, LinearLayout.LayoutParams(dp(24), dp(24)).apply { rightMargin = dp(24) })
            row.addView(TextView(this).apply {
                text = label
                setTextColor(color)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            })
            list.addView(row, LinearLayout.LayoutParams(-1, dp(60)))
        }
        item(R.drawable.ic_delete, "Delete", pal.clearFg) { confirmDeleteSelected(selectedFiles()) }
        item(R.drawable.ic_unhide, "Unhide", pal.text) { unhideFiles(selectedFiles()) }
        item(R.drawable.ic_open_with, "Move", pal.text) { showMoveDialog(selectedFiles()) }
        item(R.drawable.ic_create_folder, "Create folder", pal.text) {
            val files = selectedFiles()
            promptNewFolder { name -> moveInto(files, name) }
        }
        if (current.any { !VaultManager.isEncrypted(it) }) {
            item(R.drawable.ic_lock, "Encrypt", pal.text) { cryptFiles(selectedFiles(), true) }
        }
        if (current.any { VaultManager.isEncrypted(it) }) {
            item(R.drawable.ic_lock_open, "Decrypt", pal.text) { cryptFiles(selectedFiles(), false) }
        }

        if (current.size == 1) {
            item(R.drawable.ic_edit, "Rename", pal.text) { renameSelected(current[0]) }
        }

        dialog.setContentView(sheet)
        dialog.window?.apply {
            setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            setGravity(Gravity.BOTTOM)
        }
        dialog.show()
    }

    private fun confirmDeleteSelected(files: List<File>) {
        if (files.isEmpty()) return
        val n = files.size
        showStyledDialog(
            "Delete permanently?",
            msgBody(
                if (n == 1) "\"${VaultManager.displayName(files[0])}\" will be deleted from the vault and cannot be recovered."
                else "$n files will be deleted from the vault and cannot be recovered."
            ),
            "Delete", "Cancel"
        ) {
            files.forEach { VaultManager.deleteFile(this, it) }
            selected.clear()
            renderVaultFiles()
            Toast.makeText(this, if (n == 1) "Deleted" else "Deleted $n files", Toast.LENGTH_SHORT).show()
        }
    }

    private fun renameSelected(file: File) {
        promptText("Rename", VaultManager.displayName(file), "Rename", "Name") { raw ->
            val name = raw.trim()
            if (name.isEmpty()) {
                Toast.makeText(this, "Enter a name", Toast.LENGTH_SHORT).show()
            } else if (name != VaultManager.displayName(file)) {
                if (VaultManager.renameFile(this, file, name) != null) {
                    selected.clear()
                    renderVaultFiles()
                    Toast.makeText(this, "Renamed", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Couldn't rename (that name may already exist)", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun cryptFiles(files: List<File>, encrypt: Boolean) {
        val todo = files.filter { VaultManager.isEncrypted(it) != encrypt }
        if (todo.isEmpty()) {
            Toast.makeText(this, if (encrypt) "Already encrypted" else "Already decrypted", Toast.LENGTH_SHORT).show()
            return
        }
        val progress = showProgress(if (encrypt) "Encrypting ${todo.size} file(s)…" else "Decrypting ${todo.size} file(s)…")
        Thread {
            var ok = 0
            for (f in todo) {
                val r = if (encrypt) VaultManager.encryptInVault(applicationContext, f)
                        else VaultManager.decryptInVault(applicationContext, f)
                if (r != null) ok++
            }
            runOnUiThread {
                try { progress.dismiss() } catch (_: Exception) {}
                selected.clear()
                thumbCache.clear()
                if (vaultVisible) renderVaultFiles()
                val verb = if (encrypt) "Encrypted" else "Decrypted"
                Toast.makeText(
                    this,
                    when {
                        ok == 0 -> "Couldn't ${verb.lowercase().removeSuffix("ed")} (files left unchanged)"
                        ok < todo.size -> "$verb $ok of ${todo.size} files"
                        ok == 1 -> "$verb 1 file"
                        else -> "$verb $ok files"
                    },
                    Toast.LENGTH_SHORT
                ).show()
            }
        }.start()
    }

    private fun unhideFiles(files: List<File>) = withStoragePermission {
        if (files.isEmpty()) return@withStoragePermission
        Toast.makeText(this, "Unhiding…", Toast.LENGTH_SHORT).show()
        Thread {
            var ok = 0
            var lastFolder: String? = null
            for (f in files) {
                val folder = VaultManager.restoreToPublic(applicationContext, f)
                if (folder != null) {
                    VaultManager.deleteFile(this, f)
                    ok++
                    lastFolder = folder
                }
            }
            runOnUiThread {
                selected.clear()
                val msg = when {
                    ok == 0 -> "Couldn't unhide (still safe in the vault)"
                    ok == files.size && ok == 1 -> "Restored to $lastFolder"
                    ok == files.size -> "Restored $ok files"
                    else -> "Restored $ok of ${files.size} files (the rest are still safe in the vault)"
                }
                Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
                if (vaultVisible) renderVaultFiles()
            }
        }.start()
    }

    private fun upgradeInBackground(file: File, wantThumb: Boolean, applyThumb: (Bitmap) -> Unit) {
        val path = file.absolutePath
        if (!migrating.add(path)) return
        try {
            migrateExecutor.execute {
                try {
                    if (VaultManager.isLegacy(file) && VaultManager.migrateLegacy(file) && wantThumb) {
                        val bm = VaultManager.readThumb(file)
                        if (bm != null) {
                            thumbCache[path + file.lastModified()] = bm
                            runOnUiThread { applyThumb(bm) }
                        }
                    }
                } finally {
                    migrating.remove(path)
                }
            }
        } catch (_: Exception) {
            migrating.remove(path)
        }
    }

    private fun renderVaultFiles() {
        val folder = currentFolder
        rowUpdaters.clear()
        renderVaultChips()
        vaultFilesList.removeAllViews()

        val folders = if (folder == null) VaultManager.listFolders(this) else emptyList()
        val all = VaultManager.listFiles(this, folder)
        val filtered = all.filter { vaultFilter == 0 || categoryOf(VaultManager.displayName(it)) == vaultFilter }
        val files = when (vaultSort) {
            1 -> filtered.sortedByDescending { it.lastModified() }
            2 -> filtered.sortedByDescending { it.length() }
            else -> filtered.sortedBy { VaultManager.displayName(it).lowercase() }
        }
        selected.retainAll(files.map { it.absolutePath }.toSet())
        updateSelectionUi()

        if (folders.isEmpty() && files.isEmpty()) {
            val msg = when {
                all.isNotEmpty() -> "No ${listOf("files", "images", "videos", "files")[vaultFilter].lowercase()} here"
                folder == null -> "No files in vault"
                else -> "This folder is empty"
            }
            vaultFilesList.addView(TextView(this).apply {
                text = msg
                setTextColor(pal.icon)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            })
            return
        }

        for (f in folders) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(16), dp(8), dp(4), dp(8))
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                setOnClickListener {
                    selected.clear()
                    currentFolder = f
                    renderVaultFiles()
                }
                setOnLongClickListener { v -> showFolderMenu(v, f); true }
            }
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_folder)
                setColorFilter(pal.result)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                text = f
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(TextView(this).apply {
                text = "${VaultManager.countFiles(this@MainActivity, f)} file(s)"
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(iconButton(R.drawable.ic_more_vert, "Folder options") { showFolderMenu(it, f) }, LinearLayout.LayoutParams(dp(44), dp(44)))
            vaultFilesList.addView(row)
            vaultFilesList.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        }

        for (file in files) {
            val name = VaultManager.displayName(file)
            val mime = VaultManager.mimeFor(name)
            val isImage = mime.startsWith("image/")

            val path = file.absolutePath
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(8), dp(8), dp(8))
                isClickable = true
                setOnClickListener {
                    if (selected.isNotEmpty()) toggleSelect(path) else openVaultFile(file)
                }
                setOnLongClickListener {
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onFileLongPress(file)
                    true
                }
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val thumb = ImageView(this).apply {
                layoutParams = FrameLayout.LayoutParams(-1, -1)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setColorFilter(pal.icon)
                setImageResource(
                    when {
                        isImage -> R.drawable.ic_image
                        mime.startsWith("video/") || mime.startsWith("audio/") -> R.drawable.ic_play
                        else -> R.drawable.ic_file
                    }
                )
                tag = file.absolutePath
            }
            val selOverlay = FrameLayout(this).apply {
                background = GradientDrawable().apply {
                    cornerRadius = dpf(8)
                    setColor((pal.eqBg and 0xFFFFFF) or (0xCC shl 24))
                }
                visibility = View.GONE
                addView(ImageView(this@MainActivity).apply {
                    setImageResource(R.drawable.ic_check)
                    setColorFilter(pal.eqFg)
                }, FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER))
            }
            val thumbBox = FrameLayout(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) }
                isClickable = true
                setOnClickListener { toggleSelect(path) }
                setOnLongClickListener {
                    performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                    onFileLongPress(file)
                    true
                }
                addView(thumb)
                addView(selOverlay, FrameLayout.LayoutParams(-1, -1))
            }
            top.addView(thumbBox)
            if (VaultManager.isEncrypted(file)) {
                thumb.setImageResource(R.drawable.ic_lock)
                thumb.setColorFilter(pal.result)
                thumb.setPadding(dp(12), dp(12), dp(12), dp(12))
                thumbBox.background = GradientDrawable().apply { cornerRadius = dpf(12); setColor(pal.numBg) }
            }
            val selTint = (pal.opBg and 0xFFFFFF) or (0x55 shl 24)
            val updateRow = {
                val on = path in selected
                selOverlay.visibility = if (on) View.VISIBLE else View.GONE
                row.setBackgroundColor(if (on) selTint else Color.TRANSPARENT)
            }
            rowUpdaters[path] = updateRow
            updateRow()

            val isVideo = mime.startsWith("video/")
            val applyThumb = { bm: Bitmap ->
                if (thumb.tag == file.absolutePath) {
                    thumb.clearColorFilter()
                    thumb.setPadding(0, 0, 0, 0)
                    thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                    thumb.setImageBitmap(bm)
                }
            }
            if ((isImage || isVideo) && !VaultManager.isEncrypted(file)) {
                val key = file.absolutePath + file.lastModified()
                val cached = thumbCache[key]
                if (cached != null) {
                    applyThumb(cached)
                } else {
                    try {
                        thumbExecutor.execute {
                            val bm = VaultManager.readThumb(file)
                            if (bm != null) {
                                thumbCache[key] = bm
                                runOnUiThread { applyThumb(bm) }
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
            }
            if (VaultManager.isEncrypted(file)) upgradeInBackground(file, false, applyThumb)

            val nameCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            nameCol.addView(TextView(this).apply {
                text = name
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            nameCol.addView(TextView(this).apply {
                text = if (VaultManager.isEncrypted(file)) "Encrypted" else "Not encrypted"
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            })
            top.addView(nameCol, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(top, LinearLayout.LayoutParams(-1, -2))

            vaultFilesList.addView(row)
            vaultFilesList.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("entries", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split("\u0002").mapNotNull {
            val parts = it.split("\u0001")
            if (parts.size == 2) parts[0] to parts[1] else null
        }
    }

    private fun saveHistoryEntry(expr: String, result: String) {
        val entries = (listOf(expr to result) + loadHistory()).take(100)
        val raw = entries.joinToString("\u0002") { "${it.first}\u0001${it.second}" }
        prefs.edit().putString("entries", raw).apply()
    }

    private fun confirmClearHistory() {
        showStyledDialog("Clear history and memory?", null, "Clear", "Dismiss") { clearHistory() }
    }

    private fun clearHistory() {
        prefs.edit().remove("entries").apply()
        renderHistory()
        Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        pinBottom = true
        val entries = loadHistory().reversed()
        if (entries.isEmpty()) {
            historyList.addView(TextView(this).apply {
                text = "No history yet"
                setTextColor(pal.icon)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            }, LinearLayout.LayoutParams(-1, -2))
            return
        }
        for ((expr, result) in entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(24), dp(12), dp(24), dp(12))
                isClickable = true
                background = RippleDrawable(ColorStateList.valueOf(pal.ripple), null, ColorDrawable(Color.BLACK))
                setOnClickListener {
                    expression = result
                    previousExpression = expr
                    justEvaluated = true
                    toggleHistory()
                    refresh()
                }
            }

            row.addView(TextView(this).apply {
                text = group(expr) + " ="
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
                typeface = displayFont
                gravity = Gravity.END
                setLineSpacing(0f, 1.1f)
            }, LinearLayout.LayoutParams(-1, -2))

            val resultView = TextView(this).apply {
                typeface = displayFont
                gravity = Gravity.END
            }
            val grouped = group(result)
            resultView.text = grouped
            style(resultView, 20, 34, pal.text, grouped)
            row.addView(resultView, LinearLayout.LayoutParams(-1, -2))
            historyList.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        histScroll.post { histScroll.fullScroll(View.FOCUS_DOWN) }
    }

    private fun copyResult() {
        if (!justEvaluated && cachedRawResult.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val toCopy = (if (isInfiniteResult && cachedRawResult.isNotEmpty()) cachedRawResult else expression)
            .replace(",", "").replace('−', '-')
        cm.setPrimaryClip(ClipData.newPlainText("result", toCopy))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun pasteIntoExpression() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val sanitized = text.filter { it.isDigit() || it in "+-×÷.%()^!√" }.replace('-', '−')
        if (sanitized.isEmpty()) return
        if (justEvaluated) { expression = ""; justEvaluated = false }
        expression += sanitized
        refresh()
    }

    private fun onPress(key: String) {
        errorText = null
        if (key != "=" && pinResetPending) pinResetPending = false
        when (key) {
            in "0".."9" -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                expression += key
            }
            "." -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                val lastNumber = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!lastNumber.contains('.')) expression += if (lastNumber.isEmpty()) "0." else "."
            }
            "+", "×", "÷", "−" -> {
                justEvaluated = false
                val op = key[0]
                if (expression.isEmpty() || expression.last() == '(') {
                    if (op == '−') expression += "−"
                } else if (expression.last() in operators) {
                    expression = if (expression.length > 1 && expression[expression.length - 2] != '(')
                        expression.dropLast(1) + op
                    else if (op == '−') expression else expression.dropLast(1)
                } else {
                    expression += op
                }
            }
            "%" -> {
                justEvaluated = false
                if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²")) expression += "%"
            }
            "( )" -> {
                justEvaluated = false
                val open = expression.count { it == '(' }
                val close = expression.count { it == ')' }
                val last = expression.lastOrNull()
                val canClose = open > close && last != null && (last.isDigit() || last in ")%²πe!")
                expression += if (canClose) ")" else "("
            }
            "⌫" -> {
                if (justEvaluated) { justEvaluated = false; previousExpression = "" }
                else {
                    val hadOpen = expression.endsWith("(")
                    expression = expression.dropLast(1)
                    if (hadOpen) {
                        for (f in listOf("arcsin", "arccos", "arctan", "asin", "acos", "atan", "sin", "cos", "tan", "ln", "log")) {
                            if (expression.endsWith(f)) { expression = expression.dropLast(f.length); break }
                        }
                    }
                }
            }
            "AC" -> { expression = ""; previousExpression = ""; justEvaluated = false }
            "=" -> {
                if (pinResetPending) {
                    pinResetPending = false
                    VaultManager.resetVault(this)
                    expression = ""
                    justEvaluated = false
                    Toast.makeText(this, "PIN and vault files erased. Type a new PIN, then hold = for 3 seconds.", Toast.LENGTH_LONG).show()
                    refresh()
                    return
                }
                if (changeMode) {
                    if (isValidPin(expression)) {
                        VaultManager.setPin(this, expression)
                        changeMode = false
                        expression = ""
                        justEvaluated = false
                        Toast.makeText(this, "Password changed", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Password must be at least 4 digits", Toast.LENGTH_SHORT).show()
                    }
                    refresh()
                    return
                }
                if (VaultManager.isPinSet(this) && VaultManager.checkPin(this, expression)) {
                    expression = ""
                    justEvaluated = false
                    toggleVault()
                    refresh()
                    return
                }
                if (expression.isNotEmpty() && !justEvaluated) {
                    try {
                        val cleaned = closeParens(trimTrailingOps(expression))
                        val result = Evaluator.formatExpr(cleaned)
                        previousExpression = expression
                        expression = result
                        justEvaluated = true
                        saveHistoryEntry(previousExpression, expression)
                        if (histHeightPx > 0) renderHistory()
                    } catch (e: ArithmeticException) {
                        errorText = e.message ?: "Value too large"
                    } catch (e: Exception) {
                        errorText = "Format error"
                    }
                }
            }
        }
        refresh()
    }

    private fun trimTrailingOps(s: String): String {
        var t = s
        while (t.isNotEmpty() && (t.last() in operators || t.last() == '(')) t = t.dropLast(1)
        return t
    }

    private fun closeParens(s: String): String {
        val missing = s.count { it == '(' } - s.count { it == ')' }
        return if (missing > 0) s + ")".repeat(missing) else s
    }

    private fun group(s: String): String =
        Regex("(\\d+)(\\.\\d*)?").replace(s) { m ->
            val int = m.groupValues[1].reversed().chunked(3).joinToString(",").reversed()
            int + m.groupValues[2]
        }

    private fun availWidthFor(view: TextView): Float {
        val w = when {
            view === topView -> topScroll.width
            view === bottomView -> bottomScroll.width
            else -> view.width
        }
        if (w > 0) return w.toFloat()
        return ((if (contentW > 0) contentW else winW()) - dp(48)).toFloat()
    }

    private fun style(view: TextView, minSp: Int, maxSp: Int, color: Int, sampleText: CharSequence) {
        view.setTextColor(color)
        val compact = histHeightPx > 0 && (view === topView || view === bottomView)
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        var cap = (maxSp * uiScale).toInt()
        if (compact) cap = minOf(cap, (40 * uiScale).toInt())
        if (land && view === topView) cap = minOf(cap, (resources.configuration.screenHeightDp * 0.11f).toInt())
        if (land && view === bottomView) cap = minOf(cap, (resources.configuration.screenHeightDp * 0.11f).toInt())
        cap = minOf(cap, 100)
        val maxSp = cap
        val minSp = minOf(minSp, maxSp)
        val availWidth = availWidthFor(view)
        val paint = Paint(view.paint)
        var chosenSp = minSp
        for (sp in maxSp downTo minSp step 2) {
            paint.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp.toFloat(), resources.displayMetrics)
            if (paint.measureText(sampleText, 0, sampleText.length) <= availWidth) {
                chosenSp = sp
                break
            }
        }
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, chosenSp.toFloat())
    }

    private fun refresh() {
        scroller.forceFinished(true)
        bottomView.removeCallbacks(flingRunnable)
        scrollOffsetPx = 0f
        bottomScroll.scrollTo(0, 0)
        currentPrecision = 120

        topView.gravity = if (justEvaluated) Gravity.END or Gravity.BOTTOM else Gravity.END or Gravity.CENTER_VERTICAL
        if (justEvaluated) {
            val topStr = group(previousExpression) + " ="
            style(topView, 16, 26, pal.icon, topStr)
            topView.text = topStr
            topScroll.post { topScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }

            val cleanedPrev = closeParens(trimTrailingOps(previousExpression))
            activeEvalExpr = cleanedPrev
            isInfiniteResult = cleanedPrev.isNotEmpty() && try { Evaluator.hasInfiniteDecimals(cleanedPrev) } catch (_: Exception) { false }
            cachedRawResult = if (isInfiniteResult) {
                try { Evaluator.evalBig(cleanedPrev, currentPrecision) }
                catch (e: Exception) {
                    errorText = e.message ?: "Value too large"
                    expression
                }
            } else {
                expression
            }
        } else {
            val groupedExpr = group(expression)
            style(topView, 28, 76, pal.text, groupedExpr)
            val sb = SpannableStringBuilder(groupedExpr)
            sb.append("\u200B")
            cursorSpan.visible = true
            sb.setSpan(cursorSpan, sb.length - 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            topView.text = sb
            topScroll.post { topScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }

            preparePreviewState()
        }

        renderBottomResult()
    }

    private fun preparePreviewState() {
        val e = trimTrailingOps(expression)
        if (e.isEmpty() || Regex("^−?[\\d.]+$").matches(e)) {
            isInfiniteResult = false
            activeEvalExpr = ""
            cachedRawResult = ""
            return
        }
        try {
            val cleaned = closeParens(e)
            activeEvalExpr = cleaned
            isInfiniteResult = Evaluator.hasInfiniteDecimals(cleaned)
            cachedRawResult = if (isInfiniteResult) {
                Evaluator.evalBig(cleaned, currentPrecision)
            } else {
                Evaluator.formatExpr(cleaned)
            }
        } catch (ex: Exception) {
            isInfiniteResult = false
            cachedRawResult = ""
        }
    }

    private fun renderBottomResult() {
        if (changeMode) {
            val msg = "Enter new password, press ="
            style(bottomView, 16, 26, pal.result, msg)
            bottomView.text = msg
            return
        }
        val minSp = if (justEvaluated) 28 else 16
        val maxSp = if (justEvaluated) 64 else 26
        val mainColor = if (justEvaluated) pal.text else pal.result

        if (errorText != null) {
            style(bottomView, minSp, maxSp, pal.clearFg, errorText!!)
            bottomView.text = errorText
            return
        }

        if (!isInfiniteResult || !cachedRawResult.contains('.')) {
            val grouped = group(cachedRawResult)
            style(bottomView, minSp, maxSp, mainColor, grouped)
            bottomView.text = grouped
            return
        }

        bottomView.setTextColor(mainColor)
        bottomView.setTextSize(TypedValue.COMPLEX_UNIT_SP, minSp.toFloat())

        val availWidth = availWidthFor(bottomView)
        val paint = bottomView.paint
        val digitWidth = paint.measureText("0").coerceAtLeast(1f)
        val charOffset = (scrollOffsetPx / digitWidth).toInt()

        val dotIdx = cachedRawResult.indexOf('.')
        val intPartGrouped = group(cachedRawResult.substring(0, dotIdx)) + "."
        var frac = cachedRawResult.substring(dotIdx + 1)

        if (charOffset <= 0) {
            var count = 1
            while (count < frac.length && paint.measureText(intPartGrouped + frac.substring(0, count + 1)) <= availWidth) {
                count++
            }
            bottomView.text = intPartGrouped + frac.substring(0, count)
            return
        }

        val sampleOverhead = paint.measureText("...E-100")
        val baseVisibleDigits = ((availWidth - sampleOverhead) / digitWidth).toInt().coerceAtLeast(6)
        val endIdx = baseVisibleDigits + charOffset

        if (endIdx + 35 > frac.length && currentPrecision < 1200) {
            currentPrecision = (endIdx + 120).coerceAtMost(1200)
            try {
                cachedRawResult = Evaluator.evalBig(activeEvalExpr, currentPrecision)
                val newDot = cachedRawResult.indexOf('.')
                if (newDot != -1) frac = cachedRawResult.substring(newDot + 1)
            } catch (_: Exception) {}
        }

        val clampedEnd = endIdx.coerceAtMost(frac.length)
        val prefix = "..."
        val suffix = "E-$clampedEnd"
        val remainingForDigits = availWidth - paint.measureText(prefix) - paint.measureText(suffix)

        var startIdx = clampedEnd - 1
        while (startIdx > 0 && paint.measureText(frac, startIdx - 1, clampedEnd) <= remainingForDigits) {
            startIdx--
        }

        val visibleDigits = frac.substring(startIdx.coerceAtLeast(0), clampedEnd)
        val sb = SpannableStringBuilder()
        sb.append(prefix)
        sb.append(visibleDigits)
        val expStart = sb.length
        sb.append(suffix)
        sb.setSpan(ForegroundColorSpan(pal.icon), expStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        bottomView.text = sb
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (resizing) exitResize()
        else if (historyVisible) toggleHistory()
        else if (vaultVisible && fabMenuOpen) setFabMenu(false)
        else if (vaultVisible && selected.isNotEmpty()) clearSelection()
        else if (vaultVisible) {
            if (currentFolder != null) {
                currentFolder = null
                renderVaultFiles()
            } else {
                toggleVault()
            }
        }
        else super.onBackPressed()
    }
}
