package com.android.calcognito

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat

/**
 * Keeps the process alive while [TransferManager] has work, so adding or unhiding big files carries on after the
 * app is closed. It does no work itself.
 *
 * The notification is intentionally bland ("Calculator - Working..."): no mention of the vault, no file names,
 * hidden on the lock screen. Change [WORKING_TEXT] / [DONE_TEXT] if you want different wording.
 */
class TransferService : Service() {

    companion object {
        private const val CHANNEL_ID = "background_tasks"
        private const val NOTIF_ID = 4101
        private const val DONE_ID = 4102
        private const val WORKING_TEXT = "Working…"
        private const val DONE_TEXT = "Done"
        const val ACTION_CANCEL = "com.android.calcognito.action.CANCEL_TRANSFERS"

        @Volatile private var instance: TransferService? = null

        /** Progress changed (main thread). */
        fun refresh() {
            instance?.updateNotification()
        }

        /** The last job ended (main thread). If the service hasn't started yet, onStartCommand sees the idle state. */
        fun stopWhenIdle() {
            instance?.stopSelf()
        }

        /** A transfer finished while the app was closed. */
        fun notifyDone(context: Context) {
            try {
                ensureChannel(context)
                val n = NotificationCompat.Builder(context, CHANNEL_ID)
                    .setSmallIcon(R.drawable.ic_stat_transfer)
                    .setContentTitle(context.getString(R.string.app_name))
                    .setContentText(DONE_TEXT)
                    .setAutoCancel(true)
                    .setTimeoutAfter(60_000L)
                    .setVisibility(NotificationCompat.VISIBILITY_SECRET)
                    .setContentIntent(openAppIntent(context))
                    .build()
                context.getSystemService(NotificationManager::class.java).notify(DONE_ID, n)
            } catch (_: Exception) {
                // No notification permission or similar: the transfer is done either way.
            }
        }

        private fun ensureChannel(context: Context) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
            val nm = context.getSystemService(NotificationManager::class.java)
            if (nm.getNotificationChannel(CHANNEL_ID) != null) return
            val ch = NotificationChannel(CHANNEL_ID, "Background tasks", NotificationManager.IMPORTANCE_LOW).apply {
                setShowBadge(false)
                lockscreenVisibility = Notification.VISIBILITY_SECRET
            }
            nm.createNotificationChannel(ch)
        }

        /** Opens the app the way the launcher does (resumes the existing task). */
        private fun openAppIntent(context: Context): PendingIntent {
            val i = Intent(Intent.ACTION_MAIN)
                .addCategory(Intent.CATEGORY_LAUNCHER)
                .setClass(context, MainActivity::class.java)
                .setFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
            return PendingIntent.getActivity(context, 0, i, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        }
    }

    private var lastNotify = 0L

    override fun onCreate() {
        super.onCreate()
        instance = this
        ensureChannel(this)
        promote()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_CANCEL) TransferManager.cancelAll()
        if (!TransferManager.isBusy()) {
            stopSelf(startId)
            return START_NOT_STICKY
        }
        promote()
        // If the system kills the process there is nothing to resume (the work lives in memory); unfinished
        // copies leave only hidden ".part" files that are cleaned up on the next launch.
        return START_NOT_STICKY
    }

    /** Android 15+ limits how long a data-sync service may run; stop cleanly instead of being crashed. */
    override fun onTimeout(startId: Int, fgsType: Int) {
        TransferManager.cancelAll()
        stopSelf()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    private fun promote() {
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } catch (_: Exception) {
            // Not allowed to run in the foreground right now; give up the service (the work carries on in-process).
            stopSelf()
        }
    }

    private fun updateNotification() {
        val now = SystemClock.uptimeMillis()
        if (now - lastNotify < 800L) return
        lastNotify = now
        try {
            getSystemService(NotificationManager::class.java).notify(NOTIF_ID, buildNotification())
        } catch (_: Exception) {
        }
    }

    private fun buildNotification(): Notification {
        val pct = TransferManager.currentPercent()
        val cancel = PendingIntent.getService(
            this, 1,
            Intent(this, TransferService::class.java).setAction(ACTION_CANCEL),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_stat_transfer)
            .setContentTitle(getString(R.string.app_name))
            .setContentText(if (pct >= 0) "$WORKING_TEXT $pct%" else WORKING_TEXT)
            .setProgress(100, pct.coerceAtLeast(0), pct < 0)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setVisibility(NotificationCompat.VISIBILITY_SECRET)
            .setContentIntent(openAppIntent(this))
            .addAction(0, "Cancel", cancel)
            .build()
    }
}
