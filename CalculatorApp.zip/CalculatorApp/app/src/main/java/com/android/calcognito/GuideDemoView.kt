package com.android.calcognito

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.View
import androidx.core.graphics.ColorUtils
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min

/** Colours for the guide demo; all of them come from the app's (dynamic) palette. */
class GuideColors(
    val bg: Int,
    val stage: Int,
    val text: Int,
    val subtle: Int,
    val numBg: Int, val numFg: Int,
    val opBg: Int, val opFg: Int,
    val acBg: Int, val acFg: Int,
    val eqBg: Int, val eqFg: Int,
    val primary: Int,
    val outline: Int
)

/**
 * A looping, self-running demo of how to set the vault password:
 * type 1234 -> hold = for 3 s (password set) -> type 1234 again -> press = -> the vault opens.
 * Everything is drawn on a Canvas from a single timeline, so it never needs a video or Lottie file.
 */
class GuideDemoView(
    ctx: Context,
    private val c: GuideColors,
    private val keyFont: Typeface,
    private val displayFont: Typeface,
    private val opFont: Typeface
) : View(ctx) {

    /** Called (on the UI thread) whenever the demo moves to another step (0..3). */
    var onStepChanged: ((Int) -> Unit)? = null

    companion object {
        const val TOTAL = 15600L
        const val HOLD_MS = 3000L
        /** Where each of the 4 caption steps begins on the timeline. */
        val STEP_STARTS = longArrayOf(0L, 3400L, 8700L, 11700L)
        private const val ASPECT = 0.46f
        private val LABELS = arrayOf(
            arrayOf("AC", "( )", "%", "÷"),
            arrayOf("7", "8", "9", "×"),
            arrayOf("4", "5", "6", "−"),
            arrayOf("1", "2", "3", "+"),
            arrayOf("0", ".", "⌫", "=")
        )
        private val LIGHT_GLYPHS = setOf("÷", "×", "−", "+", "%", "( )")
        private val OPS = setOf("÷", "×", "−", "+", "%", "( )")
        private val BIG_GLYPHS = setOf("=", "÷", "×", "−", "+")
    }

    // ---- timeline -----------------------------------------------------------------------------

    private class Act(val key: String, val arrive: Long, val down: Long, val up: Long) {
        var moveStart = 0L
    }

    private fun tap(key: String, arrive: Long) = Act(key, arrive, arrive + 60, arrive + 230)

    private val acts: List<Act> = listOf(
        tap("1", 900), tap("2", 1500), tap("3", 2100), tap("4", 2700),
        Act("=", 4000, 4070, 4070 + HOLD_MS),                       // the 3 second hold
        tap("1", 9300), tap("2", 9900), tap("3", 10500), tap("4", 11100),
        tap("=", 11700)                                              // unlock
    )
    private val holdAct: Act = acts[4]
    private val unlockAct: Act = acts[9]

    init {
        for (i in acts.indices) {
            val a = acts[i]
            a.moveStart = if (i == 0) a.arrive - 600L
            else a.arrive - min(450L, a.arrive - acts[i - 1].up)
        }
        contentDescription = "Animated guide: type 1234, hold the equals key for 3 seconds to set " +
            "your password, then type 1234 again and press equals to open the secure vault."
    }

    private var running = false
    private var startUptime = 0L
    private var now = 0L
    private var lastStep = -1

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            now = (SystemClock.uptimeMillis() - startUptime) % TOTAL
            val s = stepAt(now)
            if (s != lastStep) {
                lastStep = s
                onStepChanged?.invoke(s)
            }
            invalidate()
            postOnAnimation(this)
        }
    }

    fun start() {
        if (running) return
        running = true
        startUptime = SystemClock.uptimeMillis() - now
        postOnAnimation(ticker)
    }

    fun stop() {
        running = false
        removeCallbacks(ticker)
    }

    /** Jump to the beginning of a caption step (used by the page dots). */
    fun seekToStep(step: Int) {
        now = STEP_STARTS[step.coerceIn(0, STEP_STARTS.size - 1)]
        startUptime = SystemClock.uptimeMillis() - now
        lastStep = -1
        invalidate()
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    private fun stepAt(t: Long): Int {
        var s = 0
        for (i in STEP_STARTS.indices) if (t >= STEP_STARTS[i]) s = i
        return s
    }

    /** What is typed into the mock calculator at time [t]. */
    private fun expressionAt(t: Long): String {
        val sb = StringBuilder()
        if (t < holdAct.up) {
            for (i in 0..3) if (t >= acts[i].down) sb.append(acts[i].key)
            return sb.toString()
        }
        if (t >= unlockAct.down) return ""
        for (i in 5..8) if (t >= acts[i].down) sb.append(acts[i].key)
        return sb.toString()
    }

    // ---- geometry -----------------------------------------------------------------------------

    private val stageRect = RectF()
    private val phoneRect = RectF()
    private val screenRect = RectF()
    private val tmpRect = RectF()
    private val stagePath = Path()
    private val phonePath = Path()
    private val screenPath = Path()
    private val keyRects = Array(5) { Array(4) { RectF() } }
    private var sw = 0f
    private var sh = 0f
    private var keypadTop = 0f
    private var handSize = 0f

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        stageRect.set(0f, 0f, fw, fh)
        stagePath.reset()
        stagePath.addRoundRect(stageRect, dp(28f), dp(28f), Path.Direction.CW)

        val pad = dp(14f)
        var ph = fh - 2f * pad
        var pw = ph * ASPECT
        if (pw > fw - 2f * pad) {
            pw = fw - 2f * pad
            ph = pw / ASPECT
        }
        if (pw < 1f || ph < 1f) { sw = 0f; return }
        val cx = fw / 2f
        val cy = fh / 2f
        phoneRect.set(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f)
        val bezel = max(dp(3f), pw * 0.022f)
        screenRect.set(phoneRect.left + bezel, phoneRect.top + bezel, phoneRect.right - bezel, phoneRect.bottom - bezel)
        val outerR = pw * 0.12f
        phonePath.reset()
        phonePath.addRoundRect(phoneRect, outerR, outerR, Path.Direction.CW)
        screenPath.reset()
        screenPath.addRoundRect(screenRect, outerR - bezel, outerR - bezel, Path.Direction.CW)

        sw = screenRect.width()
        sh = screenRect.height()
        val kl = screenRect.left + sw * 0.03f
        val kr = screenRect.right - sw * 0.03f
        keypadTop = screenRect.top + sh * 0.42f
        val kb = screenRect.bottom - sh * 0.025f
        val cw = (kr - kl) / 4f
        val ch = (kb - keypadTop) / 5f
        val gap = min(cw, ch) * 0.045f
        for (r in 0 until 5) for (col in 0 until 4) {
            keyRects[r][col].set(
                kl + col * cw + gap, keypadTop + r * ch + gap,
                kl + (col + 1) * cw - gap, keypadTop + (r + 1) * ch - gap
            )
        }
        handSize = sw * 0.5f
    }

    private fun keyRectOf(label: String): RectF {
        for (r in 0 until 5) for (col in 0 until 4) if (LABELS[r][col] == label) return keyRects[r][col]
        return keyRects[0][0]
    }

    // ---- drawing helpers ----------------------------------------------------------------------

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun icon(res: Int): Drawable = context.getDrawable(res)!!.mutate()

    private val dHistory = icon(R.drawable.ic_history)
    private val dMore = icon(R.drawable.ic_more_vert)
    private val dExpand = icon(R.drawable.ic_unfold_more)
    private val dBackspace = icon(R.drawable.ic_backspace)
    private val dImage = icon(R.drawable.ic_image)
    private val dPlay = icon(R.drawable.ic_play)
    private val dFile = icon(R.drawable.ic_file)
    private val dAdd = icon(R.drawable.ic_add)
    private val dInfo = icon(R.drawable.ic_info)
    private val dHand = icon(R.drawable.ic_hand)
    private val dHandOutline = icon(R.drawable.ic_hand_outline)

    private fun drawIcon(canvas: Canvas, d: Drawable, cx: Float, cy: Float, size: Float, color: Int, alpha: Int = 255) {
        val half = size / 2f
        d.setBounds(Math.round(cx - half), Math.round(cy - half), Math.round(cx + half), Math.round(cy + half))
        d.setTint(color)
        d.alpha = alpha
        d.draw(canvas)
    }

    private fun text(canvas: Canvas, s: String, x: Float, baseline: Float, size: Float, color: Int, tf: Typeface, align: Paint.Align) {
        tp.typeface = tf
        tp.textSize = size
        tp.color = color
        tp.textAlign = align
        canvas.drawText(s, x, baseline, tp)
    }

    private fun textC(canvas: Canvas, s: String, cx: Float, cy: Float, size: Float, color: Int, tf: Typeface) {
        tp.typeface = tf
        tp.textSize = size
        tp.color = color
        tp.textAlign = Paint.Align.CENTER
        val fm = tp.fontMetrics
        canvas.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, tp)
    }

    private fun measure(s: String, size: Float, tf: Typeface): Float {
        tp.typeface = tf
        tp.textSize = size
        return tp.measureText(s)
    }

    private fun smooth(f: Float): Float {
        val x = f.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    private fun decel(f: Float): Float {
        val x = 1f - f.coerceIn(0f, 1f)
        return 1f - x * x * x
    }

    private fun accel(f: Float): Float {
        val x = f.coerceIn(0f, 1f)
        return x * x * x
    }

    // ---- press state --------------------------------------------------------------------------

    private var pressLabel: String? = null
    private var pressP = 0f

    private fun computePress(t: Long) {
        pressLabel = null
        pressP = 0f
        for (a in acts) {
            if (t >= a.down && t <= a.up + 140L) {
                pressLabel = a.key
                pressP = if (t < a.up) min(1f, (t - a.down) / 50f) else 1f - (t - a.up) / 140f
                return
            }
        }
    }

    // ---- main draw ----------------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        if (sw <= 0f) return
        val t = now
        computePress(t)

        canvas.save()
        canvas.clipPath(stagePath)

        // Stage + soft tonal blobs
        fill.color = c.stage
        canvas.drawPath(stagePath, fill)
        val m = min(stageRect.width(), stageRect.height())
        fill.color = ColorUtils.setAlphaComponent(c.acBg, 110)
        canvas.drawCircle(stageRect.left + stageRect.width() * 0.08f, stageRect.top + stageRect.height() * 0.16f, m * 0.36f, fill)
        fill.color = ColorUtils.setAlphaComponent(c.eqBg, 60)
        canvas.drawCircle(stageRect.right - stageRect.width() * 0.04f, stageRect.bottom - stageRect.height() * 0.10f, m * 0.40f, fill)

        // Phone body
        fill.color = c.outline
        canvas.drawPath(phonePath, fill)
        canvas.save()
        canvas.clipPath(screenPath)
        fill.color = c.bg
        canvas.drawRect(screenRect, fill)
        drawTopBar(canvas)
        drawDisplay(canvas, t)
        drawKeys(canvas)
        drawHoldRing(canvas, t)
        drawHoldPill(canvas, t)
        drawVault(canvas, t)
        drawToast(canvas, t)
        canvas.restore()

        drawHand(canvas, t)
        canvas.restore()
    }

    private fun drawTopBar(canvas: Canvas) {
        val y = screenRect.top + sh * 0.075f
        drawIcon(canvas, dHistory, screenRect.left + sw * 0.11f, y, sw * 0.1f, c.subtle)
        drawIcon(canvas, dMore, screenRect.right - sw * 0.11f, y, sw * 0.1f, c.subtle)
    }

    private fun drawDisplay(canvas: Canvas, t: Long) {
        val expr = expressionAt(t)
        val right = screenRect.right - sw * 0.075f
        val size = sw * 0.2f
        val baseline = screenRect.top + sh * 0.25f + size * 0.35f
        val cursorW = max(dp(2f), sw * 0.012f)
        val cursorGap = sw * 0.02f
        if (expr.isNotEmpty()) {
            text(canvas, expr, right - cursorW - cursorGap, baseline, size, c.text, keyFont, Paint.Align.RIGHT)
        }
        if ((t / 530L) % 2L == 0L) {
            fill.color = c.primary
            val cy = screenRect.top + sh * 0.25f
            tmpRect.set(right - cursorW, cy - size * 0.46f, right, cy + size * 0.46f)
            canvas.drawRoundRect(tmpRect, cursorW / 2f, cursorW / 2f, fill)
        }
        drawIcon(canvas, dExpand, screenRect.left + sw * 0.11f, keypadTop - sh * 0.045f, sw * 0.1f, c.subtle)
    }

    private fun drawKeys(canvas: Canvas) {
        for (r in 0 until 5) for (col in 0 until 4) {
            val label = LABELS[r][col]
            val rect = keyRects[r][col]
            val bg: Int
            val fg: Int
            when {
                label == "=" -> { bg = c.eqBg; fg = c.eqFg }
                label == "AC" -> { bg = c.acBg; fg = c.acFg }
                label in OPS -> { bg = c.opBg; fg = c.opFg }
                else -> { bg = c.numBg; fg = c.numFg }
            }
            val p = if (label == pressLabel) pressP else 0f
            val cx = rect.centerX()
            val cy = rect.centerY()
            val cell = min(rect.width(), rect.height())
            val sc = 1f - 0.07f * p
            canvas.save()
            canvas.scale(sc, sc, cx, cy)
            fill.color = bg
            canvas.drawRoundRect(rect, cell / 2f, cell / 2f, fill)
            if (p > 0f) {
                fill.color = ColorUtils.setAlphaComponent(fg, (46 * p).toInt())
                canvas.drawRoundRect(rect, cell / 2f, cell / 2f, fill)
            }
            if (label == "⌫") {
                drawIcon(canvas, dBackspace, cx, cy, cell * 0.46f, fg)
            } else {
                val size = when {
                    label == "AC" -> cell * 0.36f
                    label in BIG_GLYPHS -> cell * 0.52f
                    label == "( )" -> cell * 0.40f
                    else -> cell * 0.44f
                }
                val tf = when {
                    label == "=" -> opFont
                    label in LIGHT_GLYPHS -> displayFont
                    else -> keyFont
                }
                textC(canvas, label, cx, cy, size, fg, tf)
            }
            canvas.restore()
        }
    }

    /** Ring that fills around the = key during the 3 second hold. */
    private fun drawHoldRing(canvas: Canvas, t: Long) {
        if (t < holdAct.down || t > holdAct.up) return
        val rect = keyRectOf("=")
        val cx = rect.centerX()
        val cy = rect.centerY()
        val r = min(rect.width(), rect.height()) / 2f + dp(4f)
        stroke.strokeWidth = max(dp(2.5f), sw * 0.018f)
        stroke.color = ColorUtils.setAlphaComponent(c.primary, 70)
        canvas.drawCircle(cx, cy, r, stroke)
        stroke.color = c.primary
        val prog = ((t - holdAct.down).toFloat() / HOLD_MS).coerceIn(0f, 1f)
        tmpRect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(tmpRect, -90f, 360f * prog, false, stroke)
    }

    /** "Hold 3s / 2s / 1s" label above the keypad. */
    private fun drawHoldPill(canvas: Canvas, t: Long) {
        if (t < holdAct.down || t > holdAct.up) return
        val remaining = ceil((holdAct.up - t) / 1000.0).toInt().coerceIn(1, 3)
        val label = "Keep holding  ${remaining}s"
        val size = sw * 0.07f
        val tw = measure(label, size, keyFont)
        val h = size * 2.1f
        val w = tw + size * 1.8f
        val cx = screenRect.centerX()
        val cy = keypadTop - sh * 0.05f
        fill.color = c.eqBg
        tmpRect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        canvas.drawRoundRect(tmpRect, h / 2f, h / 2f, fill)
        textC(canvas, label, cx, cy, size, c.eqFg, keyFont)
    }

    /** The "Password set" toast that appears when the hold completes. */
    private fun drawToast(canvas: Canvas, t: Long) {
        val start = holdAct.up
        val end = start + 1530L
        if (t < start || t > end) return
        val a = when {
            t < start + 150L -> (t - start) / 150f
            t > end - 250L -> (end - t) / 250f
            else -> 1f
        }.coerceIn(0f, 1f)
        val size = sw * 0.066f
        val tw = measure("Password set", size, keyFont)
        val h = size * 2.3f
        val w = tw + size * 2.4f
        val cx = screenRect.centerX()
        val cy = screenRect.bottom - sh * 0.07f + (1f - a) * dp(8f)
        fill.color = ColorUtils.setAlphaComponent(c.text, (255 * a).toInt())
        tmpRect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        canvas.drawRoundRect(tmpRect, h / 2f, h / 2f, fill)
        textC(canvas, "Password set", cx, cy, size, ColorUtils.setAlphaComponent(c.bg, (255 * a).toInt()), keyFont)
    }

    // ---- vault --------------------------------------------------------------------------------

    private val openStart get() = unlockAct.down + 40L

    private fun vaultProgress(t: Long): Float {
        val openEnd = openStart + 480L
        val closeStart = 14800L
        val closeEnd = 15250L
        return when {
            t < openStart -> 0f
            t < openEnd -> decel((t - openStart) / 480f)
            t < closeStart -> 1f
            t < closeEnd -> 1f - accel((t - closeStart) / 450f)
            else -> 0f
        }
    }

    private fun drawVault(canvas: Canvas, t: Long) {
        val v = vaultProgress(t)
        if (v <= 0f) return
        canvas.save()
        canvas.translate(0f, (1f - v) * sh)

        val l = screenRect.left
        val top = screenRect.top
        val r = screenRect.right
        val b = screenRect.bottom
        val cornerR = sw * 0.09f
        tmpRect.set(l, top, r, b + cornerR)
        fill.color = c.stage
        canvas.drawRoundRect(tmpRect, cornerR, cornerR, fill)
        stroke.strokeWidth = dp(1f)
        stroke.color = ColorUtils.setAlphaComponent(c.outline, 160)
        canvas.drawRoundRect(tmpRect, cornerR, cornerR, stroke)

        // Header: "Secure Vault" ... Close  (i)
        val titleSize = sw * 0.07f
        text(canvas, "Secure Vault", l + sw * 0.06f, top + sh * 0.09f + titleSize * 0.35f, titleSize, c.text, keyFont, Paint.Align.LEFT)
        drawIcon(canvas, dInfo, r - sw * 0.085f, top + sh * 0.09f, sw * 0.09f, c.subtle)
        text(canvas, "Close", r - sw * 0.16f, top + sh * 0.09f + sw * 0.016f, sw * 0.048f, c.primary, keyFont, Paint.Align.RIGHT)

        // Filter chips
        val chipsY = top + sh * 0.165f
        val chipH = sw * 0.1f
        val chipText = sw * 0.045f
        var x = l + sw * 0.06f
        val chips = arrayOf("All", "Photos", "Videos")
        for (i in chips.indices) {
            val cw = measure(chips[i], chipText, keyFont) + chipText * 1.8f
            tmpRect.set(x, chipsY - chipH / 2f, x + cw, chipsY + chipH / 2f)
            if (i == 0) {
                fill.color = c.acBg
                canvas.drawRoundRect(tmpRect, chipH * 0.3f, chipH * 0.3f, fill)
            } else {
                stroke.strokeWidth = dp(1f)
                stroke.color = c.outline
                canvas.drawRoundRect(tmpRect, chipH * 0.3f, chipH * 0.3f, stroke)
            }
            textC(canvas, chips[i], tmpRect.centerX(), chipsY, chipText, if (i == 0) c.acFg else c.text, keyFont)
            x += cw + sw * 0.025f
        }

        // File tiles (they pop in one after another)
        val gap = sw * 0.025f
        val side = sw * 0.06f
        val tile = (sw - 2f * side - 2f * gap) / 3f
        val gridTop = top + sh * 0.225f
        val tileBgs = intArrayOf(c.numBg, c.opBg, c.acBg, c.opBg, c.eqBg, c.numBg)
        val tileFgs = intArrayOf(c.numFg, c.opFg, c.acFg, c.opFg, c.eqFg, c.numFg)
        for (i in 0 until 12) {
            val row = i / 3
            val col = i % 3
            val p = decel(((t - (openStart + 250L + i * 45L)) / 220f))
            if (p <= 0f) continue
            val tx = l + side + col * (tile + gap)
            val ty = gridTop + row * (tile + gap)
            val cx = tx + tile / 2f
            val cy = ty + tile / 2f
            val k = (i * 5 + row) % tileBgs.size
            canvas.save()
            val sc = 0.8f + 0.2f * p
            canvas.scale(sc, sc, cx, cy)
            fill.color = ColorUtils.setAlphaComponent(tileBgs[k], (255 * p).toInt())
            tmpRect.set(tx, ty, tx + tile, ty + tile)
            canvas.drawRoundRect(tmpRect, tile * 0.2f, tile * 0.2f, fill)
            val d = when (i % 3) { 0 -> dImage; 1 -> dPlay; else -> dFile }
            drawIcon(canvas, d, cx, cy, tile * 0.42f, tileFgs[k], (255 * p).toInt())
            canvas.restore()
        }

        // Add button
        val fp = decel((t - (openStart + 300L)) / 260f)
        if (fp > 0f) {
            val fs = sw * 0.19f
            val fx = r - sw * 0.06f - fs / 2f
            val fy = b - sh * 0.045f - fs / 2f
            canvas.save()
            canvas.scale(fp, fp, fx, fy)
            fill.color = c.acBg
            tmpRect.set(fx - fs / 2f, fy - fs / 2f, fx + fs / 2f, fy + fs / 2f)
            canvas.drawRoundRect(tmpRect, fs * 0.3f, fs * 0.3f, fill)
            drawIcon(canvas, dAdd, fx, fy, fs * 0.5f, c.acFg)
            canvas.restore()
        }
        canvas.restore()
    }

    // ---- hand ---------------------------------------------------------------------------------

    private fun drawHand(canvas: Canvas, t: Long) {
        val first = acts[0]
        val last = acts[acts.size - 1]
        if (t < first.moveStart) return
        val exitStart = last.up + 120L
        if (t > exitStart + 500L) return

        // The hand starts and ends just below the stage.
        val offX = phoneRect.right - sw * 0.1f
        val offY = stageRect.bottom + handSize * 0.1f

        var idx = 0
        for (i in acts.indices.reversed()) {
            if (t >= acts[i].moveStart) { idx = i; break }
        }
        val a = acts[idx]
        val tr = keyRectOf(a.key)
        val tx = tr.centerX()
        val ty = tr.centerY()
        val px: Float
        val py: Float
        if (idx == 0) {
            px = offX; py = offY
        } else {
            val pr = keyRectOf(acts[idx - 1].key)
            px = pr.centerX(); py = pr.centerY()
        }
        var hx = tx
        var hy = ty
        if (t < a.arrive) {
            val f = smooth((t - a.moveStart).toFloat() / (a.arrive - a.moveStart).toFloat())
            hx = px + (tx - px) * f
            hy = py + (ty - py) * f
        }
        var alpha = 1f
        if (idx == 0) alpha = ((t - a.moveStart) / 300f).coerceIn(0f, 1f)
        if (t > exitStart) {
            val e = ((t - exitStart) / 500f).coerceIn(0f, 1f)
            val f = smooth(e)
            hx += (offX - hx) * f
            hy += (offY - hy) * f
            alpha = 1f - e
        }

        // Touch indicator under the fingertip while pressing
        if (pressP > 0f) {
            fill.color = ColorUtils.setAlphaComponent(c.text, (70 * pressP * alpha).toInt())
            canvas.drawCircle(hx, hy, handSize * 0.12f, fill)
        }

        val u = handSize / 28f
        val left = hx - 13.5f * u
        val topY = hy - 8.2f * u
        val sc = 1f - 0.06f * pressP
        canvas.save()
        canvas.scale(sc, sc, hx, hy)
        val bounds = intArrayOf(Math.round(left), Math.round(topY), Math.round(left + handSize), Math.round(topY + handSize))
        val a255 = (255 * alpha).toInt()
        dHandOutline.setBounds(bounds[0], bounds[1], bounds[2], bounds[3])
        dHandOutline.setTint(c.bg)
        dHandOutline.alpha = a255
        dHandOutline.draw(canvas)
        dHand.setBounds(bounds[0], bounds[1], bounds[2], bounds[3])
        dHand.setTint(c.text)
        dHand.alpha = a255
        dHand.draw(canvas)
        canvas.restore()
    }
}
