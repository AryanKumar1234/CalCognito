package com.android.calcognito

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.content.res.ColorStateList
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Colours for [PixelProgressDialog]; all taken from the app's (dynamic) palette. */
class ProgressColors(
    val card: Int,
    val text: Int,
    val subtext: Int,
    val active: Int,
    val track: Int,
    val tickFill: Int,
    val tickFg: Int,
    val ripple: Int = 0x33000000
)

/**
 * Compact Pixel / Quick Share style progress card: a circular indicator beside a title and a small
 * status line. On success the ring morphs into a tick and the card fades away by itself.
 *
 * With [showButtons] the card also has "Cancel" and "Hide" buttons (used for transfers that keep running in the
 * background): Cancel calls [onCancel], Hide and the back button close the card and call [onHide].
 *
 * Everything must be called on the UI thread. The dialog can be shown after a delay, so quick
 * operations never flash a dialog; [wasShown] tells you whether the person actually saw it.
 */
class PixelProgressDialog(
    private val activity: Activity,
    private val c: ProgressColors,
    private val wavy: Boolean
) {
    private val handler = Handler(Looper.getMainLooper())
    private var dialog: Dialog? = null
    private var ring: ProgressRingView? = null
    private var titleView: TextView? = null
    private var subView: TextView? = null
    private var buttonRow: LinearLayout? = null
    private var buttonsVisible = true

    private var title = ""
    private var sub = ""
    private var progress = -1f
    private var closed = false
    private var pending: Runnable? = null

    /** Lets the person back out (back button). Set before [show]. */
    var cancelable = false
    var onCancel: (() -> Unit)? = null

    /** Adds "Cancel" and "Hide" buttons. Set before [show]. */
    var showButtons = false
    var onHide: (() -> Unit)? = null

    var wasShown = false
        private set

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    /** Show now, or after [delayMs] if the work is still running by then. */
    fun show(delayMs: Long = 0L) {
        if (closed) return
        if (delayMs <= 0L) {
            reallyShow()
            return
        }
        val r = Runnable {
            pending = null
            reallyShow()
        }
        pending = r
        handler.postDelayed(r, delayMs)
    }

    /** Any argument left null keeps its previous value. [progress] < 0 means "unknown" (spinning). */
    fun update(title: String? = null, sub: String? = null, progress: Float? = null) {
        if (title != null) this.title = title
        if (sub != null) this.sub = sub
        if (progress != null) this.progress = progress
        applyState()
    }

    /** Shows or hides the Cancel / Hide buttons (e.g. while a cancel is being carried out). */
    fun setButtonsVisible(visible: Boolean) {
        buttonsVisible = visible
        applyState()
    }

    private fun applyState() {
        buttonRow?.visibility = if (buttonsVisible) View.VISIBLE else View.INVISIBLE
        titleView?.text = title
        subView?.let {
            it.text = sub
            it.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        }
        ring?.setProgress(progress)
    }

    private fun reallyShow() {
        if (closed || dialog != null) return
        if (activity.isFinishing || activity.isDestroyed) return
        val d = Dialog(activity)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        d.setCancelable(cancelable || showButtons)
        d.setCanceledOnTouchOutside(false)

        val root = LinearLayout(activity).apply {
            orientation = LinearLayout.VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(c.card)
            }
            setPadding(dp(24), dp(22), dp(24), if (showButtons) dp(12) else dp(22))
        }
        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        root.addView(card, LinearLayout.LayoutParams(-1, -2))
        val r = ProgressRingView(activity, wavy, c.active, c.track, c.tickFill, c.tickFg)
        ring = r
        card.addView(r, LinearLayout.LayoutParams(dp(48), dp(48)))

        val col = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val t = TextView(activity).apply {
            setTextColor(c.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val s = TextView(activity).apply {
            setTextColor(c.subtext)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        titleView = t
        subView = s
        col.addView(t, LinearLayout.LayoutParams(-1, -2))
        col.addView(s, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        card.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(20) })

        if (showButtons) {
            val row = LinearLayout(activity).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
            }
            row.addView(textButton("Cancel") { onCancel?.invoke() })
            row.addView(textButton("Hide") {
                dismiss()
                onHide?.invoke()
            })
            buttonRow = row
            root.addView(row, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        }

        d.setContentView(root)
        val screenW = activity.resources.displayMetrics.widthPixels
        d.window?.setLayout(minOf(screenW - dp(66), dp(360)), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.setOnCancelListener {
            closed = true
            dialog = null
            r.stop()
            // With buttons, back means Hide (the work keeps going); without them it cancels, as before.
            if (showButtons) onHide?.invoke() else onCancel?.invoke()
        }
        d.setOnDismissListener { r.stop() }
        dialog = d
        wasShown = true
        applyState()
        d.show()
    }

    private fun textButton(label: String, action: () -> Unit): TextView = TextView(activity).apply {
        text = label
        setTextColor(c.active)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        gravity = Gravity.CENTER
        setPadding(dp(12), dp(10), dp(12), dp(10))
        minWidth = dp(64)
        val mask = GradientDrawable().apply { cornerRadius = dp(20).toFloat(); setColor(Color.BLACK) }
        background = RippleDrawable(ColorStateList.valueOf(c.ripple), null, mask)
        setOnClickListener { action() }
    }

    /**
     * Completes the operation: ring fills, turns into a tick, the card fades out by itself, then [onEnd] runs.
     * If the dialog was never shown (the work was quick), [onEnd] runs right away.
     */
    fun finishSuccess(onEnd: () -> Unit) {
        cancelPending()
        val r = ring
        val d = dialog
        if (closed || d == null || r == null) {
            dismiss()
            onEnd()
            return
        }
        buttonRow?.visibility = View.INVISIBLE
        var ended = false
        val finishNow = Runnable {
            if (ended) return@Runnable
            ended = true
            fadeOutThen(onEnd)
        }
        r.finish { finishNow.run() }
        handler.postDelayed(finishNow, 2600L)
    }

    private fun fadeOutThen(after: () -> Unit) {
        val v = dialog?.window?.decorView
        if (v == null) {
            dismiss()
            after()
            return
        }
        v.animate().alpha(0f).setDuration(160L).withEndAction {
            dismiss()
            after()
        }.start()
    }

    private fun cancelPending() {
        pending?.let { handler.removeCallbacks(it) }
        pending = null
    }

    /** Closes immediately (also cancels a delayed show that hasn't happened yet). */
    fun dismiss() {
        cancelPending()
        closed = true
        ring?.stop()
        try { dialog?.dismiss() } catch (_: Exception) {}
        dialog = null
    }
}
