package com.android.calcognito

import android.app.Activity
import android.app.Dialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.Looper
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

/** Colours for [PixelProgressDialog]; all taken from the app's (dynamic) palette. */
class ProgressColors(
    val card: Int,
    val text: Int,
    val subtext: Int,
    val active: Int,
    val track: Int,
    val tickFill: Int,
    val tickFg: Int
)

/**
 * Compact Pixel / Quick Share style progress card: a circular indicator beside a title and a small
 * status line. On success the ring morphs into a tick and the card fades away by itself.
 *
 * Everything must be called on the UI thread. The dialog can be shown after a delay, so quick
 * operations never flash a dialog; [wasShown] tells you whether the person actually saw it.
 */
class PixelProgressDialog(
    private val activity: Activity,
    private val c: ProgressColors,
    private val wavy: Boolean
) {
    private val handler = Handler(Looper.getMainLooper())
    private var dialog: Dialog? = null
    private var ring: ProgressRingView? = null
    private var titleView: TextView? = null
    private var subView: TextView? = null

    private var title = ""
    private var sub = ""
    private var progress = -1f
    private var closed = false
    private var pending: Runnable? = null

    /** Lets the person back out (back button). Set before [show]. */
    var cancelable = false
    var onCancel: (() -> Unit)? = null

    var wasShown = false
        private set

    private fun dp(v: Int): Int = (v * activity.resources.displayMetrics.density).toInt()

    /** Show now, or after [delayMs] if the work is still running by then. */
    fun show(delayMs: Long = 0L) {
        if (closed) return
        if (delayMs <= 0L) {
            reallyShow()
            return
        }
        val r = Runnable {
            pending = null
            reallyShow()
        }
        pending = r
        handler.postDelayed(r, delayMs)
    }

    /** Any argument left null keeps its previous value. [progress] < 0 means "unknown" (spinning). */
    fun update(title: String? = null, sub: String? = null, progress: Float? = null) {
        if (title != null) this.title = title
        if (sub != null) this.sub = sub
        if (progress != null) this.progress = progress
        applyState()
    }

    private fun applyState() {
        titleView?.text = title
        subView?.let {
            it.text = sub
            it.visibility = if (sub.isEmpty()) View.GONE else View.VISIBLE
        }
        ring?.setProgress(progress)
    }

    private fun reallyShow() {
        if (closed || dialog != null) return
        if (activity.isFinishing || activity.isDestroyed) return
        val d = Dialog(activity)
        d.requestWindowFeature(Window.FEATURE_NO_TITLE)
        d.window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        d.window?.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        d.setCancelable(cancelable)
        d.setCanceledOnTouchOutside(false)

        val card = LinearLayout(activity).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable().apply {
                cornerRadius = dp(28).toFloat()
                setColor(c.card)
            }
            setPadding(dp(24), dp(22), dp(24), dp(22))
        }
        val r = ProgressRingView(activity, wavy, c.active, c.track, c.tickFill, c.tickFg)
        ring = r
        card.addView(r, LinearLayout.LayoutParams(dp(48), dp(48)))

        val col = LinearLayout(activity).apply { orientation = LinearLayout.VERTICAL }
        val t = TextView(activity).apply {
            setTextColor(c.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        val s = TextView(activity).apply {
            setTextColor(c.subtext)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
        titleView = t
        subView = s
        col.addView(t, LinearLayout.LayoutParams(-1, -2))
        col.addView(s, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
        card.addView(col, LinearLayout.LayoutParams(0, -2, 1f).apply { leftMargin = dp(20) })

        d.setContentView(card)
        val screenW = activity.resources.displayMetrics.widthPixels
        d.window?.setLayout(minOf(screenW - dp(66), dp(360)), ViewGroup.LayoutParams.WRAP_CONTENT)
        d.setOnCancelListener {
            closed = true
            dialog = null
            r.stop()
            onCancel?.invoke()
        }
        d.setOnDismissListener { r.stop() }
        dialog = d
        wasShown = true
        applyState()
        d.show()
    }

    /**
     * Completes the operation: ring fills, turns into a tick, the card fades out by itself, then [onEnd] runs.
     * If the dialog was never shown (the work was quick), [onEnd] runs right away.
     */
    fun finishSuccess(onEnd: () -> Unit) {
        cancelPending()
        val r = ring
        val d = dialog
        if (closed || d == null || r == null) {
            dismiss()
            onEnd()
            return
        }
        var ended = false
        val finishNow = Runnable {
            if (ended) return@Runnable
            ended = true
            fadeOutThen(onEnd)
        }
        r.finish { finishNow.run() }
        handler.postDelayed(finishNow, 2600L)
    }

    private fun fadeOutThen(after: () -> Unit) {
        val v = dialog?.window?.decorView
        if (v == null) {
            dismiss()
            after()
            return
        }
        v.animate().alpha(0f).setDuration(160L).withEndAction {
            dismiss()
            after()
        }.start()
    }

    private fun cancelPending() {
        pending?.let { handler.removeCallbacks(it) }
        pending = null
    }

    /** Closes immediately (also cancels a delayed show that hasn't happened yet). */
    fun dismiss() {
        cancelPending()
        closed = true
        ring?.stop()
        try { dialog?.dismiss() } catch (_: Exception) {}
        dialog = null
    }
}
