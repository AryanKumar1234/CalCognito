package com.example.calculator

import java.math.BigDecimal
import java.math.MathContext
import kotlin.math.*

/**
 * Recursive-descent evaluator.
 * Supports + − × ÷ ^ % ( ) ! √ sin cos tan asin acos atan ln log π e, unary minus,
 * implicit multiplication, and Pixel-style context-aware percent (A+B% == A + A*B/100).
 */
object Evaluator {

    var degrees: Boolean = true // true = degrees, false = radians

    fun eval(expr: String): Double {
        val cleaned = applyContextPercent(expr)
        val p = Parser(cleaned)
        val v = p.parseExpression()
        if (p.pos < cleaned.length) throw IllegalArgumentException("Format error")
        if (v.isNaN() || v.isInfinite()) throw ArithmeticException("Math error")
        return v
    }

    fun format(v: Double): String {
        val s = if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
        return if (s == "-0") "0" else s.replace('-', '−')
    }

    /**
     * Rewrites "A+B%" / "A-B%" into "A+(A×(B÷100))" so percent behaves like Pixel Calculator
     * (tip / discount on top of A), while a lone "B%" elsewhere still means B/100 via the
     * parser's own postfix % operator.
     */
    private fun applyContextPercent(expr: String): String {
        val regex = Regex("([0-9.)]+)([+−-])([0-9.]+)%")
        var result = expr
        var guard = 0
        while (guard++ < 20) {
            val m = regex.find(result) ?: break
            val a = m.groupValues[1]
            val op = m.groupValues[2]
            val b = m.groupValues[3]
            val replacement = "$a$op($a×($b÷100))"
            result = result.substring(0, m.range.first) + replacement + result.substring(m.range.last + 1)
        }
        return result
    }

    private class Parser(val s: String) {
        var pos = 0
        private fun peek(): Char? = if (pos < s.length) s[pos] else null
        private fun startsWith(tok: String) = s.regionMatches(pos, tok, 0, tok.length)

        fun parseExpression(): Double {
            var v = parseTerm()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v += parseTerm() }
                    '−', '-' -> { pos++; v -= parseTerm() }
                    else -> return v
                }
            }
        }

        private fun parseTerm(): Double {
            var v = parsePower()
            while (true) {
                val c = peek()
                when {
                    c == '×' -> { pos++; v *= parsePower() }
                    c == '÷' -> {
                        pos++
                        val d = parsePower()
                        if (d == 0.0) throw ArithmeticException("Divide by zero")
                        v /= d
                    }
                    c == '(' || (c != null && c.isLetter()) || c == 'π' || c == '√' -> v *= parsePower()
                    else -> return v
                }
            }
        }

        private fun parsePower(): Double {
            val base = parseUnary()
            if (peek() == '^') {
                pos++
                val exp = parsePower()
                return base.pow(exp)
            }
            return base
        }

        private fun parseUnary(): Double = when (peek()) {
            '−', '-' -> { pos++; -parseUnary() }
            '+' -> { pos++; parseUnary() }
            else -> parsePostfix()
        }

        private fun parsePostfix(): Double {
            var v = parsePrimary()
            while (true) {
                when (peek()) {
                    '%' -> { pos++; v /= 100.0 }
                    '!' -> { pos++; v = factorial(v) }
                    '²' -> { pos++; v *= v }
                    else -> return v
                }
            }
        }

        private fun factorial(x: Double): Double {
            if (x < 0 || x != Math.floor(x) || x > 170) throw ArithmeticException("Math error")
            var r = 1.0
            var i = 2
            while (i <= x.toInt()) { r *= i; i++ }
            return r
        }

        private val funcs = listOf(
            "asin", "acos", "atan", "sin", "cos", "tan", "ln", "log", "sqrt"
        )

        private fun parsePrimary(): Double {
            if (peek() == '(') {
                pos++
                val v = parseExpression()
                if (peek() == ')') pos++
                return v
            }
            if (startsWith("π")) { pos++; return Math.PI }
            if (startsWith("√")) { pos++; return sqrt(parsePostfixArgForFunction()) }
            for (f in funcs) {
                if (startsWith(f)) {
                    pos += f.length
                    val arg = parsePostfixArgForFunction()
                    return applyFunc(f, arg)
                }
            }
            if (peek() == 'e' && !(pos + 1 < s.length && s[pos + 1].isLetter())) {
                pos++; return Math.E
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Number expected")
            return s.substring(start, pos).toDouble()
        }

        private fun parsePostfixArgForFunction(): Double {
            return if (peek() == '(') parsePrimary() else parseUnary()
        }

        private fun applyFunc(name: String, x: Double): Double {
            val rad = if (degrees && name in setOf("sin", "cos", "tan")) Math.toRadians(x) else x
            return when (name) {
                "sin" -> sin(rad)
                "cos" -> cos(rad)
                "tan" -> tan(rad)
                "asin" -> if (degrees) Math.toDegrees(asin(x)) else asin(x)
                "acos" -> if (degrees) Math.toDegrees(acos(x)) else acos(x)
                "atan" -> if (degrees) Math.toDegrees(atan(x)) else atan(x)
                "ln" -> ln(x)
                "log" -> log10(x)
                "sqrt" -> sqrt(x)
                else -> throw IllegalArgumentException("Unknown function")
            }
        }
    }
}
