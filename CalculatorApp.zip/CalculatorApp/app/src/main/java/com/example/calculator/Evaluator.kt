package com.example.calculator

import java.math.BigDecimal
import java.math.MathContext

/** Recursive-descent evaluator: + − × ÷ % ( ) unary minus, implicit multiplication. */
object Evaluator {

    fun eval(expr: String): Double {
        val p = Parser(expr)
        val v = p.parseExpression()
        if (p.pos < expr.length) throw IllegalArgumentException("Format error")
        if (v.isNaN() || v.isInfinite()) throw ArithmeticException("Math error")
        return v
    }

    /** Raw (ungrouped) result string, using the '−' sign. */
    fun format(v: Double): String {
        val s = if (v == Math.floor(v) && Math.abs(v) < 1e15) v.toLong().toString()
        else BigDecimal(v).round(MathContext(12)).stripTrailingZeros().toPlainString()
        return if (s == "-0") "0" else s.replace('-', '−')
    }

    private class Parser(val s: String) {
        var pos = 0

        private fun peek(): Char? = if (pos < s.length) s[pos] else null

        fun parseExpression(): Double {
            var v = parseTerm()
            while (true) {
                when (peek()) {
                    '+' -> { pos++; v += parseTerm() }
                    '−', '-' -> { pos++; v -= parseTerm() }
                    else -> return v
                }
            }
        }

        private fun parseTerm(): Double {
            var v = parseUnary()
            while (true) {
                val c = peek()
                when {
                    c == '×' -> { pos++; v *= parseUnary() }
                    c == '÷' -> {
                        pos++
                        val d = parseUnary()
                        if (d == 0.0) throw ArithmeticException("Divide by zero")
                        v /= d
                    }
                    c == '(' -> v *= parseUnary()          // implicit multiplication: 2(3)
                    else -> return v
                }
            }
        }

        private fun parseUnary(): Double = when (peek()) {
            '−', '-' -> { pos++; -parseUnary() }
            '+' -> { pos++; parseUnary() }
            else -> parsePostfix()
        }

        private fun parsePostfix(): Double {
            var v = parsePrimary()
            while (peek() == '%') { pos++; v /= 100.0 }
            return v
        }

        private fun parsePrimary(): Double {
            if (peek() == '(') {
                pos++
                val v = parseExpression()
                if (peek() == ')') pos++          // a missing ')' at the end is tolerated
                return v
            }
            val start = pos
            while (pos < s.length && (s[pos].isDigit() || s[pos] == '.')) pos++
            if (start == pos) throw IllegalArgumentException("Number expected")
            val v = s.substring(start, pos).toDouble()
            // implicit multiplication: (2)3 handled by caller; 2( handled in parseTerm
            return v
        }
    }
}
