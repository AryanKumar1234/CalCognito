package com.example.calculator

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.view.WindowManager
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object VaultManager {
    private const val KEY_ALIAS = "CalculatorVaultKey"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BIT = 128
    private const val PREF_NAME = "vault_prefs"
    private const val KEY_PIN_HASH = "vault_pin_hash"

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
        }
        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    fun isPinSet(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.contains(KEY_PIN_HASH)
    }

    fun setPin(context: Context, pin: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PIN_HASH, pin.hashCode().toString()).apply()
    }

    fun checkPin(context: Context, pin: String): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PIN_HASH, null) ?: return false
        return saved == pin.hashCode().toString()
    }

    private fun getVaultDir(context: Context): File {
        val dir = File(context.filesDir, "secure_vault")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun listFiles(context: Context): List<File> {
        val dir = getVaultDir(context)
        return dir.listFiles()?.toList() ?: emptyList()
    }

    fun encryptAndSaveFile(context: Context, uri: Uri, originalName: String) {
        val inputStream = context.contentResolver.openInputStream(uri) ?: return
        val bytes = inputStream.readBytes()
        inputStream.close()

        val cipher = Cipher.getInstance(TRANSFORMATION)
        cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
        val iv = cipher.iv
        val encryptedData = cipher.doFinal(bytes)

        val outFile = File(getVaultDir(context), "$originalName.enc")
        // Store IV (12 bytes) + Encrypted Data
        outFile.writeBytes(iv + encryptedData)
    }

    fun decryptFile(context: Context, encFile: File, outputDir: File): File? {
        try {
            val fileBytes = encFile.readBytes()
            if (fileBytes.size < 12) return null
            val iv = fileBytes.copyOfRange(0, 12)
            val encryptedData = fileBytes.copyOfRange(12, fileBytes.size)

            val cipher = Cipher.getInstance(TRANSFORMATION)
            val spec = GCMParameterSpec(TAG_LENGTH_BIT, iv)
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), spec)
            val decryptedData = cipher.doFinal(encryptedData)

            val originalName = encFile.name.removeSuffix(".enc")
            val restoredFile = File(outputDir, originalName)
            restoredFile.writeBytes(decryptedData)
            return restoredFile
        } catch (e: Exception) {
            return null
        }
    }

    fun deleteFile(file: File) {
        if (file.exists()) file.delete()
    }

    fun applySecurityFlags(activity: Activity) {
        activity.window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }
}
