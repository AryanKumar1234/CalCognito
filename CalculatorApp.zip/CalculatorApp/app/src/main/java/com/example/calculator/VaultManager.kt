package com.example.calculator

import android.app.Activity
import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.DocumentsContract
import android.provider.MediaStore
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.view.WindowManager
import android.webkit.MimeTypeMap
import androidx.annotation.RequiresApi
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStream
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

object VaultManager {
    private const val KEY_ALIAS = "CalculatorVaultKey"
    private const val ANDROID_KEYSTORE = "AndroidKeyStore"
    private const val TRANSFORMATION = "AES/GCM/NoPadding"
    private const val TAG_LENGTH_BIT = 128
    private const val IV_SIZE = 12
    private const val PREF_NAME = "vault_prefs"
    private const val KEY_PIN_HASH = "vault_pin_hash"
    private const val TEMP_DIR = "vault_tmp"

    private fun getSecretKey(): SecretKey {
        val keyStore = KeyStore.getInstance(ANDROID_KEYSTORE).apply { load(null) }
        if (keyStore.containsAlias(KEY_ALIAS)) {
            return (keyStore.getEntry(KEY_ALIAS, null) as KeyStore.SecretKeyEntry).secretKey
        }
        val keyGenerator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, ANDROID_KEYSTORE)
        val spec = KeyGenParameterSpec.Builder(
            KEY_ALIAS,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .build()
        keyGenerator.init(spec)
        return keyGenerator.generateKey()
    }

    // ---------------------------------------------------------------- PIN

    fun isPinSet(context: Context): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        return prefs.contains(KEY_PIN_HASH)
    }

    fun setPin(context: Context, pin: String) {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_PIN_HASH, pin.hashCode().toString()).apply()
    }

    fun checkPin(context: Context, pin: String): Boolean {
        val prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
        val saved = prefs.getString(KEY_PIN_HASH, null) ?: return false
        return saved == pin.hashCode().toString()
    }

    // ---------------------------------------------------------------- Vault storage

    private fun getVaultDir(context: Context): File {
        val dir = File(context.filesDir, "secure_vault")
        if (!dir.exists()) dir.mkdirs()
        return dir
    }

    fun listFiles(context: Context): List<File> {
        val files = getVaultDir(context).listFiles { f -> f.isFile && f.name.endsWith(".enc") }
        return files?.sortedBy { it.name.lowercase() } ?: emptyList()
    }

    /** Original file name (without the ".enc" suffix). */
    fun displayName(file: File): String = file.name.removeSuffix(".enc")

    fun mimeFor(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        if (ext.isEmpty()) return "application/octet-stream"
        return when (ext) {
            "mkv" -> "video/x-matroska"
            "heic", "heif" -> "image/heic"
            "webp" -> "image/webp"
            else -> MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/octet-stream"
        }
    }

    private fun sanitize(name: String): String {
        val cleaned = name.replace(Regex("[\\\\/:*?\"<>|\\u0000-\\u001F]"), "_").trim().trimStart('.')
        return cleaned.ifEmpty { "file_${System.currentTimeMillis()}" }
    }

    private fun uniqueFile(dir: File, safeName: String): File {
        var candidate = File(dir, "$safeName.enc")
        if (!candidate.exists()) return candidate
        val dot = safeName.lastIndexOf('.')
        val base = if (dot > 0) safeName.substring(0, dot) else safeName
        val ext = if (dot > 0) safeName.substring(dot) else ""
        var i = 1
        while (true) {
            candidate = File(dir, "$base ($i)$ext.enc")
            if (!candidate.exists()) return candidate
            i++
        }
    }

    // ---------------------------------------------------------------- Hide (encrypt + remove original)

    /**
     * Streams [uri] into an encrypted file inside the app's private storage.
     * File format: 12-byte IV followed by AES-GCM ciphertext (+ tag).
     * Returns true only when the encrypted copy was written completely.
     */
    fun encryptToVault(context: Context, uri: Uri, originalName: String): Boolean {
        val target = uniqueFile(getVaultDir(context), sanitize(originalName))
        return try {
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.ENCRYPT_MODE, getSecretKey())
            val iv = cipher.iv
            var copied = 0L
            val input = context.contentResolver.openInputStream(uri) ?: throw IOException("Cannot open source")
            input.use { ins ->
                FileOutputStream(target).use { fos ->
                    fos.write(iv)
                    CipherOutputStream(fos, cipher).use { out ->
                        copied = ins.copyTo(out)
                    }
                }
            }
            if (target.length() != IV_SIZE + copied + TAG_LENGTH_BIT / 8) throw IOException("Incomplete write")
            true
        } catch (e: Exception) {
            target.delete()
            false
        }
    }

    /**
     * Tries to remove the original file without any user interaction.
     * Returns true if it is gone.
     */
    fun tryDeleteOriginal(context: Context, uri: Uri): Boolean {
        val resolver = context.contentResolver
        try {
            if (DocumentsContract.isDocumentUri(context, uri)) {
                if (DocumentsContract.deleteDocument(resolver, uri)) return true
            } else if (resolver.delete(uri, null, null) > 0) {
                return true
            }
        } catch (_: Exception) {
        }
        // Android 9 and below: direct MediaStore delete works once storage permission is granted.
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            val media = toMediaStoreUri(context, uri)
            if (media != null) {
                try {
                    if (resolver.delete(media, null, null) > 0) return true
                } catch (_: Exception) {
                }
            }
        }
        return false
    }

    /**
     * Maps a document/picker uri to the matching MediaStore uri (needed for the
     * system "allow this app to delete" request on Android 10+).
     */
    fun toMediaStoreUri(context: Context, uri: Uri): Uri? {
        try {
            if (uri.authority == MediaStore.AUTHORITY) return uri
            if (!DocumentsContract.isDocumentUri(context, uri)) return null
            val parts = DocumentsContract.getDocumentId(uri).split(":")
            if (parts.size != 2) return null
            val id = parts[1].toLongOrNull() ?: return null
            return when (uri.authority) {
                "com.android.providers.media.documents" -> {
                    val base = when (parts[0]) {
                        "image" -> MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                        "video" -> MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                        "audio" -> MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
                        else -> return null
                    }
                    ContentUris.withAppendedId(base, id)
                }
                "com.android.providers.downloads.documents" ->
                    if (parts[0] == "msf") ContentUris.withAppendedId(MediaStore.Files.getContentUri("external"), id) else null
                else -> null
            }
        } catch (_: Exception) {
            return null
        }
    }

    // ---------------------------------------------------------------- Open / view

    /** Opens a decrypting stream. Caller must close it. Authentication errors surface while reading. */
    fun openDecrypted(encFile: File): InputStream {
        val fis = FileInputStream(encFile)
        try {
            val iv = ByteArray(IV_SIZE)
            DataInputStream(fis).readFully(iv)
            val cipher = Cipher.getInstance(TRANSFORMATION)
            cipher.init(Cipher.DECRYPT_MODE, getSecretKey(), GCMParameterSpec(TAG_LENGTH_BIT, iv))
            return CipherInputStream(fis, cipher)
        } catch (e: Exception) {
            fis.close()
            throw e
        }
    }

    /** Decrypts a whole file into memory (images). Returns null on failure. */
    fun readDecrypted(encFile: File): ByteArray? = try {
        openDecrypted(encFile).use { it.readBytes() }
    } catch (e: Exception) {
        null
    }

    /** Decrypts into the private temp folder so a viewer can read it. Always clear afterwards. */
    fun decryptToTemp(context: Context, encFile: File): File? {
        val dir = File(context.cacheDir, TEMP_DIR).apply { mkdirs() }
        val out = File(dir, displayName(encFile))
        return try {
            openDecrypted(encFile).use { ins -> FileOutputStream(out).use { ins.copyTo(it) } }
            out
        } catch (e: Exception) {
            out.delete()
            null
        }
    }

    /** Removes every decrypted copy (also leftovers from older versions of the app). */
    fun clearTemp(context: Context) {
        File(context.cacheDir, TEMP_DIR).listFiles()?.forEach { it.delete() }
        context.cacheDir.listFiles()?.forEach { if (it.isFile) it.delete() }
    }

    // ---------------------------------------------------------------- Unhide / delete

    /**
     * Restores a vault file to public storage (Pictures / Movies / Music / Download).
     * Returns the folder name on success, or null on failure. The encrypted copy is NOT removed here.
     */
    fun restoreToPublic(context: Context, encFile: File): String? {
        val name = displayName(encFile)
        val mime = mimeFor(name)
        val folder = when {
            mime.startsWith("image/") -> Environment.DIRECTORY_PICTURES
            mime.startsWith("video/") -> Environment.DIRECTORY_MOVIES
            mime.startsWith("audio/") -> Environment.DIRECTORY_MUSIC
            else -> Environment.DIRECTORY_DOWNLOADS
        }
        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                restoreWithMediaStore(context, encFile, name, mime, folder)
            } else {
                restoreLegacy(context, encFile, name, folder)
            }
            folder
        } catch (e: Exception) {
            null
        }
    }

    @RequiresApi(Build.VERSION_CODES.Q)
    private fun restoreWithMediaStore(context: Context, encFile: File, name: String, mime: String, folder: String) {
        val resolver = context.contentResolver
        val collection = when {
            mime.startsWith("image/") -> MediaStore.Images.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            mime.startsWith("video/") -> MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            mime.startsWith("audio/") -> MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            else -> MediaStore.Downloads.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        }
        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            put(MediaStore.MediaColumns.MIME_TYPE, mime)
            put(MediaStore.MediaColumns.RELATIVE_PATH, folder)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val target = resolver.insert(collection, values) ?: throw IOException("Could not create file")
        try {
            val out = resolver.openOutputStream(target) ?: throw IOException("Could not open output")
            out.use { o -> openDecrypted(encFile).use { it.copyTo(o) } }
            val done = ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }
            resolver.update(target, done, null, null)
        } catch (e: Exception) {
            try { resolver.delete(target, null, null) } catch (_: Exception) {}
            throw e
        }
    }

    @Suppress("DEPRECATION")
    private fun restoreLegacy(context: Context, encFile: File, name: String, folder: String) {
        val dir = Environment.getExternalStoragePublicDirectory(folder)
        dir.mkdirs()
        var target = File(dir, name)
        if (target.exists()) {
            val dot = name.lastIndexOf('.')
            val base = if (dot > 0) name.substring(0, dot) else name
            val ext = if (dot > 0) name.substring(dot) else ""
            var i = 1
            while (target.exists()) {
                target = File(dir, "$base ($i)$ext")
                i++
            }
        }
        try {
            FileOutputStream(target).use { out -> openDecrypted(encFile).use { it.copyTo(out) } }
        } catch (e: Exception) {
            target.delete()
            throw e
        }
        MediaScannerConnection.scanFile(context, arrayOf(target.absolutePath), null, null)
    }

    fun deleteFile(file: File) {
        if (file.exists()) file.delete()
    }

    fun applySecurityFlags(activity: Activity) {
        activity.window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
    }
}
