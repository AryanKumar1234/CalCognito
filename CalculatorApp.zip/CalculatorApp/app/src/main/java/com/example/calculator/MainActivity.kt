package com.example.calculator

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** A calculator styled after the Google (Pixel) Calculator, with a scientific mode and history. */
class MainActivity : Activity() {

    private class Palette(
        val bg: Int, val panel: Int, val text: Int, val textDim: Int,
        val numBg: Int, val numFg: Int,
        val opBg: Int, val opFg: Int,
        val eqBg: Int, val eqFg: Int,
        val sciBg: Int, val sciFg: Int,
        val clearFg: Int, val ripple: Int, val divider: Int
    )

    private fun c(hex: String) = Color.parseColor(hex)

    private val light = Palette(
        bg = c("#F8F9FF"), panel = c("#E9EDF6"), text = c("#1B1B1F"), textDim = c("#5F6368"),
        numBg = c("#FFFFFF"), numFg = c("#1B1B1F"),
        opBg = c("#D3E3FD"), opFg = c("#0B57D0"),
        eqBg = c("#0B57D0"), eqFg = c("#FFFFFF"),
        sciBg = c("#E9EDF6"), sciFg = c("#0B57D0"),
        clearFg = c("#B3261E"), ripple = c("#33000000"), divider = c("#D5D9E5")
    )
    private val dark = Palette(
        bg = c("#121316"), panel = c("#1D1F24"), text = c("#E3E3E8"), textDim = c("#9AA0A6"),
        numBg = c("#2C2E34"), numFg = c("#E3E3E8"),
        opBg = c("#2E4067"), opFg = c("#D3E3FD"),
        eqBg = c("#A8C7FA"), eqFg = c("#062E6F"),
        sciBg = c("#1D1F24"), sciFg = c("#A8C7FA"),
        clearFg = c("#F2B8B5"), ripple = c("#33FFFFFF"), divider = c("#303238")
    )
    private lateinit var pal: Palette

    private lateinit var topView: TextView
    private lateinit var bottomView: TextView
    private lateinit var sciPanel: LinearLayout
    private lateinit var historyPanel: LinearLayout
    private lateinit var historyList: LinearLayout
    private lateinit var degButton: TextView
    private lateinit var fxButton: TextView

    private var expression = ""
    private var previousExpression = ""
    private var justEvaluated = false
    private var errorText: String? = null
    private var sciVisible = false
    private var historyVisible = false

    private val operators = setOf('+', '−', '×', '÷')
    private val prefs by lazy { getSharedPreferences("calc_history", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        pal = if (night) dark else light
        Evaluator.degrees = prefs.getBoolean("deg", true)

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.panel
        if (!night) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        setContentView(buildUi())

        expression = savedInstanceState?.getString("expr") ?: ""
        previousExpression = savedInstanceState?.getString("prev") ?: ""
        justEvaluated = savedInstanceState?.getBoolean("done") ?: false
        refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("expr", expression)
        outState.putString("prev", previousExpression)
        outState.putBoolean("done", justEvaluated)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * resources.displayMetrics.density

    // ---------- UI construction ----------

    private fun buildUi(): View {
        val root = FrameLayout(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
        }

        // Top bar: history + fx toggle
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(12), dp(16), dp(12), 0)
        }
        val historyBtn = TextView(this).apply {
            text = "🕘"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            setTextColor(pal.textDim)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { toggleHistory() }
        }
        degButton = TextView(this).apply {
            text = if (Evaluator.degrees) "DEG" else "RAD"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            setTextColor(pal.textDim)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = View.GONE
            setOnClickListener {
                Evaluator.degrees = !Evaluator.degrees
                prefs.edit().putBoolean("deg", Evaluator.degrees).apply()
                text = if (Evaluator.degrees) "DEG" else "RAD"
            }
        }
        fxButton = TextView(this).apply {
            text = "ƒ(x)"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(pal.opFg)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { toggleScientific() }
        }
        topBar.addView(historyBtn)
        topBar.addView(View(this), LinearLayout.LayoutParams(0, -1, 1f))
        topBar.addView(degButton)
        topBar.addView(fxButton)
        column.addView(topBar, LinearLayout.LayoutParams(-1, -2))

        // Display
        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(24), dp(8), dp(24), dp(20))
        }
        topView = TextView(this).apply {
            gravity = Gravity.END or Gravity.BOTTOM
            maxLines = 2
            setOnLongClickListener { pasteIntoExpression(); true }
        }
        bottomView = TextView(this).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            setOnLongClickListener { copyResult(); true }
        }
        display.addView(topView, LinearLayout.LayoutParams(-1, 0, 1f))
        display.addView(bottomView, LinearLayout.LayoutParams(-1, dp(72)))
        column.addView(display, LinearLayout.LayoutParams(-1, 0, 2f))

        // Keypad panel
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(12), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(pal.panel)
                val r = dpf(32)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }

        sciPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val sciRows = listOf(
            listOf("sin", "cos", "tan", "x²"),
            listOf("ln", "log", "√", "x^y"),
            listOf("π", "e", "n!", "( )")
        )
        for (row in sciRows) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (label in row) {
                line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, dp(48), 1f).apply {
                    setMargins(dp(4), dp(3), dp(4), dp(3))
                })
            }
            sciPanel.addView(line, LinearLayout.LayoutParams(-1, -2))
        }
        panel.addView(sciPanel, LinearLayout.LayoutParams(-1, -2))

        val basicRows = listOf(
            listOf("AC", "( )", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "⌫", "=")
        )
        val basicPanel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        for (row in basicRows) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (label in row) {
                line.addView(makeKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply {
                    setMargins(dp(5), dp(5), dp(5), dp(5))
                })
            }
            basicPanel.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        panel.addView(basicPanel, LinearLayout.LayoutParams(-1, 0, 1f))
        column.addView(panel, LinearLayout.LayoutParams(-1, 0, 3.4f))

        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        // History overlay panel (hidden by default)
        historyPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(pal.bg)
        }
        val histHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(20), dp(16), dp(8))
            gravity = Gravity.CENTER_VERTICAL
        }
        histHeader.addView(TextView(this).apply {
            text = "History"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        histHeader.addView(TextView(this).apply {
            text = "Clear"
            setTextColor(pal.clearFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { clearHistory() }
        })
        histHeader.addView(TextView(this).apply {
            text = "Close"
            setTextColor(pal.opFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { toggleHistory() }
        })
        historyPanel.addView(histHeader)
        val scroll = ScrollView(this)
        historyList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(historyList, LinearLayout.LayoutParams(-1, -2))
        historyPanel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(historyPanel, FrameLayout.LayoutParams(-1, -1))

        return root
    }

    private fun makeKey(label: String): TextView {
        val isOp = label in setOf("÷", "×", "−", "+", "%", "( )")
        val bg: Int; val fg: Int
        when {
            label == "=" -> { bg = pal.eqBg; fg = pal.eqFg }
            isOp -> { bg = pal.opBg; fg = pal.opFg }
            label == "AC" -> { bg = pal.numBg; fg = pal.clearFg }
            else -> { bg = pal.numBg; fg = pal.numFg }
        }
        return makeButton(label, bg, fg, if (label == "AC") 22f else 30f) { onPress(label) }.also {
            if (label == "⌫") it.setOnLongClickListener { onPress("AC"); true }
        }
    }

    private fun makeSciKey(label: String): TextView {
        return makeButton(label, pal.sciBg, pal.sciFg, 16f) { onSciPress(label) }
    }

    private fun makeButton(
        label: String, bg: Int, fg: Int, sizeSp: Float, onClick: () -> Unit
    ): TextView {
        val radius = dpf(22)
        val shape = GradientDrawable().apply { cornerRadius = radius; setColor(bg) }
        val mask = GradientDrawable().apply { cornerRadius = radius; setColor(Color.BLACK) }
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, sizeSp)
            isClickable = true
            isFocusable = true
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
            setOnClickListener { onClick() }
        }
    }

    // ---------- Scientific-key handling ----------

    private fun onSciPress(key: String) {
        if (justEvaluated) { expression = ""; justEvaluated = false }
        when (key) {
            "sin" -> insertFunction("sin(")
            "cos" -> insertFunction("cos(")
            "tan" -> insertFunction("tan(")
            "ln" -> insertFunction("ln(")
            "log" -> insertFunction("log(")
            "√" -> insertFunction("√(")
            "x²" -> expression += "²"
            "x^y" -> expression += "^"
            "n!" -> expression += "!"
            "π" -> appendValueToken("π")
            "e" -> appendValueToken("e")
            "( )" -> onPress("( )")
        }
        refresh()
    }

    private fun insertFunction(token: String) {
        if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²")) {
            expression += "×"
        }
        expression += token
    }

    private fun appendValueToken(token: String) {
        if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²")) {
            expression += "×"
        }
        expression += token
    }

    private fun toggleScientific() {
        sciVisible = !sciVisible
        sciPanel.visibility = if (sciVisible) View.VISIBLE else View.GONE
        degButton.visibility = if (sciVisible) View.VISIBLE else View.GONE
    }

    // ---------- History ----------

    private fun toggleHistory() {
        historyVisible = !historyVisible
        if (historyVisible) renderHistory()
        historyPanel.visibility = if (historyVisible) View.VISIBLE else View.GONE
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("entries", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split("\u0002").mapNotNull {
            val parts = it.split("\u0001")
            if (parts.size == 2) parts[0] to parts[1] else null
        }
    }

    private fun saveHistoryEntry(expr: String, result: String) {
        val entries = (listOf(expr to result) + loadHistory()).take(30)
        val raw = entries.joinToString("\u0002") { "${it.first}\u0001${it.second}" }
        prefs.edit().putString("entries", raw).apply()
    }

    private fun clearHistory() {
        prefs.edit().remove("entries").apply()
        renderHistory()
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        val entries = loadHistory()
        if (entries.isEmpty()) {
            historyList.addView(TextView(this).apply {
                text = "No history yet"
                setTextColor(pal.textDim)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            })
            return
        }
        for ((expr, result) in entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
                isClickable = true
                setOnClickListener {
                    expression = result
                    previousExpression = expr
                    justEvaluated = true
                    toggleHistory()
                    refresh()
                }
            }
            row.addView(TextView(this).apply {
                text = group(expr)
                setTextColor(pal.textDim)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                gravity = Gravity.END
            })
            row.addView(TextView(this).apply {
                text = "= " + group(result)
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                gravity = Gravity.END
            })
            historyList.addView(row)
            historyList.addView(View(this).apply { setBackgroundColor(pal.divider) },
                LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    // ---------- Copy / paste ----------

    private fun copyResult() {
        if (!justEvaluated) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("result", expression.replace('−', '-')))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun pasteIntoExpression() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val sanitized = text.filter { it.isDigit() || it in "+-×÷.%()^!" }
            .replace('-', '−')
        if (sanitized.isEmpty()) return
        if (justEvaluated) { expression = ""; justEvaluated = false }
        expression += sanitized
        refresh()
    }

    // ---------- Basic-key handling ----------

    private fun onPress(key: String) {
        errorText = null
        when (key) {
            in "0".."9" -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                if (expression.isNotEmpty() && expression.last() in ")%²") expression += "×"
                expression += key
            }
            "." -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                val lastNumber = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!lastNumber.contains('.')) expression += if (lastNumber.isEmpty()) "0." else "."
            }
            "+", "×", "÷", "−" -> {
                justEvaluated = false
                val op = key[0]
                if (expression.isEmpty() || expression.last() == '(') {
                    if (op == '−') expression += "−"
                } else if (expression.last() in operators) {
                    expression = if (expression.length > 1 && expression[expression.length - 2] != '(')
                        expression.dropLast(1) + op
                    else if (op == '−') expression else expression.dropLast(1)
                } else {
                    expression += op
                }
            }
            "%" -> {
                justEvaluated = false
                if (expression.isNotEmpty() && (expression.last().isDigit() ||
                            expression.last() in ")%²")) expression += "%"
            }
            "( )" -> {
                justEvaluated = false
                val open = expression.count { it == '(' }
                val close = expression.count { it == ')' }
                val last = expression.lastOrNull()
                val canClose = open > close && last != null && (last.isDigit() || last in ")%²")
                expression += if (canClose) ")" else {
                    if (last != null && (last.isDigit() || last in ")%²")) "×(" else "("
                }
            }
            "⌫" -> {
                if (justEvaluated) { justEvaluated = false; previousExpression = "" }
                else expression = expression.dropLast(1)
            }
            "AC" -> { expression = ""; previousExpression = ""; justEvaluated = false }
            "=" -> {
                if (expression.isNotEmpty() && !justEvaluated) {
                    try {
                        val result = Evaluator.format(Evaluator.eval(closeParens(trimTrailingOps(expression))))
                        previousExpression = expression
                        expression = result
                        justEvaluated = true
                        saveHistoryEntry(previousExpression, expression)
                    } catch (e: ArithmeticException) {
                        errorText = "Can't divide by 0"
                    } catch (e: Exception) {
                        errorText = "Format error"
                    }
                }
            }
        }
        refresh()
    }

    private fun trimTrailingOps(s: String): String {
        var t = s
        while (t.isNotEmpty() && (t.last() in operators || t.last() == '(')) t = t.dropLast(1)
        return t
    }

    private fun closeParens(s: String): String {
        val missing = s.count { it == '(' } - s.count { it == ')' }
        return if (missing > 0) s + ")".repeat(missing) else s
    }

    // ---------- Rendering ----------

    private fun group(s: String): String =
        Regex("(\\d+)(\\.\\d*)?").replace(s) { m ->
            val int = m.groupValues[1].reversed().chunked(3).joinToString(",").reversed()
            int + m.groupValues[2]
        }

    private fun style(view: TextView, minSp: Int, maxSp: Int, color: Int) {
        view.setTextColor(color)
        view.setAutoSizeTextTypeUniformWithConfiguration(minSp, maxSp, 2, TypedValue.COMPLEX_UNIT_SP)
    }

    private fun refresh() {
        if (justEvaluated) {
            style(topView, 18, 28, pal.textDim)
            style(bottomView, 32, 56, pal.text)
            topView.text = group(previousExpression) + " ="
            bottomView.text = group(expression)
        } else {
            style(topView, 28, 56, pal.text)
            style(bottomView, 20, 32, pal.textDim)
            topView.text = group(expression)
            bottomView.text = errorText ?: preview()
        }
    }

    private fun preview(): String {
        val e = trimTrailingOps(expression)
        if (e.isEmpty() || Regex("^−?[\\d.]+$").matches(e)) return ""
        return try {
            group(Evaluator.format(Evaluator.eval(closeParens(e))))
        } catch (ex: Exception) { "" }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (historyVisible) toggleHistory() else super.onBackPressed()
    }
}
