package com.example.calculator

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ReplacementSpan
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** A calculator styled after the Google (Pixel) Calculator, with a scientific mode and history. */
class MainActivity : Activity() {

    private class Palette(
        val bg: Int, val text: Int, val icon: Int,
        val numBg: Int, val numFg: Int,
        val opBg: Int, val opFg: Int,
        val acBg: Int, val acFg: Int,
        val eqBg: Int, val eqFg: Int,
        val sciBg: Int, val sciFg: Int,
        val result: Int, val cursor: Int,
        val clearFg: Int, val ripple: Int, val divider: Int
    )

    private fun c(hex: String) = Color.parseColor(hex)

    private val light = Palette(
        bg = c("#FFF8F6"), text = c("#231917"), icon = c("#53433F"),
        numBg = c("#F1DFDA"), numFg = c("#231917"),
        opBg = c("#E7BDB2"), opFg = c("#442A22"),
        acBg = c("#FFDBD2"), acFg = c("#723523"),
        eqBg = c("#6B5E2F"), eqFg = c("#FFFFFF"),
        sciBg = c("#F1DFDA"), sciFg = c("#442A22"),
        result = c("#6B5E2F"), cursor = c("#9A4026"),
        clearFg = c("#BA1A1A"), ripple = c("#33000000"), divider = c("#E7D6D1")
    )
    private val dark = Palette(
        bg = c("#1C110D"), text = c("#EEE0DD"), icon = c("#D7C3BD"),
        numBg = c("#40332D"), numFg = c("#EEE0DD"),
        opBg = c("#5D4038"), opFg = c("#FFDBD2"),
        acBg = c("#723523"), acFg = c("#FFDBD2"),
        eqBg = c("#DAC58E"), eqFg = c("#3B2F05"),
        sciBg = c("#40332D"), sciFg = c("#FFDBD2"),
        result = c("#DAC58E"), cursor = c("#FFB5A2"),
        clearFg = c("#FFB5A2"), ripple = c("#33FFFFFF"), divider = c("#3A2C27")
    )
    private lateinit var pal: Palette

    /** Thin caret drawn after the expression; toggled by [blink]. */
    private class CursorSpan(
        private val widthPx: Int, private val barPx: Int, private val color: Int
    ) : ReplacementSpan() {
        var visible = true
        override fun getSize(
            paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?
        ): Int = widthPx

        override fun draw(
            canvas: Canvas, text: CharSequence?, start: Int, end: Int,
            x: Float, top: Int, y: Int, bottom: Int, paint: Paint
        ) {
            if (!visible) return
            val p = Paint(paint)
            p.color = color
            p.style = Paint.Style.FILL
            val left = x + (widthPx - barPx) / 2f
            canvas.drawRect(left, top.toFloat(), left + barPx, bottom.toFloat(), p)
        }
    }

    private lateinit var topView: TextView
    private lateinit var bottomView: TextView
    private lateinit var sciPanel: LinearLayout
    private lateinit var historyPanel: LinearLayout
    private lateinit var historyList: LinearLayout
    private lateinit var degButton: TextView

    private val cursorSpan by lazy { CursorSpan(dp(8), dp(2), pal.cursor) }
    private val handler = Handler(Looper.getMainLooper())
    private val blink = object : Runnable {
        override fun run() {
            cursorSpan.visible = !cursorSpan.visible
            topView.invalidate()
            handler.postDelayed(this, 530)
        }
    }

    private var expression = ""
    private var previousExpression = ""
    private var justEvaluated = false
    private var errorText: String? = null
    private var sciVisible = false
    private var historyVisible = false

    private val operators = setOf('+', '−', '×', '÷')
    private val prefs by lazy { getSharedPreferences("calc_history", Context.MODE_PRIVATE) }
    private val displayFont: Typeface by lazy { Typeface.create("sans-serif-condensed", Typeface.NORMAL) }
    private val keyFont: Typeface by lazy { Typeface.create("sans-serif", Typeface.NORMAL) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        pal = if (night) dark else light
        Evaluator.degrees = prefs.getBoolean("deg", true)

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        if (!night) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        setContentView(buildUi())

        expression = savedInstanceState?.getString("expr") ?: ""
        previousExpression = savedInstanceState?.getString("prev") ?: ""
        justEvaluated = savedInstanceState?.getBoolean("done") ?: false
        refresh()
    }

    override fun onResume() {
        super.onResume()
        handler.removeCallbacks(blink)
        handler.postDelayed(blink, 530)
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(blink)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("expr", expression)
        outState.putString("prev", previousExpression)
        outState.putBoolean("done", justEvaluated)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * resources.displayMetrics.density

    // ---------- UI construction ----------

    private fun buildUi(): View {
        val root = FrameLayout(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
        }

        // Top bar: history (left) + overflow menu (right)
        val topBar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(12), dp(12), 0)
        }
        topBar.addView(iconButton(R.drawable.ic_history, "History") { toggleHistory() },
            LinearLayout.LayoutParams(dp(48), dp(48)))
        topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        topBar.addView(iconButton(R.drawable.ic_more_vert, "More options") { showMenu(it) },
            LinearLayout.LayoutParams(dp(48), dp(48)))
        column.addView(topBar, LinearLayout.LayoutParams(-1, -2))

        // Display: expression on top, live result underneath
        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(24), dp(8), dp(24), 0)
        }
        topView = TextView(this).apply {
            gravity = Gravity.END or Gravity.BOTTOM
            maxLines = 2
            typeface = displayFont
            setOnLongClickListener { pasteIntoExpression(); true }
        }
        bottomView = TextView(this).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            typeface = displayFont
            setOnLongClickListener { copyResult(); true }
        }
        display.addView(topView, LinearLayout.LayoutParams(-1, 0, 1f))
        display.addView(bottomView, LinearLayout.LayoutParams(-1, dp(72)))
        column.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))

        // Tool row: expand (scientific) toggle + DEG/RAD
        degButton = TextView(this).apply {
            text = if (Evaluator.degrees) "DEG" else "RAD"
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setTextColor(pal.result)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(12), dp(8), dp(12), dp(8))
            visibility = View.GONE
            setOnClickListener { toggleDegrees() }
        }
        val toolRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(4), dp(24), dp(4))
        }
        toolRow.addView(iconButton(R.drawable.ic_unfold_more, "Scientific functions") { toggleScientific() },
            LinearLayout.LayoutParams(dp(48), dp(48)))
        toolRow.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        toolRow.addView(degButton)
        column.addView(toolRow, LinearLayout.LayoutParams(-1, -2))

        // Keypad (round keys, one cell = one square)
        val dm = resources.displayMetrics
        val cell = (dm.widthPixels - dp(8)) / 4
        val rowH = minOf(cell, (dm.heightPixels * 0.11f).toInt())

        val keypad = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), 0, dp(4), dp(8))
        }

        sciPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        val sciRows = listOf(
            listOf("sin", "cos", "tan", "x²"),
            listOf("ln", "log", "√", "x^y"),
            listOf("π", "e", "n!", "( )")
        )
        for (row in sciRows) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (label in row) {
                line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, dp(44), 1f).apply {
                    setMargins(dp(4), dp(3), dp(4), dp(3))
                })
            }
            sciPanel.addView(line, LinearLayout.LayoutParams(-1, -2))
        }
        keypad.addView(sciPanel, LinearLayout.LayoutParams(-1, -2))

        val basicRows = listOf(
            listOf("AC", "( )", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "⌫", "=")
        )
        for (row in basicRows) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (label in row) {
                line.addView(makeKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply {
                    setMargins(dp(2), dp(2), dp(2), dp(2))
                })
            }
            keypad.addView(line, LinearLayout.LayoutParams(-1, rowH))
        }
        column.addView(keypad, LinearLayout.LayoutParams(-1, -2))

        root.addView(column, FrameLayout.LayoutParams(-1, -1))

        // History overlay panel (hidden by default)
        historyPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
        }
        val histHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(20), dp(16), dp(8))
            gravity = Gravity.CENTER_VERTICAL
        }
        histHeader.addView(TextView(this).apply {
            text = "History"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        histHeader.addView(TextView(this).apply {
            text = "Clear"
            setTextColor(pal.clearFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { clearHistory() }
        })
        histHeader.addView(TextView(this).apply {
            text = "Close"
            setTextColor(pal.sciFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { toggleHistory() }
        })
        historyPanel.addView(histHeader)
        val scroll = ScrollView(this)
        historyList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(historyList, LinearLayout.LayoutParams(-1, -2))
        historyPanel.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        root.addView(historyPanel, FrameLayout.LayoutParams(-1, -1))

        return root
    }

    private fun iconButton(res: Int, desc: String, onClick: (View) -> Unit): ImageView {
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
        return ImageView(this).apply {
            setImageResource(res)
            setColorFilter(pal.icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(12), dp(12), dp(12), dp(12))
            contentDescription = desc
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), null, mask)
            setOnClickListener { onClick(it) }
        }
    }

    private fun makeKey(label: String): View {
        val isOp = label in setOf("÷", "×", "−", "+", "%", "( )")
        val bg: Int
        val fg: Int
        when {
            label == "=" -> { bg = pal.eqBg; fg = pal.eqFg }
            label == "AC" -> { bg = pal.acBg; fg = pal.acFg }
            isOp -> { bg = pal.opBg; fg = pal.opFg }
            else -> { bg = pal.numBg; fg = pal.numFg }
        }
        val content: View = if (label == "⌫") {
            ImageView(this).apply {
                setImageResource(R.drawable.ic_backspace)
                setColorFilter(fg)
                layoutParams = FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER)
            }
        } else {
            TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label == "AC") 30f else 36f)
                typeface = keyFont
                layoutParams = FrameLayout.LayoutParams(-1, -1)
            }
        }
        val button = makeButton(content, bg) { onPress(label) }
        if (label == "⌫") button.setOnLongClickListener { onPress("AC"); true }
        return button
    }

    private fun makeSciKey(label: String): View {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(pal.sciFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 17f)
            typeface = keyFont
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        return makeButton(tv, pal.sciBg) { onSciPress(label) }
    }

    /** Fully rounded key: the corner radius is clamped to half the shorter side, so square cells become circles. */
    private fun makeButton(content: View, bg: Int, onClick: () -> Unit): FrameLayout {
        val radius = dpf(200)
        val shape = GradientDrawable().apply { cornerRadius = radius; setColor(bg) }
        val mask = GradientDrawable().apply { cornerRadius = radius; setColor(Color.BLACK) }
        return FrameLayout(this).apply {
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            addView(content)
        }
    }

    // ---------- Menu ----------

    private fun showMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, if (Evaluator.degrees) "Switch to radians" else "Switch to degrees")
        menu.menu.add(0, 2, 1, "Clear history")
        menu.setOnMenuItemClickListener { item ->
            if (item.itemId == 1) toggleDegrees() else clearHistory()
            true
        }
        menu.show()
    }

    private fun toggleDegrees() {
        Evaluator.degrees = !Evaluator.degrees
        prefs.edit().putBoolean("deg", Evaluator.degrees).apply()
        degButton.text = if (Evaluator.degrees) "DEG" else "RAD"
        refresh()
    }

    // ---------- Scientific-key handling ----------

    private fun onSciPress(key: String) {
        if (justEvaluated) { expression = ""; justEvaluated = false }
        when (key) {
            "sin" -> expression += "sin("
            "cos" -> expression += "cos("
            "tan" -> expression += "tan("
            "ln" -> expression += "ln("
            "log" -> expression += "log("
            "√" -> expression += "√"          // shown as 5√2, no auto "×" or "("
            "x²" -> expression += "²"
            "x^y" -> expression += "^"
            "n!" -> expression += "!"
            "π" -> expression += "π"
            "e" -> expression += "e"
            "( )" -> onPress("( )")
        }
        refresh()
    }

    private fun toggleScientific() {
        sciVisible = !sciVisible
        sciPanel.visibility = if (sciVisible) View.VISIBLE else View.GONE
        degButton.visibility = if (sciVisible) View.VISIBLE else View.GONE
    }

    // ---------- History ----------

    private fun toggleHistory() {
        historyVisible = !historyVisible
        if (historyVisible) renderHistory()
        historyPanel.visibility = if (historyVisible) View.VISIBLE else View.GONE
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("entries", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split("\u0002").mapNotNull {
            val parts = it.split("\u0001")
            if (parts.size == 2) parts[0] to parts[1] else null
        }
    }

    private fun saveHistoryEntry(expr: String, result: String) {
        val entries = (listOf(expr to result) + loadHistory()).take(30)
        val raw = entries.joinToString("\u0002") { "${it.first}\u0001${it.second}" }
        prefs.edit().putString("entries", raw).apply()
    }

    private fun clearHistory() {
        prefs.edit().remove("entries").apply()
        renderHistory()
        Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        val entries = loadHistory()
        if (entries.isEmpty()) {
            historyList.addView(TextView(this).apply {
                text = "No history yet"
                setTextColor(pal.icon)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            })
            return
        }
        for ((expr, result) in entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
                isClickable = true
                setOnClickListener {
                    expression = result
                    previousExpression = expr
                    justEvaluated = true
                    toggleHistory()
                    refresh()
                }
            }
            row.addView(TextView(this).apply {
                text = group(expr)
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                gravity = Gravity.END
            })
            row.addView(TextView(this).apply {
                text = "= " + group(result)
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                gravity = Gravity.END
            })
            historyList.addView(row)
            historyList.addView(View(this).apply { setBackgroundColor(pal.divider) },
                LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    // ---------- Copy / paste ----------

    private fun copyResult() {
        if (!justEvaluated) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("result", expression.replace('−', '-')))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun pasteIntoExpression() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val sanitized = text.filter { it.isDigit() || it in "+-×÷.%()^!√" }
            .replace('-', '−')
        if (sanitized.isEmpty()) return
        if (justEvaluated) { expression = ""; justEvaluated = false }
        expression += sanitized
        refresh()
    }

    // ---------- Basic-key handling ----------

    private fun onPress(key: String) {
        errorText = null
        when (key) {
            in "0".."9" -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                expression += key   // implicit multiplication is handled by the evaluator
            }
            "." -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                val lastNumber = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!lastNumber.contains('.')) expression += if (lastNumber.isEmpty()) "0." else "."
            }
            "+", "×", "÷", "−" -> {
                justEvaluated = false
                val op = key[0]
                if (expression.isEmpty() || expression.last() == '(') {
                    if (op == '−') expression += "−"
                } else if (expression.last() in operators) {
                    expression = if (expression.length > 1 && expression[expression.length - 2] != '(')
                        expression.dropLast(1) + op
                    else if (op == '−') expression else expression.dropLast(1)
                } else {
                    expression += op
                }
            }
            "%" -> {
                justEvaluated = false
                if (expression.isNotEmpty() && (expression.last().isDigit() ||
                            expression.last() in ")%²")) expression += "%"
            }
            "( )" -> {
                justEvaluated = false
                val open = expression.count { it == '(' }
                val close = expression.count { it == ')' }
                val last = expression.lastOrNull()
                val canClose = open > close && last != null && (last.isDigit() || last in ")%²πe!")
                expression += if (canClose) ")" else "("
            }
            "⌫" -> {
                if (justEvaluated) { justEvaluated = false; previousExpression = "" }
                else expression = expression.dropLast(1)
            }
            "AC" -> { expression = ""; previousExpression = ""; justEvaluated = false }
            "=" -> {
                if (expression.isNotEmpty() && !justEvaluated) {
                    try {
                        val result = Evaluator.format(Evaluator.eval(closeParens(trimTrailingOps(expression))))
                        previousExpression = expression
                        expression = result
                        justEvaluated = true
                        saveHistoryEntry(previousExpression, expression)
                    } catch (e: ArithmeticException) {
                        errorText = "Can't divide by 0"
                    } catch (e: Exception) {
                        errorText = "Format error"
                    }
                }
            }
        }
        refresh()
    }

    private fun trimTrailingOps(s: String): String {
        var t = s
        while (t.isNotEmpty() && (t.last() in operators || t.last() == '(')) t = t.dropLast(1)
        return t
    }

    private fun closeParens(s: String): String {
        val missing = s.count { it == '(' } - s.count { it == ')' }
        return if (missing > 0) s + ")".repeat(missing) else s
    }

    // ---------- Rendering ----------

    private fun group(s: String): String =
        Regex("(\\d+)(\\.\\d*)?").replace(s) { m ->
            val int = m.groupValues[1].reversed().chunked(3).joinToString(",").reversed()
            int + m.groupValues[2]
        }

    private fun style(view: TextView, minSp: Int, maxSp: Int, color: Int) {
        view.setTextColor(color)
        view.setAutoSizeTextTypeUniformWithConfiguration(minSp, maxSp, 2, TypedValue.COMPLEX_UNIT_SP)
    }

    private fun refresh() {
        if (justEvaluated) {
            style(topView, 18, 28, pal.icon)
            style(bottomView, 32, 56, pal.text)
            topView.text = group(previousExpression) + " ="
            bottomView.text = group(expression)
        } else {
            style(topView, 32, 68, pal.text)
            style(bottomView, 18, 28, pal.result)
            val sb = SpannableStringBuilder(group(expression))
            sb.append("\u200B")
            cursorSpan.visible = true
            sb.setSpan(cursorSpan, sb.length - 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            topView.text = sb
            bottomView.text = errorText ?: preview()
        }
    }

    private fun preview(): String {
        val e = trimTrailingOps(expression)
        if (e.isEmpty() || Regex("^−?[\\d.]+$").matches(e)) return ""
        return try {
            group(Evaluator.format(Evaluator.eval(closeParens(e))))
        } catch (ex: Exception) { "" }
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (historyVisible) toggleHistory() else super.onBackPressed()
    }
}
