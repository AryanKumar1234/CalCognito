package com.example.calculator

import android.app.Activity
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/** A calculator styled after the Google (Pixel) Calculator. */
class MainActivity : Activity() {

    // ---- colour palette (light / dark) ----
    private class Palette(
        val bg: Int, val panel: Int, val text: Int, val textDim: Int,
        val numBg: Int, val numFg: Int,
        val opBg: Int, val opFg: Int,
        val eqBg: Int, val eqFg: Int,
        val clearFg: Int, val ripple: Int
    )

    private val light = Palette(
        bg = c("#F8F9FF"), panel = c("#E9EDF6"), text = c("#1B1B1F"), textDim = c("#5F6368"),
        numBg = c("#FFFFFF"), numFg = c("#1B1B1F"),
        opBg = c("#D3E3FD"), opFg = c("#0B57D0"),
        eqBg = c("#0B57D0"), eqFg = c("#FFFFFF"),
        clearFg = c("#B3261E"), ripple = c("#33000000")
    )
    private val dark = Palette(
        bg = c("#121316"), panel = c("#1D1F24"), text = c("#E3E3E8"), textDim = c("#9AA0A6"),
        numBg = c("#2C2E34"), numFg = c("#E3E3E8"),
        opBg = c("#2E4067"), opFg = c("#D3E3FD"),
        eqBg = c("#A8C7FA"), eqFg = c("#062E6F"),
        clearFg = c("#F2B8B5"), ripple = c("#33FFFFFF")
    )
    private fun c(hex: String) = Color.parseColor(hex)
    private lateinit var pal: Palette

    // ---- views / state ----
    private lateinit var topView: TextView      // expression (or previous expression after "=")
    private lateinit var bottomView: TextView   // live preview (or result after "=")

    private var expression = ""
    private var previousExpression = ""
    private var justEvaluated = false
    private var errorText: String? = null

    private val operators = setOf('+', '−', '×', '÷')

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
                Configuration.UI_MODE_NIGHT_YES
        pal = if (night) dark else light

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.panel
        if (!night) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        setContentView(buildUi())

        expression = savedInstanceState?.getString("expr") ?: ""
        previousExpression = savedInstanceState?.getString("prev") ?: ""
        justEvaluated = savedInstanceState?.getBoolean("done") ?: false
        refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("expr", expression)
        outState.putString("prev", previousExpression)
        outState.putBoolean("done", justEvaluated)
    }

    // ---------- UI ----------

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * resources.displayMetrics.density

    private fun buildUi(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
        }

        // Display area
        val display = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.BOTTOM or Gravity.END
            setPadding(dp(24), dp(8), dp(24), dp(20))
        }
        topView = TextView(this).apply {
            gravity = Gravity.END or Gravity.BOTTOM
            maxLines = 2
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        bottomView = TextView(this).apply {
            gravity = Gravity.END or Gravity.CENTER_VERTICAL
            maxLines = 1
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
        }
        display.addView(topView, LinearLayout.LayoutParams(-1, 0, 1f))
        display.addView(bottomView, LinearLayout.LayoutParams(-1, dp(72)))
        root.addView(display, LinearLayout.LayoutParams(-1, 0, 2f))

        // Keypad panel with rounded top corners
        val panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(16), dp(12), dp(12))
            background = GradientDrawable().apply {
                setColor(pal.panel)
                val r = dpf(32)
                cornerRadii = floatArrayOf(r, r, r, r, 0f, 0f, 0f, 0f)
            }
        }
        val rows = listOf(
            listOf("AC", "( )", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "−"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "⌫", "=")
        )
        for (row in rows) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (label in row) {
                line.addView(makeKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply {
                    setMargins(dp(5), dp(5), dp(5), dp(5))
                })
            }
            panel.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
        }
        root.addView(panel, LinearLayout.LayoutParams(-1, 0, 3.4f))
        return root
    }

    private fun makeKey(label: String): TextView {
        val isOp = label in setOf("÷", "×", "−", "+", "%", "( )")
        val bg: Int; val fg: Int
        when {
            label == "=" -> { bg = pal.eqBg; fg = pal.eqFg }
            isOp -> { bg = pal.opBg; fg = pal.opFg }
            label == "AC" -> { bg = pal.numBg; fg = pal.clearFg }
            label == "⌫" -> { bg = pal.numBg; fg = pal.numFg }
            else -> { bg = pal.numBg; fg = pal.numFg }
        }
        val radius = dpf(28)
        val shape = GradientDrawable().apply { cornerRadius = radius; setColor(bg) }
        val mask = GradientDrawable().apply { cornerRadius = radius; setColor(Color.BLACK) }
        return TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(fg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, if (label == "AC") 24f else 32f)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            isClickable = true
            isFocusable = true
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
            setOnClickListener { onPress(label) }
            if (label == "⌫") setOnLongClickListener { onPress("AC"); true }
        }
    }

    // ---------- Input handling ----------

    private fun onPress(key: String) {
        errorText = null
        when (key) {
            in "0".."9" -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                if (expression.isNotEmpty() && expression.last() == ')') expression += "×"
                expression += key
            }
            "." -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                val lastNumber = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!lastNumber.contains('.')) expression += if (lastNumber.isEmpty()) "0." else "."
            }
            "+", "×", "÷", "−" -> {
                justEvaluated = false
                val op = key[0]
                if (expression.isEmpty() || expression.last() == '(') {
                    if (op == '−') expression += "−"
                } else if (expression.last() in operators) {
                    expression = if (expression.length > 1 && expression[expression.length - 2] != '(')
                        expression.dropLast(1) + op
                    else if (op == '−') expression else expression.dropLast(1)
                } else {
                    expression += op
                }
            }
            "%" -> {
                justEvaluated = false
                if (expression.isNotEmpty() && (expression.last().isDigit() ||
                            expression.last() == '%' || expression.last() == ')')) expression += "%"
            }
            "( )" -> {
                justEvaluated = false
                val open = expression.count { it == '(' }
                val close = expression.count { it == ')' }
                val last = expression.lastOrNull()
                val canClose = open > close && last != null &&
                        (last.isDigit() || last == ')' || last == '%')
                expression += if (canClose) ")" else {
                    if (last != null && (last.isDigit() || last == ')' || last == '%')) "×(" else "("
                }
            }
            "⌫" -> {
                if (justEvaluated) { justEvaluated = false; previousExpression = "" }
                else expression = expression.dropLast(1)
            }
            "AC" -> { expression = ""; previousExpression = ""; justEvaluated = false }
            "=" -> {
                if (expression.isNotEmpty() && !justEvaluated) {
                    try {
                        val result = Evaluator.format(Evaluator.eval(closeParens(trimTrailingOps(expression))))
                        previousExpression = expression
                        expression = result
                        justEvaluated = true
                    } catch (e: ArithmeticException) {
                        errorText = "Can't divide by 0"
                    } catch (e: Exception) {
                        errorText = "Format error"
                    }
                }
            }
        }
        refresh()
    }

    private fun trimTrailingOps(s: String): String {
        var t = s
        while (t.isNotEmpty() && (t.last() in operators || t.last() == '(')) t = t.dropLast(1)
        return t
    }

    private fun closeParens(s: String): String {
        val missing = s.count { it == '(' } - s.count { it == ')' }
        return if (missing > 0) s + ")".repeat(missing) else s
    }

    // ---------- Rendering ----------

    /** Adds thousands separators to every number in the expression. */
    private fun group(s: String): String =
        Regex("(\\d+)(\\.\\d*)?").replace(s) { m ->
            val int = m.groupValues[1].reversed().chunked(3).joinToString(",").reversed()
            int + m.groupValues[2]
        }

    private fun style(view: TextView, minSp: Int, maxSp: Int, color: Int) {
        view.setTextColor(color)
        view.setAutoSizeTextTypeUniformWithConfiguration(minSp, maxSp, 2, TypedValue.COMPLEX_UNIT_SP)
    }

    private fun refresh() {
        if (justEvaluated) {
            // Pixel style: old expression small on top, big result below
            style(topView, 18, 28, pal.textDim)
            style(bottomView, 32, 56, pal.text)
            topView.text = group(previousExpression) + " ="
            bottomView.text = group(expression)
        } else {
            style(topView, 28, 56, pal.text)
            style(bottomView, 20, 32, pal.textDim)
            topView.text = group(expression)
            bottomView.text = errorText ?: preview()
        }
    }

    private fun preview(): String {
        val e = trimTrailingOps(expression)
        if (e.isEmpty() || Regex("^−?[\\d.]+$").matches(e)) return ""
        return try {
            group(Evaluator.format(Evaluator.eval(closeParens(e))))
        } catch (ex: Exception) { "" }
    }
}
