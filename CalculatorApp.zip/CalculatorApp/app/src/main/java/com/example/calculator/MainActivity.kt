package com.example.calculator

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.app.Dialog
import android.app.RecoverableSecurityException
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.ColorStateList
import android.content.res.Configuration
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.media.ExifInterface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextPaint
import android.text.TextUtils
import android.text.method.LinkMovementMethod
import android.text.style.ClickableSpan
import android.text.style.ForegroundColorSpan
import android.text.style.ReplacementSpan
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.CheckBox
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.MediaController
import android.widget.OverScroller
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.annotation.RequiresApi
import androidx.core.content.FileProvider
import java.io.ByteArrayInputStream
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class Palette(
        val bg: Int, val text: Int, val icon: Int,
        val numBg: Int, val numFg: Int,
        val opBg: Int, val opFg: Int,
        val acBg: Int, val acFg: Int,
        val eqBg: Int, val eqFg: Int,
        val sciBg: Int, val sciFg: Int,
        val result: Int, val cursor: Int,
        val clearFg: Int, val ripple: Int, val divider: Int
    )

    private fun c(hex: String) = Color.parseColor(hex)

    private val light = Palette(
        bg = c("#FFF8F6"), text = c("#231917"), icon = c("#53433F"),
        numBg = c("#F1DFDA"), numFg = c("#231917"),
        opBg = c("#E7BDB2"), opFg = c("#442A22"),
        acBg = c("#FFDBD2"), acFg = c("#723523"),
        eqBg = c("#6B5E2F"), eqFg = c("#FFFFFF"),
        sciBg = c("#F1DFDA"), sciFg = c("#442A22"),
        result = c("#6B5E2F"), cursor = c("#9A4026"),
        clearFg = c("#BA1A1A"), ripple = c("#33000000"), divider = c("#E7D6D1")
    )
    private val dark = Palette(
        bg = c("#1C110D"), text = c("#EEE0DD"), icon = c("#D7C3BD"),
        numBg = c("#40332D"), numFg = c("#EEE0DD"),
        opBg = c("#5D4038"), opFg = c("#FFDBD2"),
        acBg = c("#723523"), acFg = c("#FFDBD2"),
        eqBg = c("#DAC58E"), eqFg = c("#3B2F05"),
        sciBg = c("#40332D"), sciFg = c("#FFDBD2"),
        result = c("#DAC58E"), cursor = c("#FFB5A2"),
        clearFg = c("#FFB5A2"), ripple = c("#33FFFFFF"), divider = c("#3A2C27")
    )
    private lateinit var pal: Palette

    private class CursorSpan(
        private val widthPx: Int, private val barPx: Int, private val color: Int
    ) : ReplacementSpan() {
        var visible = true
        override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int = widthPx
        override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
            if (!visible) return
            val p = Paint(paint)
            p.color = color
            p.style = Paint.Style.FILL
            val left = x + (widthPx - barPx) / 2f
            canvas.drawRect(left, top.toFloat(), left + barPx, bottom.toFloat(), p)
        }
    }

    private lateinit var topScroll: HorizontalScrollView
    private lateinit var topView: TextView
    private lateinit var bottomView: TextView
    private lateinit var historyPanel: LinearLayout
    private lateinit var historyList: LinearLayout
    private lateinit var vaultPanel: LinearLayout
    private lateinit var vaultFabHost: FrameLayout
    private lateinit var vaultFilesList: LinearLayout
    private lateinit var vaultTitle: TextView
    private lateinit var vaultChipsRow: LinearLayout
    private var currentFolder: String? = null
    private var vaultFilter = 0   // 0 all, 1 images, 2 videos, 3 files
    private var vaultSort = 0     // 0 A-Z, 1 newest, 2 largest
    private var expandBtn: ImageView? = null
    private lateinit var radKey: TextView
    private val sciLines = mutableListOf<View>()
    private val sciKeys = mutableMapOf<String, TextView>()
    private val keyTexts = mutableListOf<Pair<TextView, Float>>()
    private var backspaceIcon: ImageView? = null
    private var inverse = false

    private val cursorSpan by lazy { CursorSpan(dp(8), dp(2), pal.cursor) }
    private val handler = Handler(Looper.getMainLooper())
    private val blink = object : Runnable {
        override fun run() {
            cursorSpan.visible = !cursorSpan.visible
            topView.invalidate()
            handler.postDelayed(this, 530)
        }
    }

    private var expression = ""
    private var previousExpression = ""
    private var justEvaluated = false
    private var errorText: String? = null
    private var sciVisible = false
    private var historyVisible = false
    private var vaultVisible = false

    // Vault state
    private companion object {
        const val REQ_PICK = 1001
        const val REQ_PERM = 1002
        const val REQ_DELETE_BATCH = 9999
        const val REQ_DELETE_LEGACY = 9998
        const val REPO_URL = "https://github.com/AryanKumar1234/CalCognito"
        const val PROFILE_URL = "https://github.com/AryanKumar1234"
    }
    /** True after the old password was confirmed by a 4-second hold; the next "=" saves the new one. */
    private var changeMode = false
    private var holdFired = false
    /** True while we deliberately open a picker/viewer/system dialog, so the vault stays open on return. */
    private var leavingForTask = false
    /** True while a decrypted temp file is being shown in another app (cleared when we come back). */
    private var externalViewing = false
    private var afterPermission: (() -> Unit)? = null
    private var viewerDialog: Dialog? = null
    private var aboutDialog: Dialog? = null
    private var lastDisplayWidth = 0
    private val thumbCache = ConcurrentHashMap<String, Bitmap>()
    private val thumbExecutor = Executors.newSingleThreadExecutor()
    private val migrateExecutor = Executors.newSingleThreadExecutor()
    private val migrating = ConcurrentHashMap.newKeySet<String>()
    private var hideHidden = 0
    private var hideFailed = 0
    private var hideNotRemoved = 0
    private var batchDeleteCount = 0
    private val legacyDeleteQueue = mutableListOf<Uri>()
    private var legacyCurrent: Uri? = null

    private var currentPrecision = 120
    private var isInfiniteResult = false
    private var activeEvalExpr = ""
    private var cachedRawResult = ""
    private var scrollOffsetPx = 0f
    private lateinit var scroller: OverScroller
    private lateinit var gestureDetector: GestureDetector

    private val flingRunnable = object : Runnable {
        override fun run() {
            if (scroller.computeScrollOffset()) {
                scrollOffsetPx = scroller.currX.toFloat().coerceAtLeast(0f)
                renderBottomResult()
                bottomView.postOnAnimation(this)
            }
        }
    }

    private val operators = setOf('+', '−', '×', '÷')
    private val prefs by lazy { getSharedPreferences("calc_history", Context.MODE_PRIVATE) }

    private fun loadFont(file: String, fallback: Typeface): Typeface = try {
        Typeface.createFromAsset(assets, "fonts/$file")
    } catch (e: Exception) { fallback }

    private val displayFont: Typeface by lazy { loadFont("GoogleSansFlex-Display.ttf", Typeface.create("sans-serif-light", Typeface.NORMAL)) }
    private val keyFont: Typeface by lazy { loadFont("GoogleSansFlex-Key.ttf", Typeface.create("sans-serif-medium", Typeface.NORMAL)) }
    private val opFont: Typeface by lazy { loadFont("GoogleSansFlex-Op.ttf", Typeface.create("sans-serif-medium", Typeface.NORMAL)) }
    private val sciFont: Typeface by lazy { loadFont("GoogleSansFlex-Label.ttf", Typeface.create("sans-serif", Typeface.NORMAL)) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val night = (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES
        pal = if (night) dark else light
        Evaluator.degrees = prefs.getBoolean("deg", true)

        window.statusBarColor = pal.bg
        window.navigationBarColor = pal.bg
        if (!night) {
            @Suppress("DEPRECATION")
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        }

        VaultManager.clearTemp(applicationContext)
        VaultManager.cleanStaleMigrations(applicationContext)
        scroller = OverScroller(this)
        setContentView(buildUi())
        setupResultScrollGesture()

        expression = savedInstanceState?.getString("expr") ?: ""
        previousExpression = savedInstanceState?.getString("prev") ?: ""
        justEvaluated = savedInstanceState?.getBoolean("done") ?: false
        refresh()
    }

    override fun onResume() {
        super.onResume()
        VaultManager.applySecurityFlags(this)
        handler.removeCallbacks(blink)
        handler.postDelayed(blink, 530)
        if (externalViewing) {
            externalViewing = false
            VaultManager.clearTemp(applicationContext)
        }
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(blink)
        // Picker / viewer / system dialogs we opened ourselves must not lock the vault.
        if (leavingForTask) {
            leavingForTask = false
            return
        }
        if (changeMode) {
            changeMode = false
            expression = ""
            justEvaluated = false
            refresh()
        }
        viewerDialog?.dismiss()
        aboutDialog?.dismiss()
        if (vaultVisible) {
            toggleVault()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        thumbExecutor.shutdownNow()
        migrateExecutor.shutdownNow()
        viewerDialog?.dismiss()
        VaultManager.clearTemp(applicationContext)
    }

    /** Rotation is handled in place (see manifest configChanges) so an open vault/history is not closed. */
    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        rebuildUi()
    }

    private fun rebuildUi() {
        sciLines.clear(); sciKeys.clear(); keyTexts.clear()
        expandBtn = null; backspaceIcon = null
        lastDisplayWidth = 0
        setContentView(buildUi())
        setupResultScrollGesture()
        if (sciVisible) {
            for (line in sciLines) line.visibility = View.VISIBLE
            expandBtn?.setImageResource(R.drawable.ic_unfold_less)
        }
        updateSciLabels()
        if (historyVisible) { renderHistory(); historyPanel.visibility = View.VISIBLE }
        if (vaultVisible) { renderVaultFiles(); vaultPanel.visibility = View.VISIBLE; vaultFabHost.visibility = View.VISIBLE }
        refresh()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putString("expr", expression)
        outState.putString("prev", previousExpression)
        outState.putBoolean("done", justEvaluated)
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Int) = v * resources.displayMetrics.density

    private fun setupResultScrollGesture() {
        gestureDetector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDown(e: MotionEvent): Boolean {
                scroller.forceFinished(true)
                bottomView.removeCallbacks(flingRunnable)
                return true
            }
            override fun onScroll(e1: MotionEvent?, e2: MotionEvent, distanceX: Float, distanceY: Float): Boolean {
                if (!isInfiniteResult || errorText != null) return false
                scrollOffsetPx = (scrollOffsetPx + distanceX).coerceAtLeast(0f)
                renderBottomResult()
                return true
            }
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, velocityX: Float, velocityY: Float): Boolean {
                if (!isInfiniteResult || errorText != null) return false
                scroller.fling(scrollOffsetPx.toInt(), 0, (-velocityX).toInt(), 0, 0, Int.MAX_VALUE / 4, 0, 0)
                bottomView.postOnAnimation(flingRunnable)
                return true
            }
            override fun onLongPress(e: MotionEvent) { copyResult() }
        })
        bottomView.setOnTouchListener { _, event -> gestureDetector.onTouchEvent(event); true }
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)
        val isLandscape = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE

        if (isLandscape) {
            val mainLayout = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundColor(pal.bg)
                fitsSystemWindows = true
            }
            val leftPane = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(4), dp(12), dp(8))
            }
            val topBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }
            topBar.addView(iconButton(R.drawable.ic_history, "History") { toggleHistory() }, LinearLayout.LayoutParams(dp(44), dp(44)))
            topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            topBar.addView(iconButton(R.drawable.ic_more_vert, "More options") { showMenu(it) }, LinearLayout.LayoutParams(dp(44), dp(44)))
            leftPane.addView(topBar, LinearLayout.LayoutParams(-1, -2))

            val display = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.END
                setPadding(dp(8), dp(4), dp(8), dp(4))
            }
            topView = TextView(this).apply {
                gravity = Gravity.END or Gravity.BOTTOM
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
                setOnLongClickListener { pasteIntoExpression(); true }
            }
            topScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(topView, FrameLayout.LayoutParams(-2, -1))
            }
            bottomView = TextView(this).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
            }
            display.addView(topScroll, LinearLayout.LayoutParams(-1, 0, 1f))
            display.addView(bottomView, LinearLayout.LayoutParams(-1, dp(56)))
            display.addOnLayoutChangeListener { _, l, _, r, _, _, _, _, _ ->
                if (r - l != lastDisplayWidth) {
                    lastDisplayWidth = r - l
                    display.post { refresh() }
                }
            }
            leftPane.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))

            val sciRows = listOf(
                listOf("√", "π", "^", "!"),
                listOf(if (Evaluator.degrees) "Rad" else "Deg", "sin", "cos", "tan"),
                listOf("Inv", "e", "ln", "log")
            )
            for (row in sciRows) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (label in row) {
                    line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, dp(38), 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                leftPane.addView(line, LinearLayout.LayoutParams(-1, -2))
            }
            mainLayout.addView(leftPane, LinearLayout.LayoutParams(0, -1, 1.15f))

            val rightPane = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(4), dp(8), dp(8), dp(8))
            }
            val basicRows = listOf(
                listOf("AC", "( )", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+"),
                listOf("0", ".", "⌫", "=")
            )
            for (row in basicRows) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (label in row) {
                    line.addView(makeKey(label), LinearLayout.LayoutParams(0, 0, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                rightPane.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }
            mainLayout.addView(rightPane, LinearLayout.LayoutParams(0, -1, 1f))
            root.addView(mainLayout, FrameLayout.LayoutParams(-1, -1))
        } else {
            val column = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setBackgroundColor(pal.bg)
                fitsSystemWindows = true
            }
            val topBar = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(6), dp(3), 0)
            }
            topBar.addView(iconButton(R.drawable.ic_history, "History") { toggleHistory() }, LinearLayout.LayoutParams(dp(48), dp(48)))
            topBar.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            topBar.addView(iconButton(R.drawable.ic_more_vert, "More options") { showMenu(it) }, LinearLayout.LayoutParams(dp(48), dp(48)))
            column.addView(topBar, LinearLayout.LayoutParams(-1, -2))

            val display = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.BOTTOM or Gravity.END
                setPadding(dp(24), dp(8), dp(24), 0)
            }
            topView = TextView(this).apply {
                gravity = Gravity.END or Gravity.BOTTOM
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
                setOnLongClickListener { pasteIntoExpression(); true }
            }
            topScroll = HorizontalScrollView(this).apply {
                isHorizontalScrollBarEnabled = false
                isFillViewport = true
                overScrollMode = View.OVER_SCROLL_NEVER
                addView(topView, FrameLayout.LayoutParams(-2, -1))
            }
            bottomView = TextView(this).apply {
                gravity = Gravity.END or Gravity.CENTER_VERTICAL
                maxLines = 1
                setSingleLine(true)
                typeface = displayFont
            }
            display.addView(topScroll, LinearLayout.LayoutParams(-1, 0, 1f))
            display.addView(bottomView, LinearLayout.LayoutParams(-1, dp(72)))
            column.addView(display, LinearLayout.LayoutParams(-1, 0, 1f))

            val expBtn = iconButton(R.drawable.ic_unfold_more, "Scientific functions") { toggleScientific() }
            expandBtn = expBtn
            val toolRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(4), dp(24), dp(12))
            }
            toolRow.addView(expBtn, LinearLayout.LayoutParams(dp(48), dp(48)))
            column.addView(toolRow, LinearLayout.LayoutParams(-1, -2))

            val dm = resources.displayMetrics
            val cell = (dm.widthPixels - dp(4)) / 4
            val keypadH = minOf(cell * 5, (dm.heightPixels * 0.575f).toInt())

            val keypad = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(2), 0, dp(2), 0)
            }
            val sciRows = listOf(
                listOf("√", "π", "^", "!"),
                listOf(if (Evaluator.degrees) "Rad" else "Deg", "sin", "cos", "tan"),
                listOf("Inv", "e", "ln", "log")
            )
            for (row in sciRows) {
                val line = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    visibility = View.GONE
                }
                for (label in row) {
                    line.addView(makeSciKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                sciLines.add(line)
                keypad.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }

            val basicRows = listOf(
                listOf("AC", "( )", "%", "÷"),
                listOf("7", "8", "9", "×"),
                listOf("4", "5", "6", "−"),
                listOf("1", "2", "3", "+"),
                listOf("0", ".", "⌫", "=")
            )
            for (row in basicRows) {
                val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                for (label in row) {
                    line.addView(makeKey(label), LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(2), dp(2), dp(2), dp(2)) })
                }
                keypad.addView(line, LinearLayout.LayoutParams(-1, 0, 1f))
            }
            column.addView(keypad, LinearLayout.LayoutParams(-1, keypadH))
            root.addView(column, FrameLayout.LayoutParams(-1, -1))
        }

        // History overlay panel
        historyPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
        }
        val headerTop = if (isLandscape) dp(4) else dp(20)
        val histHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), headerTop, dp(16), dp(8))
            gravity = Gravity.CENTER_VERTICAL
        }
        histHeader.addView(TextView(this).apply {
            text = "History"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
        }, LinearLayout.LayoutParams(0, -2, 1f))
        histHeader.addView(TextView(this).apply {
            text = "Clear"
            setTextColor(pal.clearFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { clearHistory() }
        })
        histHeader.addView(TextView(this).apply {
            text = "Close"
            setTextColor(pal.sciFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { toggleHistory() }
        })
        historyPanel.addView(histHeader)
        val hScroll = ScrollView(this)
        historyList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        hScroll.addView(historyList, LinearLayout.LayoutParams(-1, -2))
        historyPanel.addView(hScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(historyPanel, FrameLayout.LayoutParams(-1, -1))

        // Vault overlay panel
        vaultPanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setBackgroundColor(pal.bg)
            fitsSystemWindows = true
        }
        val vHeader = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), headerTop, dp(8), dp(8))
            gravity = Gravity.CENTER_VERTICAL
        }
        vaultTitle = TextView(this).apply {
            text = "Secure Vault"
            setTextColor(pal.text)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(0, dp(8), dp(8), dp(8))
            setOnClickListener {
                if (currentFolder != null) {
                    currentFolder = null
                    renderVaultFiles()
                }
            }
        }
        vHeader.addView(vaultTitle, LinearLayout.LayoutParams(0, -2, 1f))
        vHeader.addView(TextView(this).apply {
            text = "Close"
            setTextColor(pal.sciFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
            setPadding(dp(12), dp(8), dp(12), dp(8))
            setOnClickListener { toggleVault() }
        })
        vHeader.addView(
            iconButton(R.drawable.ic_info, "About") { showAbout() },
            LinearLayout.LayoutParams(dp(40), dp(40)).apply { leftMargin = dp(4) }
        )
        vaultPanel.addView(vHeader)
        vaultChipsRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(dp(16), dp(4), dp(8), dp(8))
        }
        vaultPanel.addView(HorizontalScrollView(this).apply {
            isHorizontalScrollBarEnabled = false
            addView(vaultChipsRow)
        }, LinearLayout.LayoutParams(-1, -2))
        val vScroll = ScrollView(this)
        vaultFilesList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        vScroll.addView(vaultFilesList, LinearLayout.LayoutParams(-1, -2))
        vaultPanel.addView(vScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(vaultPanel, FrameLayout.LayoutParams(-1, -1))

        // Floating "add files" button (bottom right) shown while the vault is open
        val fabShape = GradientDrawable().apply { cornerRadius = dpf(20); setColor(pal.acBg) }
        val fabMask = GradientDrawable().apply { cornerRadius = dpf(20); setColor(Color.BLACK) }
        val fab = FrameLayout(this).apply {
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), fabShape, fabMask)
            elevation = dpf(6)
            isClickable = true
            isFocusable = true
            contentDescription = "Add files"
            setOnClickListener { pickFileForVault() }
            addView(ImageView(this@MainActivity).apply {
                setImageResource(R.drawable.ic_add)
                setColorFilter(pal.acFg)
            }, FrameLayout.LayoutParams(dp(32), dp(32), Gravity.CENTER))
        }
        vaultFabHost = FrameLayout(this).apply {
            visibility = View.GONE
            fitsSystemWindows = true
            addView(fab, FrameLayout.LayoutParams(dp(64), dp(64), Gravity.BOTTOM or Gravity.END).apply {
                setMargins(0, 0, dp(16), dp(16))
            })
        }
        root.addView(vaultFabHost, FrameLayout.LayoutParams(-1, -1))
        vaultFilesList.setPadding(0, 0, 0, dp(96))

        return root
    }

    private fun iconButton(res: Int, desc: String, onClick: (View) -> Unit): ImageView {
        val mask = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.BLACK) }
        return ImageView(this).apply {
            setImageResource(res)
            setColorFilter(pal.icon)
            scaleType = ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(10), dp(10), dp(10), dp(10))
            contentDescription = desc
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), null, mask)
            setOnClickListener { onClick(it) }
        }
    }

    private fun makeKey(label: String): View {
        val isOp = label in setOf("÷", "×", "−", "+", "%", "( )")
        val bg: Int
        val fg: Int
        when {
            label == "=" -> { bg = pal.eqBg; fg = pal.eqFg }
            label == "AC" -> { bg = pal.acBg; fg = pal.acFg }
            isOp -> { bg = pal.opBg; fg = pal.opFg }
            else -> { bg = pal.numBg; fg = pal.numFg }
        }
        val content: View = if (label == "⌫") {
            ImageView(this).apply {
                setImageResource(R.drawable.ic_backspace)
                setColorFilter(fg)
                layoutParams = FrameLayout.LayoutParams(dp(28), dp(28), Gravity.CENTER)
                backspaceIcon = this
            }
        } else {
            val bigOp = label in setOf("÷", "×", "−", "+", "=")
            val size = when {
                label == "AC" -> 30f
                bigOp -> 40f
                else -> 34f
            }
            TextView(this).apply {
                text = label
                gravity = Gravity.CENTER
                setTextColor(fg)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
                typeface = if (bigOp) opFont else keyFont
                includeFontPadding = false
                layoutParams = FrameLayout.LayoutParams(-1, -1)
                keyTexts.add(this to size)
            }
        }
        val button = makeButton(content, bg) { onPress(label) }
        if (label == "=") {
            // Hold "=" for 4 seconds: set the password / start changing it (see onEqualsHeld).
            val holdRunnable = Runnable {
                holdFired = true
                button.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onEqualsHeld()
            }
            button.setOnTouchListener { v, ev ->
                when (ev.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        holdFired = false
                        handler.postDelayed(holdRunnable, 4000)
                    }
                    MotionEvent.ACTION_MOVE -> {
                        if (ev.x < 0f || ev.y < 0f || ev.x > v.width || ev.y > v.height) handler.removeCallbacks(holdRunnable)
                    }
                    MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> handler.removeCallbacks(holdRunnable)
                }
                false
            }
            // A completed 4-second hold must not also count as a normal "=" press on release.
            button.setOnClickListener {
                if (holdFired) holdFired = false else onPress("=")
            }
        }
        if (label == "⌫") button.setOnLongClickListener { onPress("AC"); true }
        return button
    }

    private fun makeSciKey(label: String): View {
        val tv = TextView(this).apply {
            text = label
            gravity = Gravity.CENTER
            setTextColor(pal.opFg)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
            typeface = sciFont
            includeFontPadding = false
            layoutParams = FrameLayout.LayoutParams(-1, -1)
        }
        sciKeys[label] = tv
        if (label == "Rad" || label == "Deg") radKey = tv
        return makeButton(tv, pal.opBg) { onSciPress(label) }
    }

    private fun makeButton(content: View, bg: Int, onClick: () -> Unit): FrameLayout {
        val radius = dpf(200)
        val shape = GradientDrawable().apply { cornerRadius = radius; setColor(bg) }
        val mask = GradientDrawable().apply { cornerRadius = radius; setColor(Color.BLACK) }
        return FrameLayout(this).apply {
            background = RippleDrawable(ColorStateList.valueOf(pal.ripple), shape, mask)
            isClickable = true
            isFocusable = true
            setOnClickListener { onClick() }
            addView(content)
        }
    }

    private fun showMenu(anchor: View) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, if (Evaluator.degrees) "Switch to radians" else "Switch to degrees")
        menu.menu.add(0, 2, 1, "Clear history")
        menu.setOnMenuItemClickListener { item ->
            if (item.itemId == 1) toggleDegrees() else clearHistory()
            true
        }
        menu.show()
    }

    private fun toggleDegrees() {
        Evaluator.degrees = !Evaluator.degrees
        prefs.edit().putBoolean("deg", Evaluator.degrees).apply()
        radKey.text = if (Evaluator.degrees) "Rad" else "Deg"
        refresh()
    }

    private fun onSciPress(key: String) {
        if (key == "Rad" || key == "Deg") { toggleDegrees(); return }
        if (key == "Inv") { inverse = !inverse; updateSciLabels(); return }
        val inv = inverse
        val postfix = key == "^" || key == "!" || (key == "√" && inv)
        if (justEvaluated) {
            if (!postfix) expression = ""
            justEvaluated = false
        }
        when (key) {
            "√" -> expression += if (inv) "²" else "√"
            "π" -> expression += "π"
            "^" -> expression += "^"
            "!" -> expression += "!"
            "e" -> expression += "e"
            "sin" -> expression += if (inv) "asin(" else "sin("
            "cos" -> expression += if (inv) "acos(" else "cos("
            "tan" -> expression += if (inv) "atan(" else "tan("
            "ln" -> expression += if (inv) "e^(" else "ln("
            "log" -> expression += if (inv) withTimes("10^(") else "log("
        }
        if (inverse && key != "π" && key != "^" && key != "!" && key != "e") {
            inverse = false
            updateSciLabels()
        }
        refresh()
    }

    private fun withTimes(token: String): String =
        if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²!πe.")) "×$token" else token

    private fun updateSciLabels() {
        sciKeys["sin"]?.text = if (inverse) "sin⁻¹" else "sin"
        sciKeys["cos"]?.text = if (inverse) "cos⁻¹" else "cos"
        sciKeys["tan"]?.text = if (inverse) "tan⁻¹" else "tan"
        sciKeys["ln"]?.text = if (inverse) "eˣ" else "ln"
        sciKeys["log"]?.text = if (inverse) "10ˣ" else "log"
        sciKeys["√"]?.text = if (inverse) "x²" else "√"
        sciKeys["Inv"]?.typeface = if (inverse) Typeface.DEFAULT_BOLD else sciFont
    }

    private fun toggleScientific() {
        sciVisible = !sciVisible
        for (line in sciLines) line.visibility = if (sciVisible) View.VISIBLE else View.GONE
        expandBtn?.setImageResource(if (sciVisible) R.drawable.ic_unfold_less else R.drawable.ic_unfold_more)
    }

    private fun toggleHistory() {
        historyVisible = !historyVisible
        if (historyVisible) renderHistory()
        historyPanel.visibility = if (historyVisible) View.VISIBLE else View.GONE
    }

    private fun toggleVault() {
        vaultVisible = !vaultVisible
        if (vaultVisible) {
            renderVaultFiles()
        } else {
            thumbCache.clear()
            currentFolder = null
            vaultFilter = 0
            viewerDialog?.dismiss()
        }
        vaultPanel.visibility = if (vaultVisible) View.VISIBLE else View.GONE
        vaultFabHost.visibility = if (vaultVisible) View.VISIBLE else View.GONE
    }

    private fun openUrl(url: String) {
        leavingForTask = true   // keep the vault open when we come back from the browser
        try {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
        } catch (e: ActivityNotFoundException) {
            leavingForTask = false
            Toast.makeText(this, "No app found to open this link", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showAbout() {
        val sb = SpannableStringBuilder()
        fun link(text: String, url: String) {
            val start = sb.length
            sb.append(text)
            sb.setSpan(object : ClickableSpan() {
                override fun onClick(widget: View) { openUrl(url) }
                override fun updateDrawState(ds: TextPaint) {
                    ds.color = pal.result
                    ds.isUnderlineText = true
                }
            }, start, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        sb.append("How to Use → ")
        link("CalCognito", REPO_URL)
        sb.append("\n\nCreated by The AryanOnion · ")
        link("GitHub", PROFILE_URL)

        val body = TextView(this).apply {
            text = sb
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            setTextColor(pal.text)
            setLineSpacing(0f, 1.2f)
            movementMethod = LinkMovementMethod.getInstance()
            highlightColor = Color.TRANSPARENT
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(8), dp(24), 0)
            addView(body)
        }
        aboutDialog?.dismiss()
        aboutDialog = AlertDialog.Builder(this)
            .setTitle("About")
            .setView(box)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun isValidPin(s: String) = s.length >= 4 && s.all { it.isDigit() }

    /** Called when "=" has been held for 4 seconds. */
    private fun onEqualsHeld() {
        if (changeMode || justEvaluated) return
        if (!VaultManager.isPinSet(this)) {
            if (isValidPin(expression)) {
                VaultManager.setPin(this, expression)
                expression = ""
                refresh()
                Toast.makeText(this, "Password set", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Type at least 4 digits, then hold = for 4 seconds", Toast.LENGTH_LONG).show()
            }
        } else if (VaultManager.checkPin(this, expression)) {
            // Old password confirmed: clear it and wait for the new one (saved with the next "=").
            expression = ""
            changeMode = true
            refresh()
        }
        // Wrong password while one is set: do nothing, so nothing reveals the vault exists.
    }

    private fun getFileName(uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            val cursor = contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            try {
                if (cursor != null && cursor.moveToFirst()) {
                    val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx != -1) result = cursor.getString(idx)
                }
            } finally {
                cursor?.close()
            }
        }
        if (result == null) {
            result = uri.path
            val cut = result?.lastIndexOf('/')
            if (cut != -1 && cut != null) {
                result = result?.substring(cut + 1)
            }
        }
        return result
    }

    // ====================================================================== Vault: hide

    private fun withStoragePermission(action: () -> Unit) {
        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.P &&
            checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED
        ) {
            afterPermission = action
            leavingForTask = true
            requestPermissions(arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE), REQ_PERM)
        } else {
            action()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_PERM) {
            val action = afterPermission
            afterPermission = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) {
                action?.invoke()
            } else {
                Toast.makeText(this, "Storage permission is needed to move files", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun pickFileForVault() = withStoragePermission {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
        }
        leavingForTask = true
        try {
            startActivityForResult(intent, REQ_PICK)
        } catch (e: Exception) {
            leavingForTask = false
            Toast.makeText(this, "No file picker available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun collectUris(data: Intent): List<Uri> {
        val list = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) {
                clip.getItemAt(i).uri?.let { list.add(it) }
            }
        } else {
            data.data?.let { list.add(it) }
        }
        return list
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        when (requestCode) {
            REQ_PICK -> if (resultCode == RESULT_OK && data != null) confirmAdd(collectUris(data))
            REQ_DELETE_BATCH -> {
                if (resultCode != RESULT_OK) hideNotRemoved += batchDeleteCount
                finishHide()
            }
            REQ_DELETE_LEGACY -> {
                val uri = legacyCurrent
                legacyCurrent = null
                if (resultCode == RESULT_OK && uri != null) {
                    try {
                        if (contentResolver.delete(uri, null, null) <= 0) hideNotRemoved++
                    } catch (_: Exception) {
                        hideNotRemoved++
                    }
                } else {
                    hideNotRemoved++
                }
                processLegacyDeleteQueue()
            }
        }
    }

    /** Asks whether the files should also be encrypted (unchecked by default). */
    private fun confirmAdd(uris: List<Uri>) {
        if (uris.isEmpty()) return
        val check = CheckBox(this).apply {
            text = "Encrypt the files"
            isChecked = false
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(24), dp(4), dp(24), 0)
            addView(check)
        }
        AlertDialog.Builder(this)
            .setTitle("Add ${uris.size} file(s) to vault")
            .setMessage(
                "Files are moved into the vault and removed from your gallery and file manager.\n\n" +
                "Not encrypted: opens instantly, and other apps can't see it, but the file itself isn't scrambled.\n" +
                "Encrypted: fully protected, but a bit slower to add and open."
            )
            .setView(box)
            .setPositiveButton("Add") { _, _ -> hideSelectedFiles(uris, check.isChecked) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun hideSelectedFiles(uris: List<Uri>, encrypt: Boolean) {
        if (uris.isEmpty()) return
        hideHidden = 0
        hideFailed = 0
        hideNotRemoved = 0
        val targetFolder = currentFolder
        val progress = AlertDialog.Builder(this)
            .setMessage("Moving ${uris.size} file(s) into the vault…")
            .setCancelable(false)
            .create()
        progress.show()

        Thread {
            val needConfirm = mutableListOf<Uri>()
            for ((i, uri) in uris.withIndex()) {
                val name = getFileName(uri) ?: "file_${System.currentTimeMillis()}_$i"
                if (!VaultManager.addToVault(applicationContext, uri, name, targetFolder, encrypt)) {
                    hideFailed++
                    continue
                }
                hideHidden++
                // The encrypted copy is safely stored; now remove the original.
                if (!VaultManager.tryDeleteOriginal(applicationContext, uri)) {
                    val media = VaultManager.toMediaStoreUri(applicationContext, uri)
                    if (media != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) needConfirm.add(media)
                    else hideNotRemoved++
                }
            }
            runOnUiThread {
                try { progress.dismiss() } catch (_: Exception) {}
                renderVaultFiles()
                when {
                    needConfirm.isEmpty() -> finishHide()
                    Build.VERSION.SDK_INT >= Build.VERSION_CODES.R -> requestBatchDelete(needConfirm)
                    else -> {
                        legacyDeleteQueue.addAll(needConfirm)
                        processLegacyDeleteQueue()
                    }
                }
            }
        }.start()
    }

    /** Android 11+: one system dialog asks permission to delete all the originals at once. */
    @RequiresApi(Build.VERSION_CODES.R)
    private fun requestBatchDelete(uris: List<Uri>) {
        batchDeleteCount = uris.size
        try {
            val request = MediaStore.createDeleteRequest(contentResolver, uris)
            leavingForTask = true
            startIntentSenderForResult(request.intentSender, REQ_DELETE_BATCH, null, 0, 0, 0)
        } catch (e: Exception) {
            leavingForTask = false
            hideNotRemoved += uris.size
            finishHide()
        }
    }

    /** Android 10: one system dialog per file. */
    private fun processLegacyDeleteQueue() {
        while (legacyDeleteQueue.isNotEmpty()) {
            val uri = legacyDeleteQueue.removeAt(0)
            try {
                if (contentResolver.delete(uri, null, null) <= 0) hideNotRemoved++
            } catch (e: SecurityException) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && e is RecoverableSecurityException) {
                    legacyCurrent = uri
                    leavingForTask = true
                    try {
                        startIntentSenderForResult(e.userAction.actionIntent.intentSender, REQ_DELETE_LEGACY, null, 0, 0, 0)
                        return
                    } catch (_: Exception) {
                        leavingForTask = false
                        legacyCurrent = null
                        hideNotRemoved++
                    }
                } else {
                    hideNotRemoved++
                }
            } catch (_: Exception) {
                hideNotRemoved++
            }
        }
        finishHide()
    }

    private fun finishHide() {
        renderVaultFiles()
        if (hideFailed == 0 && hideNotRemoved == 0) {
            if (hideHidden > 0) Toast.makeText(this, "$hideHidden file(s) hidden in the vault", Toast.LENGTH_SHORT).show()
            return
        }
        val msg = StringBuilder()
        if (hideHidden > 0) msg.append("$hideHidden file(s) are now in the vault.\n\n")
        if (hideNotRemoved > 0) {
            msg.append("$hideNotRemoved original(s) could not be removed from their old location, so they are still visible there. ")
            msg.append("Delete them manually, or allow the deletion request when Android asks.\n\n")
        }
        if (hideFailed > 0) msg.append("$hideFailed file(s) could not be copied into the vault and were left untouched.")
        AlertDialog.Builder(this)
            .setTitle("Hide result")
            .setMessage(msg.toString().trim())
            .setPositiveButton("OK", null)
            .show()
    }

    // ====================================================================== Vault: open

    private fun actionText(label: String, color: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextColor(color)
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
        typeface = Typeface.DEFAULT_BOLD
        setPadding(dp(10), dp(10), dp(10), dp(10))
        setOnClickListener { onClick() }
    }

    private fun openVaultFile(file: File) {
        val mime = VaultManager.mimeFor(VaultManager.displayName(file))
        when {
            mime.startsWith("image/") -> showImageViewer(file)
            mime.startsWith("video/") || mime.startsWith("audio/") -> showMediaViewer(file)
            else -> openExternally(file, mime)
        }
    }

    /** Full-screen in-app viewer with Unhide / Delete / Close. */
    private fun showViewer(file: File, content: View, onClose: () -> Unit = {}) {
        viewerDialog?.dismiss()
        val dialog = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        dialog.window?.setFlags(WindowManager.LayoutParams.FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE)

        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setBackgroundColor(Color.parseColor("#B3000000"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        bar.addView(TextView(this).apply {
            text = VaultManager.displayName(file)
            setTextColor(Color.WHITE)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
            setPadding(dp(8), 0, dp(8), 0)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        bar.addView(actionText("Unhide", Color.WHITE) { dialog.dismiss(); unhideFile(file) })
        bar.addView(actionText("Delete", Color.parseColor("#FFB5A2")) { dialog.dismiss(); confirmDelete(file) })
        bar.addView(actionText("Close", Color.WHITE) { dialog.dismiss() })
        root.addView(bar, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))

        dialog.setContentView(root)
        dialog.setOnDismissListener {
            onClose()
            if (viewerDialog === dialog) viewerDialog = null
            VaultManager.clearTemp(applicationContext)
        }
        viewerDialog = dialog
        dialog.show()
    }

    private fun showImageViewer(file: File) {
        val dm = resources.displayMetrics
        Thread {
            val bm = try {
                VaultManager.readDecrypted(file)?.let { VaultManager.decodeBitmap(it, dm.widthPixels, dm.heightPixels) }
            } catch (_: Throwable) {
                null
            }
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (bm == null) {
                    Toast.makeText(this, "Unable to open this image", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val iv = ImageView(this).apply {
                    setImageBitmap(bm)
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(0, dp(56), 0, 0)
                }
                showViewer(file, iv)
            }
        }.start()
    }

    private fun showMediaViewer(file: File) {
        Toast.makeText(this, "Opening…", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp: File? = if (VaultManager.isEncrypted(file)) VaultManager.decryptToTemp(applicationContext, file) else file
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (tmp == null) {
                    Toast.makeText(this, "Decryption failed", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val vv = VideoView(this)
                val controller = MediaController(this)
                controller.setAnchorView(vv)
                vv.setMediaController(controller)
                vv.setOnPreparedListener { vv.start() }
                vv.setOnErrorListener { _, _, _ ->
                    Toast.makeText(this, "Couldn't play this file", Toast.LENGTH_SHORT).show()
                    true
                }
                vv.setVideoPath(tmp.absolutePath)
                val holder = FrameLayout(this).apply {
                    addView(vv, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
                }
                showViewer(file, holder) { try { vv.stopPlayback() } catch (_: Exception) {} }
            }
        }.start()
    }

    /** PDFs, documents, etc.: decrypt to a private temp file and hand it to an app that can open it. */
    private fun openExternally(file: File, mime: String) {
        Toast.makeText(this, "Opening…", Toast.LENGTH_SHORT).show()
        Thread {
            val tmp = VaultManager.decryptToTemp(applicationContext, file)
            runOnUiThread {
                if (isDestroyed || isFinishing) return@runOnUiThread
                if (tmp == null) {
                    Toast.makeText(this, "Decryption failed", Toast.LENGTH_SHORT).show()
                    return@runOnUiThread
                }
                val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", tmp)
                val viewMime = if (mime == "application/octet-stream") "*/*" else mime
                val viewIntent = Intent(Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, viewMime)
                    addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                leavingForTask = true
                externalViewing = true
                try {
                    startActivity(viewIntent)
                } catch (e: Exception) {
                    leavingForTask = false
                    externalViewing = false
                    VaultManager.clearTemp(applicationContext)
                    Toast.makeText(this, "No app can open this file. Use Unhide to restore it.", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ====================================================================== Vault: unhide / delete

    private fun unhideFile(file: File) = withStoragePermission {
        Toast.makeText(this, "Unhiding…", Toast.LENGTH_SHORT).show()
        Thread {
            val folder = VaultManager.restoreToPublic(applicationContext, file)
            if (folder != null) VaultManager.deleteFile(file)
            runOnUiThread {
                if (folder != null) {
                    Toast.makeText(this, "Restored to $folder", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this, "Couldn't unhide this file (it is still safe in the vault)", Toast.LENGTH_LONG).show()
                }
                renderVaultFiles()
            }
        }.start()
    }

    private fun confirmDelete(file: File) {
        AlertDialog.Builder(this)
            .setTitle("Delete permanently?")
            .setMessage("\"${VaultManager.displayName(file)}\" will be deleted from the vault and cannot be recovered.")
            .setPositiveButton("Delete") { _, _ ->
                VaultManager.deleteFile(file)
                renderVaultFiles()
                Toast.makeText(this, "Deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ====================================================================== Vault: list, filters, folders

    /** 1 = images, 2 = videos, 3 = everything else (documents, audio, ...). */
    private fun categoryOf(name: String): Int {
        val mime = VaultManager.mimeFor(name)
        return when {
            mime.startsWith("image/") -> 1
            mime.startsWith("video/") -> 2
            else -> 3
        }
    }

    private fun filterChip(label: String, selected: Boolean, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
        setTextColor(if (selected) pal.eqFg else pal.sciFg)
        typeface = if (selected) Typeface.DEFAULT_BOLD else Typeface.DEFAULT
        setPadding(dp(14), dp(7), dp(14), dp(7))
        background = GradientDrawable().apply {
            cornerRadius = dpf(100)
            setColor(if (selected) pal.eqBg else pal.numBg)
        }
        setOnClickListener { onClick() }
    }

    private fun chipParams() = LinearLayout.LayoutParams(-2, -2).apply { setMargins(0, 0, dp(8), 0) }

    private fun renderVaultChips() {
        vaultChipsRow.removeAllViews()
        listOf("All", "Images", "Videos", "Files").forEachIndexed { i, label ->
            vaultChipsRow.addView(filterChip(label, vaultFilter == i) {
                vaultFilter = i
                renderVaultFiles()
            }, chipParams())
        }
        val sortLabels = listOf("A–Z", "Newest", "Largest")
        vaultChipsRow.addView(filterChip("Sort: ${sortLabels[vaultSort]}", false) {
            vaultSort = (vaultSort + 1) % 3
            renderVaultFiles()
        }, chipParams())
        if (currentFolder == null) {
            vaultChipsRow.addView(filterChip("+ Folder", false) { promptNewFolder() }, chipParams())
        }
    }

    private fun promptText(title: String, initial: String, positive: String, onOk: (String) -> Unit) {
        val input = EditText(this).apply {
            hint = "Folder name"
            setSingleLine(true)
            setText(initial)
            setSelection(text.length)
        }
        val box = FrameLayout(this).apply {
            setPadding(dp(20), dp(8), dp(20), 0)
            addView(input)
        }
        AlertDialog.Builder(this)
            .setTitle(title)
            .setView(box)
            .setPositiveButton(positive) { _, _ -> onOk(input.text.toString()) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    /** Creates a folder. When [onCreated] is given (move flow) an existing folder with that name is reused. */
    private fun promptNewFolder(onCreated: ((String) -> Unit)? = null) {
        promptText("New folder", "", "Create") { raw ->
            val name = VaultManager.cleanFolderName(raw)
            if (name == null) {
                Toast.makeText(this, "Enter a folder name", Toast.LENGTH_SHORT).show()
            } else if (VaultManager.folderExists(this, name)) {
                if (onCreated != null) onCreated(name)
                else Toast.makeText(this, "A folder with that name already exists", Toast.LENGTH_SHORT).show()
            } else if (VaultManager.createFolder(this, name)) {
                if (onCreated != null) {
                    onCreated(name)
                } else {
                    renderVaultFiles()
                    Toast.makeText(this, "Folder created", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Couldn't create folder", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun showFolderMenu(anchor: View, folder: String) {
        val menu = PopupMenu(this, anchor)
        menu.menu.add(0, 1, 0, "Rename")
        menu.menu.add(0, 2, 1, "Delete folder")
        menu.setOnMenuItemClickListener { item ->
            if (item.itemId == 1) {
                promptText("Rename folder", folder, "Rename") { raw ->
                    val newName = VaultManager.cleanFolderName(raw)
                    if (newName == null) {
                        Toast.makeText(this, "Enter a folder name", Toast.LENGTH_SHORT).show()
                    } else if (newName != folder) {
                        if (VaultManager.renameFolder(this, folder, newName)) renderVaultFiles()
                        else Toast.makeText(this, "Couldn't rename (that name may already exist)", Toast.LENGTH_SHORT).show()
                    }
                }
            } else {
                confirmDeleteFolder(folder)
            }
            true
        }
        menu.show()
    }

    private fun confirmDeleteFolder(folder: String) {
        AlertDialog.Builder(this)
            .setTitle("Delete folder?")
            .setMessage("\"$folder\" will be removed. Any files inside move back to the main vault, nothing is deleted.")
            .setPositiveButton("Delete folder") { _, _ ->
                VaultManager.deleteFolder(this, folder)
                renderVaultFiles()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showMoveDialog(file: File) {
        val targets = mutableListOf<String?>()
        val labels = mutableListOf<String>()
        if (currentFolder != null) {
            targets.add(null)
            labels.add("Main vault")
        }
        for (f in VaultManager.listFolders(this)) {
            if (f != currentFolder) {
                targets.add(f)
                labels.add(f)
            }
        }
        labels.add("+ New folder…")
        AlertDialog.Builder(this)
            .setTitle("Move to")
            .setItems(labels.toTypedArray()) { _, which ->
                if (which == labels.size - 1) promptNewFolder { name -> moveInto(file, name) }
                else moveInto(file, targets[which])
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun moveInto(file: File, folder: String?) {
        val moved = VaultManager.moveFile(this, file, folder)
        renderVaultFiles()
        Toast.makeText(
            this,
            if (moved != null) "Moved to ${folder ?: "main vault"}" else "Couldn't move file",
            Toast.LENGTH_SHORT
        ).show()
    }

    /** Old-format encrypted files are re-encrypted in the fast format (with a thumbnail), one at a time. */
    private fun upgradeInBackground(file: File, wantThumb: Boolean, applyThumb: (Bitmap) -> Unit) {
        val path = file.absolutePath
        if (!migrating.add(path)) return
        try {
            migrateExecutor.execute {
                try {
                    if (VaultManager.isLegacy(file) && VaultManager.migrateLegacy(file) && wantThumb) {
                        val bm = VaultManager.readThumb(file)
                        if (bm != null) {
                            thumbCache[path + file.lastModified()] = bm
                            runOnUiThread { applyThumb(bm) }
                        }
                    }
                } finally {
                    migrating.remove(path)
                }
            }
        } catch (_: Exception) {
            migrating.remove(path)
        }
    }

    private fun renderVaultFiles() {
        val folder = currentFolder
        vaultTitle.text = if (folder == null) "Secure Vault" else "‹  $folder"
        renderVaultChips()
        vaultFilesList.removeAllViews()

        val folders = if (folder == null) VaultManager.listFolders(this) else emptyList()
        val all = VaultManager.listFiles(this, folder)
        val filtered = all.filter { vaultFilter == 0 || categoryOf(VaultManager.displayName(it)) == vaultFilter }
        val files = when (vaultSort) {
            1 -> filtered.sortedByDescending { it.lastModified() }
            2 -> filtered.sortedByDescending { it.length() }
            else -> filtered.sortedBy { VaultManager.displayName(it).lowercase() }
        }

        if (folders.isEmpty() && files.isEmpty()) {
            val msg = when {
                all.isNotEmpty() -> "No ${listOf("files", "images", "videos", "files")[vaultFilter].lowercase()} here"
                folder == null -> "No files in vault"
                else -> "This folder is empty"
            }
            vaultFilesList.addView(TextView(this).apply {
                text = msg
                setTextColor(pal.icon)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            })
            return
        }

        for (f in folders) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setPadding(dp(16), dp(8), dp(4), dp(8))
                gravity = Gravity.CENTER_VERTICAL
                isClickable = true
                setOnClickListener {
                    currentFolder = f
                    renderVaultFiles()
                }
                setOnLongClickListener { v -> showFolderMenu(v, f); true }
            }
            row.addView(ImageView(this).apply {
                setImageResource(R.drawable.ic_folder)
                setColorFilter(pal.result)
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(8), dp(8), dp(8), dp(8))
            }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) })
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            col.addView(TextView(this).apply {
                text = f
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 1
                ellipsize = TextUtils.TruncateAt.END
            })
            col.addView(TextView(this).apply {
                text = "${VaultManager.countFiles(this@MainActivity, f)} file(s)"
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            })
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(iconButton(R.drawable.ic_more_vert, "Folder options") { showFolderMenu(it, f) }, LinearLayout.LayoutParams(dp(44), dp(44)))
            vaultFilesList.addView(row)
            vaultFilesList.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        }

        for (file in files) {
            val name = VaultManager.displayName(file)
            val mime = VaultManager.mimeFor(name)
            val isImage = mime.startsWith("image/")

            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(8), dp(8), dp(2))
                isClickable = true
                setOnClickListener { openVaultFile(file) }
            }
            val top = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
            }

            val thumb = ImageView(this).apply {
                layoutParams = LinearLayout.LayoutParams(dp(48), dp(48)).apply { setMargins(0, 0, dp(12), 0) }
                scaleType = ImageView.ScaleType.CENTER_INSIDE
                setPadding(dp(10), dp(10), dp(10), dp(10))
                setColorFilter(pal.icon)
                setImageResource(
                    when {
                        isImage -> R.drawable.ic_image
                        mime.startsWith("video/") || mime.startsWith("audio/") -> R.drawable.ic_play
                        else -> R.drawable.ic_file
                    }
                )
                tag = file.absolutePath
            }
            top.addView(thumb)

            val isVideo = mime.startsWith("video/")
            val applyThumb = { bm: Bitmap ->
                if (thumb.tag == file.absolutePath) {
                    thumb.clearColorFilter()
                    thumb.setPadding(0, 0, 0, 0)
                    thumb.scaleType = ImageView.ScaleType.CENTER_CROP
                    thumb.setImageBitmap(bm)
                }
            }
            if (isImage || isVideo) {
                val key = file.absolutePath + file.lastModified()
                val cached = thumbCache[key]
                if (cached != null) {
                    applyThumb(cached)
                } else {
                    try {
                        thumbExecutor.execute {
                            val bm = VaultManager.readThumb(file)
                            if (bm != null) {
                                thumbCache[key] = bm
                                runOnUiThread { applyThumb(bm) }
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
            }
            if (VaultManager.isEncrypted(file)) upgradeInBackground(file, isImage, applyThumb)

            val nameCol = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            nameCol.addView(TextView(this).apply {
                text = name
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                maxLines = 2
                ellipsize = TextUtils.TruncateAt.END
            })
            nameCol.addView(TextView(this).apply {
                text = if (VaultManager.isEncrypted(file)) "Encrypted" else "Not encrypted"
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            })
            top.addView(nameCol, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(top, LinearLayout.LayoutParams(-1, -2))

            val actions = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.END
            }
            actions.addView(actionText("Move", pal.text) { showMoveDialog(file) })
            actions.addView(actionText("Unhide", pal.result) { unhideFile(file) })
            actions.addView(actionText("Delete", pal.clearFg) { confirmDelete(file) })
            row.addView(actions, LinearLayout.LayoutParams(-1, -2))

            vaultFilesList.addView(row)
            vaultFilesList.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun loadHistory(): List<Pair<String, String>> {
        val raw = prefs.getString("entries", "") ?: ""
        if (raw.isEmpty()) return emptyList()
        return raw.split("\u0002").mapNotNull {
            val parts = it.split("\u0001")
            if (parts.size == 2) parts[0] to parts[1] else null
        }
    }

    private fun saveHistoryEntry(expr: String, result: String) {
        val entries = (listOf(expr to result) + loadHistory()).take(30)
        val raw = entries.joinToString("\u0002") { "${it.first}\u0001${it.second}" }
        prefs.edit().putString("entries", raw).apply()
    }

    private fun clearHistory() {
        prefs.edit().remove("entries").apply()
        renderHistory()
        Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
    }

    private fun renderHistory() {
        historyList.removeAllViews()
        val entries = loadHistory()
        if (entries.isEmpty()) {
            historyList.addView(TextView(this).apply {
                text = "No history yet"
                setTextColor(pal.icon)
                setPadding(dp(16), dp(24), dp(16), dp(24))
                gravity = Gravity.CENTER
            })
            return
        }
        for ((expr, result) in entries) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(16), dp(12), dp(16), dp(12))
                isClickable = true
                setOnClickListener {
                    expression = result
                    previousExpression = expr
                    justEvaluated = true
                    toggleHistory()
                    refresh()
                }
            }
            row.addView(TextView(this).apply {
                text = group(expr)
                setTextColor(pal.icon)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
                gravity = Gravity.END
            })
            row.addView(TextView(this).apply {
                text = "= " + group(result)
                setTextColor(pal.text)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 22f)
                gravity = Gravity.END
            })
            historyList.addView(row)
            historyList.addView(View(this).apply { setBackgroundColor(pal.divider) }, LinearLayout.LayoutParams(-1, dp(1)))
        }
    }

    private fun copyResult() {
        if (!justEvaluated && cachedRawResult.isEmpty()) return
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val toCopy = (if (isInfiniteResult && cachedRawResult.isNotEmpty()) cachedRawResult else expression)
            .replace(",", "").replace('−', '-')
        cm.setPrimaryClip(ClipData.newPlainText("result", toCopy))
        Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
    }

    private fun pasteIntoExpression() {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        val clip = cm.primaryClip ?: return
        if (clip.itemCount == 0) return
        val text = clip.getItemAt(0).coerceToText(this).toString()
        val sanitized = text.filter { it.isDigit() || it in "+-×÷.%()^!√" }.replace('-', '−')
        if (sanitized.isEmpty()) return
        if (justEvaluated) { expression = ""; justEvaluated = false }
        expression += sanitized
        refresh()
    }

    private fun onPress(key: String) {
        errorText = null
        when (key) {
            in "0".."9" -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                expression += key
            }
            "." -> {
                if (justEvaluated) { expression = ""; justEvaluated = false }
                val lastNumber = expression.takeLastWhile { it.isDigit() || it == '.' }
                if (!lastNumber.contains('.')) expression += if (lastNumber.isEmpty()) "0." else "."
            }
            "+", "×", "÷", "−" -> {
                justEvaluated = false
                val op = key[0]
                if (expression.isEmpty() || expression.last() == '(') {
                    if (op == '−') expression += "−"
                } else if (expression.last() in operators) {
                    expression = if (expression.length > 1 && expression[expression.length - 2] != '(')
                        expression.dropLast(1) + op
                    else if (op == '−') expression else expression.dropLast(1)
                } else {
                    expression += op
                }
            }
            "%" -> {
                justEvaluated = false
                if (expression.isNotEmpty() && (expression.last().isDigit() || expression.last() in ")%²")) expression += "%"
            }
            "( )" -> {
                justEvaluated = false
                val open = expression.count { it == '(' }
                val close = expression.count { it == ')' }
                val last = expression.lastOrNull()
                val canClose = open > close && last != null && (last.isDigit() || last in ")%²πe!")
                expression += if (canClose) ")" else "("
            }
            "⌫" -> {
                if (justEvaluated) { justEvaluated = false; previousExpression = "" }
                else expression = expression.dropLast(1)
            }
            "AC" -> { expression = ""; previousExpression = ""; justEvaluated = false }
            "=" -> {
                if (changeMode) {
                    if (isValidPin(expression)) {
                        VaultManager.setPin(this, expression)
                        changeMode = false
                        expression = ""
                        justEvaluated = false
                        Toast.makeText(this, "Password changed", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Password must be at least 4 digits", Toast.LENGTH_SHORT).show()
                    }
                    refresh()
                    return
                }
                if (VaultManager.isPinSet(this) && VaultManager.checkPin(this, expression)) {
                    expression = ""
                    justEvaluated = false
                    toggleVault()
                    refresh()
                    return
                }
                if (expression.isNotEmpty() && !justEvaluated) {
                    try {
                        val cleaned = closeParens(trimTrailingOps(expression))
                        val result = Evaluator.format(Evaluator.eval(cleaned))
                        previousExpression = expression
                        expression = result
                        justEvaluated = true
                        saveHistoryEntry(previousExpression, expression)
                    } catch (e: ArithmeticException) {
                        errorText = e.message ?: "Value too large"
                    } catch (e: Exception) {
                        errorText = "Format error"
                    }
                }
            }
        }
        refresh()
    }

    private fun trimTrailingOps(s: String): String {
        var t = s
        while (t.isNotEmpty() && (t.last() in operators || t.last() == '(')) t = t.dropLast(1)
        return t
    }

    private fun closeParens(s: String): String {
        val missing = s.count { it == '(' } - s.count { it == ')' }
        return if (missing > 0) s + ")".repeat(missing) else s
    }

    private fun group(s: String): String =
        Regex("(\\d+)(\\.\\d*)?").replace(s) { m ->
            val int = m.groupValues[1].reversed().chunked(3).joinToString(",").reversed()
            int + m.groupValues[2]
        }

    /** Width available to a display text view: its real width once laid out, else an estimate for the current orientation. */
    private fun availWidthFor(view: TextView): Float {
        val w = if (view === topView) topScroll.width else view.width
        if (w > 0) return w.toFloat()
        val screenW = resources.displayMetrics.widthPixels
        return if (resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE)
            screenW * 0.535f - dp(40) else (screenW - dp(48)).toFloat()
    }

    private fun style(view: TextView, minSp: Int, maxSp: Int, color: Int, sampleText: CharSequence) {
        view.setTextColor(color)
        val availWidth = availWidthFor(view)
        val paint = Paint(view.paint)
        var chosenSp = minSp
        for (sp in maxSp downTo minSp step 2) {
            paint.textSize = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_SP, sp.toFloat(), resources.displayMetrics)
            if (paint.measureText(sampleText, 0, sampleText.length) <= availWidth) {
                chosenSp = sp
                break
            }
        }
        view.setTextSize(TypedValue.COMPLEX_UNIT_SP, chosenSp.toFloat())
    }

    private fun refresh() {
        scroller.forceFinished(true)
        bottomView.removeCallbacks(flingRunnable)
        scrollOffsetPx = 0f
        currentPrecision = 120

        if (justEvaluated) {
            val topStr = group(previousExpression) + " ="
            style(topView, 16, 26, pal.icon, topStr)
            topView.text = topStr
            topScroll.post { topScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }

            val cleanedPrev = closeParens(trimTrailingOps(previousExpression))
            activeEvalExpr = cleanedPrev
            isInfiniteResult = cleanedPrev.isNotEmpty() && try { Evaluator.hasInfiniteDecimals(cleanedPrev) } catch (_: Exception) { false }
            cachedRawResult = if (isInfiniteResult) {
                try { Evaluator.evalBig(cleanedPrev, currentPrecision) }
                catch (e: Exception) {
                    errorText = e.message ?: "Value too large"
                    expression
                }
            } else {
                expression
            }
        } else {
            val groupedExpr = group(expression)
            style(topView, 28, 60, pal.text, groupedExpr)
            val sb = SpannableStringBuilder(groupedExpr)
            sb.append("\u200B")
            cursorSpan.visible = true
            sb.setSpan(cursorSpan, sb.length - 1, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            topView.text = sb
            topScroll.post { topScroll.fullScroll(HorizontalScrollView.FOCUS_RIGHT) }

            preparePreviewState()
        }

        renderBottomResult()
    }

    private fun preparePreviewState() {
        val e = trimTrailingOps(expression)
        if (e.isEmpty() || Regex("^−?[\\d.]+$").matches(e)) {
            isInfiniteResult = false
            activeEvalExpr = ""
            cachedRawResult = ""
            return
        }
        try {
            val cleaned = closeParens(e)
            activeEvalExpr = cleaned
            isInfiniteResult = Evaluator.hasInfiniteDecimals(cleaned)
            cachedRawResult = if (isInfiniteResult) {
                Evaluator.evalBig(cleaned, currentPrecision)
            } else {
                Evaluator.format(Evaluator.eval(cleaned))
            }
        } catch (ex: Exception) {
            isInfiniteResult = false
            cachedRawResult = ""
        }
    }

    private fun renderBottomResult() {
        if (changeMode) {
            val msg = "Enter new password, press ="
            style(bottomView, 16, 26, pal.result, msg)
            bottomView.text = msg
            return
        }
        val minSp = if (justEvaluated) 28 else 16
        val maxSp = if (justEvaluated) 52 else 26
        val mainColor = if (justEvaluated) pal.text else pal.result

        if (errorText != null) {
            style(bottomView, minSp, maxSp, pal.clearFg, errorText!!)
            bottomView.text = errorText
            return
        }

        if (!isInfiniteResult || !cachedRawResult.contains('.')) {
            val grouped = group(cachedRawResult)
            style(bottomView, minSp, maxSp, mainColor, grouped)
            bottomView.text = grouped
            return
        }

        bottomView.setTextColor(mainColor)
        bottomView.setTextSize(TypedValue.COMPLEX_UNIT_SP, minSp.toFloat())

        val availWidth = availWidthFor(bottomView)
        val paint = bottomView.paint
        val digitWidth = paint.measureText("0").coerceAtLeast(1f)
        val charOffset = (scrollOffsetPx / digitWidth).toInt()

        val dotIdx = cachedRawResult.indexOf('.')
        val intPartGrouped = group(cachedRawResult.substring(0, dotIdx)) + "."
        var frac = cachedRawResult.substring(dotIdx + 1)

        if (charOffset <= 0) {
            var count = 1
            while (count < frac.length && paint.measureText(intPartGrouped + frac.substring(0, count + 1)) <= availWidth) {
                count++
            }
            bottomView.text = intPartGrouped + frac.substring(0, count)
            return
        }

        val sampleOverhead = paint.measureText("...E-100")
        val baseVisibleDigits = ((availWidth - sampleOverhead) / digitWidth).toInt().coerceAtLeast(6)
        val endIdx = baseVisibleDigits + charOffset

        if (endIdx + 35 > frac.length && currentPrecision < 1200) {
            currentPrecision = (endIdx + 120).coerceAtMost(1200)
            try {
                cachedRawResult = Evaluator.evalBig(activeEvalExpr, currentPrecision)
                val newDot = cachedRawResult.indexOf('.')
                if (newDot != -1) frac = cachedRawResult.substring(newDot + 1)
            } catch (_: Exception) {}
        }

        val clampedEnd = endIdx.coerceAtMost(frac.length)
        val prefix = "..."
        val suffix = "E-$clampedEnd"
        val remainingForDigits = availWidth - paint.measureText(prefix) - paint.measureText(suffix)

        var startIdx = clampedEnd - 1
        while (startIdx > 0 && paint.measureText(frac, startIdx - 1, clampedEnd) <= remainingForDigits) {
            startIdx--
        }

        val visibleDigits = frac.substring(startIdx.coerceAtLeast(0), clampedEnd)
        val sb = SpannableStringBuilder()
        sb.append(prefix)
        sb.append(visibleDigits)
        val expStart = sb.length
        sb.append(suffix)
        sb.setSpan(ForegroundColorSpan(pal.icon), expStart, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        bottomView.text = sb
    }

    @Suppress("DEPRECATION")
    override fun onBackPressed() {
        if (historyVisible) toggleHistory()
        else if (vaultVisible) {
            if (currentFolder != null) {
                currentFolder = null
                renderVaultFiles()
            } else {
                toggleVault()
            }
        }
        else super.onBackPressed()
    }
}
