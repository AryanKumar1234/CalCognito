package com.onion.calcognito

import android.app.Application
import android.content.Context

/**
 * The virtual engine hooks into the Application. In the processes it creates for hidden apps it starts here; in the
 * main process it starts only when hidden apps are first used, so a problem with the engine on some phone can never
 * stop the calculator from opening (see EngineBridge). With no engine in the build all of this does nothing.
 */
class CalApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        EngineBridge.attach(base)
    }

    override fun onCreate() {
        super.onCreate()
        CrashReport.install(this)
        EngineBridge.checkPreviousCrash(this)
        EngineBridge.create()
    }
}
