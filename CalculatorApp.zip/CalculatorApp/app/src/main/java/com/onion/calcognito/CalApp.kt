package com.onion.calcognito

import android.app.Application
import android.content.Context

/**
 * The virtual engine has to start inside the Application, in this process and in every process it creates for hidden
 * apps. With no engine in the build both calls do nothing.
 */
class CalApp : Application() {
    override fun attachBaseContext(base: Context) {
        super.attachBaseContext(base)
        EngineBridge.attach(base)
    }

    override fun onCreate() {
        super.onCreate()
        EngineBridge.create()
    }
}
