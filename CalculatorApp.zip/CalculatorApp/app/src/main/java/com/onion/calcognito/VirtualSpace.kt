package com.onion.calcognito

import android.app.Activity
import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Hidden apps that work like Parallel Space.
 *
 * The app is cloned into a virtual space run by an embedded engine (see [EngineBridge]): it runs inside this app
 * without being installed on the phone, with its own private data, and the clone is never re-installed or archived
 * as an .apks file. The engine keeps its own internal copy of the app's APK, like every app of this kind.
 *
 * This object only remembers each app's name and icon (taken from the real app while it is still installed) so the
 * vault list can draw them; the engine itself is the source of truth for what actually runs.
 */
object VirtualSpace {
    const val USER_ID = 0
    private const val PREF = "virtual_space"
    private const val ICON_DIR = "virtual_space_icons"

    class VApp(val pkg: String, val label: String, val icon: Bitmap?)

    val available: Boolean get() = EngineBridge.available

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun iconFile(ctx: Context, pkg: String) =
        File(File(ctx.filesDir, ICON_DIR).apply { mkdirs() }, "$pkg.png")

    private fun records(ctx: Context): JSONObject = try {
        JSONObject(prefs(ctx).getString("apps", "{}") ?: "{}")
    } catch (_: Throwable) {
        JSONObject()
    }

    fun list(ctx: Context): List<VApp> {
        val r = records(ctx)
        val out = ArrayList<VApp>()
        for (pkg in r.keys()) {
            val icon = try { BitmapFactory.decodeFile(iconFile(ctx, pkg).absolutePath) } catch (_: Throwable) { null }
            out.add(VApp(pkg, r.optString(pkg, pkg), icon))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun contains(ctx: Context, pkg: String) = records(ctx).has(pkg)

    private fun toBitmap(d: Drawable, size: Int = 144): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null && d.bitmap.width <= size * 2) return d.bitmap
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return bm
    }

    /** Clones [pkg] into the space. Blocking (worker thread). Returns null on success, else a short reason. */
    fun add(ctx: Context, pkg: String): String? {
        if (!available) return "The hidden-app engine isn't part of this build"
        val pm = ctx.packageManager
        val label: String
        var icon: Bitmap? = null
        try {
            val ai = pm.getApplicationInfo(pkg, 0)
            label = pm.getApplicationLabel(ai).toString()
            icon = try { toBitmap(pm.getApplicationIcon(ai)) } catch (_: Throwable) { null }
        } catch (_: Throwable) {
            return "That app is no longer installed"
        }
        if (!EngineBridge.install(pkg, USER_ID)) {
            return "The engine couldn't run this app (some apps, for example ones installed as split APKs, may not be supported)"
        }
        val r = records(ctx).put(pkg, label)
        prefs(ctx).edit().putString("apps", r.toString()).apply()
        icon?.let {
            try { FileOutputStream(iconFile(ctx, pkg)).use { o -> it.compress(Bitmap.CompressFormat.PNG, 100, o) } } catch (_: Throwable) {}
        }
        return null
    }

    /** Main thread. */
    fun launch(activity: Activity, pkg: String): Boolean = EngineBridge.launch(activity, pkg, USER_ID)

    /** Removes the clone and all its data. Blocking (worker thread). */
    fun remove(ctx: Context, pkg: String): Boolean {
        val gone = EngineBridge.uninstall(pkg, USER_ID) || !EngineBridge.isInstalled(pkg, USER_ID)
        if (gone) {
            val r = records(ctx)
            r.remove(pkg)
            prefs(ctx).edit().putString("apps", r.toString()).apply()
            iconFile(ctx, pkg).delete()
        }
        return gone
    }

    /** Used when the vault is reset: wipes every clone. Runs in the background. */
    fun clearAll(ctx: Context) {
        val app = ctx.applicationContext
        val pkgs = records(app).keys().asSequence().toList()
        prefs(app).edit().clear().apply()
        File(app.filesDir, ICON_DIR).deleteRecursively()
        if (pkgs.isNotEmpty()) Thread { pkgs.forEach { try { EngineBridge.uninstall(it, USER_ID) } catch (_: Throwable) {} } }.start()
    }
}
