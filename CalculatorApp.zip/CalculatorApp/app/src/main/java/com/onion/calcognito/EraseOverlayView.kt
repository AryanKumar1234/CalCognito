package com.onion.calcognito

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.ColorUtils
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Full-screen "Forgot PIN" erase animation, identical to the one in the How to use guide: a red wipe spreads from
 * the = key, "Erasing files" (bin) then "Relaunching" (spinning arrow) play, and [onFinished] runs at the end.
 * It swallows touches while it plays.
 */
class EraseOverlayView(
    ctx: Context,
    private val danger: Int,
    private val fg: Int,
    private val font: Typeface,
    private val originX: Float,
    private val originY: Float,
    private val onFinished: () -> Unit
) : View(ctx) {

    private val dDelete = ctx.getDrawable(R.drawable.ic_delete)!!.mutate()
    private val dRefresh = ctx.getDrawable(R.drawable.ic_refresh)!!.mutate()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER; typeface = font }
    private var t = 0L
    private var anim: ValueAnimator? = null

    // Same timeline as GuideDemoView.drawRelaunch
    private val wipe = 420L
    private val e1 = wipe
    private val e2 = e1 + 850L
    private val e3 = e2 + 950L
    private val e4 = e3 + 450L

    init {
        isClickable = true
        isFocusable = true
    }

    fun start() {
        anim = ValueAnimator.ofFloat(0f, e4.toFloat()).apply {
            duration = e4
            interpolator = LinearInterpolator()
            addUpdateListener { t = (it.animatedValue as Float).toLong(); invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) onFinished() }
            })
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel()
        super.onDetachedFromWindow()
    }

    private fun decel(f: Float): Float { val x = 1f - f.coerceIn(0f, 1f); return 1f - x * x * x }

    private fun drawIcon(c: Canvas, d: android.graphics.drawable.Drawable, cx: Float, cy: Float, size: Float, alpha: Int) {
        val h = (size / 2f).toInt()
        d.setBounds((cx - h).toInt(), (cy - h).toInt(), (cx + h).toInt(), (cy + h).toInt())
        d.setTint(fg)
        d.alpha = alpha
        d.draw(c)
    }

    private fun label(c: Canvas, s: String, cx: Float, y: Float, size: Float, alpha: Int) {
        textPaint.textSize = size
        textPaint.color = ColorUtils.setAlphaComponent(fg, alpha)
        c.drawText(s, cx, y, textPaint)
    }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val maxR = hypot(max(originX, w - originX), max(originY, h - originY))
        val fade = if (t > e3) 1f - (t - e3) / 450f else 1f
        fill.color = ColorUtils.setAlphaComponent(danger, (255 * fade).toInt())
        canvas.drawCircle(originX, originY, maxR * decel(t / wipe.toFloat()), fill)

        val appear = ((t - 300L) / 200f).coerceIn(0f, 1f) * fade
        if (appear <= 0f) return
        val cx = w / 2f
        val cy = h / 2f - h * 0.02f
        val minSide = minOf(w, h)
        val iconSize = minSide * 0.24f
        val labelSize = minSide * 0.07f
        val mixB = ((t - (e2 - 100L)) / 200f).coerceIn(0f, 1f)

        val aErase = appear * (1f - mixB)
        if (aErase > 0f) {
            val pop = decel((t - 300L) / 260f)
            val sc = 0.6f + 0.4f * pop + 0.08f * sin(pop * Math.PI).toFloat()
            canvas.save()
            canvas.scale(sc, sc, cx, cy)
            drawIcon(canvas, dDelete, cx, cy, iconSize, (255 * aErase).toInt())
            canvas.restore()
            label(canvas, "Erasing files", cx, cy + iconSize * 0.95f + labelSize * 0.35f, labelSize, (255 * aErase).toInt())
        }
        val aRelaunch = appear * mixB
        if (aRelaunch > 0f) {
            val spin = (t - e2) / 950f * 540f
            canvas.save()
            canvas.rotate(spin, cx, cy)
            drawIcon(canvas, dRefresh, cx, cy, iconSize, (255 * aRelaunch).toInt())
            canvas.restore()
            label(canvas, "Relaunching", cx, cy + iconSize * 0.95f + labelSize * 0.35f, labelSize, (255 * aRelaunch).toInt())
        }
    }
}
