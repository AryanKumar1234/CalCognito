package com.onion.calcognito

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import java.io.File

/** What an "add to vault" job reports when it ends. [needConfirm] are originals Android must ask the person to delete. */
class AddResult(val hidden: Int, val failed: Int, val notRemoved: Int, val needConfirm: List<Uri>)

/** What an "unhide" job reports when it ends. */
class UnhideResult(val restored: Int, val total: Int, val lastFolder: String?)

/** What an encrypt / decrypt job reports when it ends. [firstNew] is the first converted file (the viewer needs it). */
class CryptResult(val done: Int, val total: Int, val firstNew: File?)

/**
 * The actual work for the kinds of transfer. Everything here runs on the transfer thread, inside
 * [TransferManager], and deliberately knows nothing about any Activity: the app may be closed while it runs.
 */
object TransferJobs {

    /** At or above this (total) size the progress card appears straight away. */
    const val BIG_BYTES = 100L * 1024 * 1024

    /** Small adds only show the card if they turn out to take a moment. */
    private const val SMALL_ADD_CARD_DELAY_MS = 400L

    /**
     * Copies [uris] into the vault one by one, removing each original once its copy is complete.
     * [sizes] holds each file's size in bytes, or -1 when the provider doesn't say.
     */
    fun add(uris: List<Uri>, sizes: List<Long>, folder: String?, encrypt: Boolean): TransferManager.Job {
        val total = if (sizes.all { it >= 0L }) sizes.sum() else -1L
        val big = total < 0L || total >= BIG_BYTES
        return TransferManager.Job(
            kind = TransferManager.Kind.ADD,
            title = "Adding…",
            count = uris.size,
            totalBytes = total,
            grantUris = uris,
            cardDelayMs = if (big) 0L else SMALL_ADD_CARD_DELAY_MS
        ) { ctx, job ->
            var hidden = 0
            var failed = 0
            var notRemoved = 0
            val needConfirm = mutableListOf<Uri>()
            for ((i, uri) in uris.withIndex()) {
                if (job.cancelled) break
                val name = queryName(ctx, uri) ?: "file_${System.currentTimeMillis()}_$i"
                job.label = if (uris.size == 1) shortName(name) else "${i + 1} of ${uris.size}"
                val ok = VaultManager.addToVault(ctx, uri, name, folder, encrypt, cancelled = { job.cancelled }) { delta ->
                    job.addBytes(delta)
                }
                if (!ok) {
                    // A copy stopped by Cancel isn't a failure; the original was never touched.
                    if (!job.cancelled) failed++
                    continue
                }
                hidden++

                if (!VaultManager.tryDeleteOriginal(ctx, uri)) {
                    val media = VaultManager.toMediaStoreUri(ctx, uri)
                    if (media != null && Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) needConfirm.add(media)
                    else notRemoved++
                }
            }
            AddResult(hidden, failed, notRemoved, needConfirm)
        }
    }

    /**
     * Copies vault [files] back to public storage and removes them from the vault once each copy is complete.
     * The progress card only appears when the files add up to [BIG_BYTES] or more.
     */
    fun unhide(files: List<File>): TransferManager.Job {
        val total = files.sumOf { it.length() }
        return TransferManager.Job(
            kind = TransferManager.Kind.UNHIDE,
            title = "Unhiding…",
            count = files.size,
            totalBytes = total,
            grantUris = emptyList(),
            cardDelayMs = if (total >= BIG_BYTES) 0L else -1L
        ) { ctx, job ->
            var restored = 0
            var lastFolder: String? = null
            for ((i, f) in files.withIndex()) {
                if (job.cancelled) break
                job.label = if (files.size == 1) shortName(VaultManager.displayName(f)) else "${i + 1} of ${files.size}"
                val folder = VaultManager.restoreToPublic(ctx, f, cancelled = { job.cancelled }) { delta ->
                    job.addBytes(delta)
                }
                if (folder != null) {
                    VaultManager.deleteFile(ctx, f)
                    restored++
                    lastFolder = folder
                }
            }
            UnhideResult(restored, files.size, lastFolder)
        }
    }

    /**
     * Encrypts (or decrypts) vault [files] in place, one by one. The caller passes only files that actually need
     * converting. The progress card appears when they add up to [BIG_BYTES] or more.
     */
    fun crypt(files: List<File>, encrypt: Boolean): TransferManager.Job {
        val total = files.sumOf { it.length() }
        return TransferManager.Job(
            kind = if (encrypt) TransferManager.Kind.ENCRYPT else TransferManager.Kind.DECRYPT,
            title = if (encrypt) "Encrypting…" else "Decrypting…",
            count = files.size,
            totalBytes = total,
            grantUris = emptyList(),
            cardDelayMs = if (total >= BIG_BYTES) 0L else -1L
        ) { ctx, job ->
            var done = 0
            var firstNew: File? = null
            for ((i, f) in files.withIndex()) {
                if (job.cancelled) break
                job.label = if (files.size == 1) shortName(VaultManager.displayName(f)) else "${i + 1} of ${files.size}"
                val out = if (encrypt) {
                    VaultManager.encryptInVault(ctx, f, cancelled = { job.cancelled }) { delta -> job.addBytes(delta) }
                } else {
                    VaultManager.decryptInVault(ctx, f, cancelled = { job.cancelled }) { delta -> job.addBytes(delta) }
                }
                if (out != null) {
                    done++
                    if (firstNew == null) firstNew = out
                }
            }
            CryptResult(done, files.size, firstNew)
        }
    }

    private fun shortName(name: String): String = if (name.length > 18) name.take(18) + "..." else name

    private fun queryName(ctx: Context, uri: Uri): String? {
        var result: String? = null
        if (uri.scheme == "content") {
            try {
                ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                    if (c.moveToFirst()) {
                        val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx != -1) result = c.getString(idx)
                    }
                }
            } catch (_: Exception) {
            }
        }
        if (result == null) {
            result = uri.path?.substringAfterLast('/')
        }
        return result
    }
}
