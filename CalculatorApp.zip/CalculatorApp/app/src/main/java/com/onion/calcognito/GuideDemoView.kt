package com.onion.calcognito

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.os.SystemClock
import android.view.MotionEvent
import android.view.VelocityTracker
import android.view.View
import android.view.ViewConfiguration
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import androidx.core.graphics.ColorUtils
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min

/** Colours for the guide demo; all of them come from the app's (dynamic) palette. */
class GuideColors(
    val bg: Int,
    val stage: Int,
    val text: Int,
    val subtle: Int,
    val numBg: Int, val numFg: Int,
    val opBg: Int, val opFg: Int,
    val acBg: Int, val acFg: Int,
    val eqBg: Int, val eqFg: Int,
    val primary: Int,
    val outline: Int,
    /** Red used by the "Forgot PIN?" slide. */
    val danger: Int
)

/**
 * A looping, self-running demo with five slides:
 *  1-4  set the vault password: type 1234 -> hold = for 3 s (password set) -> type 1234 again -> press = -> the vault opens
 *  5    "Forgot PIN?" (in red): type 0000 -> hold = for 3 s -> press = to confirm -> everything is erased, app relaunches
 * Everything is drawn on a Canvas from a single timeline, so it never needs a video or Lottie file.
 * The slides can be swiped (see [SwipeHost]) or jumped to with [goToStep].
 */
class GuideDemoView(
    ctx: Context,
    private val c: GuideColors,
    private val keyFont: Typeface,
    private val displayFont: Typeface,
    private val opFont: Typeface
) : View(ctx) {

    /** Called (on the UI thread) whenever the demo moves to another step (0..4). */
    var onStepChanged: ((Int) -> Unit)? = null

    companion object {
        /** The "Forgot PIN?" slide starts here; everything before it is the set-a-password story. */
        const val FORGOT_START = 15600L
        const val TOTAL = FORGOT_START + 11400L
        const val HOLD_MS = 3000L
        /** Where each of the 5 caption steps begins on the timeline. */
        val STEP_STARTS = longArrayOf(0L, 3400L, 8700L, 11700L, FORGOT_START)
        /** Index of the red "Forgot PIN?" step. */
        const val STEP_FORGOT = 4
        private const val ASPECT = 0.46f
        private val LABELS = arrayOf(
            arrayOf("AC", "( )", "%", "÷"),
            arrayOf("7", "8", "9", "×"),
            arrayOf("4", "5", "6", "−"),
            arrayOf("1", "2", "3", "+"),
            arrayOf("0", ".", "⌫", "=")
        )
        private val LIGHT_GLYPHS = setOf("÷", "×", "−", "+", "%", "( )")
        private val OPS = setOf("÷", "×", "−", "+", "%", "( )")
        private val BIG_GLYPHS = setOf("=", "÷", "×", "−", "+")
    }

    // ---- timeline -----------------------------------------------------------------------------

    private class Act(val key: String, val arrive: Long, val down: Long, val up: Long) {
        var moveStart = 0L
    }

    private fun tap(key: String, arrive: Long) = Act(key, arrive, arrive + 60, arrive + 230)

    private val acts: List<Act> = listOf(
        tap("1", 900), tap("2", 1500), tap("3", 2100), tap("4", 2700),
        Act("=", 4000, 4070, 4070 + HOLD_MS),                       // the 3 second hold
        tap("1", 9300), tap("2", 9900), tap("3", 10500), tap("4", 11100),
        tap("=", 11700)                                              // unlock
    )
    private val holdAct: Act = acts[4]
    private val unlockAct: Act = acts[9]

    /** "Forgot PIN?" slide: type 0000, hold = for 3 s, then press = to confirm the erase. */
    private val fgActs: List<Act> = listOf(
        tap("0", FORGOT_START + 900), tap("0", FORGOT_START + 1500), tap("0", FORGOT_START + 2100), tap("0", FORGOT_START + 2700),
        Act("=", FORGOT_START + 4000, FORGOT_START + 4070, FORGOT_START + 4070 + HOLD_MS),
        tap("=", FORGOT_START + 8600)
    )
    private val fgHold: Act = fgActs[4]
    private val fgConfirm: Act = fgActs[5]

    init {
        for (list in listOf(acts, fgActs)) {
            for (i in list.indices) {
                val a = list[i]
                a.moveStart = if (i == 0) a.arrive - 600L
                else a.arrive - min(450L, a.arrive - list[i - 1].up)
            }
        }
        contentDescription = "Animated guide with five slides you can swipe through. Type 1234, hold the equals key " +
            "for 3 seconds to set your password, then type 1234 again and press equals to open the secure vault. " +
            "If you forget your PIN, type 0000, hold equals for 3 seconds and press equals to confirm; this erases " +
            "the vault files and relaunches the app."
    }

    private fun isForgot(t: Long) = t >= FORGOT_START
    private fun actsAt(t: Long): List<Act> = if (isForgot(t)) fgActs else acts
    private fun holdOf(t: Long): Act = if (isForgot(t)) fgHold else holdAct
    private fun accentOf(t: Long): Int = if (isForgot(t)) c.danger else c.primary

    /** 0 for the password slides, 1 for the red slide (ramps around the boundary and back at the loop point). */
    private fun dangerOf(t: Long): Float {
        val into = smooth((t - (FORGOT_START - 300L)) / 500f)
        val out = smooth((t - (TOTAL - 450L)) / 450f)
        return (into - out).coerceIn(0f, 1f)
    }

    private var running = false
    private var startUptime = 0L
    private var now = 0L
    private var lastStep = -1

    private val ticker = object : Runnable {
        override fun run() {
            if (!running) return
            now = (SystemClock.uptimeMillis() - startUptime) % TOTAL
            val s = stepAt(now)
            if (s != lastStep) {
                lastStep = s
                onStepChanged?.invoke(s)
            }
            invalidate()
            postOnAnimation(this)
        }
    }

    fun start() {
        if (running) return
        running = true
        startUptime = SystemClock.uptimeMillis() - now
        postOnAnimation(ticker)
    }

    fun stop() {
        running = false
        removeCallbacks(ticker)
    }

    /** Jump to the beginning of a caption step with no animation. */
    fun seekToStep(step: Int) {
        now = STEP_STARTS[step.coerceIn(0, STEP_STARTS.size - 1)]
        startUptime = SystemClock.uptimeMillis() - now
        lastStep = -1
        invalidate()
    }

    /** The slide currently sliding in (-1 when none). Lets rapid taps stack up instead of restarting the same slide. */
    private var pendingTarget = -1

    /** Instantly finishes a slide that is still animating, so the next one can start from the right place. */
    private fun settleSlide() {
        val pending = pendingTarget
        if (pending < 0) return
        slideAnim?.cancel()
        pendingTarget = -1
        slideX = 0f
        nbStep = -1
        seekToStep(pending)
    }

    /** Slides to [step] (used by the page dots), in the direction of travel. */
    fun goToStep(step: Int) {
        settleSlide()
        val target = step.coerceIn(0, STEP_STARTS.size - 1)
        val cur = stepAt(now)
        if (target == cur) return
        slideAnim?.cancel()
        slideX = 0f
        commitSlide(target, if (target > cur) 1 else -1)
    }

    /** The slide after the one showing (or sliding in). Safe to call as fast as the user can tap. */
    fun goNext() {
        val base = if (pendingTarget >= 0) pendingTarget else stepAt(now)
        goToStep(base + 1)
    }

    // ---- swiping between slides ---------------------------------------------------------------

    private var slideX = 0f          // how far the current slide is dragged (px); negative = towards the next one
    private var nbStep = -1          // the slide coming in from the side (-1 = none)
    private var nbSide = 1           // +1 = it waits on the right, -1 = on the left
    private var dragBase = 0f
    private var slideAnim: ValueAnimator? = null

    /** A horizontal drag has started at [x] (see [SwipeHost]). */
    fun beginDrag(x: Float) {
        slideAnim?.cancel()
        pendingTarget = -1
        dragBase = x - slideX
    }

    fun dragTo(x: Float) {
        val w = stageRect.width()
        if (w <= 0f) return
        var d = (x - dragBase).coerceIn(-w, w)
        val forward = d < 0f
        val target = stepAt(now) + if (forward) 1 else -1
        if (d != 0f) {
            if (target < 0 || target >= STEP_STARTS.size) {
                nbStep = -1
                d *= 0.3f            // nothing beyond the first / last slide: rubber-band
            } else {
                nbStep = target
                nbSide = if (forward) 1 else -1
            }
        }
        slideX = d
        invalidate()
    }

    /** The finger lifted with horizontal velocity [vx] (px/s). */
    fun endDrag(vx: Float) {
        val w = stageRect.width()
        val cur = stepAt(now)
        val go = when {
            slideX < -w * 0.18f || vx < -900f -> 1
            slideX > w * 0.18f || vx > 900f -> -1
            else -> 0
        }
        val target = cur + go
        if (go != 0 && target >= 0 && target < STEP_STARTS.size) commitSlide(target, go)
        else animateSlide(0f, 220L) { nbStep = -1 }
    }

    /** Finishes the slide to [target], which waits on side [side]; the swap at the end is invisible. */
    private fun commitSlide(target: Int, side: Int) {
        nbStep = target
        nbSide = side
        pendingTarget = target
        animateSlide(-side * stageRect.width(), 260L) {
            // The incoming slide is now exactly where the new current slide starts, so swapping causes no jump.
            pendingTarget = -1
            slideX = 0f
            nbStep = -1
            seekToStep(target)
        }
    }

    private fun animateSlide(to: Float, maxMs: Long, onEnd: () -> Unit) {
        slideAnim?.cancel()
        val w = max(1f, stageRect.width())
        val ms = (maxMs * (abs(to - slideX) / w)).toLong().coerceIn(90L, maxMs)
        slideAnim = ValueAnimator.ofFloat(slideX, to).apply {
            duration = ms
            interpolator = DecelerateInterpolator(1.6f)
            addUpdateListener {
                slideX = it.animatedValue as Float
                invalidate()
            }
            addListener(object : AnimatorListenerAdapter() {
                private var cancelled = false
                override fun onAnimationCancel(animation: Animator) { cancelled = true }
                override fun onAnimationEnd(animation: Animator) { if (!cancelled) onEnd() }
            })
            start()
        }
    }

    override fun onDetachedFromWindow() {
        stop()
        super.onDetachedFromWindow()
    }

    private fun stepAt(t: Long): Int {
        var s = 0
        for (i in STEP_STARTS.indices) if (t >= STEP_STARTS[i]) s = i
        return s
    }

    /** What is typed into the mock calculator at time [t]. */
    private fun expressionAt(t: Long): String {
        val sb = StringBuilder()
        if (isForgot(t)) {
            if (t >= fgHold.up) return ""            // the hold clears the display and asks for confirmation
            for (i in 0..3) if (t >= fgActs[i].down) sb.append(fgActs[i].key)
            return sb.toString()
        }
        if (t < holdAct.up) {
            for (i in 0..3) if (t >= acts[i].down) sb.append(acts[i].key)
            return sb.toString()
        }
        if (t >= unlockAct.down) return ""
        for (i in 5..8) if (t >= acts[i].down) sb.append(acts[i].key)
        return sb.toString()
    }

    // ---- geometry -----------------------------------------------------------------------------

    private val stageRect = RectF()
    private val phoneRect = RectF()
    private val screenRect = RectF()
    private val tmpRect = RectF()
    private val stagePath = Path()
    private val phonePath = Path()
    private val screenPath = Path()
    private val keyRects = Array(5) { Array(4) { RectF() } }
    private var sw = 0f
    private var sh = 0f
    private var keypadTop = 0f
    private var handSize = 0f

    private fun dp(v: Float) = v * resources.displayMetrics.density

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        super.onSizeChanged(w, h, ow, oh)
        val fw = w.toFloat()
        val fh = h.toFloat()
        stageRect.set(0f, 0f, fw, fh)
        stagePath.reset()
        stagePath.addRoundRect(stageRect, dp(28f), dp(28f), Path.Direction.CW)

        val pad = dp(14f)
        var ph = fh - 2f * pad
        var pw = ph * ASPECT
        if (pw > fw - 2f * pad) {
            pw = fw - 2f * pad
            ph = pw / ASPECT
        }
        if (pw < 1f || ph < 1f) { sw = 0f; return }
        val cx = fw / 2f
        val cy = fh / 2f
        phoneRect.set(cx - pw / 2f, cy - ph / 2f, cx + pw / 2f, cy + ph / 2f)
        val bezel = max(dp(3f), pw * 0.022f)
        screenRect.set(phoneRect.left + bezel, phoneRect.top + bezel, phoneRect.right - bezel, phoneRect.bottom - bezel)
        val outerR = pw * 0.12f
        phonePath.reset()
        phonePath.addRoundRect(phoneRect, outerR, outerR, Path.Direction.CW)
        screenPath.reset()
        screenPath.addRoundRect(screenRect, outerR - bezel, outerR - bezel, Path.Direction.CW)

        sw = screenRect.width()
        sh = screenRect.height()
        val kl = screenRect.left + sw * 0.03f
        val kr = screenRect.right - sw * 0.03f
        keypadTop = screenRect.top + sh * 0.42f
        val kb = screenRect.bottom - sh * 0.025f
        val cw = (kr - kl) / 4f
        val ch = (kb - keypadTop) / 5f
        val gap = min(cw, ch) * 0.045f
        for (r in 0 until 5) for (col in 0 until 4) {
            keyRects[r][col].set(
                kl + col * cw + gap, keypadTop + r * ch + gap,
                kl + (col + 1) * cw - gap, keypadTop + (r + 1) * ch - gap
            )
        }
        handSize = sw * 0.5f
    }

    private fun keyRectOf(label: String): RectF {
        for (r in 0 until 5) for (col in 0 until 4) if (LABELS[r][col] == label) return keyRects[r][col]
        return keyRects[0][0]
    }

    // ---- drawing helpers ----------------------------------------------------------------------

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val tp = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun icon(res: Int): Drawable = context.getDrawable(res)!!.mutate()

    private val dHistory = icon(R.drawable.ic_history)
    private val dMore = icon(R.drawable.ic_more_vert)
    private val dExpand = icon(R.drawable.ic_unfold_more)
    private val dBackspace = icon(R.drawable.ic_backspace)
    private val dImage = icon(R.drawable.ic_image)
    private val dPlay = icon(R.drawable.ic_play)
    private val dFile = icon(R.drawable.ic_file)
    private val dAdd = icon(R.drawable.ic_add)
    private val dInfo = icon(R.drawable.ic_info)
    private val dDelete = icon(R.drawable.ic_delete)
    private val dRefresh = icon(R.drawable.ic_refresh)
    private val dHand = icon(R.drawable.ic_hand)
    private val dHandOutline = icon(R.drawable.ic_hand_outline)

    private fun drawIcon(canvas: Canvas, d: Drawable, cx: Float, cy: Float, size: Float, color: Int, alpha: Int = 255) {
        val half = size / 2f
        d.setBounds(Math.round(cx - half), Math.round(cy - half), Math.round(cx + half), Math.round(cy + half))
        d.setTint(color)
        d.alpha = alpha
        d.draw(canvas)
    }

    private fun text(canvas: Canvas, s: String, x: Float, baseline: Float, size: Float, color: Int, tf: Typeface, align: Paint.Align) {
        tp.typeface = tf
        tp.textSize = size
        tp.color = color
        tp.textAlign = align
        canvas.drawText(s, x, baseline, tp)
    }

    private fun textC(canvas: Canvas, s: String, cx: Float, cy: Float, size: Float, color: Int, tf: Typeface) {
        tp.typeface = tf
        tp.textSize = size
        tp.color = color
        tp.textAlign = Paint.Align.CENTER
        val fm = tp.fontMetrics
        canvas.drawText(s, cx, cy - (fm.ascent + fm.descent) / 2f, tp)
    }

    private fun measure(s: String, size: Float, tf: Typeface): Float {
        tp.typeface = tf
        tp.textSize = size
        return tp.measureText(s)
    }

    private fun smooth(f: Float): Float {
        val x = f.coerceIn(0f, 1f)
        return x * x * (3f - 2f * x)
    }

    private fun decel(f: Float): Float {
        val x = 1f - f.coerceIn(0f, 1f)
        return 1f - x * x * x
    }

    private fun accel(f: Float): Float {
        val x = f.coerceIn(0f, 1f)
        return x * x * x
    }

    // ---- press state --------------------------------------------------------------------------

    private var pressLabel: String? = null
    private var pressP = 0f

    private fun computePress(t: Long) {
        pressLabel = null
        pressP = 0f
        for (a in actsAt(t)) {
            if (t >= a.down && t <= a.up + 140L) {
                pressLabel = a.key
                pressP = if (t < a.up) min(1f, (t - a.down) / 50f) else 1f - (t - a.up) / 140f
                return
            }
        }
    }

    // ---- main draw ----------------------------------------------------------------------------

    override fun onDraw(canvas: Canvas) {
        if (sw <= 0f) return
        val w = stageRect.width()
        val cur = now
        canvas.save()
        canvas.clipPath(stagePath)

        // While swiping, the neighbouring slide waits just outside the stage and the tint blends towards it.
        val drawNeighbour = nbStep >= 0 && slideX != 0f
        val nbT = if (drawNeighbour) STEP_STARTS[nbStep] else cur
        val mixCur = dangerOf(cur)
        val mix = if (drawNeighbour) mixCur + (dangerOf(nbT) - mixCur) * min(1f, abs(slideX) / w) else mixCur
        drawStage(canvas, mix)

        canvas.save()
        canvas.translate(slideX, 0f)
        drawScene(canvas, cur)
        canvas.restore()
        if (drawNeighbour) {
            canvas.save()
            canvas.translate(slideX + nbSide * w, 0f)
            drawScene(canvas, nbT)
            canvas.restore()
        }
        canvas.restore()
    }

    /** The card behind the phone: background plus two soft tonal blobs (they turn red on the "Forgot PIN?" slide). */
    private fun drawStage(canvas: Canvas, mix: Float) {
        fill.color = c.stage
        canvas.drawPath(stagePath, fill)
        val m = min(stageRect.width(), stageRect.height())
        fill.color = ColorUtils.setAlphaComponent(ColorUtils.blendARGB(c.acBg, c.danger, 0.55f * mix), 110)
        canvas.drawCircle(stageRect.left + stageRect.width() * 0.08f, stageRect.top + stageRect.height() * 0.16f, m * 0.36f, fill)
        fill.color = ColorUtils.setAlphaComponent(ColorUtils.blendARGB(c.eqBg, c.danger, 0.7f * mix), 60 + (40 * mix).toInt())
        canvas.drawCircle(stageRect.right - stageRect.width() * 0.04f, stageRect.bottom - stageRect.height() * 0.10f, m * 0.40f, fill)
    }

    /** The phone and everything on it, as it looks at timeline position [t]. */
    private fun drawScene(canvas: Canvas, t: Long) {
        computePress(t)
        fill.color = c.outline
        canvas.drawPath(phonePath, fill)
        canvas.save()
        canvas.clipPath(screenPath)
        fill.color = c.bg
        canvas.drawRect(screenRect, fill)
        drawTopBar(canvas)
        drawDisplay(canvas, t)
        drawKeys(canvas)
        drawHoldRing(canvas, t)
        drawHoldPill(canvas, t)
        drawVault(canvas, t)
        drawToast(canvas, t)
        drawResetPrompt(canvas, t)
        drawRelaunch(canvas, t)
        canvas.restore()
        drawHand(canvas, t)
    }

    private fun drawTopBar(canvas: Canvas) {
        val y = screenRect.top + sh * 0.075f
        drawIcon(canvas, dHistory, screenRect.left + sw * 0.11f, y, sw * 0.1f, c.subtle)
        drawIcon(canvas, dMore, screenRect.right - sw * 0.11f, y, sw * 0.1f, c.subtle)
    }

    private fun drawDisplay(canvas: Canvas, t: Long) {
        val expr = expressionAt(t)
        val right = screenRect.right - sw * 0.075f
        val size = sw * 0.2f
        val baseline = screenRect.top + sh * 0.25f + size * 0.35f
        val cursorW = max(dp(2f), sw * 0.012f)
        val cursorGap = sw * 0.02f
        if (expr.isNotEmpty()) {
            text(canvas, expr, right - cursorW - cursorGap, baseline, size, if (isForgot(t)) c.danger else c.text, keyFont, Paint.Align.RIGHT)
        }
        if ((t / 530L) % 2L == 0L) {
            fill.color = accentOf(t)
            val cy = screenRect.top + sh * 0.25f
            tmpRect.set(right - cursorW, cy - size * 0.46f, right, cy + size * 0.46f)
            canvas.drawRoundRect(tmpRect, cursorW / 2f, cursorW / 2f, fill)
        }
        drawIcon(canvas, dExpand, screenRect.left + sw * 0.11f, keypadTop - sh * 0.045f, sw * 0.1f, c.subtle)
    }

    private fun drawKeys(canvas: Canvas) {
        for (r in 0 until 5) for (col in 0 until 4) {
            val label = LABELS[r][col]
            val rect = keyRects[r][col]
            val bg: Int
            val fg: Int
            when {
                label == "=" -> { bg = c.eqBg; fg = c.eqFg }
                label == "AC" -> { bg = c.acBg; fg = c.acFg }
                label in OPS -> { bg = c.opBg; fg = c.opFg }
                else -> { bg = c.numBg; fg = c.numFg }
            }
            val p = if (label == pressLabel) pressP else 0f
            val cx = rect.centerX()
            val cy = rect.centerY()
            val cell = min(rect.width(), rect.height())
            val sc = 1f - 0.07f * p
            canvas.save()
            canvas.scale(sc, sc, cx, cy)
            fill.color = bg
            canvas.drawRoundRect(rect, cell / 2f, cell / 2f, fill)
            if (p > 0f) {
                fill.color = ColorUtils.setAlphaComponent(fg, (46 * p).toInt())
                canvas.drawRoundRect(rect, cell / 2f, cell / 2f, fill)
            }
            if (label == "⌫") {
                drawIcon(canvas, dBackspace, cx, cy, cell * 0.46f, fg)
            } else {
                val size = when {
                    label == "AC" -> cell * 0.36f
                    label in BIG_GLYPHS -> cell * 0.52f
                    label == "( )" -> cell * 0.40f
                    else -> cell * 0.44f
                }
                val tf = when {
                    label == "=" -> opFont
                    label in LIGHT_GLYPHS -> displayFont
                    else -> keyFont
                }
                textC(canvas, label, cx, cy, size, fg, tf)
            }
            canvas.restore()
        }
    }

    /** Ring that fills around the = key during the 3 second hold. */
    private fun drawHoldRing(canvas: Canvas, t: Long) {
        val hold = holdOf(t)
        if (t < hold.down || t > hold.up) return
        val rect = keyRectOf("=")
        val cx = rect.centerX()
        val cy = rect.centerY()
        val r = min(rect.width(), rect.height()) / 2f + dp(4f)
        val accent = accentOf(t)
        stroke.strokeWidth = max(dp(2.5f), sw * 0.018f)
        stroke.color = ColorUtils.setAlphaComponent(accent, 70)
        canvas.drawCircle(cx, cy, r, stroke)
        stroke.color = accent
        val prog = ((t - hold.down).toFloat() / HOLD_MS).coerceIn(0f, 1f)
        tmpRect.set(cx - r, cy - r, cx + r, cy + r)
        canvas.drawArc(tmpRect, -90f, 360f * prog, false, stroke)
    }

    /** "Hold 3s / 2s / 1s" label above the keypad. */
    private val holdLabels = Array(3) { "Keep holding  ${it + 1}s" }

    private fun drawHoldPill(canvas: Canvas, t: Long) {
        val hold = holdOf(t)
        if (t < hold.down || t > hold.up) return
        val remaining = ceil((hold.up - t) / 1000.0).toInt().coerceIn(1, 3)
        val label = holdLabels[remaining - 1]
        val size = sw * 0.07f
        val tw = measure(label, size, keyFont)
        val h = size * 2.1f
        val w = tw + size * 1.8f
        val cx = screenRect.centerX()
        val cy = keypadTop - sh * 0.05f
        fill.color = if (isForgot(t)) c.danger else c.eqBg
        tmpRect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        canvas.drawRoundRect(tmpRect, h / 2f, h / 2f, fill)
        textC(canvas, label, cx, cy, size, if (isForgot(t)) c.bg else c.eqFg, keyFont)
    }

    /**
     * The confirmation the real app shows in the calculator's result line once "0000" has been held:
     * red text under the (now empty) expression, until = is pressed.
     */
    private fun drawResetPrompt(canvas: Canvas, t: Long) {
        if (!isForgot(t)) return
        val start = fgHold.up + 120L
        val end = fgConfirm.down + 60L
        if (t < start || t > end) return
        val a = when {
            t < start + 220L -> (t - start) / 220f
            t > end - 120L -> (end - t) / 120f
            else -> 1f
        }.coerceIn(0f, 1f)
        val msg = "Press = to erase & reset PIN"
        var size = sw * 0.054f
        val maxW = sw * 0.8f
        val tw = measure(msg, size, keyFont)
        if (tw > maxW) size *= maxW / tw
        val right = screenRect.right - sw * 0.075f
        val y = screenRect.top + sh * 0.335f
        text(canvas, msg, right, y + size * 0.35f, size, ColorUtils.setAlphaComponent(c.danger, (255 * a).toInt()), keyFont, Paint.Align.RIGHT)
    }

    /**
     * After the confirming = press: a red wipe spreads from the key, "Erasing files" then "Relaunching" play, and the
     * wipe fades away to reveal a fresh, empty calculator (the app has relaunched).
     */
    private fun drawRelaunch(canvas: Canvas, t: Long) {
        if (!isForgot(t)) return
        val s0 = fgConfirm.down + 60L
        val e1 = s0 + 420L      // the wipe covers the screen
        val e2 = e1 + 850L      // "Erasing files" until here
        val e3 = e2 + 950L      // "Relaunching" until here
        val e4 = e3 + 450L      // fades out
        if (t < s0 || t > e4) return
        val key = keyRectOf("=")
        val kx = key.centerX()
        val ky = key.centerY()
        val maxR = hypot(
            max(kx - screenRect.left, screenRect.right - kx),
            max(ky - screenRect.top, screenRect.bottom - ky)
        )
        val fade = if (t > e3) 1f - (t - e3) / 450f else 1f
        fill.color = ColorUtils.setAlphaComponent(c.danger, (248 * fade).toInt())
        canvas.drawCircle(kx, ky, maxR * decel((t - s0) / 420f), fill)

        val appear = ((t - (s0 + 300L)) / 200f).coerceIn(0f, 1f) * fade
        if (appear <= 0f) return
        val cx = screenRect.centerX()
        val cy = screenRect.centerY() - sh * 0.02f
        val iconSize = sw * 0.24f
        val labelSize = sw * 0.07f
        val mixB = ((t - (e2 - 100L)) / 200f).coerceIn(0f, 1f)    // 0 = erasing, 1 = relaunching
        val fg = c.bg

        // Erasing: a bin that pops in
        val aErase = appear * (1f - mixB)
        if (aErase > 0f) {
            val pop = decel((t - (s0 + 300L)) / 260f)
            val sc = 0.6f + 0.4f * pop + 0.08f * kotlin.math.sin(pop * Math.PI).toFloat()
            canvas.save()
            canvas.scale(sc, sc, cx, cy)
            drawIcon(canvas, dDelete, cx, cy, iconSize, fg, (255 * aErase).toInt())
            canvas.restore()
            textC(canvas, "Erasing files", cx, cy + iconSize * 0.95f, labelSize, ColorUtils.setAlphaComponent(fg, (255 * aErase).toInt()), keyFont)
        }
        // Relaunching: a spinning arrow
        val aRelaunch = appear * mixB
        if (aRelaunch > 0f) {
            val spin = (t - e2) / 950f * 540f
            canvas.save()
            canvas.rotate(spin, cx, cy)
            drawIcon(canvas, dRefresh, cx, cy, iconSize, fg, (255 * aRelaunch).toInt())
            canvas.restore()
            textC(canvas, "Relaunching", cx, cy + iconSize * 0.95f, labelSize, ColorUtils.setAlphaComponent(fg, (255 * aRelaunch).toInt()), keyFont)
        }
    }

    /** The "Password set" toast that appears when the hold completes. */
    private fun drawToast(canvas: Canvas, t: Long) {
        val start = holdAct.up
        val end = start + 1530L
        if (t < start || t > end) return
        val a = when {
            t < start + 150L -> (t - start) / 150f
            t > end - 250L -> (end - t) / 250f
            else -> 1f
        }.coerceIn(0f, 1f)
        val size = sw * 0.066f
        val tw = measure("Password set", size, keyFont)
        val h = size * 2.3f
        val w = tw + size * 2.4f
        val cx = screenRect.centerX()
        val cy = screenRect.bottom - sh * 0.07f + (1f - a) * dp(8f)
        fill.color = ColorUtils.setAlphaComponent(c.text, (255 * a).toInt())
        tmpRect.set(cx - w / 2f, cy - h / 2f, cx + w / 2f, cy + h / 2f)
        canvas.drawRoundRect(tmpRect, h / 2f, h / 2f, fill)
        textC(canvas, "Password set", cx, cy, size, ColorUtils.setAlphaComponent(c.bg, (255 * a).toInt()), keyFont)
    }

    // ---- vault --------------------------------------------------------------------------------

    private val openStart get() = unlockAct.down + 40L

    private fun vaultProgress(t: Long): Float {
        val openEnd = openStart + 480L
        val closeStart = 14800L
        val closeEnd = 15250L
        return when {
            t < openStart -> 0f
            t < openEnd -> decel((t - openStart) / 480f)
            t < closeStart -> 1f
            t < closeEnd -> 1f - accel((t - closeStart) / 450f)
            else -> 0f
        }
    }

    private fun drawVault(canvas: Canvas, t: Long) {
        val v = vaultProgress(t)
        if (v <= 0f) return
        canvas.save()
        canvas.translate(0f, (1f - v) * sh)

        val l = screenRect.left
        val top = screenRect.top
        val r = screenRect.right
        val b = screenRect.bottom
        val cornerR = sw * 0.09f
        tmpRect.set(l, top, r, b + cornerR)
        fill.color = c.stage
        canvas.drawRoundRect(tmpRect, cornerR, cornerR, fill)
        stroke.strokeWidth = dp(1f)
        stroke.color = ColorUtils.setAlphaComponent(c.outline, 160)
        canvas.drawRoundRect(tmpRect, cornerR, cornerR, stroke)

        // Header: "Secure Vault" ... Close  (i)
        val titleSize = sw * 0.07f
        text(canvas, "Secure Vault", l + sw * 0.06f, top + sh * 0.09f + titleSize * 0.35f, titleSize, c.text, keyFont, Paint.Align.LEFT)
        drawIcon(canvas, dInfo, r - sw * 0.085f, top + sh * 0.09f, sw * 0.09f, c.subtle)
        text(canvas, "Close", r - sw * 0.16f, top + sh * 0.09f + sw * 0.016f, sw * 0.048f, c.primary, keyFont, Paint.Align.RIGHT)

        // Filter chips
        val chipsY = top + sh * 0.165f
        val chipH = sw * 0.1f
        val chipText = sw * 0.045f
        var x = l + sw * 0.06f
        val chips = arrayOf("All", "Photos", "Videos")
        for (i in chips.indices) {
            val cw = measure(chips[i], chipText, keyFont) + chipText * 1.8f
            tmpRect.set(x, chipsY - chipH / 2f, x + cw, chipsY + chipH / 2f)
            if (i == 0) {
                fill.color = c.acBg
                canvas.drawRoundRect(tmpRect, chipH * 0.3f, chipH * 0.3f, fill)
            } else {
                stroke.strokeWidth = dp(1f)
                stroke.color = c.outline
                canvas.drawRoundRect(tmpRect, chipH * 0.3f, chipH * 0.3f, stroke)
            }
            textC(canvas, chips[i], tmpRect.centerX(), chipsY, chipText, if (i == 0) c.acFg else c.text, keyFont)
            x += cw + sw * 0.025f
        }

        // File tiles (they pop in one after another)
        val gap = sw * 0.025f
        val side = sw * 0.06f
        val tile = (sw - 2f * side - 2f * gap) / 3f
        val gridTop = top + sh * 0.225f
        val tileBgs = intArrayOf(c.numBg, c.opBg, c.acBg, c.opBg, c.eqBg, c.numBg)
        val tileFgs = intArrayOf(c.numFg, c.opFg, c.acFg, c.opFg, c.eqFg, c.numFg)
        for (i in 0 until 12) {
            val row = i / 3
            val col = i % 3
            val p = decel(((t - (openStart + 250L + i * 45L)) / 220f))
            if (p <= 0f) continue
            val tx = l + side + col * (tile + gap)
            val ty = gridTop + row * (tile + gap)
            val cx = tx + tile / 2f
            val cy = ty + tile / 2f
            val k = (i * 5 + row) % tileBgs.size
            canvas.save()
            val sc = 0.8f + 0.2f * p
            canvas.scale(sc, sc, cx, cy)
            fill.color = ColorUtils.setAlphaComponent(tileBgs[k], (255 * p).toInt())
            tmpRect.set(tx, ty, tx + tile, ty + tile)
            canvas.drawRoundRect(tmpRect, tile * 0.2f, tile * 0.2f, fill)
            val d = when (i % 3) { 0 -> dImage; 1 -> dPlay; else -> dFile }
            drawIcon(canvas, d, cx, cy, tile * 0.42f, tileFgs[k], (255 * p).toInt())
            canvas.restore()
        }

        // Add button
        val fp = decel((t - (openStart + 300L)) / 260f)
        if (fp > 0f) {
            val fs = sw * 0.19f
            val fx = r - sw * 0.06f - fs / 2f
            val fy = b - sh * 0.045f - fs / 2f
            canvas.save()
            canvas.scale(fp, fp, fx, fy)
            fill.color = c.acBg
            tmpRect.set(fx - fs / 2f, fy - fs / 2f, fx + fs / 2f, fy + fs / 2f)
            canvas.drawRoundRect(tmpRect, fs * 0.3f, fs * 0.3f, fill)
            drawIcon(canvas, dAdd, fx, fy, fs * 0.5f, c.acFg)
            canvas.restore()
        }
        canvas.restore()
    }

    // ---- hand ---------------------------------------------------------------------------------

    private fun drawHand(canvas: Canvas, t: Long) {
        val list = actsAt(t)
        val first = list[0]
        val last = list[list.size - 1]
        if (t < first.moveStart) return
        val exitStart = last.up + 120L
        if (t > exitStart + 500L) return

        // The hand starts and ends just below the stage.
        val offX = phoneRect.right - sw * 0.1f
        val offY = stageRect.bottom + handSize * 0.1f

        var idx = 0
        for (i in list.indices.reversed()) {
            if (t >= list[i].moveStart) { idx = i; break }
        }
        val a = list[idx]
        val tr = keyRectOf(a.key)
        val tx = tr.centerX()
        val ty = tr.centerY()
        val px: Float
        val py: Float
        if (idx == 0) {
            px = offX; py = offY
        } else {
            val pr = keyRectOf(list[idx - 1].key)
            px = pr.centerX(); py = pr.centerY()
        }
        var hx = tx
        var hy = ty
        if (t < a.arrive) {
            val f = smooth((t - a.moveStart).toFloat() / (a.arrive - a.moveStart).toFloat())
            hx = px + (tx - px) * f
            hy = py + (ty - py) * f
        }
        var alpha = 1f
        if (idx == 0) alpha = ((t - a.moveStart) / 300f).coerceIn(0f, 1f)
        if (t > exitStart) {
            val e = ((t - exitStart) / 500f).coerceIn(0f, 1f)
            val f = smooth(e)
            hx += (offX - hx) * f
            hy += (offY - hy) * f
            alpha = 1f - e
        }

        // Touch indicator under the fingertip while pressing
        if (pressP > 0f) {
            fill.color = ColorUtils.setAlphaComponent(if (isForgot(t)) c.danger else c.text, (70 * pressP * alpha).toInt())
            canvas.drawCircle(hx, hy, handSize * 0.12f, fill)
        }

        val u = handSize / 28f
        val left = hx - 13.5f * u
        val topY = hy - 8.2f * u
        val sc = 1f - 0.06f * pressP
        canvas.save()
        canvas.scale(sc, sc, hx, hy)
        val bounds = intArrayOf(Math.round(left), Math.round(topY), Math.round(left + handSize), Math.round(topY + handSize))
        val a255 = (255 * alpha).toInt()
        dHandOutline.setBounds(bounds[0], bounds[1], bounds[2], bounds[3])
        dHandOutline.setTint(c.bg)
        dHandOutline.alpha = a255
        dHandOutline.draw(canvas)
        dHand.setBounds(bounds[0], bounds[1], bounds[2], bounds[3])
        dHand.setTint(c.text)
        dHand.alpha = a255
        dHand.draw(canvas)
        canvas.restore()
    }
}

/**
 * Container for the guide: turns horizontal drags anywhere on the page into slide swipes on [demo], while taps on
 * its buttons and dots still work (a drag only takes over once it is clearly horizontal).
 */
class SwipeHost(ctx: Context, private val demo: GuideDemoView) : FrameLayout(ctx) {

    private val slop = ViewConfiguration.get(ctx).scaledTouchSlop
    private var downX = 0f
    private var downY = 0f
    private var dragging = false
    private var tracker: VelocityTracker? = null

    private fun track(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            tracker?.recycle()
            tracker = VelocityTracker.obtain()
            downX = ev.x
            downY = ev.y
            dragging = false
        }
        tracker?.addMovement(ev)
        when (ev.actionMasked) {
            MotionEvent.ACTION_MOVE -> {
                if (!dragging) {
                    val dx = ev.x - downX
                    val dy = ev.y - downY
                    if (abs(dx) > slop && abs(dx) > abs(dy) * 1.3f) {
                        dragging = true
                        parent?.requestDisallowInterceptTouchEvent(true)
                        demo.beginDrag(ev.x)
                    }
                }
                if (dragging) demo.dragTo(ev.x)
            }
            MotionEvent.ACTION_UP -> {
                if (dragging) {
                    tracker?.computeCurrentVelocity(1000)
                    demo.endDrag(tracker?.xVelocity ?: 0f)
                }
                dragging = false
                tracker?.recycle()
                tracker = null
            }
            MotionEvent.ACTION_CANCEL -> {
                if (dragging) demo.endDrag(0f)
                dragging = false
                tracker?.recycle()
                tracker = null
            }
        }
        return dragging
    }

    override fun onInterceptTouchEvent(ev: MotionEvent): Boolean = track(ev)

    override fun onTouchEvent(ev: MotionEvent): Boolean {
        track(ev)
        return true
    }
}
