package com.onion.calcognito

import android.app.ActivityManager
import android.app.Application
import android.app.ApplicationExitInfo
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import androidx.annotation.RequiresApi
import java.io.PrintWriter
import java.io.StringWriter
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Finds out why the app closed, without needing a computer. Java crashes are written down by an exception handler;
 * native crashes (which no handler can catch) are read back from Android's own exit records on the next start
 * (Android 11+). [pending] returns a short report to show once, or null if the last run ended normally.
 */
object CrashReport {
    private const val PREFS = "crash_report"

    private fun device() =
        "Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT}), ${Build.MANUFACTURER} ${Build.MODEL}, " +
            (Build.SUPPORTED_ABIS.firstOrNull() ?: "?")

    private fun stamp(time: Long = System.currentTimeMillis()) =
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(time))

    private fun processName(): String? = try {
        if (Build.VERSION.SDK_INT >= 28) Application.getProcessName() else null
    } catch (_: Throwable) {
        null
    }

    /** The main process (the one the person is using), as opposed to the crash screen or a hidden app's process. */
    fun isMainProcess(ctx: Context): Boolean = processName()?.let { it == ctx.packageName } ?: true

    /** Opens the crash screen (its own process) with [report]. */
    fun show(ctx: Context, report: String) {
        try {
            ctx.startActivity(
                Intent(ctx, CrashActivity::class.java)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
                    .putExtra("report", report.take(7000))
            )
        } catch (_: Throwable) {
        }
    }

    /** Call in Application.onCreate (every process). */
    fun install(app: Application) {
        val previous = Thread.getDefaultUncaughtExceptionHandler()
        val main = isMainProcess(app)
        Thread.setDefaultUncaughtExceptionHandler { thread, error ->
            try {
                val sw = StringWriter()
                error.printStackTrace(PrintWriter(sw))
                val text = "Java crash on ${stamp()} (thread ${thread.name})\n${device()}\n\n" + sw.toString().take(5000)
                val p = app.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                p.edit().putString("java", text).putBoolean("javaShown", false).commit()
                if (main) {
                    // Show it straight away, in its own process, before this one dies.
                    show(app, text)
                    p.edit().putBoolean("javaShown", true).commit()
                }
            } catch (_: Throwable) {
            }
            if (previous != null) {
                previous.uncaughtException(thread, error)
            } else {
                android.os.Process.killProcess(android.os.Process.myPid())
                System.exit(10)
            }
        }
    }

    /** What went wrong last time, once; null if nothing did. */
    fun pending(ctx: Context): String? {
        val p = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val sb = StringBuilder()
        // A Java crash that was already shown on screen when it happened is not shown a second time.
        if (!p.getBoolean("javaShown", false)) p.getString("java", null)?.let { sb.append(it).append("\n\n") }
        p.edit().remove("java").remove("javaShown").apply()
        if (Build.VERSION.SDK_INT >= 30) sb.append(exitRecords(ctx, p))
        val text = sb.toString().trim()
        return text.ifEmpty { null }
    }

    @RequiresApi(30)
    private fun reasonName(reason: Int): String? = when (reason) {
        ApplicationExitInfo.REASON_CRASH -> "Java crash"
        ApplicationExitInfo.REASON_CRASH_NATIVE -> "native crash"
        ApplicationExitInfo.REASON_ANR -> "app not responding"
        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "failed to start"
        ApplicationExitInfo.REASON_SIGNALED -> "killed by a signal"
        else -> null   // normal kills (swipe away, memory pressure ...) are not interesting
    }

    @RequiresApi(30)
    private fun exitRecords(ctx: Context, p: SharedPreferences): String {
        val seen = p.getLong("seen", 0L)
        var newest = seen
        val sb = StringBuilder()
        try {
            val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            for (info in am.getHistoricalProcessExitReasons(null, 0, 6)) {
                if (info.timestamp <= seen) continue
                newest = maxOf(newest, info.timestamp)
                val name = reasonName(info.reason) ?: continue
                sb.append("Process \"${info.processName}\" ended: $name on ${stamp(info.timestamp)}\n")
                if (!info.description.isNullOrBlank()) sb.append("  ${info.description}\n")
                val raw = try {
                    info.traceInputStream?.use { it.readBytes() }
                } catch (_: Throwable) {
                    null
                }
                if (raw != null && raw.isNotEmpty()) {
                    for (line in interesting(raw)) sb.append("  ").append(line).append('\n')
                }
                sb.append('\n')
            }
        } catch (_: Throwable) {
        }
        if (newest > seen) p.edit().putLong("seen", newest).apply()
        if (sb.isNotEmpty()) sb.insert(0, "${device()}\n\n")
        return sb.toString()
    }

    /** Native crash dumps are binary; pull out the readable lines that name the signal, the libraries and the code. */
    private fun interesting(raw: ByteArray): List<String> {
        val data = if (raw.size > 400_000) raw.copyOf(400_000) else raw
        val keep = Regex(
            "signal|SIG[A-Z]+|abort|fatal|assert|backtrace|\\.so|calcognito|niunaijun|libart|libc|jni|hook|dobby|native",
            RegexOption.IGNORE_CASE
        )
        val found = LinkedHashSet<String>()
        val cur = StringBuilder()
        fun flush() {
            if (cur.length >= 6) {
                val s = cur.toString().trim()
                if (keep.containsMatchIn(s)) found.add(s.take(140))
            }
            cur.setLength(0)
        }
        for (b in data) {
            val c = b.toInt() and 0xFF
            if (c in 32..126) cur.append(c.toChar()) else flush()
        }
        flush()
        return found.take(40)
    }
}
