plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Hidden apps run in an embedded virtual engine (BlackBox). Build its AAR with scripts/build_engine.sh and put it in
// app/libs: when one is there the real engine bridge is compiled in, otherwise a stub is used and the app still builds.
val engineAars = fileTree("libs") { include("*.aar") }
val hasEngine = !engineAars.isEmpty

android {
    namespace = "com.onion.calcognito"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.onion.calcognito"
        minSdk = 24
        targetSdk = 36
        versionCode = 8
        versionName = "1.7"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    // One fixed debug key, committed with the project. Without it every CI run signs the APK with a brand-new random
    // key, and Android refuses to install a build over the previous one ("App conflicts with older package").
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    sourceSets {
        getByName("main") {
            java.srcDir(if (hasEngine) "src/engine/java" else "src/noengine/java")
        }
    }
    packaging {
        jniLibs {
            // Keep native libraries extracted on disk; virtual engines generally need that.
            useLegacyPackaging = true
        }
    }
}

dependencies {
    if (hasEngine) implementation(engineAars)
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    // Video / audio player (ExoPlayer): MP4, MKV, WebM, MOV, TS, FLV, MP3, AAC, FLAC, OGG/Opus, WAV, AMR, MIDI ...
    implementation("androidx.media3:media3-exoplayer:1.6.1")
    implementation("androidx.media3:media3-ui:1.6.1")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
