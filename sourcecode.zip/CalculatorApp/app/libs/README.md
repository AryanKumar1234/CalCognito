# libmpv for the video player

The vault video player uses libmpv (as in Nosved Player). The library is committed here as:

    app/libs/mpvlib.aar

It is `mpv-android-lib-2026-07-18.aar` from https://github.com/Riteshp2001/mpvlibAndroid/releases/tag/2026-07-18
(that repository is the working sibling of SunnyVishnu3/mpvlibAndroid). It contains `jni/<abi>/` native libraries —
`libmpv.so` and the JNI glue `libplayer.so` plus the FFmpeg libraries — which Android loads with `System.loadLibrary`
("mpv", "player"), so nothing has to be extracted from assets at runtime.

Do **not** take SunnyVishnu3/mpvlibAndroid's 2026-6-1 release instead: it ships only `assets/native-v9a/*.so`, has no
`libplayer.so`, and the player fails at runtime with `UnsatisfiedLinkError ("The video engine couldn't start")`.

Only `arm64-v8a` and `armeabi-v7a` are packaged into the APK (`ndk { abiFilters }` in `app/build.gradle.kts`); the AAR
also carries x86/x86_64 for emulators, which would add about 30 MB for no benefit on a phone.

The AAR is large (about 71 MB, most of it FFmpeg and libmpv), which is why the mpv build's APK is much bigger than the
ExoPlayer build in `CalculatorApp-v20.zip`.
