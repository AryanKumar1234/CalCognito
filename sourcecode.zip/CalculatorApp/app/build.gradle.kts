plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.onion.calcognito"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.onion.calcognito"
        minSdk = 24
        targetSdk = 36
        versionCode = 15
        versionName = "3.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        ndk {
            // libmpv (app/libs/mpvlib.aar) ships arm64-v8a, armeabi-v7a, x86 and x86_64. Phones are arm64 (or old
            // 32-bit ARM); dropping the two emulator ABIs keeps roughly 30 MB of dead native code out of the APK.
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // One fixed debug key, committed with the project. Without it every CI run signs the APK with a brand-new random
    // key, and Android refuses to install a build over the previous one ("App conflicts with older package").
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }
    }

    buildTypes {
        release {
            // Not debuggable, so Android does not run the app with CheckJNI (which aborts the process on JNI problems
            // the engine's native code would otherwise survive). Signed with the same committed key as the debug build,
            // so it installs over it and over the previous release. No R8: the engine reaches into the app by name.
            isMinifyEnabled = false
            isDebuggable = false
            signingConfig = signingConfigs.getByName("debug")
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    lint {
        // Release builds run lint "vital" checks; the all-files permission is declared on purpose (see the manifest).
        checkReleaseBuilds = false
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging {
        jniLibs {
            // Keep native libraries extracted on disk; virtual engines generally need that.
            useLegacyPackaging = true
        }
    }
}

// Kotlin's JVM target (kotlinOptions is gone in Kotlin 2.4; this is the compilerOptions DSL).
kotlin {
    compilerOptions {
        jvmTarget.set(org.jetbrains.kotlin.gradle.dsl.JvmTarget.JVM_17)
    }
}

dependencies {
    // Hidden apps run in an embedded virtual engine (BlackBox), built from the :Bcore module (with :black-reflection and
    // :compiler) in this project. Only EngineBridge.kt touches it.
    implementation(project(":Bcore"))
    // Lets the engine reach the Android internals it hooks even though this app targets a recent Android version.
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    // Hiding apps with Shizuku or Sui (same API; the provider also starts Sui automatically). MIT licensed.
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    // Video / audio player: libmpv (the engine of Nosved Player / mpv-android), through MpvEngine.kt.
    // Put mpvlib.aar in app/libs/ (see app/libs/README.md for where to get it).
    implementation(files("libs/mpvlib.aar"))
    // mpvlib's Kotlin API uses Flow / StateFlow.
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.9.0")
    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")
}
