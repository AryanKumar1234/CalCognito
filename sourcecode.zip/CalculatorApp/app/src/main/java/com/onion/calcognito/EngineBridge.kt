package com.onion.calcognito

import android.app.Application
import android.content.Context
import android.os.Build
import android.util.Log
import org.lsposed.hiddenapibypass.HiddenApiBypass
import top.niunaijun.blackbox.BlackBoxCore
import top.niunaijun.blackbox.app.configuration.ClientConfiguration

/**
 * The ONLY file that touches the BlackBox virtual-engine classes. The engine is built from source with the app (the
 * :Bcore, :black-reflection and :compiler modules of this project). Every call is wrapped so an engine problem can
 * never crash the calculator.
 *
 * The engine is NOT started when the app opens. Its low-level hooks can crash some phones (that would make the whole
 * app crash every time it opens), so the main process only starts it the first time hidden apps are used ([start]),
 * and remembers if that start ever killed the app so it can be switched off. The processes the engine creates for the
 * hidden apps themselves start it straight away, as the engine requires.
 *
 * Hidden-API access: the engine's native start-up looks up a hidden Android method (Field.getArtField). The likely
 * cause of the earlier "JNI DETECTED ERROR ... mid == null" crash is that an app targeting a recent Android version is
 * refused that lookup unless the exemption is set first (the refusal aborts the process). The engine's own bypass may
 * not work on every phone, so it is also done here with [HiddenApiBypass] before the engine attaches. The project the
 * engine came from targets Android 9 (API 28), which would hide the problem; this app does not.
 *
 * Privacy: by default the engine uploads the full logcat to a third-party server when a crash is caught. That is
 * switched off in [configuration] (empty chat id), so nothing leaves the phone.
 */
object EngineBridge {
    private const val TAG = "CalEngine"
    private const val GUARD = "engine_guard"
    @Volatile private var attached = false
    @Volatile private var created = false
    @Volatile private var bypassTried = false
    @Volatile private var lastFailure: String? = null
    @Volatile private var appBase: Context? = null

    /** The engine is running in this process. */
    val available: Boolean get() = attached && created

    /** True when the engine classes are part of this build (so "not available" means it failed to start). */
    val compiledIn: Boolean get() = true

    /** Why the engine did not start (shown in the app and written to logcat as "CalEngine"); null if no error was seen. */
    val failure: String? get() = lastFailure

    private fun processName(): String? = try {
        if (Build.VERSION.SDK_INT >= 28) Application.getProcessName()
        else java.io.File("/proc/self/cmdline").readText().trim('\u0000', ' ')
    } catch (_: Throwable) {
        null
    }

    private fun isMainProcess(ctx: Context): Boolean {
        val name = processName() ?: return true
        return name == ctx.packageName
    }

    /** The app's own processes (main and the crash screen), as opposed to the ones the engine creates for hidden apps. */
    private fun isOwnProcess(ctx: Context): Boolean {
        val name = processName() ?: return true
        return name == ctx.packageName || name == ctx.packageName + ":crash"
    }

    private fun describe(t: Throwable): String {
        val parts = ArrayList<String>()
        var cur: Throwable? = t
        var depth = 0
        while (cur != null && depth < 4) {
            parts.add(cur.javaClass.name + (cur.message?.let { ": " + it.take(160) } ?: ""))
            cur = cur.cause
            depth++
        }
        return parts.joinToString("  <-  ")
    }

    private fun fail(stage: String, t: Throwable) {
        attached = false
        created = false
        val text = "$stage failed: ${describe(t)}"
        lastFailure = text
        try { Log.e(TAG, text, t) } catch (_: Throwable) {}
    }

    /** Lets this process reach hidden Android members (see the note on the class). Done once per process. */
    private fun relaxHiddenApi() {
        if (bypassTried) return
        bypassTried = true
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return
        try {
            HiddenApiBypass.addHiddenApiExemptions("L")
        } catch (t: Throwable) {
            try { Log.w(TAG, "Hidden-API bypass failed: ${describe(t)}") } catch (_: Throwable) {}
        }
    }

    /**
     * What the engine asks the host app. The switches come from [EngineOptions] (the engine settings in the Apps
     * folder) and are read every time they are asked for, so changing one applies to the next hidden app that starts
     * without needing to restart the engine. Defaults match the engine's own sample app, except for the log upload.
     */
    private fun configuration(base: Context) = object : ClientConfiguration() {
        override fun getHostPackageName(): String = base.packageName
        override fun isHideRoot(): Boolean = EngineOptions.hideRoot(base)
        override fun isEnableDaemonService(): Boolean = EngineOptions.daemonEnabled(base)
        override fun isGamingMode(): Boolean = EngineOptions.gamingMode(base)
        override fun isUseVpnNetwork(): Boolean = EngineOptions.useVpnNetwork(base)
        override fun isDisableFlagSecure(): Boolean = EngineOptions.disableFlagSecure(base)
        // The engine's default would send the whole logcat to a third-party server after a caught crash.
        override fun getLogSenderChatId(): String = ""
    }

    private fun attachNow(base: Context) {
        try {
            relaxHiddenApi()
            BlackBoxCore.get().doAttachBaseContext(base, configuration(base))
            attached = true
            lastFailure = null
        } catch (t: Throwable) {
            fail("Attach", t)
        }
    }

    private fun createNow() {
        if (!attached) return
        try {
            BlackBoxCore.get().doCreate()
            created = true
        } catch (t: Throwable) {
            fail("Start", t)
        }
    }

    /** Application.attachBaseContext. Hidden-app processes start the engine now; the main process waits for [start]. */
    fun attach(base: Context) {
        appBase = base
        if (isOwnProcess(base)) return
        attachNow(base)
    }

    /** Application.onCreate (same rule as [attach]). */
    fun create() {
        val ctx = appBase ?: return
        if (isOwnProcess(ctx)) return
        createNow()
    }

    /**
     * Starts the engine in the main process if it isn't running yet. Blocking: call from a worker thread. If the
     * process dies natively while this runs, [checkPreviousCrash] sees the marker on the next launch and turns the
     * engine off, so the app still opens. Returns whether the engine is running.
     */
    @Synchronized
    fun start(ctx: Context): Boolean {
        if (available) return true
        val p = ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE)
        if (p.getBoolean("disabled", false)) {
            lastFailure = p.getString("note", null)
            return false
        }
        p.edit().putString("inflight", "start").commit()   // synchronous, so it survives a crash right after
        try {
            if (!attached) attachNow(appBase ?: ctx.applicationContext)
            createNow()
        } catch (t: Throwable) {
            fail("Start", t)
        } finally {
            p.edit().remove("inflight").commit()
        }
        return available
    }

    /** Call once when the app opens: if the last start of the engine never finished, it crashed the app. */
    fun checkPreviousCrash(ctx: Context) {
        if (!isMainProcess(ctx)) return
        val p = ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE)
        val op = p.getString("inflight", null) ?: return
        val e = p.edit().remove("inflight")
        if (op == "start") {
            val note = "The hidden-app engine crashed this app while starting on this phone (Android " +
                "${Build.VERSION.RELEASE}, API ${Build.VERSION.SDK_INT}). It has been switched off so the app keeps " +
                "opening normally."
            e.putBoolean("disabled", true).putString("note", note)
            lastFailure = note
        }
        e.commit()
    }

    fun disabledByCrash(ctx: Context): Boolean =
        ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE).getBoolean("disabled", false)

    /** Lets the engine try to start again after it was switched off. */
    fun resetGuard(ctx: Context) {
        ctx.getSharedPreferences(GUARD, Context.MODE_PRIVATE).edit().clear().commit()
        lastFailure = null
    }

    /** null = could not tell. */
    private fun queryInstalled(pkg: String, userId: Int): Boolean? = try {
        BlackBoxCore.get().isInstalled(pkg, userId)
    } catch (_: Throwable) {
        null
    }

    fun isInstalled(pkg: String, userId: Int): Boolean = available && queryInstalled(pkg, userId) == true

    /**
     * The engine's own reason for the most recent failed [install] (null after a success). Shown to the user so a
     * failure says what actually went wrong, instead of a guess.
     */
    @Volatile
    var lastInstallError: String? = null
        private set

    /** Clones the installed app [pkg] into the virtual space. Blocking: call from a worker thread. */
    fun install(pkg: String, userId: Int): Boolean {
        lastInstallError = null
        if (!available) {
            lastInstallError = "the engine isn't running"
            return false
        }
        return try {
            val r = BlackBoxCore.get().installPackageAsUser(pkg, userId)
            val listed = queryInstalled(pkg, userId) != false
            val ok = r != null && r.success && listed
            if (!ok) {
                lastInstallError = when {
                    r == null -> "the engine returned no result"
                    !r.success -> r.msg ?: "the engine refused to install it"
                    else -> "the engine finished, but the app isn't listed as installed in the space"
                }
                try { Log.w(TAG, "install $pkg failed: $lastInstallError") } catch (_: Throwable) {}
            }
            ok
        } catch (t: Throwable) {
            lastInstallError = describe(t)
            try { Log.w(TAG, "install $pkg threw: ${describe(t)}", t) } catch (_: Throwable) {}
            false
        }
    }

    /** Installs the APK file [apk] (package [pkg]) into the virtual space. Blocking: call from a worker thread. */
    fun installFile(apk: java.io.File, pkg: String, userId: Int): Boolean {
        lastInstallError = null
        if (!available) {
            lastInstallError = "the engine isn't running"
            return false
        }
        return try {
            val r = BlackBoxCore.get().installPackageAsUser(apk, userId)
            val listed = queryInstalled(pkg, userId) != false
            val ok = r != null && r.success && listed
            if (!ok) {
                lastInstallError = when {
                    r == null -> "the engine returned no result"
                    !r.success -> r.msg ?: "the engine refused to install it"
                    else -> "the engine finished, but the app isn't listed as installed in the space"
                }
                try { Log.w(TAG, "installFile $pkg failed: $lastInstallError") } catch (_: Throwable) {}
            }
            ok
        } catch (t: Throwable) {
            lastInstallError = describe(t)
            try { Log.w(TAG, "installFile $pkg threw: ${describe(t)}", t) } catch (_: Throwable) {}
            false
        }
    }

    /** Closes the clone's process if it is running, so its next start sees changes made to the space. Blocking. */
    fun stop(pkg: String, userId: Int) {
        if (!available) return
        try {
            BlackBoxCore.get().stopPackage(pkg, userId)
        } catch (_: Throwable) {
        }
    }

    /** Starts the cloned app inside the virtual space (the engine opens its window itself). Call on the main thread. */
    @Suppress("UNUSED_PARAMETER")
    fun launch(ctx: Context, pkg: String, userId: Int): Boolean {
        if (!available) return false
        return try {
            BlackBoxCore.get().launchApk(pkg, userId)
        } catch (_: Throwable) {
            false
        }
    }

    /** Removes the clone and its data from the virtual space. Blocking. */
    fun uninstall(pkg: String, userId: Int): Boolean {
        if (!available) return false
        try {
            BlackBoxCore.get().uninstallPackageAsUser(pkg, userId)
        } catch (_: Throwable) {
            return false
        }
        return queryInstalled(pkg, userId) != true
    }
}
