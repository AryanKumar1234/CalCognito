package com.onion.calcognito

import android.content.Context

/**
 * The few things the person can customise (Settings, top right of the vault). Plain SharedPreferences; every value
 * has a default so a fresh install behaves like the old versions.
 */
object AppSettings {
    private const val PREF = "calc_settings"

    const val HIDE_ASK = "ask"
    const val HIDE_SHIZUKU = "shizuku"
    const val HIDE_ENGINE = "engine"

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** Adding files: is the "Encrypt the files" box ticked by default? */
    fun encryptByDefault(ctx: Context) = p(ctx).getBoolean("encrypt_default", false)
    fun setEncryptByDefault(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("encrypt_default", v).apply()

    /** Adding files: show the "Add files" question every time? When off, the choice above is used straight away. */
    fun askBeforeAdd(ctx: Context) = p(ctx).getBoolean("ask_before_add", true)
    fun setAskBeforeAdd(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("ask_before_add", v).apply()

    /** Hiding apps: [HIDE_ASK] (ask every time), [HIDE_SHIZUKU] or [HIDE_ENGINE]. */
    fun hideMethod(ctx: Context): String = p(ctx).getString("hide_method", HIDE_ASK) ?: HIDE_ASK
    fun setHideMethod(ctx: Context, v: String) = p(ctx).edit().putString("hide_method", v).apply()

    /** Hiding an app with the engine: is "also set up Google services (microG)" ticked by default? */
    fun gmsWithHide(ctx: Context) = p(ctx).getBoolean("gms_with_hide", true)
    fun setGmsWithHide(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("gms_with_hide", v).apply()

    /** The video player continues from where each video was left. */
    fun resumeVideos(ctx: Context) = p(ctx).getBoolean("resume_videos", true)
    fun setResumeVideos(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("resume_videos", v).apply()

    /** Sort order of the "Choose an app to hide" list: 0 A–Z, 1 Z–A, 2 newest installed, 3 oldest installed, 4 largest. */
    fun appPickerSort(ctx: Context) = p(ctx).getInt("app_picker_sort", 0)
    fun setAppPickerSort(ctx: Context, v: Int) = p(ctx).edit().putInt("app_picker_sort", v).apply()

    // ---- where each video was left (per vault file) ----
    private fun rp(ctx: Context) = ctx.applicationContext.getSharedPreferences("video_resume", Context.MODE_PRIVATE)
    fun resumePosition(ctx: Context, key: String): Long = rp(ctx).getLong(key, 0L)
    fun saveResumePosition(ctx: Context, key: String, ms: Long) {
        if (ms <= 0L) rp(ctx).edit().remove(key).apply() else rp(ctx).edit().putLong(key, ms).apply()
    }
    fun clearResumePositions(ctx: Context) = rp(ctx).edit().clear().apply()
}
