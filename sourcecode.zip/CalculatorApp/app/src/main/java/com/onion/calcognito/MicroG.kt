package com.onion.calcognito

import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

/**
 * Fetches microG (the open-source stand-in for Google Play services) from microG's official F-Droid repository, for
 * phones that have no Google Play services of their own. Nothing is bundled in the app: the three packages are
 * downloaded over HTTPS the first time and checked against the SHA-256 the repository publishes.
 *
 *  - GmsCore         com.google.android.gms   (Play services replacement)
 *  - GsfProxy        com.google.android.gsf   (Services Framework proxy)
 *  - FakeStore       com.android.vending      (Play Store stand-in, lets apps ask for "Play Store" checks)
 *
 * They are installed into the hidden space only (see [VirtualSpace.enableGms]); the engine reports Google's certificate
 * for them to cloned apps (microG's "fake-signature" manifest entry), which is the signature spoofing microG needs.
 */
object MicroG {
    private const val REPO = "https://microg.org/fdroid/repo"
    private const val INDEX = "$REPO/index-v1.json"
    private const val DIR = "microg"
    private const val CONNECT_MS = 15_000
    private const val READ_MS = 30_000

    class Entry(val pkg: String, val apkName: String, val sha256: String, val versionCode: Long)

    class MicroGException(message: String) : Exception(message)

    private fun open(url: String): HttpURLConnection {
        require(url.startsWith("https://")) { "refusing a non-HTTPS download" }
        return (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = CONNECT_MS
            readTimeout = READ_MS
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "Calculator-microG-installer")
        }
    }

    private fun supportedAbis(): Set<String> =
        (if (Build.VERSION.SDK_INT >= 21) Build.SUPPORTED_ABIS.toList() else listOf(Build.CPU_ABI)).toSet()

    /** The repository's list of the newest build of each wanted package that this phone can run. */
    private fun readIndex(wanted: List<String>): Map<String, Entry> {
        val conn = open(INDEX)
        val text = try {
            if (conn.responseCode != 200) throw MicroGException("microg.org answered HTTP ${conn.responseCode}")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
        val packages = JSONObject(text).optJSONObject("packages")
            ?: throw MicroGException("the microG repository list had no packages")
        val abis = supportedAbis()
        val out = HashMap<String, Entry>()
        for (pkg in wanted) {
            val arr = packages.optJSONArray(pkg) ?: continue
            var best: Entry? = null
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val apk = o.optString("apkName")
                if (apk.isEmpty() || apk.contains("-hw")) continue          // Huawei variant: needs HMS, not for us
                if (o.optInt("minSdkVersion", 1) > Build.VERSION.SDK_INT) continue
                val native = o.optJSONArray("nativecode")
                if (native != null && native.length() > 0) {
                    val has = (0 until native.length()).any { native.getString(it) in abis }
                    if (!has) continue
                }
                if (!o.optString("hashType", "sha256").equals("sha256", true)) continue
                val e = Entry(pkg, apk, o.optString("hash").lowercase(), o.optLong("versionCode"))
                if (best == null || e.versionCode > best.versionCode) best = e
            }
            if (best != null) out[pkg] = best
        }
        return out
    }

    private fun sha256(f: File): String {
        val md = MessageDigest.getInstance("SHA-256")
        f.inputStream().use { ins ->
            val buf = ByteArray(64 * 1024)
            while (true) {
                val n = ins.read(buf)
                if (n < 0) break
                md.update(buf, 0, n)
            }
        }
        return md.digest().joinToString("") { "%02x".format(it) }
    }

    private fun cacheDir(ctx: Context) = File(ctx.filesDir, DIR).apply { mkdirs() }

    /** Downloads [e] (or reuses the verified copy from an earlier try). Returns the APK file. */
    private fun download(ctx: Context, e: Entry, progress: (Int) -> Unit): File {
        val dir = cacheDir(ctx)
        val target = File(dir, e.apkName)
        if (target.isFile && e.sha256.isNotEmpty() && sha256(target) == e.sha256) return target
        val part = File(dir, e.apkName + ".part")
        val conn = open("$REPO/${e.apkName}")
        try {
            if (conn.responseCode != 200) throw MicroGException("microg.org answered HTTP ${conn.responseCode} for ${e.apkName}")
            val total = conn.contentLengthLong
            var done = 0L
            conn.inputStream.use { ins ->
                FileOutputStream(part).use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) progress((done * 100 / total).toInt())
                    }
                }
            }
        } catch (t: Throwable) {
            part.delete()
            throw t
        } finally {
            conn.disconnect()
        }
        if (e.sha256.isEmpty() || sha256(part) != e.sha256) {
            part.delete()
            throw MicroGException("the downloaded ${e.apkName} did not match the checksum from microG, so it was discarded")
        }
        target.delete()
        if (!part.renameTo(target)) throw MicroGException("couldn't save ${e.apkName}")
        // Keep only the newest copy of each package.
        dir.listFiles()?.filter { it.name.startsWith(e.pkg + "-") && it.name != e.apkName }?.forEach { it.delete() }
        return target
    }

    /**
     * Downloads the newest microG build of each package in [packages] that this phone supports. Blocking: worker
     * thread. [progress] gets (package, percent 0-100 or -1 while the list is being read). Packages the repository
     * doesn't offer for this phone are left out of the result.
     */
    fun fetch(ctx: Context, packages: List<String>, progress: (String, Int) -> Unit = { _, _ -> }): Map<String, File> {
        val index = try {
            progress(packages.first(), -1)
            readIndex(packages)
        } catch (t: MicroGException) {
            throw t
        } catch (t: Throwable) {
            throw MicroGException("couldn't reach microg.org (${t.javaClass.simpleName}${t.message?.let { ": $it" } ?: ""}). Check your internet connection and try again")
        }
        val out = LinkedHashMap<String, File>()
        for (pkg in packages) {
            val e = index[pkg] ?: continue
            out[pkg] = try {
                download(ctx, e) { progress(pkg, it) }
            } catch (t: MicroGException) {
                throw t
            } catch (t: Throwable) {
                throw MicroGException("downloading ${e.apkName} failed (${t.javaClass.simpleName}${t.message?.let { ": $it" } ?: ""})")
            }
        }
        return out
    }

    /** Deletes the downloaded APKs. */
    fun clearCache(ctx: Context) {
        File(ctx.filesDir, DIR).deleteRecursively()
    }
}
