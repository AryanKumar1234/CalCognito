package com.onion.calcognito

import android.content.Context

/**
 * The hidden-app engine's own switches — the same ones BlackBox (the engine this app runs hidden apps with) offers in
 * its settings screen. They are plain SharedPreferences, read by [EngineBridge]'s ClientConfiguration every time the
 * engine asks, so a change applies the next time a hidden app starts.
 *
 * Every value defaults to off, which is what the app used before these switches existed, so a fresh install behaves
 * exactly as it did.
 */
object EngineOptions {
    private const val PREF = "engine_options"

    private fun p(ctx: Context) = ctx.applicationContext.getSharedPreferences(PREF, Context.MODE_PRIVATE)

    /** Hides root-related apps (Magisk, SuperSU, root managers) from the apps running in the hidden space. */
    fun hideRoot(ctx: Context) = p(ctx).getBoolean("hide_root", false)
    fun setHideRoot(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("hide_root", v).apply()

    /** Keeps the engine's background service running, so hidden apps start faster. */
    fun daemonEnabled(ctx: Context) = p(ctx).getBoolean("daemon", false)
    fun setDaemonEnabled(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("daemon", v).apply()

    /** Gaming mode: gives a hidden app's main thread display-level priority. */
    fun gamingMode(ctx: Context) = p(ctx).getBoolean("gaming_mode", false)
    fun setGamingMode(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("gaming_mode", v).apply()

    /** Sends the hidden apps' network traffic through the phone's VPN. */
    fun useVpnNetwork(ctx: Context) = p(ctx).getBoolean("use_vpn", false)
    fun setUseVpnNetwork(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("use_vpn", v).apply()

    /** Lets screenshots and screen recording capture hidden apps (clears FLAG_SECURE in them). */
    fun disableFlagSecure(ctx: Context) = p(ctx).getBoolean("disable_flag_secure", false)
    fun setDisableFlagSecure(ctx: Context, v: Boolean) = p(ctx).edit().putBoolean("disable_flag_secure", v).apply()

    /** A one-line summary of the switches that are on, for the row in the Apps folder. */
    fun summary(ctx: Context): String {
        val on = ArrayList<String>()
        if (hideRoot(ctx)) on.add("Root hidden")
        if (gamingMode(ctx)) on.add("Gaming mode")
        if (disableFlagSecure(ctx)) on.add("Screenshots allowed")
        if (useVpnNetwork(ctx)) on.add("VPN")
        if (daemonEnabled(ctx)) on.add("Background service")
        return if (on.isEmpty()) "Defaults · everything off" else on.joinToString(" · ")
    }
}
