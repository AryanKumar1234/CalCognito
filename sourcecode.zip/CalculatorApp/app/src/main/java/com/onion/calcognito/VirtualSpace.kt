package com.onion.calcognito

import android.app.Activity
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.os.Build
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream

/**
 * Hidden apps that work like Parallel Space.
 *
 * The app is cloned into a virtual space run by an embedded engine (see [EngineBridge]): it runs inside this app
 * without being installed on the phone, with its own private data, and the clone is never re-installed or archived
 * as an .apks file. The engine keeps its own internal copy of the app's APK, like every app of this kind.
 *
 * This object only remembers each app's name and icon (taken from the real app while it is still installed) so the
 * vault list can draw them; the engine itself is the source of truth for what actually runs.
 */
object VirtualSpace {
    const val USER_ID = 0
    private const val PREF = "virtual_space"
    private const val ICON_DIR = "virtual_space_icons"

    class VApp(val pkg: String, val label: String, val icon: Bitmap?)

    val available: Boolean get() = EngineBridge.available

    /** The engine starts the first time hidden apps are used, not when the app opens. Blocking: worker thread. */
    fun ensureStarted(ctx: Context): Boolean = EngineBridge.start(ctx.applicationContext)

    /** Why hiding apps isn't possible right now: no engine in this build, switched off after a crash, or failed to start. */
    val unavailableReason: String
        get() = when {
            !EngineBridge.compiledIn ->
                "This build has no hidden-app engine yet. Build it with the GitHub workflow or scripts/build_engine.sh " +
                    "(see the README) and install that build"
            EngineBridge.failure != null ->
                "The engine is part of this build but couldn't start.\n\n${EngineBridge.failure}\n\n" +
                    "Send this message to whoever maintains the app."
            else -> "The engine hasn't started yet. Try again."
        }

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE)
    private fun iconFile(ctx: Context, pkg: String) =
        File(File(ctx.filesDir, ICON_DIR).apply { mkdirs() }, "$pkg.png")

    private fun records(ctx: Context): JSONObject = try {
        JSONObject(prefs(ctx).getString("apps", "{}") ?: "{}")
    } catch (_: Throwable) {
        JSONObject()
    }

    fun list(ctx: Context): List<VApp> {
        val r = records(ctx)
        val out = ArrayList<VApp>()
        for (pkg in r.keys()) {
            val icon = try { BitmapFactory.decodeFile(iconFile(ctx, pkg).absolutePath) } catch (_: Throwable) { null }
            out.add(VApp(pkg, r.optString(pkg, pkg), icon))
        }
        return out.sortedBy { it.label.lowercase() }
    }

    fun contains(ctx: Context, pkg: String) = records(ctx).has(pkg)

    private fun toBitmap(d: Drawable, size: Int = 144): Bitmap {
        if (d is BitmapDrawable && d.bitmap != null && d.bitmap.width <= size * 2) return d.bitmap
        val bm = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        val c = Canvas(bm)
        d.setBounds(0, 0, size, size)
        d.draw(c)
        return bm
    }

    // ----- Google Play services -----
    //
    // Apps that sign in with Google, use push notifications, Maps, ads or in-app purchases talk to Google Play
    // services. Inside the space such an app is seen under this app's identity, not its own, so the phone's own
    // Play services often refuses it. The way virtual spaces solve this (Parallel Space, VirtualApp) is to copy
    // Google's own apps from the phone into the space, where they see the cloned apps as their neighbours.
    // Experimental: it depends on the engine being able to copy those apps (many phones install Play services in
    // several parts) and on the Play services version.

    class GmsResult(val ok: Boolean, val message: String)

    private const val GMS = "com.google.android.gms"
    private const val GMS_KEY = "gms"
    private val GMS_PACKAGES = listOf("com.google.android.gsf", GMS, "com.android.vending")

    private fun gmsLabel(pkg: String) = when (pkg) {
        "com.google.android.gsf" -> "Google Services Framework"
        GMS -> "Google Play services"
        else -> "Google Play Store"
    }

    private fun hostHas(ctx: Context, pkg: String): Boolean = try {
        ctx.packageManager.getPackageInfo(pkg, 0)
        true
    } catch (_: Throwable) {
        false
    }

    /** True when the phone has Google Play services (the copy is made from it). */
    fun hostHasGms(ctx: Context): Boolean = hostHas(ctx, GMS)

    /**
     * True when the space gets microG instead of a copy of Google's own apps: the phone has no Google Play services
     * (many Chinese-market, custom-ROM and de-Googled phones), so there is nothing to copy. See [MicroG].
     */
    fun usesMicroG(ctx: Context): Boolean = !hostHasGms(ctx)

    /** Google's own apps (the Google app, Maps, YouTube, Gmail, Photos...), which all need Play services to run. */
    private fun isGoogleOwnApp(pkg: String): Boolean = pkg.startsWith("com.google.") && pkg !in GMS_PACKAGES

    /**
     * Should the user be offered Play services setup before opening [pkg]? True when the app depends on Play services
     * and they are not in the space: never set up, or marked as set up while the engine no longer has them (the
     * space's data was cleared, or an earlier copy failed part-way). Opening such an app is what produces "Google Play
     * services isn't supported on this device". Blocking (may read the app's code): worker thread, engine running.
     */
    fun needsGmsSetup(ctx: Context, pkg: String): Boolean {
        if (!usesGms(ctx, pkg)) return false
        if (!gmsEnabled(ctx)) return true
        return EngineBridge.available && !EngineBridge.isInstalled(GMS, USER_ID)
    }

    /** Closes the clone if it is running, so that its next start sees Play services. Blocking. */
    fun restart(pkg: String) = EngineBridge.stop(pkg, USER_ID)

    /**
     * Does [pkg] use Google Play services?
     *
     * Only apps built with a recent Play services library declare the marker in their manifest. Google's own apps (the
     * Google app, Maps, YouTube) and apps built with older libraries use Play services without it, so the manifest is
     * checked first and otherwise the app's own code is searched for Play services client classes. Without the second
     * check those apps were cloned with no way to set Play services up, and inside the clone they showed "Google Play
     * services isn't supported on this device". The answer is cached per app version, so the search runs once.
     */
    fun usesGms(ctx: Context, pkg: String): Boolean {
        return try {
            // Google's own apps always depend on Play services. Checked by name first because the code search below can
            // miss them (their code is heavily obfuscated) and cannot run at all once the original app is uninstalled.
            if (isGoogleOwnApp(pkg)) return true
            val pi = ctx.packageManager.getPackageInfo(pkg, PackageManager.GET_META_DATA)
            val ai = pi.applicationInfo ?: return false
            if (ai.metaData?.containsKey("com.google.android.gms.version") == true) {
                true
            } else {
                val version = if (android.os.Build.VERSION.SDK_INT >= 28) pi.longVersionCode.toString()
                else @Suppress("DEPRECATION") pi.versionCode.toString()
                cachedUsesGms(ctx, pkg, version) ?: scanForGms(ai).also { saveUsesGms(ctx, pkg, version, it) }
            }
        } catch (_: Throwable) {
            false
        }
    }

    private const val GMS_USES = "gms_using_apps"
    private const val GMS_CLASSES = "com/google/android/gms/"
    private const val GMS_SCAN_BYTES = 96L * 1024 * 1024   // stops on huge apps; the classes are in the first dexes

    private fun cachedUsesGms(ctx: Context, pkg: String, version: String): Boolean? = try {
        val parts = (JSONObject(prefs(ctx).getString(GMS_USES, "{}") ?: "{}").optString(pkg, "")).split('#')
        if (parts.size == 2 && parts[0] == version) parts[1] == "1" else null
    } catch (_: Throwable) {
        null
    }

    private fun saveUsesGms(ctx: Context, pkg: String, version: String, value: Boolean) = try {
        val o = JSONObject(prefs(ctx).getString(GMS_USES, "{}") ?: "{}")
        o.put(pkg, version + (if (value) "#1" else "#0"))
        prefs(ctx).edit().putString(GMS_USES, o.toString()).apply()
    } catch (_: Throwable) {
    }

    /** Searches the app's dex files (base APK and its splits) for Play services client classes. */
    private fun scanForGms(ai: android.content.pm.ApplicationInfo): Boolean {
        val apks = ArrayList<String>()
        ai.sourceDir?.let { apks.add(it) }
        ai.splitSourceDirs?.let { apks.addAll(it) }
        var budget = GMS_SCAN_BYTES
        for (path in apks) {
            if (budget <= 0) break
            try {
                java.util.zip.ZipFile(path).use { zip ->
                    for (entry in zip.entries()) {
                        if (budget <= 0) break
                        if (!entry.name.startsWith("classes") || !entry.name.endsWith(".dex")) continue
                        zip.getInputStream(entry).use { input ->
                            val buf = ByteArray(1 shl 18)
                            var carry = 0
                            while (budget > 0) {
                                val n = input.read(buf, carry, buf.size - carry)
                                if (n <= 0) break
                                budget -= n
                                val len = carry + n
                                // ISO-8859-1 maps bytes 1:1, and String.indexOf is far faster than a byte loop.
                                if (String(buf, 0, len, Charsets.ISO_8859_1).contains(GMS_CLASSES)) return true
                                carry = (GMS_CLASSES.length - 1).coerceAtMost(len)
                                System.arraycopy(buf, len - carry, buf, 0, carry)
                            }
                        }
                    }
                }
            } catch (_: Throwable) {
            }
        }
        return false
    }

    /** The Google apps that have been copied into the space. */
    fun gmsInstalled(ctx: Context): List<String> = try {
        val a = JSONArray(prefs(ctx).getString(GMS_KEY, "[]") ?: "[]")
        (0 until a.length()).map { a.getString(it) }
    } catch (_: Throwable) {
        emptyList()
    }

    fun gmsEnabled(ctx: Context): Boolean = GMS in gmsInstalled(ctx)

    private fun saveGms(ctx: Context, list: List<String>) {
        prefs(ctx).edit().putString(GMS_KEY, JSONArray(list).toString()).apply()
    }

    /**
     * Copies Google Play services (and the Services Framework and Play Store, whichever the phone has) into the
     * space. Blocking: worker thread. [progress] is told the name of the app being copied.
     */
    fun enableGms(ctx: Context, progress: (String) -> Unit = {}): GmsResult {
        if (!ensureStarted(ctx)) return GmsResult(false, unavailableReason)
        if (!hostHasGms(ctx)) return enableMicroG(ctx, progress)
        val done = gmsInstalled(ctx).toMutableList()
        val failed = ArrayList<String>()
        var gmsError: String? = null
        for (pkg in GMS_PACKAGES) {
            // Skip what is really in the space. Something recorded as copied but gone from the engine (its data was
            // cleared) is copied again instead of being trusted.
            val present = pkg in done && EngineBridge.isInstalled(pkg, USER_ID)
            if (!hostHas(ctx, pkg) || present) continue
            progress(gmsLabel(pkg))
            if (EngineBridge.install(pkg, USER_ID)) {
                if (pkg !in done) done.add(pkg)
                saveGms(ctx, done)   // keep progress even if a later one fails
            } else {
                failed.add(gmsLabel(pkg))
                if (pkg == GMS) gmsError = EngineBridge.lastInstallError
                done.remove(pkg)     // not in the space, so don't claim it is
                saveGms(ctx, done)
            }
        }
        if (GMS !in done) {
            val why = gmsError?.let { "\n\nThe engine said: $it" } ?: ""
            return GmsResult(
                false,
                "The engine couldn't copy Google Play services. Many phones install it in several parts, which this " +
                    "engine may not support. Apps that need Google sign-in or notifications will keep failing.$why"
            )
        }
        val extra = if (failed.isEmpty()) "" else "\n\nCouldn't copy: ${failed.joinToString(", ")}."
        return GmsResult(
            true,
            "Google Play services is now inside the hidden space. Close the cloned app if it is open and start it " +
                "again from the Apps folder, then sign in to Google there; it can take a moment the first time. " +
                "Support is experimental, so some apps may still not sign in.$extra"
        )
    }

    /**
     * For phones without Google Play services: downloads microG (GmsCore, GsfProxy and FakeStore, from microG's own
     * F-Droid repository) and installs it into the space. The engine shows cloned apps Google's certificate for these
     * packages (see PackageManagerCompat.fakeSignatures), which is the signature spoofing microG needs, so nothing on
     * the phone itself is changed and no root is needed. Blocking: worker thread.
     */
    private fun enableMicroG(ctx: Context, progress: (String) -> Unit): GmsResult {
        val done = gmsInstalled(ctx).toMutableList()
        val missing = GMS_PACKAGES.filter { !(it in done && EngineBridge.isInstalled(it, USER_ID)) }
        if (missing.isEmpty()) {
            return GmsResult(true, "microG is already inside the hidden space.")
        }
        val files = try {
            MicroG.fetch(ctx, missing) { pkg, pct ->
                progress(if (pct < 0) "Contacting microg.org" else "Downloading ${microGLabel(pkg)} · $pct%")
            }
        } catch (e: MicroG.MicroGException) {
            return GmsResult(false, "Couldn't download microG: ${e.message}.")
        }
        if (GMS in missing && GMS !in files) {
            return GmsResult(
                false,
                "microG's repository has no Play services build for this phone (Android ${Build.VERSION.RELEASE}, " +
                    "${Build.SUPPORTED_ABIS.firstOrNull() ?: "unknown CPU"})."
            )
        }
        val failed = ArrayList<String>()
        var gmsError: String? = null
        // Services Framework first, then Play services, then the Store stand-in (same order as GMS_PACKAGES).
        for (pkg in GMS_PACKAGES) {
            val apk = files[pkg] ?: continue
            progress("Installing ${microGLabel(pkg)}")
            if (EngineBridge.installFile(apk, pkg, USER_ID)) {
                if (pkg !in done) done.add(pkg)
            } else {
                failed.add(microGLabel(pkg))
                if (pkg == GMS) gmsError = EngineBridge.lastInstallError
                done.remove(pkg)
            }
            saveGms(ctx, done)
        }
        if (GMS !in done) {
            val why = gmsError?.let { "\n\nThe engine said: $it" } ?: ""
            return GmsResult(false, "The engine couldn't install microG's Play services.$why")
        }
        val extra = if (failed.isEmpty()) "" else "\n\nCouldn't install: ${failed.joinToString(", ")}."
        return GmsResult(
            true,
            "microG is now inside the hidden space and stands in for Google Play services there. Close the cloned app " +
                "if it is open and start it again from the Apps folder. Signing in to a Google account inside the space " +
                "works for most apps; anything that needs Google's own servers to vouch for the device (Play Integrity, " +
                "some banking and streaming apps) will still refuse. Support is experimental.$extra"
        )
    }

    private fun microGLabel(pkg: String) = when (pkg) {
        "com.google.android.gsf" -> "microG Services Framework Proxy"
        GMS -> "microG Services"
        else -> "microG Companion (FakeStore)"
    }

    /** Removes the copied Google apps again. Blocking. True if everything is gone. */
    fun disableGms(ctx: Context): Boolean {
        if (gmsInstalled(ctx).isNotEmpty() && !ensureStarted(ctx)) return false
        val left = ArrayList<String>()
        for (pkg in gmsInstalled(ctx)) {
            val gone = EngineBridge.uninstall(pkg, USER_ID) || !EngineBridge.isInstalled(pkg, USER_ID)
            if (!gone) left.add(pkg)
        }
        saveGms(ctx, left)
        return left.isEmpty()
    }

    /** Clones [pkg] into the space. Blocking (worker thread). Returns null on success, else a short reason. */
    fun add(ctx: Context, pkg: String): String? {
        if (!ensureStarted(ctx)) return unavailableReason
        val pm = ctx.packageManager
        val label: String
        var icon: Bitmap? = null
        try {
            val ai = pm.getApplicationInfo(pkg, 0)
            label = pm.getApplicationLabel(ai).toString()
            icon = try { toBitmap(pm.getApplicationIcon(ai)) } catch (_: Throwable) { null }
        } catch (_: Throwable) {
            return "That app is no longer installed"
        }
        if (!EngineBridge.install(pkg, USER_ID)) {
            return "The engine couldn't run this app (some apps, for example ones installed as split APKs, may not be supported)"
        }
        val r = records(ctx).put(pkg, label)
        prefs(ctx).edit().putString("apps", r.toString()).apply()
        icon?.let {
            try { FileOutputStream(iconFile(ctx, pkg)).use { o -> it.compress(Bitmap.CompressFormat.PNG, 100, o) } } catch (_: Throwable) {}
        }
        return null
    }

    /** Main thread. */
    fun launch(activity: Activity, pkg: String): Boolean = EngineBridge.launch(activity, pkg, USER_ID)

    /** Removes the clone and all its data. Blocking (worker thread). */
    fun remove(ctx: Context, pkg: String): Boolean {
        // Without a running engine nothing can be erased, and it would wrongly look as if the clone was already gone.
        if (!ensureStarted(ctx)) return false
        val gone = EngineBridge.uninstall(pkg, USER_ID) || !EngineBridge.isInstalled(pkg, USER_ID)
        if (gone) {
            val r = records(ctx)
            r.remove(pkg)
            prefs(ctx).edit().putString("apps", r.toString()).apply()
            iconFile(ctx, pkg).delete()
        }
        return gone
    }

    /** Used when the vault is reset: wipes every clone. Runs in the background. */
    fun clearAll(ctx: Context) {
        val app = ctx.applicationContext
        val pkgs = records(app).keys().asSequence().toList() + gmsInstalled(app)
        prefs(app).edit().clear().apply()
        File(app.filesDir, ICON_DIR).deleteRecursively()
        if (pkgs.isNotEmpty()) Thread {
            if (ensureStarted(app)) pkgs.forEach { try { EngineBridge.uninstall(it, USER_ID) } catch (_: Throwable) {} }
        }.start()
    }
}
