plugins {
    id("com.android.application") version "8.11.1" apply false
    // 2.4.21: libmpv's AAR (app/libs/mpvlib.aar) is compiled with Kotlin metadata 2.4.0, which the old 2.0.21
    // compiler refuses to read ("compiled with an incompatible version of Kotlin").
    id("org.jetbrains.kotlin.android") version "2.4.21" apply false
}
